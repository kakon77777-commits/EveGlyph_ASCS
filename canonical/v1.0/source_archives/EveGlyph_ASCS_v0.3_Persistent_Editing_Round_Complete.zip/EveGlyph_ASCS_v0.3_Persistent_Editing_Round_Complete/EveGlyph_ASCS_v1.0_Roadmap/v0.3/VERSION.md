# EveGlyph ASCS Version Record — v0.3

**Release:** `ascs/0.3`  
**Round:** Persistent Editing, History & Merge Semantics  
**Date:** 2026-08-24

## Layer Version Tuple

```text
ASCS      = ascs/0.3
EGIR      = egir/0.1
EGStore   = egstore/0.1
EGCR      = egcr/0.1
NCM       = ncm/0.1
Glyph     = glyph/0.1
Agent     = agent-contract/0.1
History   = org.evemisslab.history/0.1
Conflict  = org.evemisslab.history-conflict/0.1
Recovery  = org.evemisslab.recovery/0.1
```

## Canonicalization

```text
EGIR canonicalization = egir-cj/0.1
```

No canonicalization or existing hash-preimage semantics changed in this round.

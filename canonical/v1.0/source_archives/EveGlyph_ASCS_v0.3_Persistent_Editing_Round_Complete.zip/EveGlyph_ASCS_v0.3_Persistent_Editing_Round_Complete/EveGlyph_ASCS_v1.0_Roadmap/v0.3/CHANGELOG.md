# CHANGELOG — ASCS v0.3

## Added

- Three-layer history model: Intent / Canonical Commit DAG / Session Navigation.
- Stable branch identity separated from mutable branch name.
- Branch / Workspace Fork / Object Fork semantic distinction.
- Multi-channel merge model: object content, placement, relation, alias/metadata, lifecycle.
- First-class canonical conflict object profile.
- Conflicted merge workspace that can be checkpointed and recovered.
- Explicit conflict-resolution provenance and final merge-parent requirements.
- Canonical revert semantics distinct from session undo/redo.
- Autosave draft semantics distinct from checkpoint commit.
- Recovery capsule profile and stale-head recovery procedure.
- External-effect replay guard.
- Rebase provenance and history-rewrite boundary.
- Physical / derived / intent / canonical history compaction separation.
- Machine-readable history/merge conformance vectors.
- Handoff checklist for local implementation.

## Changed

- ASCS release version advanced from `ascs/0.2` to `ascs/0.3`.
- v1.0 roadmap status advanced to mark v0.3 complete and v0.4 next.

## Unchanged

- `egir/0.1`
- `egstore/0.1`
- `egcr/0.1`
- `ncm/0.1`
- `glyph/0.1`
- `agent-contract/0.1`
- `egir-cj/0.1`

No existing TW-01 content/revision/workspace hash semantics were changed.

# COMPATIBILITY — ASCS v0.3

## Compatibility Statement

v0.3 adds persistent history/merge governance through namespaced profiles. It does not reinterpret existing `egir/0.1`, `egstore/0.1`, or `egcr/0.1` canonical fields.

| Producer | Consumer | Result |
|---|---|---|
| ASCS v0.1/v0.2 EGIR without v0.3 history extension | v0.3 runtime | Backward / Exact canonical semantics |
| ASCS v0.3 with noncritical history extension | preserving v0.2 reader | ForwardPreserve |
| ASCS v0.3 conflict object as unknown namespaced kind | TW-01 preserving reader | ForwardPreserve, no execution |
| ASCS v0.3 unresolved critical conflict | runtime without conflict profile | PreserveOnly / UnsupportedFeature / RejectExecution |
| v0.3 recovery capsule | runtime without recovery profile | Ignore/preserve external recovery artifact; do not reinterpret as commit |
| v0.3 history extension | reader that drops unknown extensions | Incompatible writer behavior; MUST NOT overwrite source |

## Stable Meaning Requirements

- Branch name is mutable; workspace revision is immutable citation.
- Conflict object is canonical state, not a derived UI warning.
- Autosave draft is not a workspace commit.
- Canonical undo is a new revert commit.
- Rebase creates new history and provenance; it does not mutate old revisions.

## Critical Feature Rule

If unresolved conflict affects executable or semantic correctness, producer SHOULD mark the corresponding history/conflict feature critical. A runtime that cannot interpret it MUST NOT execute the affected workspace as if merge were complete.

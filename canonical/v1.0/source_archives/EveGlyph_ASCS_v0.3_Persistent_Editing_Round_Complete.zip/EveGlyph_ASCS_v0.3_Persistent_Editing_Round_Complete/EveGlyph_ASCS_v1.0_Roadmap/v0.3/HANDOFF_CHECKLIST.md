# v0.3 Local Implementation Handoff Checklist

A future local implementation is not v0.3-compatible until it can answer all items below.

## History Core

- [ ] Separate intent/command log from canonical commit DAG.
- [ ] Separate session-local navigation from canonical commit DAG.
- [ ] Persist immutable workspace revisions with parent references.
- [ ] Pin every canonical write to a base workspace revision.
- [ ] Return typed conflict on stale base instead of silent overwrite.

## Branch / Fork

- [ ] Stable branch ID survives branch rename.
- [ ] Branch creation does not create a new workspace identity.
- [ ] Workspace fork creates a new workspace identity with `forkedFrom` provenance.
- [ ] Immutable citations use workspace revision, not mutable branch alias.

## Merge

- [ ] Deterministically choose or reject ambiguous merge base.
- [ ] Merge object content and placement through separate channels.
- [ ] Auto-merge independent content-vs-placement changes.
- [ ] Conflict concurrent distinct placement moves unless a declared profile resolves them.
- [ ] Conflict delete-vs-edit and delete-vs-move.
- [ ] Revalidate relation endpoints/predicate/authority after merge.
- [ ] Preserve left/right parents in final merge commit.

## Conflict

- [ ] Store unresolved conflict as first-class canonical object/state.
- [ ] Persist conflicted workspace across close/crash/reopen.
- [ ] Block only affected execution paths, not the entire workspace by default.
- [ ] Record conflict-resolution actor, policy, outputs and provenance.

## Undo / Recovery

- [ ] Session undo does not delete canonical commits.
- [ ] Canonical undo creates a new revert commit.
- [ ] Autosave draft does not create a workspace commit.
- [ ] Checkpoint validates and durably persists before moving branch head.
- [ ] Recovery capsule stores base revision and pending commands.
- [ ] Recovery on advanced head branches/rebases/merges instead of silent replay.
- [ ] External effects are not automatically replayed unless explicitly idempotent.

## Retention

- [ ] Physical/index compaction cannot rewrite canonical history.
- [ ] Anchored/shared revisions are protected from ordinary UI cleanup.
- [ ] Rebase/squash-like workflows preserve provenance and do not mutate immutable revisions.
- [ ] Known-but-pruned payload is distinguishable from nonexistent revision.

## Validation

- [ ] Run every case in `V0.3_Support/conformance/history_merge_vectors.json`.
- [ ] Produce ExplainCommit / ExplainMerge / ExplainConflict / ExplainRecovery diagnostics.

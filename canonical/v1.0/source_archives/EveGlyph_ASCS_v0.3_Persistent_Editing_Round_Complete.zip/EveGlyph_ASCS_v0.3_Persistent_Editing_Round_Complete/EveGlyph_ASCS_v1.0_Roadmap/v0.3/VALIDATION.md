# VALIDATION — ASCS v0.3 Persistent Editing, History & Merge Semantics

**Date:** 2026-08-24  
**Release:** `ascs/0.3`

## 1. Canonical Source Validation

Validated Markdown sources:

- `V0.3_Persistent_Editing_History_and_Merge_Semantics.md`
- `VERSION.md`
- `CHANGELOG.md`
- `COMPATIBILITY.md`
- `MIGRATIONS.md`
- `HANDOFF_CHECKLIST.md`
- `V0.3_RELEASE_INDEX.md`
- `../V1.0_ROADMAP_v0.2.md`

Checks performed:

- UTF-8 strict decode: PASS
- LF-only line endings: PASS
- forbidden control characters: PASS
- canonical math delimiters only (`$...$`, `$$...$$`): PASS
- display-math delimiter balance: PASS
- inline-math delimiter scan outside fenced code: PASS
- roadmap v0.1 left unchanged; roadmap progress update emitted as v0.2: PASS

Primary normative specification size:

```text
30,182 UTF-8 bytes
1,458 lines
```

## 2. Machine-Readable Artifacts

- `V0.3_Support/schemas/history-profile.schema.json`: JSON parse PASS
- JSON Schema Draft 2020-12 meta-schema check: PASS
- Representative history + conflict + recovery instance: 0 validation errors
- `V0.3_Support/conformance/history_merge_vectors.json`: JSON parse PASS
- Conformance vector count: 12

## 3. v0.2 Compatibility-Governance Questions

1. **Which layer version changed?**  
   `ASCS: ascs/0.2 → ascs/0.3`; new optional profiles `org.evemisslab.history/0.1`, `org.evemisslab.history-conflict/0.1`, `org.evemisslab.recovery/0.1`.

2. **Which old data remains Exact / Backward?**  
   Existing `egir/0.1`, `egstore/0.1`, `egcr/0.1`, `ncm/0.1`, `glyph/0.1` canonical data requires no reinterpretation; v0.3 runtime can consume prior baseline without mandatory migration.

3. **Which compatibility is Backward?**  
   v0.1/v0.2 canonical bundles without v0.3 history extensions are backward-compatible with v0.3 semantics.

4. **Which compatibility is ForwardPreserve?**  
   A preserving older reader can round-trip noncritical namespaced history metadata and unknown conflict kind without executing it.

5. **Which data requires Migration?**  
   None mandatorily. Stable branch IDs / history metadata / recovery profiles are optional enrichment migrations only.

6. **Which cases must Reject / PreserveOnly?**  
   Runtime lacking conflict semantics MUST NOT execute an artifact whose unresolved critical conflict affects executable or semantic correctness.

7. **Canonicalization changed?**  
   No. `egir-cj/0.1` is unchanged.

8. **Hash preimage changed?**  
   No existing TW-01 content/revision/workspace preimage changed.

9. **New critical extension?**  
   History/conflict profile is normally namespaced and preservable; unresolved conflicts SHOULD be marked critical when their interpretation is required for safe execution.

10. **Capability authority expanded?**  
    No existing capability name is reinterpreted or expanded.

11. **Predicate/operator meaning changed?**  
    No.

12. **Stable golden vectors drifted?**  
    No existing vector is redefined. v0.3 adds a new independent history/merge vector set.

## 4. Design-Consistency Checks

- Branch does not create a new workspace identity: PASS
- Workspace Fork explicitly creates new workspace identity + provenance: PASS
- Content and placement merge channels are separated: PASS
- Stale-write default is typed conflict, not LWW: PASS
- Concurrent distinct placement moves default to conflict: PASS
- Delete-vs-edit / delete-vs-move default to conflict: PASS
- Conflict is first-class canonical state: PASS
- Conflicted merge can be checkpointed/recovered: PASS
- Canonical undo creates a new revert commit: PASS
- Autosave draft does not equal canonical checkpoint: PASS
- Recovery on advanced head cannot silently replay: PASS
- External effects are not automatically replayed: PASS
- In-place canonical-history squash is forbidden for shared/anchored history: PASS
- v0.2 → v0.3 mandatory canonical migration: NONE

## 5. Release Verdict

```text
PASS — v0.3 freeze criteria satisfied.
```

Next permitted round:

```text
v0.4 — Spatial Region, Nested Canvas & Local Grammar Freeze
```

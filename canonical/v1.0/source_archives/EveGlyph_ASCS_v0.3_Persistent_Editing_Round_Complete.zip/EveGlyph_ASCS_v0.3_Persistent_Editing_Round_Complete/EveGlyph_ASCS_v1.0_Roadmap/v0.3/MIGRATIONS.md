# MIGRATIONS — ASCS v0.3

## Mandatory Migration

```text
No mandatory canonical data migration required from ASCS v0.2 to v0.3.
```

The following existing contracts remain unchanged:

- `egir/0.1`
- `egstore/0.1`
- `egcr/0.1`
- `ncm/0.1`
- `glyph/0.1`
- `egir-cj/0.1`

## Optional Enrichment Migration

An implementation MAY enrich an existing workspace by adding:

- stable branch IDs;
- `org.evemisslab.history/0.1` metadata;
- history publication/retention metadata;
- recovery-capsule support.

Optional enrichment MUST NOT:

- change existing persistent object IDs;
- recompute existing object/revision/workspace hashes merely because metadata was added outside existing hash-covered fields;
- rewrite existing immutable revisions;
- overwrite the source artifact before validation.

## Migration Provenance

Any enrichment migration SHOULD record:

```text
source_release
target_release
tool/version
input workspace revision
output workspace revision if one is intentionally created
fidelity
actor
time
```

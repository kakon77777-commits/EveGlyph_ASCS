# v0.9 Handoff Checklist

- Read the v0.9 main specification.
- Read Security Boundary / Recovery / Observability matrices.
- Run `python V0.9_Support/tools/validate_v09.py --json`.
- Run regression tests.
- Treat P1/P2 performance targets as environment-pinned classes.
- Do not use telemetry/log data as canonical authority.
- Do not silently auto-retry unknown external effects.
- Do not ship plaintext production secrets or caches.
- Implement migration dry-run and rollback before v1.0 product rollout.

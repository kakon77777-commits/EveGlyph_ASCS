#!/usr/bin/env python3
from pathlib import Path
import argparse, json, re, sys
try:
    import jsonschema
except Exception:
    jsonschema=None

ROOT=Path(__file__).resolve().parents[1]
SCHEMAS=ROOT/'schemas'
EXAMPLES=ROOT/'examples'
CONF=ROOT/'conformance'/'operational_conformance_vectors.json'

SCHEMA_MAP={
 'operational-policy/1.0-candidate.1':'operational-policy.schema.json',
 'resource-budget/1.0-candidate.1':'resource-budget.schema.json',
 'recovery-profile/1.0-candidate.1':'recovery-profile.schema.json',
 'explain-record/1.0-candidate.1':'explain-record.schema.json',
 'benchmark-profile/1.0-candidate.1':'benchmark-profile.schema.json',
 'release-manifest/1.0-candidate.1':'release-manifest.schema.json',
 'migration-plan/1.0-candidate.1':'migration-plan.schema.json',
 'compatibility-matrix/1.0-candidate.1':'compatibility-matrix.schema.json',
}

class VError(Exception): pass

def load(p): return json.loads(Path(p).read_text(encoding='utf-8'))

def validate_semantic(name,obj):
    p=obj.get('profile')
    if p=='operational-policy/1.0-candidate.1':
        if obj['default_deny'] is not True: raise VError(f'{name}: operational policy must default deny')
        if obj['secret_policy']['plaintext_persistent_storage_allowed'] is not False: raise VError(f'{name}: plaintext persistent secret storage forbidden')
        if obj['external_effect_policy']['unknown_outcome_auto_retry'] is not False: raise VError(f'{name}: unknown external effect must not auto retry')
        zone={(z['class'],z['default_trust']) for z in obj['trust_zones']}
        if ('adapter','untrusted') not in zone or ('external','untrusted') not in zone: raise VError(f'{name}: adapter/external zones must include untrusted defaults')
    elif p=='resource-budget/1.0-candidate.1':
        for lim in obj['limits']:
            if lim['kind']=='hard' and lim['breach_policy']!='reject': raise VError(f"{name}: hard limit {lim['metric']} must reject")
        if not obj['environment_required']: raise VError(f'{name}: benchmark environment pin is required')
    elif p=='recovery-profile/1.0-candidate.1':
        for c in obj['cases']:
            if c['fault']=='external-effect-unknown' and c['auto_retry_external_effect']:
                raise VError(f'{name}: unknown external effect cannot auto retry')
    elif p=='explain-record/1.0-candidate.1':
        text=json.dumps(obj,ensure_ascii=False).lower()
        # reject common secret-bearing keys in explain payload; redaction labels are allowed
        forbidden_keys={'api_key','apikey','password','bearer_token','access_token','secret_value'}
        def walk(x):
            if isinstance(x,dict):
                for k,v in x.items():
                    if k.lower() in forbidden_keys: raise VError(f'{name}: secret-bearing field {k} forbidden')
                    walk(v)
            elif isinstance(x,list):
                for v in x: walk(v)
        walk(obj)
        if not obj['redactions']: raise VError(f'{name}: explain record must state redaction handling')
    elif p=='benchmark-profile/1.0-candidate.1':
        if not re.fullmatch(r'[0-9a-f]{64}',obj['dataset']['sha256']): raise VError(f'{name}: dataset hash invalid')
        if not obj['environment']['runtime'] or not obj['environment']['cpu']: raise VError(f'{name}: environment must be pinned/described')
    elif p=='release-manifest/1.0-candidate.1':
        if obj['rollback']['supported'] is not True or not obj['rollback']['procedure_ref']: raise VError(f'{name}: rollback contract required')
        if obj['migration']['from']=='ascs/0.8' and obj['migration']['to']=='ascs/0.9' and obj['migration']['mandatory_canonical_migration']:
            raise VError(f'{name}: v0.8->v0.9 must not claim mandatory canonical migration')
    elif p=='migration-plan/1.0-candidate.1':
        if not obj['dry_run'] or not obj['backup_required'] or not obj['rollback']['checkpoint_required']: raise VError(f'{name}: dry-run backup checkpoint required')
        cc=obj['canonicalization_change']
        if cc['changes'] is False and cc['from']!=cc['to']: raise VError(f'{name}: unchanged canonicalization must retain same id')
        if cc['changes'] is True and cc['from']==cc['to']: raise VError(f'{name}: changed canonicalization requires new id')
    elif p=='compatibility-matrix/1.0-candidate.1':
        if not obj['required_gates']: raise VError(f'{name}: compatibility gates required')
        for row in obj['producer_consumer']:
            if row['status']=='Incompatible' and row['required_action']!='reject': raise VError(f'{name}: incompatible row must reject')

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--json',action='store_true'); a=ap.parse_args()
    errors=[]; counts={'schemas':0,'examples':0,'vectors':0}
    schemas={}
    for p in sorted(SCHEMAS.glob('*.json')):
        try:
            s=load(p); counts['schemas']+=1
            if jsonschema: jsonschema.Draft202012Validator.check_schema(s)
            schemas[p.name]=s
        except Exception as e: errors.append(f'{p.name}: schema error: {e}')
    for p in sorted(EXAMPLES.glob('*.json')):
        try:
            o=load(p); counts['examples']+=1
            sn=SCHEMA_MAP.get(o.get('profile'))
            if not sn: raise VError(f'unknown profile {o.get("profile")}')
            if jsonschema:
                es=list(jsonschema.Draft202012Validator(schemas[sn]).iter_errors(o))
                if es: raise VError('; '.join(e.message for e in es))
            validate_semantic(p.name,o)
        except Exception as e: errors.append(f'{p.name}: {e}')
    try:
        v=load(CONF)['vectors']; ids=[x['id'] for x in v]; counts['vectors']=len(v)
        if len(ids)!=len(set(ids)): errors.append('conformance vector ids not unique')
    except Exception as e: errors.append(f'vectors: {e}')
    result={'status':'PASS' if not errors else 'FAIL','counts':counts,'errors':errors}
    if a.json: print(json.dumps(result,ensure_ascii=False,indent=2))
    else:
        print(result['status'],counts)
        for e in errors: print('ERROR',e)
    return 0 if not errors else 1
if __name__=='__main__': raise SystemExit(main())

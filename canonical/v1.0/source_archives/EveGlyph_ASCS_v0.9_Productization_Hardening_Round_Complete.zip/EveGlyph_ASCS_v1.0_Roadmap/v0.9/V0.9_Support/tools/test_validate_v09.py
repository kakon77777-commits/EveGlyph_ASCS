#!/usr/bin/env python3
from pathlib import Path
import copy, importlib.util, json, unittest

MODPATH=Path(__file__).with_name('validate_v09.py')
spec=importlib.util.spec_from_file_location('v09validator',MODPATH); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
EX=m.EXAMPLES

def load(name): return json.loads((EX/name).read_text(encoding='utf-8'))

class ValidatorRegression(unittest.TestCase):
    def assertRejected(self,obj,name='fixture.json'):
        with self.assertRaises(m.VError): m.validate_semantic(name,obj)
    def test_default_allow_policy_rejected(self):
        o=load('operational_policy_local.json'); o['default_deny']=False; self.assertRejected(o)
    def test_hard_limit_degrade_rejected(self):
        o=load('resource_budget_p1.json'); o['limits'][0]['breach_policy']='degrade'; self.assertRejected(o)
    def test_unknown_external_effect_auto_retry_rejected(self):
        o=load('recovery_profile.json');
        for c in o['cases']:
            if c['fault']=='external-effect-unknown': c['auto_retry_external_effect']=True
        self.assertRejected(o)
    def test_release_without_rollback_rejected(self):
        o=load('release_manifest.json'); o['rollback']['procedure_ref']=''; self.assertRejected(o)
    def test_secret_bearing_field_in_explain_rejected(self):
        o=load('explain_mutation.json'); o['api_key']='plaintext'; self.assertRejected(o)
    def test_canonicalization_change_without_new_id_rejected(self):
        o=load('migration_v08_v09.json'); o['canonicalization_change']['changes']=True; self.assertRejected(o)

if __name__=='__main__': unittest.main(verbosity=2)

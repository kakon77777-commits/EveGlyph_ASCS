# Version

- ASCS release: `ascs/0.9`
- Date: 2026-08-25
- Status: Final Pre-v1.0 Operational Freeze
- Mandatory canonical migration from v0.8: **No**
- Canonicalization: `egir-cj/0.1` unchanged

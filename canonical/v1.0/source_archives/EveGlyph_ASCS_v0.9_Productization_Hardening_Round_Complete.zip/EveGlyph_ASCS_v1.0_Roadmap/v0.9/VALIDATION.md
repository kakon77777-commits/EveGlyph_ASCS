# v0.9 Validation Report

**Release:** EveGlyph ASCS v0.9 — Productization & Operational Hardening Freeze  
**Date:** 2026-08-25

## Fresh reference validation

- validator regression tests: **6 / 6 PASS**
- JSON Schema Draft 2020-12 profiles: **8 / 8 PASS**
- machine-readable examples: **11 / 11 PASS**
- conformance vectors: **46 / 46 unique PASS**
- canonical release source scan before validation report: **35 files PASS**
- main specification: **19,652 UTF-8 bytes / 771 lines**

## Semantic gates exercised

The regression suite verifies that the validator rejects:

1. default-allow operational policy;
2. hard resource limit using degrade instead of reject;
3. automatic retry of an unknown external-effect outcome;
4. release manifest without rollback procedure;
5. secret-bearing field in an Explain record;
6. canonicalization change that reuses the same canonicalization identifier.

The full validator additionally checks profile/schema validity, operational default-deny rules, adapter/external trust zones, secret storage constraints, environment-pinned benchmarks, v0.8→v0.9 migration semantics, and compatibility matrix rejection rules.

## Canonical source gates

The final release gate verifies:

- UTF-8 decode and round-trip;
- LF-only line endings;
- no disallowed control characters;
- canonical Markdown math delimiters only;
- JSON parse;
- Python AST parse;
- internal SHA-256 manifest;
- cumulative package SHA-256 manifest;
- ZIP integrity and extracted-package hash verification.

## Compatibility result

$$
\boxed{
v0.8\rightarrow v0.9
\text{ requires no mandatory canonical migration}
}
$$

`egir-cj/0.1` and existing EGIR / EGStore / EGCR / NCM / Glyph / Agent / Interchange profile meanings are unchanged. v0.9 adds operational metadata and release gates only.

## Evidence boundary

This release freezes productization requirements and conformance fixtures. It does **not** claim that the existing browser prototype already satisfies a production profile, nor that the reference performance numbers are measured product benchmarks. P1/P2 values are handoff targets that must be re-measured on a pinned implementation environment.

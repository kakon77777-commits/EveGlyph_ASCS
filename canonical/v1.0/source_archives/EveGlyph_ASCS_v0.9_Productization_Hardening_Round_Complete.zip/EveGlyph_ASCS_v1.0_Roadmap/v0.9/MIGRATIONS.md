# v0.9 Migrations

No mandatory canonical data migration exists from v0.8. Implementations may add operational policy, resource budget, recovery, release, and benchmark records. Such enrichment must not alter existing content/revision/workspace addresses.

# v0.9 Changelog

Added operational hardening profiles for security, resource budgets, recovery, explainability, benchmarking, release, migration, and compatibility. No existing canonical identity/hash semantics were redefined.

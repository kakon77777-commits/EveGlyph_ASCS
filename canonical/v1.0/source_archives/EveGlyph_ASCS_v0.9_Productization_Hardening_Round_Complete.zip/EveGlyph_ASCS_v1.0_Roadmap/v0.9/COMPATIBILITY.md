# v0.9 Compatibility

`v0.8 -> v0.9` is additive and requires no mandatory canonical migration. Existing EGIR/EGStore/EGCR/NCM/Glyph/Agent/Interchange profiles retain their frozen semantics. Operational metadata may be added alongside existing state.

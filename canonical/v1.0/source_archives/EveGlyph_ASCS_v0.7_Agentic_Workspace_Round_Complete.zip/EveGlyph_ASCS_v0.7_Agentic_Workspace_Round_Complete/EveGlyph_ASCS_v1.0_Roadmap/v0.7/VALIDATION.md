# v0.7 Validation Report

**Release:** EveGlyph ASCS v0.7 — Agentic Workspace Contract  
**Date:** 2026-08-25

## Fresh validation evidence

Final release-tree commands were executed after the v0.7 specification, schemas, examples, validator, governance files and Roadmap v0.6 were written.

### Reference regression tests

```text
Ran 4 tests
OK
```

The negative tests prove the validator rejects:

1. an untrusted workspace document promoted to directive authority;
2. a direct-mode mutation without `base_workspace_revision`;
3. an external effect without explicit capability;
4. an external effect without replay policy.

### Full candidate validator

```text
v0.7 schemas: 9
v0.7 examples: 11
v0.7 vectors: 36
PASS
```

The validator additionally recomputes the Context Pack ID, verifies inline source SHA-256 values, checks trust-class escalation rules, proposal capability requirements, mode/review boundaries, external-effect replay rules, cross-record principal/run/context/proposal provenance, MCP adapter non-authority, and conformance category coverage.

### JSON Schema / source checks

```text
PYTHON_AST: PASS
JSON_PARSE: PASS (21)
TEXT_SCAN: PASS (final release tree; count verified by release gate)
```

Text scan requirements:

- UTF-8 strict decode;
- LF-only source;
- no disallowed control characters;
- Markdown math source uses only `$...$` and `$$...$$`;
- no legacy parenthesis/bracket-style LaTeX math delimiters;
- balanced `$` / `$$` delimiters outside fenced/inline code.

## Compatibility gate

PASS.

v0.7 does not redefine:

- `egir/0.1`;
- `egstore/0.1`;
- `egcr/0.1`;
- `egir-cj/0.1`;
- v0.3 history/merge semantics;
- v0.4 spatial semantics;
- `ncm/0.1` or `ncm/1.0-candidate.1`;
- `glyph/0.1` or `glyph/1.0-candidate.1`.

Therefore:

$$
\boxed{
v0.6\rightarrow v0.7
\text{ requires no mandatory canonical migration}
}
$$

## External reference boundary

The current MCP interoperability reference is specification revision `2026-07-28`. Its stateless core is used only to shape the MCP adapter example. MCP remains an edge transport/tool protocol and is not required for EveGlyph canonical workspace identity or agent principal identity.

## Release hygiene

- Python bytecode caches removed before packaging.
- `SHA256SUMS.txt` covers the final v0.7 round files except itself.
- Package-level SHA manifest is generated after staging.
- ZIP integrity and extracted SHA verification are executed before the release is reported complete.

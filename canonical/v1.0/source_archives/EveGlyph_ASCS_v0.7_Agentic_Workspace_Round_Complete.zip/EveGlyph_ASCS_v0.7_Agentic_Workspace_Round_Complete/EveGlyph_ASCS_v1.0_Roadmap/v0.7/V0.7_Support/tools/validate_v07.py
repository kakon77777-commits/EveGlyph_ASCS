#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator


def _load(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def _canonical_json(obj: Any) -> bytes:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def _content_id(prefix: str, obj: Any) -> str:
    return f"{prefix}:sha256:" + hashlib.sha256(_canonical_json(obj)).hexdigest()


def semantic_validate_context_pack(pack: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    if not pack.get("base_workspace_revision"):
        errors.append("context pack requires base_workspace_revision")

    no_id = dict(pack)
    no_id.pop("context_pack_id", None)
    expected = _content_id("context-pack", no_id)
    if pack.get("context_pack_id") != expected:
        errors.append(f"context_pack_id mismatch: expected {expected}")

    untrusted_roles = {
        "workspace-document",
        "selection",
        "external-resource",
        "adapter-metadata",
    }
    tool_names: set[str] = set()
    for tool in pack.get("tool_manifest", {}).get("tools", []):
        name = tool.get("name")
        if name in tool_names:
            errors.append(f"duplicate tool name in pinned manifest: {name}")
        tool_names.add(name)

    for src in pack.get("sources", []):
        role = src.get("role")
        trust = src.get("trust_class")
        if role in untrusted_roles and trust in {"directive", "trusted-policy"}:
            errors.append(f"untrusted source role {role} cannot self-upgrade to {trust}")
        if role == "workspace-policy" and trust != "trusted-policy":
            errors.append("workspace-policy must be classified trusted-policy by host authority")
        if role == "user-directive" and trust != "directive":
            errors.append("user-directive source must be directive")
        inline = src.get("inline_content")
        if inline is not None:
            digest = hashlib.sha256(inline.encode("utf-8")).hexdigest()
            if digest != src.get("content_sha256"):
                errors.append(f"source {src.get('source_id')} inline content hash mismatch")
        # Data may contain instruction-shaped text, but trust comes from the host record.
        if src.get("authority_origin") in {"workspace-data", "external-data", "generated", "adapter"} and trust == "trusted-policy":
            errors.append(f"source {src.get('source_id')} authority origin cannot produce trusted-policy")

    task = pack.get("task", {})
    if task.get("authority_class") != "run-directive":
        errors.append("task authority_class must remain run-directive")
    return errors


_REQUIRED_BY_EFFECT = {
    "canonical-write": {"workspace.commit"},
    "candidate-write": {"candidate.write"},
    "execution": {"runtime.execute"},
    "external-read": {"external.file.read"},
    "external-write": {"external.file.write"},
    "external-process": {"external.process.spawn"},
    "external-network": {"external.network"},
}


def semantic_validate_proposal(prop: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    mode = prop.get("mode")
    commands = prop.get("commands", [])
    mutating = any(c.get("effect_class") != "pure-read" for c in commands)
    if mutating and not prop.get("base_workspace_revision"):
        errors.append("mutating proposal requires base_workspace_revision")
    if mode == "direct" and not prop.get("base_workspace_revision"):
        errors.append("direct mode cannot bypass base_workspace_revision pinning")
    if mode == "suggest":
        for c in commands:
            if c.get("command_kind") != "advisory" or c.get("effect_class") != "pure-read":
                errors.append("suggest mode cannot create canonical/candidate/external mutations")
    if mode == "patch" and not prop.get("review", {}).get("required"):
        errors.append("patch mode requires review before canonical commit")

    for c in commands:
        effect = c.get("effect_class")
        caps = set(c.get("required_capabilities") or [])
        for req in _REQUIRED_BY_EFFECT.get(effect, set()):
            if req not in caps:
                errors.append(f"{effect} command missing required capability {req}")
        if c.get("command_kind") == "edit-object" and "object.write" not in caps:
            errors.append("edit-object command missing required capability object.write")
        if c.get("command_kind") == "promote-relation" and "relation.promote" not in caps:
            errors.append("promote-relation command missing required capability relation.promote")
        if effect.startswith("external-"):
            if not caps:
                errors.append("external effect requires explicit capability")
            if not c.get("replay_policy"):
                errors.append("external effect requires replay_policy")
        elif c.get("replay_policy") is not None:
            errors.append("non-external command must not declare replay_policy")
        if not c.get("validator_profile"):
            errors.append("every command requires deterministic validator_profile")

    validation = prop.get("validation", {})
    if validation.get("model_self_validation_authoritative") is not False:
        errors.append("model self-validation cannot be authoritative")
    if validation.get("deterministic_required") is not True:
        errors.append("deterministic validation is required")
    return errors


def semantic_validate_external_effect(effect: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    if effect.get("authorization", {}).get("decision") == "allowed" and not effect.get("authorization", {}).get("grant_id"):
        errors.append("allowed external effect must record capability grant_id")
    replay = effect.get("replay_policy")
    key = effect.get("idempotency_key")
    if replay in {"idempotent", "safe-retry"} and not key:
        errors.append(f"{replay} external effect requires idempotency_key")
    if effect.get("status") == "unknown" and replay == "safe-retry":
        errors.append("unknown external effect cannot be auto safe-retry without separate outcome reconciliation")
    if effect.get("status") in {"started", "succeeded", "failed", "unknown"} and effect.get("started_at") is None:
        errors.append("started/terminal external effect must record started_at")
    return errors


def _schema_errors(schema: dict[str, Any], instance: Any) -> list[str]:
    validator = Draft202012Validator(schema)
    return [f"{list(e.path)}: {e.message}" for e in sorted(validator.iter_errors(instance), key=lambda e: list(e.path))]


def validate_all(support: Path) -> dict[str, Any]:
    support = Path(support)
    schema_dir = support / "schemas"
    example_dir = support / "examples"
    conf_dir = support / "conformance"
    errors: list[str] = []
    schema_reports: dict[str, str] = {}

    schemas: dict[str, dict[str, Any]] = {}
    for p in sorted(schema_dir.glob("*.schema.json")):
        schema = _load(p)
        try:
            Draft202012Validator.check_schema(schema)
            schema_reports[p.name] = "PASS"
            schemas[p.name] = schema
        except Exception as exc:
            schema_reports[p.name] = f"FAIL: {exc}"
            errors.append(f"schema {p.name}: {exc}")

    mapping = {
        "agent_principal_example.json": "agent-principal.schema.json",
        "capability_grant_example.json": "capability-grant.schema.json",
        "review_policy_example.json": "agent-review-policy.schema.json",
        "context_pack_example.json": "agent-context-pack.schema.json",
        "agent_run_example.json": "agent-run.schema.json",
        "patch_proposal_example.json": "agent-proposal.schema.json",
        "direct_proposal_example.json": "agent-proposal.schema.json",
        "external_effect_proposal_example.json": "agent-proposal.schema.json",
        "external_effect_record_example.json": "external-effect-record.schema.json",
        "mcp_adapter_profile_example.json": "agent-adapter-profile.schema.json",
        "file_agent_adapter_profile_example.json": "agent-adapter-profile.schema.json",
    }
    examples: dict[str, Any] = {}
    for name, schema_name in mapping.items():
        obj = _load(example_dir / name)
        examples[name] = obj
        for err in _schema_errors(schemas[schema_name], obj):
            errors.append(f"{name}: {err}")

    # Semantic validation beyond JSON Schema.
    for err in semantic_validate_context_pack(examples["context_pack_example.json"]):
        errors.append(f"context_pack_example.json: {err}")
    for name in ["patch_proposal_example.json", "direct_proposal_example.json", "external_effect_proposal_example.json"]:
        for err in semantic_validate_proposal(examples[name]):
            errors.append(f"{name}: {err}")
    for err in semantic_validate_external_effect(examples["external_effect_record_example.json"]):
        errors.append(f"external_effect_record_example.json: {err}")

    # Cross-record identity/provenance relationships.
    principal = examples["agent_principal_example.json"]
    grant = examples["capability_grant_example.json"]
    pack = examples["context_pack_example.json"]
    run = examples["agent_run_example.json"]
    if grant["subject_principal_id"] != principal["principal_id"]:
        errors.append("capability grant subject does not match agent principal")
    if run["principal_id"] != principal["principal_id"]:
        errors.append("run principal does not match agent principal")
    if run["context_pack_id"] != pack["context_pack_id"]:
        errors.append("run context_pack_id does not match context pack")
    if run["base_workspace_revision"] != pack["base_workspace_revision"]:
        errors.append("run/base context revision mismatch")
    if grant["grant_id"] not in pack["policy_snapshot"]["capability_grant_ids"]:
        errors.append("context pack does not pin the example capability grant")
    for name in ["patch_proposal_example.json", "direct_proposal_example.json", "external_effect_proposal_example.json"]:
        p = examples[name]
        if p["run_id"] != run["run_id"] or p["principal_id"] != principal["principal_id"]:
            errors.append(f"{name} run/principal provenance mismatch")
        if p["base_workspace_revision"] != run["base_workspace_revision"]:
            errors.append(f"{name} base revision mismatch with run")

    # Adapter invariants: transport is never canonical identity authority.
    mcp = examples["mcp_adapter_profile_example.json"]
    if mcp["protocol"]["version"] == "2026-07-28" and mcp["protocol"]["state_model"] != "stateless-core":
        errors.append("MCP 2026-07-28 adapter must declare stateless-core")
    for name in ["mcp_adapter_profile_example.json", "file_agent_adapter_profile_example.json"]:
        a = examples[name]
        if a["identity_authority"] or a["session_identity_authority"] or a["canonical_write_path"] != "runtime-transaction":
            errors.append(f"{name} violates adapter authority boundary")

    vectors = _load(conf_dir / "agent_conformance_vectors.json")
    for err in _schema_errors(schemas["agent-conformance-vectors.schema.json"], vectors):
        errors.append(f"agent_conformance_vectors.json: {err}")
    ids = [v["id"] for v in vectors["vectors"]]
    if len(ids) != len(set(ids)):
        errors.append("conformance vector IDs are not unique")
    required_categories = {"identity","run","context","capability","mode","revision","candidate","promotion","validation","external-effect","adapter","security","tools","policy","failure","cancellation","provenance","replaceability"}
    missing = required_categories - {v["category"] for v in vectors["vectors"]}
    if missing:
        errors.append("missing conformance categories: " + ", ".join(sorted(missing)))

    return {
        "ok": not errors,
        "schema_count": len(schemas),
        "example_count": len(mapping),
        "vector_count": len(vectors["vectors"]),
        "schema_reports": schema_reports,
        "errors": errors,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--support", type=Path, default=Path(__file__).resolve().parent.parent)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    report = validate_all(args.support)
    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        print(f"v0.7 schemas: {report['schema_count']}")
        print(f"v0.7 examples: {report['example_count']}")
        print(f"v0.7 vectors: {report['vector_count']}")
        print("PASS" if report["ok"] else "FAIL")
        for err in report["errors"]:
            print(" -", err)
    return 0 if report["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())

import copy
import json
import sys
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
SUPPORT = HERE.parent
sys.path.insert(0, str(HERE))

from validate_v07 import validate_all, semantic_validate_context_pack, semantic_validate_proposal


class ValidateV07Tests(unittest.TestCase):
    def load(self, rel):
        return json.loads((SUPPORT / rel).read_text(encoding="utf-8"))

    def test_valid_release_examples_pass(self):
        report = validate_all(SUPPORT)
        self.assertTrue(report["ok"], report)

    def test_untrusted_source_cannot_be_directive(self):
        pack = self.load("examples/context_pack_example.json")
        bad = copy.deepcopy(pack)
        bad["sources"][3]["trust_class"] = "directive"
        errors = semantic_validate_context_pack(bad)
        self.assertTrue(any("untrusted" in e.lower() for e in errors), errors)

    def test_direct_mode_cannot_bypass_base_revision(self):
        proposal = self.load("examples/direct_proposal_example.json")
        bad = copy.deepcopy(proposal)
        bad["base_workspace_revision"] = None
        errors = semantic_validate_proposal(bad)
        self.assertTrue(any("base_workspace_revision" in e for e in errors), errors)

    def test_external_effect_requires_capability_and_replay_policy(self):
        proposal = self.load("examples/external_effect_proposal_example.json")
        bad = copy.deepcopy(proposal)
        bad["commands"][0]["required_capabilities"] = []
        bad["commands"][0]["replay_policy"] = None
        errors = semantic_validate_proposal(bad)
        joined = "\n".join(errors)
        self.assertIn("external", joined.lower())
        self.assertIn("replay_policy", joined)


if __name__ == "__main__":
    unittest.main()

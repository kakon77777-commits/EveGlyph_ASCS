# v0.7 Local Handoff Checklist

Before declaring a local implementation v0.7-compatible, verify:

- [ ] Logical agent principal is separate from provider/model/runtime.
- [ ] Each execution attempt has a new run ID.
- [ ] Context Pack is separate from rendered prompt.
- [ ] Context Pack pins base workspace revision.
- [ ] Context sources carry host-assigned trust classes.
- [ ] Workspace/external data cannot self-upgrade to directive authority.
- [ ] Source content hashes are checked for staleness.
- [ ] Tool schemas are pinned in the context/tool manifest.
- [ ] Capabilities are explicit and scope-aware.
- [ ] Suggest mode cannot mutate canonical workspace.
- [ ] Patch mode requires review before commit.
- [ ] Direct mode still requires validation, base revision and capability checks.
- [ ] Direct mode does not implicitly authorize external effects.
- [ ] Mutating proposals carry base workspace revision.
- [ ] Stale proposals conflict/rebase/branch/merge instead of overwriting silently.
- [ ] Model self-validation is never sufficient canonical evidence.
- [ ] Candidate relation promotion requires explicit capability.
- [ ] `runtime.execute` is separate from read/write permissions.
- [ ] External effects record intent, authorization, replay policy and observed outcome.
- [ ] Unknown external effects are not blindly retried.
- [ ] Secrets are referenced/redacted, not embedded in portable canonical context.
- [ ] MCP/CLI/HTTP/file-agent adapters have no identity authority.
- [ ] Legacy filesystem changes are treated as external effects until import/commit.
- [ ] Agent commits link principal -> run -> context -> proposal -> validation -> authority -> resulting revision.
- [ ] v0.7 conformance vectors and reference validator pass.

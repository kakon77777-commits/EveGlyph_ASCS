# v0.7 Changelog

## Added

- logical agent principal identity;
- immutable run-attempt provenance;
- hashed logical Context Pack;
- source trust classes and source hash pinning;
- tool manifest pinning;
- scoped capability grants;
- suggest/patch/direct review-policy semantics;
- proposal/candidate/commit lifecycle;
- external-effect intent/replay/outcome records;
- MCP/CLI/HTTP/file-agent adapter non-authority contract;
- current EveGlyph Editor compatibility map;
- 9 JSON Schema Draft 2020-12 schemas;
- 11 canonical examples;
- 36 conformance vectors;
- reference semantic validator and regression tests.

## Unchanged

- EGIR canonical hash domains;
- EGStore physical semantics;
- EGCR transaction model;
- v0.3 history/merge;
- v0.4 spatial contracts;
- v0.5 math profile;
- v0.6 glyph profile.

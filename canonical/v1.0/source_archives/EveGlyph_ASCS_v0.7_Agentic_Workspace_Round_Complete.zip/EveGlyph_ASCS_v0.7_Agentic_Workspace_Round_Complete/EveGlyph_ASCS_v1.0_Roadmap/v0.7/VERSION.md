# VERSION

```text
ASCS roadmap round: v0.7
Contract family: Agentic Workspace Contract
Status: COMPLETE / candidate freeze
Date: 2026-08-25
```

Profiles introduced:

```text
agent-principal/1.0-candidate.1
agent-context-pack/1.0-candidate.1
agent-run/1.0-candidate.1
agent-proposal/1.0-candidate.1
capability-grant/1.0-candidate.1
agent-review-policy/1.0-candidate.1
external-effect/1.0-candidate.1
agent-adapter/1.0-candidate.1
agent-conformance/1.0-candidate.1
```

# v0.7 Compatibility

## Classification

```text
v0.6 -> v0.7: Backward / additive contract
mandatory canonical data migration: NO
```

v0.7 does not alter existing EGIR/EGStore/EGCR hash preimages or the v0.3/v0.4/v0.5/v0.6 object semantics.

Existing workspaces without agent v0.7 records remain valid. New runs MAY begin emitting v0.7 principal/context/run/proposal/capability/effect records.

## Current Editor mapping

- `suggest / patch / direct` remain UI concepts, now compiled to review policy semantics.
- `cautious / standard / trusted` become capability templates, not unbounded authority labels.
- `.eveglyph/context-pack.json` remains a legacy debug projection; a v0.7 logical Context Pack has its own hash identity.
- filesystem/git-diff agents remain supported through `file-agent` compatibility adapters.
- MCP/CLI/HTTP/provider changes do not change persistent workspace or agent principal identity by themselves.

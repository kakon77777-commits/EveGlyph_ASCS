# v0.7 Migrations

## Mandatory canonical migration

None.

## Optional enrichment for future runs

When the local implementation adopts v0.7, new agent runs SHOULD create:

1. logical Agent Principal;
2. explicit Capability Grant;
3. Context Pack pinned to workspace/policy/tool/source hashes;
4. immutable Agent Run summary;
5. Proposal records before canonical mutation;
6. External Effect records when leaving the canonical world;
7. provenance links from commits back to the proposal/run/context/principal.

Do not fabricate these records retroactively for historical runs that did not capture the necessary evidence.

## Legacy file-agent

Treat pre-commit filesystem writes as external effects. Convert their snapshot/diff into an import proposal, then validate/review/commit into EGIR.

# GSC Technical Design v0.1 — Addendum: Gate 8 Symbolic Autotile Runtime / Runtime Cache Baseline

本附錄記錄 Gate 8 已落地的 implementation baseline。

## 核心命題

$$
S \to A_{16},
$$

以及

$$
(S,\theta_R) \to k_{\mathrm{cache}} \to C_R.
$$

其中：

- $S$ 是 canonical AssetSymbol
- $A_{16}$ 是四鄰接 16-state autotile runtime artifact
- $k_{\mathrm{cache}}$ 是 deterministic runtime cache key
- $C_R$ 是 bounded runtime render cache

## 已實作 API

- `buildSymbolicAutotileRuntimeBundle()`
- `validateSymbolicAutotileRuntimeBundle()`
- `autotileRuntimeBundleToJson()`
- `computeRuntimeRenderCacheKey()`
- `createRuntimeRenderCache()`
- `getOrBuildRuntimeBundleCached()`

## Autotile 規格 baseline

四鄰接 bit mapping：

- N = 1
- E = 2
- S = 4
- W = 8

因此 runtime sheet 包含 16 個 deterministic variants，排成 4×4 sheet。

## Cache baseline

目前 cache 使用 stable serialization 與 FNV-1a 32-bit hash，並支援 bounded capacity、hit/miss/eviction 統計與 LRU-like touch order。

## 邊界

本 Gate 不宣稱已完成 RPG Maker 原生 autotile 規格的全部 quadrant / corner rule，也不宣稱已完成 persistent disk cache；這些留待下一層 engine-specific refinement。

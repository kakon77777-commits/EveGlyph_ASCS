# GSC Technical Design v0.1 — Addendum: Gate 4A Ordered Contour Anchors / Turning Points

本附錄不改變 `Technical Design v0.1` 的主版本號，而是記錄其後第一個已落地的 Gate 4 實作基線。

## 新增命題

在 Gate 3 之後，AssetSymbol 已帶有：

$$
(\text{regions},\text{adjacency},\text{topology}).
$$

Gate 4A 再進一步要求：

$$
\text{unordered boundary set}
\longrightarrow
\text{ordered contour anchors}
\longrightarrow
\text{turning points}.
$$

這樣做的目的，不是追求完美幾何，而是建立一個可以被後續 skeleton、corner-aware rerender、part grammar 使用的穩定中介層。

## 目前資料模型

region-level：

```json
{
  "topology": {
    "boundary": [[x,y], ...],
    "boundaryPixelCount": 0,
    "perimeter": 0,
    "holeCount": 0,
    "fillRatio": 0,
    "symmetry": {"vertical": 0, "horizontal": 0},
    "contour": {
      "orderedAnchors": [{"x":0,"y":0,"type":"NW","angle":0,"source":"corner"}],
      "turningPoints": [{"x":0,"y":0,"type":"NW","angle":0,"source":"corner"}],
      "anchorCount": 0,
      "turnCount": 0
    }
  }
}
```

asset-level：

```json
{
  "topology": {
    "totalContourAnchors": 0,
    "totalTurningPoints": 0
  }
}
```

## 已完成狀態

- `extractStrictContourAnchors()` 已實作
- strict asset 預設版本升至 `v0.4`
- validator 已支援 contour metadata
- regression tests 已覆蓋 ring / rectangle / summary totals / API exposure

## 接下來

真正的 Gate 4B / Gate 5 重點將是：

- skeleton / medial hints
- ordered corner classes
- contour simplification
- topology-aware rerender
- sprite / tile part grammar

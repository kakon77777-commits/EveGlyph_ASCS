# GSC Technical Design v0.1 — Addendum: Gate 4C Skeleton Graph / Segment Compression

本附錄記錄 Gate 4C 已落地的 implementation baseline。

## 新增命題

在 Gate 4B 之後，我們已經有 pixel-level skeleton / medial hints：

$$
\text{region mask} \to K.
$$

Gate 4C 再進一步要求：

$$
K \to G_K=(V_K,E_K),
$$

其中：

- $V_K$ 為 skeleton graph nodes
- $E_K$ 為沿 skeleton tracing 的 branchless path segments

## 資料模型

每個 non-transparent region 現在在 `topology.medial.graph` 內保存：

- `nodes`
- `edges`
- `nodeCount`
- `edgeCount`
- `branchlessPathCount`

asset-level topology summary 則新增：

- `totalSkeletonGraphNodes`
- `totalSkeletonGraphEdges`
- `totalSkeletonBranchlessPaths`

## 已完成狀態

- `extractStrictSkeletonGraph()` 已實作
- strict asset 預設版本升至 `v0.6`
- validator 已支援 skeleton graph metadata
- UI / JSON-only log 已顯示 skeleton graph totals
- regression tests 已覆蓋 line segment compression、plus junction graph、summary totals、API exposure

## 意義

這一層把逐 pixel skeleton hints 轉為可交給後續 grammar / rerender 模組的結構圖，因此是 Gate 5 的直接前置層。

# GSC Technical Design v0.1 — Addendum: Gate 6 Enhanced Re-render Baseline

本附錄記錄 Gate 6 已落地的 implementation baseline。

## 核心命題

Gate 6 引入：

$$
R_{\mathrm{enhanced}}(S;\,\text{topology},\text{contour},\text{medial},G_K,P).
$$

其中：

- $S$ 是 canonical AssetSymbol
- $G_K$ 是 Gate 4C 的 skeleton graph
- $P$ 是 Gate 5 的 part grammar baseline

## 與 Gate 1 的關係

- Gate 1 exact renderer 保留不變，作為 bit-faithful reference path
- Gate 6 enhanced renderer 不要求 byte-for-byte 等於 source，而是作為 source-blind 的高解析度重繪基線
- 兩條 renderer 路徑都不允許偷偷依賴原始 source image buffer

## 目前已使用的 metadata

- region boundary
- contour ordered anchors / turning points
- medial max radius
- skeleton graph edge count
- part grammar primitive / orientation / role

## 已完成狀態

- `renderEnhancedStrictSymbolicAsset()` 已實作
- strict local UI 已可切換 exact / enhanced render mode
- regression tests 已覆蓋：
  - API exposure
  - output dimensions
  - difference from exact scaling
  - partial alpha on silhouette
  - ring-hole preservation
  - primitive-sensitive behavior
  - UI control exposure

## 意義

Gate 6 讓 canonical representation 第一次真正進入「非 block upscale」階段，且仍維持 source-blind discipline。這將成為 Gate 7 runtime / texture workflow 的前置基線。

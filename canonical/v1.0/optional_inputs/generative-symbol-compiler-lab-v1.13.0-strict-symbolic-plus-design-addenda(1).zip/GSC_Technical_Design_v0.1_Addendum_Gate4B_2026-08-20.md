# GSC Technical Design v0.1 — Addendum: Gate 4B Skeleton / Medial Hints Baseline

本附錄沿用 Technical Design v0.1，不變更主設計文件版本號；它記錄 Gate 4B 已落地的實作基線。

## 1. Gate 4B representation

對每個非透明 region $R_i$，新增：

$$
M_i=(K_i,E_i,J_i,\rho_i),
$$

其中：

- $K_i$：digital skeleton pixels；
- $E_i$：endpoint hints；
- $J_i$：junction hints；
- $\rho_i$：skeleton point 的離散 medial radius。

因此 AssetSymbol 的幾何表示開始從：

$$
\text{boundary-only topology}
$$

進入：

$$
\text{boundary + internal structural hints}.
$$

## 2. Algorithms

### 2.1 Skeleton

目前採 deterministic Zhang–Suen thinning 作為 baseline。

這個選擇的目的不是宣稱已得到數學上唯一或精確的 medial axis，而是先取得：

- 可重現；
- 可 JSON 序列化；
- 能保留細線；
- 可供 branch / part inference 使用；

的 digital skeleton。

### 2.2 Radius

使用 Manhattan distance transform：

$$
\rho(p)=d_1(p,\Omega\setminus R).
$$

每個 skeleton point 因而同時攜帶位置與局部厚度 hint。

## 3. Branch hints

目前使用 8-neighbor skeleton degree：

$$
\deg(p)\le 1 \Rightarrow \text{endpoint hint},
$$

$$
\deg(p)\ge 3 \Rightarrow \text{junction hint}.
$$

這仍是 pixel-level branch hint；下一階段才會把 junction clusters 與 skeleton chains 壓縮成真正 graph nodes / edges。

## 4. AssetSymbol v0.5

region-level 新增：

```json
{
  "medial": {
    "algorithm": "zhang-suen+manhattan-distance-v0.1",
    "skeletonPixels": [],
    "endpointPixels": [],
    "junctionPixels": [],
    "skeletonPixelCount": 0,
    "endpointCount": 0,
    "junctionCount": 0,
    "maxRadius": 0,
    "meanRadius": 0,
    "thinningIterations": 0,
    "skipped": false
  }
}
```

asset-level 新增：

```json
{
  "topology": {
    "totalSkeletonPixels": 0,
    "totalSkeletonEndpoints": 0,
    "totalSkeletonJunctions": 0,
    "maxMedialRadius": 0
  }
}
```

## 5. Implementation status

已完成：

- `extractStrictMedialHints()`
- Zhang–Suen thinning baseline
- Manhattan radius hints
- endpoint / junction hints
- AssetSymbol v0.5 validator support
- local UI summary
- Gate 2 normalized-route regression repair
- regression tests

尚未完成：

- skeleton graph compression
- junction clustering
- edge / segment ordering
- semantic part grammar
- topology-aware high-resolution rerender

## 6. Recommended next sub-gate

$$
\boxed{\text{Gate 4C — Skeleton Graph / Segment Compression}}
$$

把目前的 pixel-level skeleton 轉成：

$$
G_K=(V_K,E_K),
$$

再讓 part grammar 不必直接依賴逐像素 skeleton。

# GSC Technical Design v0.1 — Addendum: Gate 9 Batch Tileset / Engine-specific Adapter Baseline

本附錄記錄 Gate 9 已落地的 implementation baseline。

## 核心命題

$$
\{S_1,S_2,\ldots,S_n\}
\to
B_{\mathrm{tileset}}
$$

其中 $S_i$ 是 canonical AssetSymbol，$B_{\mathrm{tileset}}$ 是 engine-facing consumer artifact。

## 已實作 API

- `buildBatchTilesetRuntimeBundle()`
- `validateBatchTilesetRuntimeBundle()`
- `batchTilesetRuntimeBundleToJson()`
- `parseBatchTilesetRuntimeBundleJson()`

## Engine profiles

- `rpgmaker-like-a5` / `A5-like`：8 columns，最多 16 rows
- `rpgmaker-like-b-e` / `B-E-like`：16 columns，最多 16 rows

Tiles 採 deterministic row-major mapping。不同 rendered frame 尺寸會被置中到共同 cell。

## Cache integration

Gate 9 可接入 Gate 8 runtime render cache：相同 AssetSymbol + render options 在重複 batch build 時可命中 cache，而不必重新 render。

## 已完成狀態

- 多 AssetSymbol batch composition 已實作
- exact / enhanced render mode 均可使用
- duplicate id validation 已實作
- JSON round-trip 已實作
- local UI batch queue / profile selector / JSON / PNG export 已實作
- regression tests 已覆蓋 A5-like / B-E-like / mixed sizes / duplicate IDs / round-trip / UI / cache reuse

## 重要限制

`A5-like / B-E-like` 目前只是 layout profile baseline，並非 RPG Maker MV/MZ native import packaging 的逐位元相容承諾。

## 下一步

Gate 10 建議進入：

- native import packaging / adapter hardening
- concrete MV/MZ dimension / slot validation
- multi-sheet package export
- engine plugin bridge / import helper

# GSC Technical Design v0.1 — Addendum: Gate 11 Native Project Binding / Import Helper Baseline

Gate 11 introduces the first project-facing binding manifest:

$$
P_{\mathrm{native}} \to B_{\mathrm{project}}.
$$

The binding plan remains preview-only. It records the image-copy target, optional `data/Tilesets.json` slot patch, resource reference, overwrite policy, and explicit-confirmation requirement without touching the actual project.

## Tileset binding baseline

`tilesetNames` mapping used by the baseline:

- A5 → index 4
- B → index 5
- C → index 6
- D → index 7
- E → index 8

## Character binding baseline

`character-single` creates an `img/characters/$Name.png` resource reference and does not patch `Tilesets.json`.

## Safety model

- preview-only
- non-mutating
- cloned Tilesets snapshot for patch preview
- future write operation requires explicit confirmation

## Next gate

Gate 12 — Transactional Project Apply / Rollback Guard.

# Generative Symbol Compiler Lab
## Formal Technical Design v0.1

**Project:** Generative Symbol Compiler Lab  
**Organization:** EVEMISSLAB  
**Document type:** Formal Technical Design  
**Design document version:** v0.1  
**Implementation baseline:** v1.13.0-strict-symbolic  
**Current AssetSymbol schema baseline:** v0.7  
**Date:** 2026-08-20  
**Status:** Active design baseline

---

## 0. Executive Summary

Generative Symbol Compiler Lab is an experimental visual compilation system whose central goal is to replace a direct pixel-dependent rendering path with a symbolic intermediate representation that is sufficient for reconstruction, structural analysis, controlled re-rendering, and eventually runtime visual generation.

The immediate target domain is pixel art and pixel-like assets. This domain is deliberately chosen because it is discrete, palette-bounded, grid-aligned, and structurally interpretable. The project does not begin by assuming a general-purpose vision model. Instead, it establishes a verifiable compiler pipeline in which the source image may be read during compilation, but the renderer must operate without access to the source pixel buffer.

The core architectural proposition is:

$$
I \xrightarrow{C} S,\qquad \mathrm{discard}(I),\qquad S \xrightarrow{R} \hat I.
$$

For exact finite-palette pixel art, the current strict path already verifies:

$$
\hat I = I.
$$

For pixel-like inputs that require normalization, the current design uses:

$$
I \xrightarrow{N} I_N \xrightarrow{C} S,\qquad \mathrm{discard}(I),\qquad S \xrightarrow{R} \hat I,
$$

with the current Gate 2 success condition:

$$
\hat I = I_N.
$$

The project has already completed the first three implementation gates at baseline level:

- Gate 1: Exact Symbolic Carry — completed.
- Gate 2: Pixel Normalizer — completed as a baseline.
- Gate 3: Topology Lift — completed as a baseline.
- Gate 4A: Ordered Contour Anchors — completed as a baseline.
- Gate 4B: Skeleton / Medial Hints — completed as a baseline.
- Gate 4C: Skeleton Graph / Segment Compression — completed as a baseline.

The next design stages will add skeleton and corner descriptors, part grammar, topology-aware high-resolution re-rendering, and a runtime adapter suitable for RPG Maker-style tile, sprite, autotile, UI, and layered visual assets.

This document is the canonical technical design baseline for that direction.

---

# 1. Problem Definition

## 1.1 Traditional pixel asset model

A conventional 2D game asset is normally treated as a raster object:

$$
I \in \mathbb{R}^{W \times H \times C}.
$$

At runtime, the renderer usually treats the asset as something to copy, sample, scale, interpolate, composite, or shader-transform. The internal structure of the asset is mostly external to the image representation itself.

For pixel art, integer nearest-neighbor enlargement preserves hard edges, but it does not create additional geometric or semantic detail. Smooth interpolation can generate higher-resolution pixels, but it often weakens intentional pixel geometry. AI super-resolution can create visually plausible detail, but may alter identity, shape, palette logic, or game-specific constraints.

The design objective here is different.

Instead of treating the source raster as the permanent canonical representation, the compiler attempts to produce a symbolic visual asset:

$$
S = C(I).
$$

The renderer then interprets the symbolic asset:

$$
\hat I = R(S).
$$

If the symbolic representation is sufficient, the image does not need to remain the only authoritative carrier of visual information.

## 1.2 Core research question

The immediate research question is:

> Can a symbolic representation carry enough visual information to reconstruct a pixel-art asset without the renderer accessing the original source pixels?

The longer-term engineering question is:

> Can the same representation become a controllable visual asset model that supports high-resolution reconstruction, structural transformation, animation, tile composition, runtime rendering, and game-engine integration?

## 1.3 Non-goal

This project does not currently claim that palette RUN encoding is a superior compression format.

The first objective is representation sufficiency and controllability, not minimum byte count.

In fact, for some inputs:

$$
|S| > |I|.
$$

That is acceptable during the current research stage. Compression, factorization, grammar sharing, delta encoding, contour encoding, and asset-family deduplication are later optimization problems.

---

# 2. Design Principles

## 2.1 Source-blind rendering

The most important invariant is that the strict renderer must not depend on the original source image.

The compiler may receive:

$$
C(I).
$$

The renderer must receive only:

$$
R(S).
$$

It must not secretly implement:

$$
R(S,I).
$$

This is enforced as an interface and validation rule, not merely as an informal intention.

## 2.2 Explicit transformation

If a pixel-like source must be normalized, quantized, denoised, or structurally transformed, that transformation must be explicit.

The system should expose:

$$
I \xrightarrow{N} I_N
$$

rather than hiding normalization inside the renderer.

This allows the experimenter to distinguish three independent questions:

1. Did normalization alter the input?
2. Did symbolic compilation preserve the normalized target?
3. Did symbolic rendering preserve the compiled representation?

## 2.3 Deterministic baseline before generative enhancement

The project establishes exact deterministic baselines before introducing higher-level generation.

The ordering is intentional:

$$
\text{Exact Carry} \to \text{Normalization} \to \text{Topology} \to \text{Grammar} \to \text{Enhanced Re-render}.
$$

A high-resolution renderer is not accepted as evidence of symbolic sufficiency unless the lower-level representation can already be independently validated.

## 2.4 Legacy isolation

The earlier source-preserving semantic renderer remains valuable as a separate experimental branch, but it must remain distinguishable from strict symbolic reconstruction.

Therefore the project maintains two conceptual paths:

- Legacy source-preserving semantic rendering.
- Strict source-blind symbolic reconstruction.

The legacy path proves controllable source-preserving rendering. The strict path tests symbolic representation sufficiency.

These are related but not equivalent claims.

## 2.5 Interaction gates instead of traditional time estimates

Project progress is defined by verifiable interaction gates, not calendar estimates.

A gate is complete when its invariants and tests pass.

The relevant unit of progress is therefore closer to:

$$
\text{design} \to \text{implementation} \to \text{probe} \to \text{failure analysis} \to \text{verification}.
$$

---

# 3. System Architecture

## 3.1 High-level pipeline

The target architecture is:

$$
\text{Input Asset}
\xrightarrow{N}
\text{Canonical Raster}
\xrightarrow{C}
\text{AssetSymbol}
\xrightarrow{T}
\text{Topology / Grammar}
\xrightarrow{R}
\text{Rendered Output}.
$$

The runtime-oriented extension is:

$$
\text{AssetSymbol}
\xrightarrow{G}
\text{Runtime Visual Asset}
\xrightarrow{R_\sigma}
\text{Output at scale } \sigma.
$$

## 3.2 Components

### A. Input Adapter

Responsibilities:

- decode PNG, WebP, GIF, JPEG where supported by the browser;
- expose width, height, and RGBA buffer;
- avoid embedding source data into canonical symbolic output.

Current status: **completed for local browser workflow**.

### B. Pixel Normalizer

Responsibilities:

- alpha normalization;
- palette reduction;
- isolated noise cleanup;
- future lattice and contour-aware cleanup.

Current status: **baseline completed**.

### C. Strict Symbol Compiler

Responsibilities:

- build palette;
- convert raster rows into RUN tokens;
- identify connected regions;
- construct adjacency graph;
- attach topology metadata;
- return a canonical AssetSymbol object.

Current status: **completed through AssetSymbol v0.7 baseline**.

### D. Validator

Responsibilities:

- validate schema and version;
- validate canvas geometry;
- validate palette entries;
- require complete sequential RUN coverage;
- reject invalid palette references;
- reject hidden source payload fields;
- validate topology and normalization metadata where present.

Current status: **completed for current schema baseline**.

### E. Strict Renderer

Responsibilities:

- accept AssetSymbol only;
- reconstruct RGBA output from palette and RUN geometry;
- perform deterministic integer-scale symbolic rerasterization;
- remain operational after source buffer destruction.

Current status: **completed for exact symbolic reconstruction and integer-scale output**.

### F. Topology Extractor

Responsibilities:

- derive region boundaries;
- measure perimeter;
- detect holes;
- calculate fill ratio;
- estimate vertical and horizontal symmetry;
- preserve topology metadata for higher-level rendering.

Current status: **baseline completed**.

### G. Geometry Semantics Layer

Planned responsibilities:

- turning points and corners;
- skeleton or medial-axis hints;
- line and junction descriptors;
- shape anchors;
- part-level relations.

Current status: **baseline completed for region-level part grammar tokens**.

### H. Part Grammar Layer

Responsibilities now entering baseline scope:

- sprite-part decomposition;
- tile grammar;
- UI grammar;
- reusable motif definitions;
- attachment and layer relationships.

Current status: **baseline completed for region-level part grammar tokens**.

### I. Enhanced Renderer

Planned responsibilities:

- render from symbolic shape/topology instead of simple pixel blocks;
- generate higher-resolution contours and surfaces;
- preserve asset identity and structural invariants;
- support multiple render policies from the same symbolic asset.

Current status: **baseline completed for region-level part grammar tokens**.

### J. RPG Maker Runtime Adapter

Planned responsibilities:

- load symbolic tilesets and sprites;
- interpret autotile and neighbor rules;
- map symbolic assets to runtime layers;
- provide PNG/raster fallback;
- support cacheable re-rendered output at arbitrary target scale.

Current status: **baseline completed for region-level part grammar tokens**.

---

# 4. Current Canonical Data Model

## 4.1 AssetSymbol v0.7

The current canonical representation can be summarized as:

$$
S = (
\text{canvas},
\text{palette},
\text{tokens},
\text{regions},
\text{adjacency},
\text{topology},
\text{normalization?},
\text{stats}
).
$$

A representative structure is:

```json
{
  "schema": "evemisslab.symbolic-image",
  "version": "0.3",
  "mode": "strict-source-blind",
  "encoding": "palette-runs",
  "canvas": {
    "width": 16,
    "height": 16,
    "pixelAspect": 1
  },
  "palette": [],
  "tokens": [],
  "regions": [],
  "adjacency": [],
  "topology": {},
  "normalization": {},
  "stats": {}
}
```

`normalization` is optional because Gate 1 exact assets do not require it.

## 4.2 Canvas

The canvas describes the canonical discrete coordinate system.

Current fields:

- `width`
- `height`
- `pixelAspect`

Future fields may include:

- logical tile size;
- origin convention;
- subpixel logical scale;
- asset pivot;
- anchor points.

## 4.3 Palette

The current palette is an array of RGBA byte tuples.

Each entry is:

```json
[47, 128, 237, 255]
```

The current exact compiler treats distinct RGBA tuples as distinct colors.

## 4.4 RUN tokens

The renderer-critical representation currently uses horizontal RUN tokens.

Example:

```json
{
  "op": "RUN",
  "y": 4,
  "x": 7,
  "length": 5,
  "paletteIndex": 3
}
```

A valid RUN stream must exactly and sequentially cover every row.

If the canvas has width $W$ and height $H$, the validated token stream must represent exactly:

$$
W \cdot H
$$

logical raster cells.

## 4.5 Regions

Regions are 4-neighbor connected components of a single palette index.

Current region metadata includes:

- region ID;
- palette index;
- area;
- bounding box;
- centroid;
- topology metadata.

## 4.6 Adjacency graph

Region adjacency is represented as graph edges between connected regions.

Conceptually:

$$
G_R = (V_R, E_R),
$$

where $V_R$ is the region set and $E_R$ is the region adjacency set.

This graph is expected to become increasingly important for tile grammar, part grammar, and runtime structural manipulation.

## 4.7 Topology metadata

Current region-level topology metadata includes:

- boundary pixel coordinates;
- boundary pixel count;
- perimeter;
- hole count;
- fill ratio;
- vertical symmetry score;
- horizontal symmetry score;
- transparency classification.

Current asset-level topology summary includes:

- region count;
- adjacency count;
- total boundary pixels;
- total perimeter;
- total holes;
- weighted vertical symmetry;
- weighted horizontal symmetry.

The current topology layer is descriptive metadata. It is not yet the primary renderer input.

That distinction is deliberate.

---

# 5. Compiler Modes

## 5.1 Gate 1: Exact mode

Exact mode is designed for already-clean finite-palette pixel art.

Pipeline:

$$
I \xrightarrow{C_{\mathrm{exact}}} S.
$$

Success condition:

$$
R(S)=I.
$$

Current status: **completed**.

Current behavior:

- exact RGBA palette extraction;
- explicit palette limit;
- no silent color quantization;
- complete RUN stream;
- connected regions;
- adjacency;
- topology metadata;
- source-blind rendering.

If the input exceeds the selected exact palette limit, compilation is rejected.

This rejection is intentional because Exact mode must not silently change the source.

## 5.2 Gate 2: Normalized mode

Normalized mode is designed for pixel-like inputs that contain limited anti-aliasing, alpha noise, near-duplicate colors, or isolated noise.

Pipeline:

$$
I \xrightarrow{N} I_N \xrightarrow{C} S.
$$

Current success condition:

$$
R(S)=I_N.
$$

Current status: **baseline completed**.

Current normalizer operators:

### Alpha threshold

Intermediate alpha is mapped to transparent or opaque state according to a threshold.

### Palette reduction

A finite set of palette anchors is selected, and colors are mapped to an anchor using deterministic color distance.

### Despeckle

A conservative local 4-neighbor majority rule can replace isolated pixels.

Future normalizer work may include:

- pixel lattice inference;
- repeated-block inference;
- anti-alias edge recovery;
- JPEG block noise rejection;
- contour-preserving quantization;
- palette-role clustering.

---

# 6. Source-Blind Invariants

The strict path is governed by the following invariants.

## SB-1: Renderer input invariant

The strict renderer receives AssetSymbol and render options only.

## SB-2: No source pixel dependency

The renderer must continue to function after the source buffer is destroyed.

The current regression strategy explicitly performs:

```text
compile -> destroy source.data -> render -> byte-for-byte compare
```

Current status: **implemented and tested**.

## SB-3: Hidden payload rejection

Canonical validation rejects source-like hidden fields such as:

- `sourceData`
- `sourceImage`
- `sourcePixels`
- `pixelBuffer`
- image Data URLs

Current status: **implemented and tested**.

## SB-4: Explicit normalization

If a source transformation occurs before strict compilation, its configuration and statistics must be visible as normalization metadata.

Current status: **implemented for Gate 2 baseline**.

## SB-5: Deterministic reconstruction

For the same canonical AssetSymbol and render scale, strict baseline output should be deterministic.

Current status: **implemented for current renderer**.

---

# 7. Topology Lift

## 7.1 Purpose

RUN tokens prove that symbolic reconstruction is possible, but they remain close to a raster encoding.

The topology layer begins to extract information that can remain meaningful under a change of output resolution.

The intended transition is:

$$
\text{Raster cells}
\to
\text{regions}
\to
\text{boundaries}
\to
\text{topology}
\to
\text{shape grammar}.
$$

## 7.2 Completed Gate 3 baseline

Gate 3 currently computes:

- boundary pixels;
- perimeter;
- holes;
- fill ratio;
- vertical symmetry;
- horizontal symmetry.

Current status: **completed as a baseline**.

## 7.3 Not yet completed

The following items are deliberately not described as completed:

- contour chain compression;
- ordered polygonal contour reconstruction;
- full contour-chain compression;
- exact polygonal corner classification;
- continuous or exact medial axis;
- skeleton graph compression;
- junction clustering / graph;
- semantic part decomposition.

These belong to the next geometry-semantic stage.

---

# 8. Planned Geometry Semantics and Part Grammar

## 8.1 Gate 4 target

Gate 4 should transform topology metadata into a more generative structural representation.

A possible future representation is:

$$
S_G = (V, E, A, P, M),
$$

where:

- $V$ represents structural vertices or anchors;
- $E$ represents contours, skeleton edges, or attachment relations;
- $A$ represents attributes;
- $P$ represents parts;
- $M$ represents motifs or reusable structural patterns.

## 8.2 Corner and turning-point extraction

Current status: **completed as Gate 4A baseline**.

The compiler should identify meaningful changes in contour direction rather than treat every boundary pixel as equally important.

This enables a representation closer to:

$$
\partial R \to \{p_1,p_2,\ldots,p_k\}
$$

with ordered shape anchors.

## 8.3 Skeleton or medial hints

Current status: **completed as Gate 4C baseline**.

For elongated or articulated regions, the compiler derives internal directional structure using deterministic Zhang–Suen thinning plus a Manhattan distance transform. Each skeleton point therefore carries a discrete local radius hint. Endpoint and junction hints are derived from local skeleton degree. Transparent regions are skipped so that background carrier space does not dominate geometry statistics.

The implemented objective is deliberately not a mathematically perfect medial axis. It is a stable deterministic skeleton / medial hint representation sufficient for later rendering and part inference.

## 8.4 Part grammar

Current status: **completed as Gate 5 baseline**.

The asset model now supports a first conservative part-grammar layer over regions. It does not yet claim full semantic anatomy, but it does serialize structural part tokens and summary counts.

The long-term asset model should support richer part relations.

For a character sprite, a grammar could eventually resemble:

$$
\mathrm{Character}
=
\mathrm{Head}
+
\mathrm{Torso}
+
\mathrm{Arms}
+
\mathrm{Legs}
+
\mathrm{Accessory}
+
\mathrm{Shadow}.
$$

For a tile:

$$
\mathrm{Tile}
=
\mathrm{Base}
+
\mathrm{Edge}
+
\mathrm{Corner}
+
\mathrm{Decoration}.
$$

These are still long-term richer targets. The current implementation instead uses a conservative primitive baseline: `carrier / dot / bar / block / ring / junction / blob`, plus orientation / role / attachments metadata.

---

# 9. Enhanced Re-render Design

## 9.1 Current output

The current strict renderer performs integer symbolic rerasterization.

For integer scale $k$:

$$
R_k(S)
$$

re-rasterizes logical RUN geometry at scale $k$.

This preserves exact block geometry but does not create new high-resolution shape detail.

Current status: **completed**.

## 9.2 Target output

The enhanced renderer should generate a higher-resolution image from symbolic structure rather than from interpolated source pixels.

The target form is:

$$
R_{\sigma,\theta}(S),
$$

where:

- $\sigma$ is output scale or target resolution;
- $\theta$ is a renderer policy or style configuration.

The essential requirement is structural consistency.

Let $\mathcal{T}$ be a topology/structure extractor. A target invariant is:

$$
\mathcal{T}(R_{\sigma,\theta}(S)) \simeq \mathcal{T}(S).
$$

The exact equivalence relation will depend on the renderer mode.

## 9.3 Enhanced renderer policies

Planned policies may include:

- pixel-faithful high-density redraw;
- contour-smoothed redraw;
- vector-like flat redraw;
- material-aware redraw;
- sprite-specific redraw;
- tile-specific redraw.

The same AssetSymbol should be able to drive more than one renderer policy.

This is a major reason to separate representation from raster output.

---

# 10. RPG Maker-Oriented Visual Runtime

## 10.1 Design intent

The long-term objective is not merely to upscale exported PNG files.

The stronger target is to replace part of the traditional visual asset logic with a symbolic asset runtime.

A conventional runtime may conceptually use:

$$
\text{PNG asset} + \text{engine rules} \to \text{screen}.
$$

The target model is:

$$
\text{Symbolic asset} + \text{asset grammar} + \text{renderer policy} \to \text{screen}.
$$

## 10.2 Asset classes

The runtime should eventually support at least the following classes.

### SymbolicTile

Represents one logical tile with:

- base region structure;
- edge semantics;
- corner semantics;
- palette/material roles;
- neighbor compatibility.

### SymbolicTileSet

Represents a family of tiles with shared motifs and palette grammar.

### SymbolicAutoTile

Represents rule-driven tile variation based on neighbor masks.

A future form may be:

$$
T = f(M_N, E, C, D),
$$

where $M_N$ is a neighbor mask, $E$ is edge grammar, $C$ is corner grammar, and $D$ is decoration state.

### SymbolicSprite

Represents one pose or frame using regions, parts, anchors, and palette roles.

### SymbolicSpriteSet

Represents a family of poses or animation frames with shared grammar.

### SymbolicUIAsset

Represents windowskins, frames, icons, gauges, and reusable interface motifs.

## 10.3 Runtime compatibility strategy

The first engine integration should not require an immediate total engine rewrite.

A safer architecture is an adapter layer:

$$
\text{AssetSymbol}
\to
\text{Runtime Adapter}
\to
\text{Render Cache / GPU Texture}
\to
\text{Existing Engine}.
$$

This allows gradual replacement of visual logic while retaining compatibility with conventional raster paths.

## 10.4 Raster fallback

The runtime should preserve a fallback path:

$$
S \xrightarrow{R} I_{\mathrm{cache}}.
$$

If a plugin, engine subsystem, or export target only accepts raster images, the symbolic asset can be rendered into a cache texture without changing the canonical source representation.

---

# 11. Validation Strategy

## 11.1 Current automated baseline

As of implementation baseline v1.13.0-strict-symbolic, the project has automated tests for both the legacy compiler and strict symbolic path.

The current strict-specific tests cover:

- API exposure;
- palette and RUN generation;
- source-blind exact reconstruction;
- JSON round-trip;
- integer-scale rendering;
- region metadata;
- palette-limit rejection;
- hidden source payload rejection;
- normalizer API;
- alpha threshold behavior;
- palette reduction;
- isolated noise removal;
- normalized compile rescue;
- topology API;
- asset topology summary;
- hole detection;
- symmetry scoring.

Current combined project verification baseline: **105 automated tests passing at the time v1.13.0-strict-symbolic was packaged**.

## 11.2 Gate-level success metrics

### Gate 1

Primary metric:

$$
Q_{\mathrm{exact}} = \mathbf{1}[R(C(I))=I].
$$

### Gate 2

Primary metric:

$$
Q_{\mathrm{normalized}} = \mathbf{1}[R(C(N(I)))=N(I)].
$$

Secondary metrics:

- original palette size;
- normalized palette size;
- quantized pixel count;
- alpha snap count;
- despeckled pixel count.

### Gate 3

Metrics:

- region count;
- adjacency count;
- boundary pixel count;
- perimeter;
- hole count;
- symmetry score.

### Gate 4 and later

Planned metrics:

- contour fidelity;
- skeleton stability;
- corner retention;
- topology preservation;
- part consistency;
- identity retention;
- cross-scale structural stability;
- asset-family reuse ratio.

## 11.3 Future visual quality metric

Enhanced re-rendering should not be evaluated only with pixel MSE.

A future composite quality function may use:

$$
Q
=
\lambda_p Q_{\mathrm{pixel}}
+
\lambda_e Q_{\mathrm{edge}}
+
\lambda_t Q_{\mathrm{topology}}
+
\lambda_g Q_{\mathrm{geometry}}
+
\lambda_s Q_{\mathrm{semantic}}.
$$

The weights must be renderer- and domain-specific.

---

# 12. Failure Modes

## 12.1 Palette explosion

Problem:

A pixel-like image may contain thousands of nearly identical colors because of anti-aliasing, gradients, JPEG artifacts, or alpha variation.

Current response:

- Exact mode rejects over-limit input.
- Normalized mode provides explicit palette reduction.

## 12.2 Symbolic representation larger than raster input

Problem:

Region and topology metadata can increase serialized size.

Current interpretation:

This is not currently a correctness failure. The present objective is sufficiency and structural extraction.

Future response:

- token compaction;
- contour compression;
- shared grammar;
- delta frames;
- motif deduplication;
- binary serialization.

## 12.3 Over-normalization

Problem:

Palette reduction or despeckle may remove intentional detail.

Current response:

Normalization is visible as its own stage, so the user can inspect $I_N$ before treating it as the canonical compile target.

Future response:

- adaptive thresholds;
- region-protected cleanup;
- contour-aware quantization;
- per-asset normalizer profiles.

## 12.4 False topology semantics

Problem:

A boundary or hole is a geometric fact, but a semantic label such as "eye", "door", or "weapon" is an interpretation.

Design rule:

Geometry-derived metadata and semantic grammar must remain separate layers until semantic inference is sufficiently reliable.

## 12.5 Hidden source dependency regression

Problem:

Future renderer improvements may accidentally reintroduce direct source pixel access.

Required response:

Source-blind regression tests must remain permanent.

---

# 13. Versioning Strategy

## 13.1 Project version

Project implementation versions describe the working local lab package.

Current baseline:

`v1.13.0-strict-symbolic`

## 13.2 AssetSymbol schema version

AssetSymbol has its own schema version.

Current baseline:

`0.3`

This version must change when canonical serialized semantics change incompatibly or materially.

## 13.3 Technical design version

This document uses an independent design version.

Current version:

`Technical Design v0.1`

A later code version does not automatically require a new design document version unless the architecture, invariants, or planned system behavior materially changes.

## 13.4 Compatibility

The current validator accepts historical strict AssetSymbol versions used by the lab where supported.

The runtime should eventually include explicit migration functions:

$$
M_{a\to b}: S_a \to S_b.
$$

---

# 14. Implementation Status Matrix

| Subsystem | Status | Current baseline |
|---|---|---|
| Legacy source-preserving semantic renderer | Completed experimental baseline | v0.6-v1.0 line |
| Strict local lab UI | Completed | v1.1+ |
| AssetSymbol JSON workflow | Completed | v0.1+ |
| Exact finite-palette compiler | Completed | Gate 1 |
| Source-blind strict renderer | Completed | Gate 1 |
| Hidden source payload rejection | Completed | Gate 1 |
| Integer symbolic scaling | Completed | Gate 1 |
| Connected regions | Completed | Gate 1 |
| Region adjacency graph | Completed | Gate 1 |
| Alpha normalization | Completed baseline | Gate 2 |
| Palette reduction | Completed baseline | Gate 2 |
| Despeckle | Completed baseline | Gate 2 |
| Explicit normalization metadata | Completed | Gate 2 |
| Boundary extraction | Completed baseline | Gate 3 |
| Perimeter calculation | Completed baseline | Gate 3 |
| Hole detection | Completed baseline | Gate 3 |
| Symmetry scoring | Completed baseline | Gate 3 |
| Ordered contour anchors / turning points | Completed baseline | Gate 4A |
| Corner extraction | Partial baseline | Gate 4A |
| Skeleton / medial hints | Completed baseline | Gate 4B |
| Skeleton graph / segment compression | Completed baseline | Gate 4C |
| Part grammar baseline | Completed baseline | Gate 5 |
| Part grammar | Completed baseline | Gate 5 |
| Tile grammar | Partial baseline | Gate 8 |
| Enhanced high-resolution renderer | Completed baseline | Gate 6 |
| Topology-aware re-rendering | Completed baseline | Gate 6 |
| RPG Maker runtime adapter | Completed baseline | Gate 7 |
| Symbolic autotile runtime | Completed baseline | Gate 8 |
| Runtime render cache | Completed baseline | Gate 8 |
| Batch tileset composition | Completed baseline | Gate 9 |
| A5-like / B-E-like engine profile adapter | Completed baseline | Gate 9 |
| Native RPG Maker import packaging | Completed baseline | Gate 10 |
| MV/MZ native dimension / slot validation | Completed baseline | Gate 10 |
| Native project binding / import helper | Completed baseline | Gate 11 |
| Transactional project apply / rollback guard | Planned | Gate 12 |

---

# 15. Interaction Gate Plan

## Gate 1 — Exact Symbolic Carry

**Status: Completed.**

Exit criteria already satisfied:

- compiler emits canonical symbolic asset;
- source can be destroyed;
- renderer reconstructs exactly;
- JSON-only render works;
- hidden source payloads are rejected.

## Gate 2 — Pixel Normalizer

**Status: Baseline completed.**

Exit criteria already satisfied for current baseline:

- explicit normalization stage exists;
- alpha normalization works;
- palette reduction works;
- isolated noise cleanup works;
- normalized target is exactly reconstructable from AssetSymbol.

Further normalization quality work remains possible without invalidating Gate 2 baseline.

## Gate 3 — Topology Lift

**Status: Baseline completed.**

Exit criteria already satisfied for current baseline:

- boundary metadata exists;
- perimeter exists;
- holes can be detected;
- symmetry scores exist;
- topology summary survives in AssetSymbol JSON.

## Gate 4 — Geometry Semantics

**Status: Completed through Gate 4C baseline.**

Exit criteria satisfied for current baseline:

- deterministic corner/turning-point extraction;
- stable skeleton or medial hints on benchmark sprites and tiles;
- structural anchor graph;
- first region-level part grammar baseline;
- JSON round-trip of the new grammar layer;
- no source dependency added to renderer path.

## Gate 5 — Part Grammar Baseline

**Status: Baseline completed.**

Exit criteria already satisfied for current baseline:

- region-level part tokens exist;
- asset-level part summary exists;
- JSON round-trip preserves the grammar layer;
- higher-level renderer stages can consume the serialized part tokens;

## Gate 6 — Enhanced Re-render Baseline

**Status: Baseline completed.**

Exit criteria satisfied for current baseline:

- a non-block enhanced renderer exists;
- enhanced output is generated directly from AssetSymbol without source image;
- exact renderer remains available as reference mode;
- ring-hole preservation and primitive-sensitive behavior are covered by regression tests;
- local UI can switch between exact and enhanced source-blind renderers;

## Gate 7 — RPG Maker Visual Runtime

**Status: Baseline completed.**

Exit criteria satisfied for current baseline:

- symbolic tile or sprite asset loads through the runtime adapter;
- renderer can output an engine-consumable texture or image;
- both a tile bundle and a character 3×4 sheet workflow are end-to-end;
- runtime bundle can be generated from `AssetSymbol JSON` only;
- runtime export controls are exposed in the local UI;

## Gate 8 — Symbolic Autotile Runtime / Runtime Cache

**Status: Baseline completed.**

Baseline exit criteria satisfied:

- runtime bundle can be refined into 16-state autotile-aware structural variants;
- repeated runtime outputs can be cached without breaking source-blind invariants;
- deterministic cache keys and bounded eviction are implemented;
- conventional raster/runtime texture output remains available;
- engine-side visual behavior does not require the original source image after compilation.

Remaining refinement: multi-asset batch tileset export and full engine-specific autotile compatibility.

## Gate 9 — Batch Tileset / Engine-specific Adapter

**Status: Baseline completed.**

Baseline exit criteria satisfied:

- multiple AssetSymbols can be composed into a batch tileset artifact;
- engine-specific layout metadata is generated deterministically;
- A5-like 8-column and B–E-like 16-column RPG Maker-like profiles are implemented;
- Gate 8 runtime cache can be reused across batch builds;
- local UI supports queueing and batch JSON / PNG export;

## Gate 10 — Native Import Packaging / Adapter Hardening

**Status: Baseline completed.**

Baseline exit criteria satisfied:

- concrete MV/MZ native dimension / slot validation exists;
- A5 / B–E / `$` single-character import packages can be exported;
- explicit import manifest is emitted next to engine-facing texture output;
- profile-level compatibility checks are separated from the generic Gate 9 layout baseline;
- unsafe filename and oversize native-cell inputs are rejected;

## Gate 11 — Native Project Binding / Import Helper

**Status: Baseline completed.**

Baseline exit criteria satisfied:

- project-facing import helper consumes Gate 10 native manifests;
- no project data is overwritten; binding plans are preview-only;
- generated project patch plan is deterministic and reviewable;
- Tilesets.json patch preview works on cloned snapshots;
- character resources bind without unnecessary Tilesets database patches;

## Gate 12 — Transactional Project Apply / Rollback Guard

**Status: Planned.**

Proposed exit criteria:

- binding plans can be applied only after explicit confirmation;
- image and database writes create backups before mutation;
- partial failure can roll back all mutations;
- dry-run remains available;
- no write escapes the selected project root;

---

# 16. API Baseline

The current strict APIs are conceptually:

```js
normalizePixelLikeImage(image, options)
compileStrictSymbolicAsset(image, options)
compileNormalizedStrictSymbolicAsset(image, options)
extractStrictTopology(...)
validateStrictSymbolicAsset(asset)
renderStrictSymbolicAsset(asset, options)
strictSymbolicAssetToJson(asset)
parseStrictSymbolicAssetJson(text)
renderEnhancedStrictSymbolicAsset(asset, options)
buildRpgMakerRuntimeBundle(asset, options)
buildSymbolicAutotileRuntimeBundle(asset, options)
computeRuntimeRenderCacheKey(asset, options)
createRuntimeRenderCache(options)
getOrBuildRuntimeBundleCached(cache, asset, options)
buildBatchTilesetRuntimeBundle(entries, options)
validateBatchTilesetRuntimeBundle(bundle)
batchTilesetRuntimeBundleToJson(bundle, options)
parseBatchTilesetRuntimeBundleJson(text)
buildRpgMakerNativeImportPackage(entries, options)
validateRpgMakerNativeImportPackage(pkg)
rpgMakerNativeImportPackageToJson(pkg, options)
parseRpgMakerNativeImportPackageJson(text)
```

Current image object shape:

```js
{
  width,
  height,
  data: Uint8ClampedArray
}
```

Current strict renderer options include integer `scale`.

The important architectural property is not the exact JavaScript signature. It is the separation:

$$
\mathrm{Compiler}: I \to S,
$$

$$
\mathrm{Renderer}: S \to \hat I.
$$

---

# 17. Recommended Repository Layout

The current local lab can evolve toward the following structure:

```text
/
├─ index.html
├─ strict-symbolic.html
├─ app.js
├─ strict-symbolic-app.js
├─ src/
│  ├─ core.js
│  ├─ normalizer.js            # future split
│  ├─ strict-compiler.js       # future split
│  ├─ topology.js              # future split
│  ├─ grammar.js               # future
│  ├─ renderer-exact.js        # future split
│  └─ renderer-enhanced.js     # future
├─ runtime/
│  ├─ rpgmaker-adapter.js      # future
│  ├─ tile-runtime.js          # future
│  └─ sprite-runtime.js        # future
├─ tests/
├─ examples/
└─ docs/
   ├─ TECHNICAL_DESIGN_v0.1.md
   ├─ STRICT_SYMBOLIC_GATE_1.md
   ├─ STRICT_SYMBOLIC_GATE_2.md
   └─ STRICT_SYMBOLIC_GATE_3.md
```

This is a recommended modularization target, not a requirement to immediately refactor the current working `core.js`.

The refactor should occur only when Gate 4 growth makes the single core file materially harder to reason about or test.

---

# 18. Long-Term Architectural Direction

The strongest form of the project is not simply an image converter.

The target progression is:

$$
\text{Raster Asset}
\to
\text{Symbolic Asset}
\to
\text{Structural Asset}
\to
\text{Generative Runtime Asset}.
$$

At the first stage, the symbolic asset proves that the source raster is not required for reconstruction.

At the second stage, structure such as regions, boundaries, topology, skeletons, and parts becomes explicit.

At the third stage, multiple visual outputs can be generated from the same canonical asset.

At the runtime stage, a game engine no longer needs to treat a PNG file as the only visual truth. It can treat the symbolic asset as the canonical visual object and rasterize it according to device scale, style policy, animation state, tile neighbors, or runtime conditions.

The corresponding conceptual shift is:

$$
\boxed{
\text{Image as final asset}
\quad\to\quad
\text{Image as one rendering of an asset}
}
$$

That is the architectural direction this lab is designed to test incrementally.

---

# 19. Immediate Next Technical Step

Gate 4A, Gate 4B, Gate 4C, Gate 5, Gate 6, Gate 7, Gate 8, Gate 9, Gate 10, and Gate 11 are now completed as baselines.

The next recommended implementation sub-gate is:

**Gate 12 — Transactional Project Apply / Rollback Guard Baseline.**

Gate 11 now converts Gate 10 native packages into preview-only project binding plans and database patch previews. The next step is an explicitly confirmed transactional apply layer with backup and rollback guarantees:

$$
\{S_1,\ldots,S_n\}
\to
B_{\mathrm{tileset}}
\to
P_{\mathrm{native}}.
$$

That next layer should consume the validated binding plan rather than rescanning raster pixels or rebuilding layout rules.

The intended progression is:

$$
\text{Gate 4A contour}
\to
\text{Gate 4B medial}
\to
\text{Gate 4C skeleton graph}
\to
\text{Gate 5 part grammar}
\to
\text{Gate 6 enhanced render}
\to
\text{Gate 7 runtime bundle}
\to
\text{Gate 8 autotile/cache}
\to
\text{Gate 9 batch tileset}
\to
\text{Gate 10 native packaging}.
$$

This preserves the existing research discipline:

$$
\text{one stronger representation} \to \text{verify} \to \text{then add the next semantic layer}.
$$

---

# 20. Canonical Status Statement

At Technical Design v0.1, the project has already demonstrated the following limited but important result:

> Within the tested finite-palette pixel-art domain, a source-blind renderer can reconstruct an image exactly from a symbolic palette-and-RUN representation after the source pixel buffer has been destroyed. Pixel-like inputs can additionally be normalized into an explicit canonical target that is likewise exactly reconstructable from the symbolic representation. The current implementation also extracts baseline region topology metadata including boundaries, perimeter, holes, fill ratio, and symmetry.

The project has demonstrated baseline native RPG Maker packaging and preview-only project binding in addition to the earlier source-blind renderer/runtime layers. It has not yet demonstrated transactional in-place project mutation, full native autotile compatibility, persistent cache, rollback-safe project writes, or engine plugin injection.

---

**End of Technical Design v0.1**


## Addendum — Gate 4C

Gate 4C introduces a structural graph over the skeleton baseline:

$$
K \to G_K=(V_K,E_K).
$$

At implementation baseline v1.6.0, each non-transparent region now stores `topology.medial.graph` with node and edge lists, plus summary counts. This makes the representation directly usable for the next stage of part grammar and topology-aware re-rendering without having to rescan all skeleton pixels.


## Addendum — Gate 5

Gate 5 introduces a conservative part-grammar layer:

$$
(\text{region},\text{topology},\text{medial},G_K) \to P.
$$

At implementation baseline v1.9.0, each region still carries a `partGrammar` object with primitive, orientation, role, and attachment metadata. The asset-level `partGrammar` summary now feeds both the enhanced rerender baseline and the new runtime bundle adapter, while the canonical asset itself remains unchanged.


## Addendum — Gate 6

Gate 6 introduces the first conservative enhanced rerender baseline:

$$
R_{	ext{enhanced}}(S;	ext{ topology},	ext{ contour},	ext{ medial},G_K,P).
$$

This renderer remains source-blind and does not replace the exact renderer. Instead, it sits beside the exact path as a preview / upscale mode that consumes structural metadata already serialized in the canonical asset.


## Addendum — Gate 7

Gate 7 introduces the first RPG Maker-like runtime adapter baseline:

$$
S 	o B_R.
$$

Here $B_R$ is not a new canonical artifact; it is a consumer-layer bundle derived from `AssetSymbol`. This layer currently emits tile bundles and character 3×4 sheets while preserving the source-blind discipline established by earlier gates.


## Addendum — Gate 8

Gate 8 adds a 16-state four-neighbor autotile runtime artifact and a deterministic bounded runtime cache while keeping `AssetSymbol v0.7` unchanged as the canonical representation.


## Addendum — Gate 9

Gate 9 adds multi-asset batch tileset composition:

$$
\{S_1,S_2,\ldots,S_n\}\to B_{\mathrm{tileset}}.
$$

The batch artifact remains a consumer-layer output. A5-like and B–E-like profiles provide deterministic row-major layout metadata, while Gate 8 cache entries can be reused across repeated batch builds. Native RPG Maker packaging remains a later hardening step.


## Addendum — Gate 10

Gate 10 introduces a validated native packaging layer over Gate 9:

$$
B_{\mathrm{tileset}} \to P_{\mathrm{native}}.
$$

The packaging layer implements MV/MZ-native sheet dimensions for A5 and B–E tilesets, preserves the required blank top-left B slot, and supports `$` single-character 3×4 sheets. It remains a consumer layer over AssetSymbol and does not mutate the canonical representation.


## Addendum — Gate 11

Gate 11 introduces a preview-only project binding layer:

$$
P_{\mathrm{native}} \to B_{\mathrm{project}}.
$$

The layer records project-relative copy operations, Tilesets database slot patches, and character resource references without writing any project files. Tilesets patch previews are computed on cloned JSON snapshots, preserving the non-mutating safety boundary.

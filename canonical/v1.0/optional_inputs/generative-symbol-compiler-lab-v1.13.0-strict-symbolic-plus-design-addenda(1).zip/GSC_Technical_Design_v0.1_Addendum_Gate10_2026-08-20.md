# GSC Technical Design v0.1 — Addendum: Gate 10 Native Import Packaging / Adapter Hardening

## 核心命題

Gate 10 將 Gate 9 的 generic batch sheet 收緊成：

$$
B_{\mathrm{tileset}} \to P_{\mathrm{native}}.
$$

## 已實作 native constraints

- MV/MZ tile size: 48×48
- A5: 384×768, 8×16
- B–E: 768×768, 16×16
- B slot 0 reserved blank
- `$` single-character: 3×4 sheet under `img/characters`

## 已實作 API

- `buildRpgMakerNativeImportPackage()`
- `validateRpgMakerNativeImportPackage()`
- `rpgMakerNativeImportPackageToJson()`
- `parseRpgMakerNativeImportPackageJson()`

## Hardening

- deterministic integer-contain cell fit
- >48×48 tileset source rejection
- unsafe path / filename rejection
- profile-specific capacity validation
- manifest / texture separation

## 非目標

Gate 10 尚不修改 `data/Tilesets.json`、不自動註冊 project resource、也不注入 RPG Maker plugin。這些屬於 Gate 11 project binding / import helper。

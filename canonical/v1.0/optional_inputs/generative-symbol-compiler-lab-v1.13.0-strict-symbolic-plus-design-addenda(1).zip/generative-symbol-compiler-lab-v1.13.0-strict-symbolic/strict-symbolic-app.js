(function () {
  'use strict';

  const core = window.GenerativeSymbolCompilerCore;
  const $ = (id) => document.getElementById(id);
  const fileInput = $('fileInput');
  const paletteLimit = $('paletteLimit');
  const scaleInput = $('scaleInput');
  const compileMode = $('compileMode');
  const renderMode = $('renderMode');
  const runtimeKind = $('runtimeKind');
  const batchProfile = $('batchProfile');
  const batchStatusBox = $('batchStatusBox');
  const nativeEngine = $('nativeEngine');
  const nativeProfile = $('nativeProfile');
  const nativeBaseName = $('nativeBaseName');
  const nativeStatusBox = $('nativeStatusBox');
  const projectTilesetId = $('projectTilesetId');
  const projectOverwritePolicy = $('projectOverwritePolicy');
  const projectTilesetsSnapshot = $('projectTilesetsSnapshot');
  const projectTilesetsPreview = $('projectTilesetsPreview');
  const projectBindingStatusBox = $('projectBindingStatusBox');
  const normalizedPaletteSize = $('normalizedPaletteSize');
  const alphaThreshold = $('alphaThreshold');
  const despeckleCheck = $('despeckleCheck');
  const sourceCanvas = $('sourceCanvas');
  const normalizedCanvas = $('normalizedCanvas');
  const reconCanvas = $('reconCanvas');
  const scaleCanvas = $('scaleCanvas');
  const assetJson = $('assetJson');
  const statusBox = $('statusBox');
  const proofBanner = $('proofBanner');

  let currentSource = null;
  let currentNormalized = null;
  let currentAsset = null;
  let batchTilesetAssets = [];
  let nextBatchAssetIndex = 1;

  function log(message) {
    statusBox.textContent = message;
  }

  function canvasToImageObject(canvas) {
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    return { width: canvas.width, height: canvas.height, data: new Uint8ClampedArray(imageData.data) };
  }

  function putImageObject(canvas, image) {
    canvas.width = image.width;
    canvas.height = image.height;
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.putImageData(new ImageData(new Uint8ClampedArray(image.data), image.width, image.height), 0, 0);
  }

  function clearCanvas(canvas, width = 16, height = 16) {
    canvas.width = width;
    canvas.height = height;
    canvas.getContext('2d').clearRect(0, 0, width, height);
  }

  function exactEqual(a, b) {
    if (!a || !b || a.width !== b.width || a.height !== b.height || a.data.length !== b.data.length) return false;
    for (let i = 0; i < a.data.length; i += 1) if (a.data[i] !== b.data[i]) return false;
    return true;
  }

  function makeDemo() {
    const w = 16;
    const h = 16;
    const colors = {
      t: [0, 0, 0, 0],
      k: [21, 25, 36, 255],
      b: [55, 132, 232, 255],
      d: [31, 72, 145, 255],
      w: [236, 247, 255, 255],
      g: [122, 222, 178, 255]
    };
    const rows = [
      'ttttttkkkktttttt',
      'tttttkkkkkkttttt',
      'ttttkkbbbbkktttt',
      'tttkkbbbbbbkkttt',
      'ttkkbbwwwwbbkktt',
      'ttkkbbwwwwbbkktt',
      'tkkbbbkkkkbbbkkk',
      'tkkbbkbbbbkbbkkk',
      'tkkbbkbbbbkbbkkk',
      'ttkkbbbggbbbkktt',
      'tttkkbbggbbkkttt',
      'ttttkkbbbbkktttt',
      'tttttkbddbkkkktt',
      'tttttkbddbbkkttt',
      'tttttkkddkkttttt',
      'ttttttkkkktttttt'
    ];
    const data = new Uint8ClampedArray(w * h * 4);
    let p = 0;
    for (const row of rows) {
      for (const ch of row) {
        const c = colors[ch];
        data[p++] = c[0]; data[p++] = c[1]; data[p++] = c[2]; data[p++] = c[3];
      }
    }
    return { width: w, height: h, data };
  }

  function setSource(image, label) {
    currentSource = { width: image.width, height: image.height, data: new Uint8ClampedArray(image.data) };
    currentNormalized = null;
    currentAsset = null;
    putImageObject(sourceCanvas, currentSource);
    clearCanvas(normalizedCanvas, image.width, image.height);
    clearCanvas(reconCanvas, image.width, image.height);
    clearCanvas(scaleCanvas, image.width * Number(scaleInput.value), image.height * Number(scaleInput.value));
    $('sourceStatus').textContent = `${label} · ${image.width}×${image.height} · source buffer loaded`;
    $('normalizedStatus').textContent = 'Gate 1 bypasses normalization. Gate 2 will show the canonical normalized target here.';
    $('reconStatus').textContent = 'Waiting for strict compilation.';
    $('sourceMetric').textContent = 'LOADED';
    $('exactMetric').textContent = '—';
    $('paletteMetric').textContent = '—';
    $('runMetric').textContent = '—';
    $('regionMetric').textContent = '—';
    $('jsonMetric').textContent = '—';
    $('purgeBtn').disabled = false;
    proofBanner.classList.remove('pass');
    proofBanner.innerHTML = '<strong>Gate 1–11:</strong> Source loaded. Compile remains source-blind after cut; runtime, autotile, batch, and native MV/MZ import-package exports all consume AssetSymbol rather than the original source image.';
    log('Ready to compile. Gate 1 accepts exact RGBA palettes only. Gate 2 makes normalization explicit. Gate 3–5 attach topology, contour anchors, skeleton graph, medial-radius hints, and part grammar. Gate 6 consumes that metadata in an enhanced source-blind preview renderer. Gate 7 exports runtime bundles for tile or character workflows directly from AssetSymbol. Gate 8 adds 16-state autotile sheet generation and deterministic runtime cache semantics.');
  }

  function updateAssetMetrics(asset, json, exact) {
    $('exactMetric').textContent = exact == null ? 'N/A' : exact ? 'YES' : 'NO';
    $('paletteMetric').textContent = String(asset.palette.length);
    $('runMetric').textContent = String(asset.tokens.length);
    $('regionMetric').textContent = String(asset.regions.length);
    $('jsonMetric').textContent = new TextEncoder().encode(json).length.toLocaleString();
    $('scaleBadge').textContent = `${scaleInput.value}×`;
  }

  function getNormalizerOptions() {
    return {
      alphaThreshold: Number(alphaThreshold.value),
      paletteSize: normalizedPaletteSize.value === '' ? null : Number(normalizedPaletteSize.value),
      despeckle: despeckleCheck.checked
    };
  }

  function renderCurrentAsset() {
    if (!currentAsset) return;
    const mode = renderMode.value;
    const renderer = mode === 'enhanced' ? core.renderEnhancedStrictSymbolicAsset : core.renderStrictSymbolicAsset;
    const recon = renderer(currentAsset, { scale: 1 });
    const scaled = renderer(currentAsset, { scale: Number(scaleInput.value) });
    putImageObject(reconCanvas, recon);
    putImageObject(scaleCanvas, scaled);
    $('reconStatus').textContent = `${recon.width}×${recon.height} reconstructed from AssetSymbol only · render mode ${mode === 'enhanced' ? 'Gate 6 Enhanced' : 'Gate 1 Exact'}.`;
    $('scaleBadge').textContent = `${scaleInput.value}×`;
  }

  function buildCurrentRuntimeBundle() {
    if (!currentAsset) throw new Error('Nothing to export: compile or load an AssetSymbol first.');
    const options = {
      assetKind: runtimeKind.value,
      scale: Number(scaleInput.value),
      renderMode: renderMode.value
    };
    if (runtimeKind.value === 'autotile') return core.buildSymbolicAutotileRuntimeBundle(currentAsset, options);
    return core.buildRpgMakerRuntimeBundle(currentAsset, options);
  }


  function updateBatchTilesetStatus(message) {
    $('batchCount').textContent = String(batchTilesetAssets.length);
    if (message) {
      batchStatusBox.textContent = message;
      return;
    }
    if (!batchTilesetAssets.length) {
      batchStatusBox.textContent = 'Batch queue is empty.';
      return;
    }
    batchStatusBox.textContent = `Queued ${batchTilesetAssets.length} AssetSymbol(s).
Profile: ${batchProfile.value}
Render mode: ${renderMode.value}
Scale: ${scaleInput.value}×`;
  }

  function cloneCurrentAssetForBatch() {
    if (!currentAsset) throw new Error('Nothing to add: compile or load an AssetSymbol first.');
    return core.parseStrictSymbolicAssetJson(core.strictSymbolicAssetToJson(currentAsset));
  }

  function buildCurrentBatchTilesetBundle() {
    if (!batchTilesetAssets.length) throw new Error('Batch tileset queue is empty.');
    return core.buildBatchTilesetRuntimeBundle(batchTilesetAssets, {
      profile: batchProfile.value,
      scale: Number(scaleInput.value),
      renderMode: renderMode.value
    });
  }


  function buildCurrentNativeImportPackage() {
    const profile = nativeProfile.value;
    let entries;
    if (profile === 'character-single') {
      if (!currentAsset) throw new Error('Single-character native export requires a current AssetSymbol.');
      entries = [{ id: 'character', asset: cloneCurrentAssetForBatch() }];
    } else if (batchTilesetAssets.length) {
      entries = batchTilesetAssets;
    } else if (currentAsset) {
      entries = [{ id: 'asset_0000', asset: cloneCurrentAssetForBatch() }];
    } else {
      throw new Error('Native tileset export requires the Gate 9 batch queue or a current AssetSymbol.');
    }
    return core.buildRpgMakerNativeImportPackage(entries, {
      engine: nativeEngine.value,
      profile,
      baseName: nativeBaseName.value,
      scale: Number(scaleInput.value),
      renderMode: renderMode.value
    });
  }

  function updateNativeImportStatus(message) {
    if (message) {
      nativeStatusBox.textContent = message;
      return;
    }
    nativeStatusBox.textContent = `Engine: ${nativeEngine.value}
Profile: ${nativeProfile.value}
Base name: ${nativeBaseName.value}
Render mode: ${renderMode.value}
Tileset source: ${batchTilesetAssets.length ? `${batchTilesetAssets.length} queued asset(s)` : currentAsset ? 'current AssetSymbol fallback' : 'none'}`;
  }

  function buildCurrentProjectBindingPlan() {
    const pkg = buildCurrentNativeImportPackage();
    const options = { overwritePolicy: projectOverwritePolicy.value };
    if (pkg.profile !== 'character-single') options.tilesetId = Number(projectTilesetId.value);
    return core.buildRpgMakerProjectBindingPlan(pkg, options);
  }

  function updateProjectBindingStatus(message) {
    if (message) {
      projectBindingStatusBox.textContent = message;
      return;
    }
    projectBindingStatusBox.textContent = `Gate 11 safe mode: preview-only
Native profile: ${nativeProfile.value}
Tileset database ID: ${nativeProfile.value === 'character-single' ? 'N/A for character' : projectTilesetId.value}
Overwrite policy: ${projectOverwritePolicy.value}
Mutates project: NO`;
  }

  function downloadImageObject(name, image) {
    const canvas = document.createElement('canvas');
    canvas.width = image.width;
    canvas.height = image.height;
    const ctx = canvas.getContext('2d');
    ctx.putImageData(new ImageData(new Uint8ClampedArray(image.data), image.width, image.height), 0, 0);
    canvas.toBlob((blob) => {
      if (!blob) return;
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = name;
      a.click();
      setTimeout(() => URL.revokeObjectURL(a.href), 1000);
    }, 'image/png');
  }

  function compileSource() {
    if (!currentSource) {
      log('No in-memory source buffer. Load an image/demo, or render an AssetSymbol JSON directly.');
      return;
    }
    try {
      const sourceSnapshot = { width: currentSource.width, height: currentSource.height, data: new Uint8ClampedArray(currentSource.data) };
      const route = compileMode.value;
      let asset;
      let activeTarget = sourceSnapshot;
      let normalization = null;

      if (route === 'normalized') {
        const options = { ...getNormalizerOptions(), maxPalette: Number(paletteLimit.value) };
        normalization = core.normalizePixelLikeImage(sourceSnapshot, options);
        currentNormalized = normalization.image;
        activeTarget = normalization.image;
        putImageObject(normalizedCanvas, currentNormalized);
        $('normalizedStatus').textContent = `Gate 2 target · palette ${normalization.stats.originalPaletteSize} → ${normalization.stats.normalizedPaletteSize} · alpha snap ${normalization.stats.alphaSnappedTransparent + normalization.stats.alphaSnappedOpaque} · despeckle ${normalization.stats.despeckledPixels}`;
        asset = core.compileNormalizedStrictSymbolicAsset(currentSource, options);
      } else {
        currentNormalized = null;
        clearCanvas(normalizedCanvas, sourceSnapshot.width, sourceSnapshot.height);
        $('normalizedStatus').textContent = 'Gate 1 exact route selected. No normalization applied.';
        asset = core.compileStrictSymbolicAsset(currentSource, { maxPalette: Number(paletteLimit.value) });
      }

      const reconBeforeCut = core.renderStrictSymbolicAsset(asset);
      const exact = exactEqual(activeTarget, reconBeforeCut);
      const json = core.strictSymbolicAssetToJson(asset);
      const topology = asset.topology || null;

      currentAsset = asset;
      assetJson.value = json;
      currentSource.data.fill(0x7b);
      currentSource = null;
      $('sourceMetric').textContent = 'CUT';
      $('sourceStatus').textContent = 'Display preview retained, but the JS source image object has been destroyed/released.';
      updateAssetMetrics(asset, json, exact);
      renderCurrentAsset();
      proofBanner.classList.toggle('pass', exact);
      proofBanner.innerHTML = exact
        ? `<strong>PASS:</strong> ${route === 'normalized' ? 'Normalized target' : 'Exact source'} reconstructed before source destruction; source buffer is now cut. Gate 5 part grammar metadata is embedded in S; Gate 6 preview rerender is available; Gate 7 runtime export is available; Gate 8 autotile/runtime-cache baseline is now available.`
        : '<strong>FAIL:</strong> Strict symbolic reconstruction differed from the active compile target. Do not proceed to higher semantic layers.';
      log(`Compiled strict AssetSymbol v${asset.version}.
Route: ${route === 'normalized' ? 'Gate 2 · Normalized' : 'Gate 1 · Exact'}
Palette: ${asset.palette.length}
RUN tokens: ${asset.tokens.length}
Connected regions: ${asset.regions.length}
Adjacency edges: ${asset.adjacency.length}
Contour anchors / turns: ${topology ? `${topology.totalContourAnchors} / ${topology.totalTurningPoints}` : 'N/A'}
Skeleton pixels / endpoints / junctions: ${topology ? `${topology.totalSkeletonPixels} / ${topology.totalSkeletonEndpoints} / ${topology.totalSkeletonJunctions}` : 'N/A'}
Skeleton graph nodes / edges / paths: ${topology ? `${topology.totalSkeletonGraphNodes} / ${topology.totalSkeletonGraphEdges} / ${topology.totalSkeletonBranchlessPaths}` : 'N/A'}
Part grammar: ${asset.partGrammar ? `${asset.partGrammar.partCount} parts · primary ${asset.partGrammar.primaryPartIds.join(', ') || 'N/A'}` : 'N/A'}
Max medial radius: ${topology ? topology.maxMedialRadius : 'N/A'}
Exact reconstruction vs active target: ${exact ? 'PASS' : 'FAIL'}${normalization ? `
Normalizer stats: palette ${normalization.stats.originalPaletteSize} → ${normalization.stats.normalizedPaletteSize}, alphaSnap ${normalization.stats.alphaSnappedTransparent + normalization.stats.alphaSnappedOpaque}, despeckle ${normalization.stats.despeckledPixels}, quantizedPixels ${normalization.stats.quantizedPixels}` : ''}
Source object after compile: CUT`);
    } catch (error) {
      proofBanner.classList.remove('pass');
      log(`Compile rejected: ${error.message}\n\nTip: Gate 1 is intentionally exact. If the input contains antialiasing, gradients, JPEG noise, or many alpha levels, switch to Gate 2 so normalization stays explicit.`);
    }
  }

  function renderJsonOnly() {
    try {
      const asset = core.parseStrictSymbolicAssetJson(assetJson.value);
      currentAsset = asset;
      currentSource = null;
      currentNormalized = null;
      clearCanvas(sourceCanvas);
      clearCanvas(normalizedCanvas);
      $('normalizedStatus').textContent = asset.normalization ? 'Normalized target is not available without the original input; JSON-only rendering still works because the canonical artifact is S.' : 'No normalized target attached.';
      renderCurrentAsset();
      const json = core.strictSymbolicAssetToJson(asset);
      updateAssetMetrics(asset, json, null);
      $('sourceMetric').textContent = 'NONE';
      $('sourceStatus').textContent = 'No source image required for this render.';
      proofBanner.classList.add('pass');
      proofBanner.innerHTML = '<strong>JSON-ONLY PASS:</strong> Renderer accepted only AssetSymbol S. No source image object is loaded.';
      log(`Rendered AssetSymbol JSON only.
Canvas: ${asset.canvas.width}×${asset.canvas.height}
Palette: ${asset.palette.length}
RUN tokens: ${asset.tokens.length}
Topology holes: ${asset.topology ? asset.topology.totalHoles : 'N/A'}
Contour anchors / turns: ${asset.topology ? `${asset.topology.totalContourAnchors} / ${asset.topology.totalTurningPoints}` : 'N/A'}
Skeleton pixels / endpoints / junctions: ${asset.topology ? `${asset.topology.totalSkeletonPixels} / ${asset.topology.totalSkeletonEndpoints} / ${asset.topology.totalSkeletonJunctions}` : 'N/A'}
Skeleton graph nodes / edges / paths: ${asset.topology ? `${asset.topology.totalSkeletonGraphNodes} / ${asset.topology.totalSkeletonGraphEdges} / ${asset.topology.totalSkeletonBranchlessPaths}` : 'N/A'}
Part grammar: ${asset.partGrammar ? `${asset.partGrammar.partCount} parts · primary ${asset.partGrammar.primaryPartIds.join(', ') || 'N/A'}` : 'N/A'}
Render mode preview: ${renderMode.value === 'enhanced' ? 'Gate 6 · Enhanced Re-render' : 'Gate 1 · Exact Renderer'}
Runtime export kind: ${runtimeKind.value === 'autotile' ? 'Gate 8 · Autotile 4×4 Sheet' : runtimeKind.value === 'character' ? 'Gate 7 · Character 3×4 Sheet' : 'Gate 7 · Tile Bundle'}
Max medial radius: ${asset.topology ? asset.topology.maxMedialRadius : 'N/A'}
Topology symmetry (V/H): ${asset.topology ? `${asset.topology.symmetry.vertical} / ${asset.topology.symmetry.horizontal}` : 'N/A'}
Source dependency: NONE`);
    } catch (error) {
      log(`Asset JSON rejected: ${error.message}`);
    }
  }

  function loadFile(file) {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      const c = document.createElement('canvas');
      c.width = img.naturalWidth;
      c.height = img.naturalHeight;
      const ctx = c.getContext('2d', { willReadFrequently: true });
      ctx.imageSmoothingEnabled = false;
      ctx.drawImage(img, 0, 0);
      const image = canvasToImageObject(c);
      setSource(image, file.name);
      URL.revokeObjectURL(url);
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      log('Could not decode this image file.');
    };
    img.src = url;
  }

  function downloadText(name, text, type) {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([text], { type }));
    a.download = name;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  }

  $('demoBtn').addEventListener('click', () => setSource(makeDemo(), 'Built-in 16×16 pixel demo'));
  $('compileBtn').addEventListener('click', compileSource);
  $('renderJsonBtn').addEventListener('click', renderJsonOnly);
  $('purgeBtn').addEventListener('click', () => {
    clearCanvas(sourceCanvas);
    currentSource = null;
    $('sourceMetric').textContent = 'PURGED';
    $('sourceStatus').textContent = 'Source preview canvas purged. Symbol renderer remains operational.';
    $('purgeBtn').disabled = true;
  });
  scaleInput.addEventListener('change', renderCurrentAsset);
  renderMode.addEventListener('change', renderCurrentAsset);
  runtimeKind.addEventListener('change', () => { if (currentAsset) log(`Runtime export kind set to ${runtimeKind.value}.`); });
  fileInput.addEventListener('change', () => {
    const file = fileInput.files && fileInput.files[0];
    if (file) loadFile(file);
  });
  $('downloadJsonBtn').addEventListener('click', () => {
    if (!currentAsset) return log('Nothing to download: compile or load an AssetSymbol first.');
    downloadText(`strict-symbolic-asset-v${currentAsset.version}.json`, core.strictSymbolicAssetToJson(currentAsset), 'application/json');
  });
  $('downloadPngBtn').addEventListener('click', () => {
    if (!currentAsset) return log('Nothing to download: compile or load an AssetSymbol first.');
    reconCanvas.toBlob((blob) => {
      if (!blob) return;
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = 'strict-symbolic-reconstruction.png';
      a.click();
      setTimeout(() => URL.revokeObjectURL(a.href), 1000);
    }, 'image/png');
  });
  $('downloadRuntimeJsonBtn').addEventListener('click', () => {
    try {
      const bundle = buildCurrentRuntimeBundle();
      const kind = bundle.schema === 'evemisslab.symbolic-autotile-runtime-bundle' ? 'autotile' : bundle.assetKind;
      const json = kind === 'autotile' ? core.autotileRuntimeBundleToJson(bundle) : core.runtimeBundleToJson(bundle);
      const count = kind === 'autotile' ? bundle.variants.length : bundle.frames.length;
      downloadText(`strict-symbolic-runtime-${kind}-${bundle.renderMode}-${bundle.scale}x.json`, json, 'application/json');
      log(`Runtime bundle JSON exported.
Kind: ${kind}
Render mode: ${bundle.renderMode}
Frame / variant count: ${count}
Texture: ${bundle.texture.width}×${bundle.texture.height}`);
    } catch (error) {
      log(error.message);
    }
  });
  $('downloadRuntimePngBtn').addEventListener('click', () => {
    try {
      const bundle = buildCurrentRuntimeBundle();
      const canvas = document.createElement('canvas');
      canvas.width = bundle.texture.width;
      canvas.height = bundle.texture.height;
      const ctx = canvas.getContext('2d');
      ctx.putImageData(new ImageData(new Uint8ClampedArray(bundle.texture.data), bundle.texture.width, bundle.texture.height), 0, 0);
      canvas.toBlob((blob) => {
        if (!blob) return;
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        const kind = bundle.schema === 'evemisslab.symbolic-autotile-runtime-bundle' ? 'autotile' : bundle.assetKind;
        a.download = `strict-symbolic-runtime-${kind}-${bundle.renderMode}-${bundle.scale}x.png`;
        a.click();
        setTimeout(() => URL.revokeObjectURL(a.href), 1000);
      }, 'image/png');
    } catch (error) {
      log(error.message);
    }
  });


  $('addBatchAssetBtn').addEventListener('click', () => {
    try {
      const asset = cloneCurrentAssetForBatch();
      const id = `asset_${String(nextBatchAssetIndex++).padStart(4, '0')}`;
      batchTilesetAssets.push({ id, asset });
      updateBatchTilesetStatus(`Added ${id}.
Queue size: ${batchTilesetAssets.length}`);
      updateNativeImportStatus();
    } catch (error) {
      updateBatchTilesetStatus(error.message);
    }
  });
  $('clearBatchAssetsBtn').addEventListener('click', () => {
    batchTilesetAssets = [];
    nextBatchAssetIndex = 1;
    updateBatchTilesetStatus('Batch queue cleared.');
    updateNativeImportStatus();
  });
  batchProfile.addEventListener('change', () => updateBatchTilesetStatus());
  $('downloadBatchTilesetJsonBtn').addEventListener('click', () => {
    try {
      const bundle = buildCurrentBatchTilesetBundle();
      downloadText(`strict-symbolic-batch-${bundle.profile}-${bundle.renderMode}-${bundle.scale}x.json`, core.batchTilesetRuntimeBundleToJson(bundle), 'application/json');
      updateBatchTilesetStatus(`Batch JSON exported.
Tiles: ${bundle.tileCount}
Profile: ${bundle.adapter.profile}
Sheet: ${bundle.texture.width}×${bundle.texture.height}`);
    } catch (error) {
      updateBatchTilesetStatus(error.message);
    }
  });
  $('downloadBatchTilesetPngBtn').addEventListener('click', () => {
    try {
      const bundle = buildCurrentBatchTilesetBundle();
      downloadImageObject(`strict-symbolic-batch-${bundle.profile}-${bundle.renderMode}-${bundle.scale}x.png`, bundle.texture);
      updateBatchTilesetStatus(`Batch PNG exported.
Tiles: ${bundle.tileCount}
Profile: ${bundle.adapter.profile}
Sheet: ${bundle.texture.width}×${bundle.texture.height}`);
    } catch (error) {
      updateBatchTilesetStatus(error.message);
    }
  });


  nativeEngine.addEventListener('change', () => updateNativeImportStatus());
  nativeProfile.addEventListener('change', () => updateNativeImportStatus());
  nativeBaseName.addEventListener('input', () => updateNativeImportStatus());
  $('downloadNativeManifestBtn').addEventListener('click', () => {
    try {
      const pkg = buildCurrentNativeImportPackage();
      downloadText(`${pkg.target.fileName.replace(/\.png$/i, '')}.native-import.json`, core.rpgMakerNativeImportPackageToJson(pkg), 'application/json');
      updateNativeImportStatus(`Native manifest exported.
Target: ${pkg.target.relativePath}
Texture: ${pkg.texture.width}×${pkg.texture.height}
Mappings: ${pkg.mappings.length}`);
    } catch (error) {
      updateNativeImportStatus(error.message);
    }
  });
  $('downloadNativePngBtn').addEventListener('click', () => {
    try {
      const pkg = buildCurrentNativeImportPackage();
      downloadImageObject(pkg.target.fileName, pkg.texture);
      updateNativeImportStatus(`Native PNG exported.
Target: ${pkg.target.relativePath}
Texture: ${pkg.texture.width}×${pkg.texture.height}`);
    } catch (error) {
      updateNativeImportStatus(error.message);
    }
  });

  projectTilesetId.addEventListener('input', () => updateProjectBindingStatus());
  projectOverwritePolicy.addEventListener('change', () => updateProjectBindingStatus());
  nativeProfile.addEventListener('change', () => updateProjectBindingStatus());
  $('downloadProjectBindingPlanBtn').addEventListener('click', () => {
    try {
      const plan = buildCurrentProjectBindingPlan();
      const suffix = plan.resourceRef.kind === 'tileset' ? `${plan.resourceRef.slotName}-tileset-${plan.resourceRef.tilesetId}` : 'character';
      downloadText(`gsc-project-binding-${suffix}.json`, core.projectBindingPlanToJson(plan), 'application/json');
      updateProjectBindingStatus(`Binding plan exported.
Safe mode: ${plan.safeMode}
Target: ${plan.operations[0].relativePath}
Database patches: ${plan.databasePatches.length}
Mutates project: ${plan.mutatesProject ? 'YES' : 'NO'}`);
    } catch (error) {
      updateProjectBindingStatus(error.message);
    }
  });
  $('previewTilesetsPatchBtn').addEventListener('click', () => {
    try {
      const plan = buildCurrentProjectBindingPlan();
      if (!plan.databasePatches.length) {
        projectTilesetsPreview.value = '';
        updateProjectBindingStatus('Character binding requires no Tilesets.json patch. The resource reference is carried in the binding plan only.');
        return;
      }
      const snapshot = JSON.parse(projectTilesetsSnapshot.value);
      const preview = core.applyRpgMakerTilesetsPatchPreview(snapshot, plan);
      projectTilesetsPreview.value = JSON.stringify(preview, null, 2);
      updateProjectBindingStatus(`Tilesets.json patch preview generated.
Tileset ID: ${plan.databasePatches[0].tilesetId}
Slot: ${plan.databasePatches[0].slotName} / index ${plan.databasePatches[0].slotIndex}
Value: ${plan.databasePatches[0].value}
Original snapshot was not modified.`);
    } catch (error) {
      updateProjectBindingStatus(error.message);
    }
  });

  setSource(makeDemo(), 'Built-in 16×16 pixel demo');
  updateBatchTilesetStatus();
  updateNativeImportStatus();
  updateProjectBindingStatus();
})();

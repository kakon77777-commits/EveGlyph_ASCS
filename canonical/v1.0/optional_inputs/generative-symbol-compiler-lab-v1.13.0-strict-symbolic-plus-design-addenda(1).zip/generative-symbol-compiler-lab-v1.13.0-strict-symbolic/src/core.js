(function (global) {
  'use strict';

  function clamp(value, min, max) { return Math.max(min, Math.min(max, value)); }
  function deepClone(value) { return JSON.parse(JSON.stringify(value)); }
  function lerp(a, b, t) { return a + (b - a) * t; }
  function getIndex(x, y, w) { return (y * w + x) * 4; }

  function hexToRgb(hex) {
    const clean = String(hex).replace('#', '');
    if (clean.length === 3) return clean.split('').map((c) => parseInt(c + c, 16));
    return [clean.slice(0, 2), clean.slice(2, 4), clean.slice(4, 6)].map((v) => parseInt(v, 16));
  }
  function rgbToHex(r, g, b) { return '#' + [r, g, b].map((n) => Math.round(n).toString(16).padStart(2, '0')).join(''); }
  function blendHex(a, b, t) {
    const x = hexToRgb(a); const y = hexToRgb(b); const q = clamp(t, 0, 1);
    return rgbToHex(
      x[0] * (1 - q) + y[0] * q,
      x[1] * (1 - q) + y[1] * q,
      x[2] * (1 - q) + y[2] * q
    );
  }
  function applyAlpha(hex, alpha) {
    const [r, g, b] = hexToRgb(hex);
    return `rgba(${r}, ${g}, ${b}, ${alpha})`;
  }

  function rgbToHsl(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b);
    let h = 0; let s = 0; const l = (max + min) / 2;
    if (max !== min) {
      const d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      switch (max) {
        case r: h = (g - b) / d + (g < b ? 6 : 0); break;
        case g: h = (b - r) / d + 2; break;
        default: h = (r - g) / d + 4; break;
      }
      h /= 6;
    }
    return [h, s, l];
  }

  function hslToRgb(h, s, l) {
    function hue2rgb(p, q, t) {
      if (t < 0) t += 1;
      if (t > 1) t -= 1;
      if (t < 1 / 6) return p + (q - p) * 6 * t;
      if (t < 1 / 2) return q;
      if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
      return p;
    }
    let r; let g; let b;
    if (s === 0) r = g = b = l;
    else {
      const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
      const p = 2 * l - q;
      r = hue2rgb(p, q, h + 1 / 3);
      g = hue2rgb(p, q, h);
      b = hue2rgb(p, q, h - 1 / 3);
    }
    return [Math.round(r * 255), Math.round(g * 255), Math.round(b * 255)];
  }

  function computeLuma(r, g, b) { return 0.2126 * r + 0.7152 * g + 0.0722 * b; }

  function resizeDimensions(w, h, maxSize) {
    const scale = Math.min(1, maxSize / Math.max(w, h));
    return { width: Math.max(1, Math.round(w * scale)), height: Math.max(1, Math.round(h * scale)) };
  }

  function createCompilerConfig() {
    return {
      subjectMode: 'auto',
      targetStyle: 'painterly',
      moodBias: 0,
      detailBias: 0,
      energyBias: 0,
      warmthBias: 0,
      compositionBias: 0,
      maxSize: 640
    };
  }

  function validateCompilerConfig(config) {
    if (!config || typeof config !== 'object') throw new Error('Config must be an object');
    const required = ['subjectMode', 'targetStyle', 'moodBias', 'detailBias', 'energyBias', 'warmthBias', 'compositionBias', 'maxSize'];
    for (const key of required) if (!(key in config)) throw new Error(`Missing config: ${key}`);
    return true;
  }

  function configToJson(config) { return JSON.stringify(config, null, 2); }
  function parseConfigJson(text) {
    const parsed = JSON.parse(text);
    validateCompilerConfig(parsed);
    return parsed;
  }

  function createDemoImage(width, height) {
    const w = width || 560;
    const h = height || 720;
    const data = new Uint8ClampedArray(w * h * 4);
    for (let y = 0; y < h; y += 1) {
      for (let x = 0; x < w; x += 1) {
        const i = getIndex(x, y, w);
        const gx = x / Math.max(1, w - 1);
        const gy = y / Math.max(1, h - 1);
        let r = 238 - gy * 42;
        let g = 245 - gx * 22;
        let b = 255 - gx * 44;

        const dxHair = x - w * 0.54; const dyHair = y - h * 0.28;
        if ((dxHair * dxHair) / (w * w * 0.035) + (dyHair * dyHair) / (h * h * 0.05) < 1) {
          r = 82; g = 73; b = 96;
        }
        const dxFace = x - w * 0.55; const dyFace = y - h * 0.33;
        if ((dxFace * dxFace) / (w * w * 0.02) + (dyFace * dyFace) / (h * h * 0.03) < 1) {
          r = 243; g = 210; b = 194;
        }
        if (x > w * 0.36 && x < w * 0.74 && y > h * 0.48 && y < h * 0.88) {
          r = 120; g = 160; b = 225;
        }
        const orbA = (x - w * 0.18) ** 2 + (y - h * 0.18) ** 2;
        if (orbA < (w * 0.06) ** 2) { r = 255; g = 217; b = 145; }
        const orbB = (x - w * 0.82) ** 2 + (y - h * 0.78) ** 2;
        if (orbB < (w * 0.08) ** 2) { r = 136; g = 197; b = 255; }
        data[i] = clamp(Math.round(r), 0, 255);
        data[i + 1] = clamp(Math.round(g), 0, 255);
        data[i + 2] = clamp(Math.round(b), 0, 255);
        data[i + 3] = 255;
      }
    }
    return { width: w, height: h, data };
  }

  function sobelEdges(image) {
    const { width: w, height: h, data } = image;
    const gray = new Float32Array(w * h);
    const out = new Float32Array(w * h);
    for (let y = 0; y < h; y += 1) {
      for (let x = 0; x < w; x += 1) {
        const idx = getIndex(x, y, w);
        gray[y * w + x] = computeLuma(data[idx], data[idx + 1], data[idx + 2]);
      }
    }
    const gxK = [-1,0,1,-2,0,2,-1,0,1];
    const gyK = [-1,-2,-1,0,0,0,1,2,1];
    let maxMag = 0;
    for (let y = 1; y < h - 1; y += 1) {
      for (let x = 1; x < w - 1; x += 1) {
        let gx = 0; let gy = 0; let ki = 0;
        for (let j = -1; j <= 1; j += 1) {
          for (let i = -1; i <= 1; i += 1) {
            const v = gray[(y + j) * w + (x + i)];
            gx += v * gxK[ki];
            gy += v * gyK[ki];
            ki += 1;
          }
        }
        const mag = Math.sqrt(gx * gx + gy * gy);
        out[y * w + x] = mag;
        if (mag > maxMag) maxMag = mag;
      }
    }
    if (maxMag > 0) for (let i = 0; i < out.length; i += 1) out[i] = out[i] / maxMag * 255;
    return out;
  }

  function analyzeImage(image) {
    const { width: w, height: h, data } = image;
    const edges = sobelEdges(image);
    let rSum = 0; let gSum = 0; let bSum = 0;
    let lumSum = 0; let lumSqSum = 0;
    let satSum = 0; let warmCount = 0; let coolCount = 0;
    let centerSkinLike = 0; let centerCount = 0; let edgeStrong = 0;
    const swatches = Array.from({ length: 4 }, () => ({ r: 0, g: 0, b: 0, count: 0 }));
    const total = w * h;

    for (let y = 0; y < h; y += 1) {
      for (let x = 0; x < w; x += 1) {
        const idx = getIndex(x, y, w);
        const r = data[idx]; const g = data[idx + 1]; const b = data[idx + 2];
        const [hue, sat, lum] = rgbToHsl(r, g, b);
        const luma = computeLuma(r, g, b);
        rSum += r; gSum += g; bSum += b;
        lumSum += luma; lumSqSum += luma * luma;
        satSum += sat;
        if (r > g && g > b) warmCount += 1;
        if (b > r && b > g) coolCount += 1;
        if (edges[y * w + x] > 92) edgeStrong += 1;

        const isCenter = x > w * 0.25 && x < w * 0.75 && y > h * 0.15 && y < h * 0.7;
        if (isCenter) {
          centerCount += 1;
          if (r > 160 && g > 120 && b > 100 && r > b && Math.abs(r - g) < 90) centerSkinLike += 1;
        }

        const bucket = (y < h / 2 ? 0 : 2) + (x < w / 2 ? 0 : 1);
        swatches[bucket].r += r; swatches[bucket].g += g; swatches[bucket].b += b; swatches[bucket].count += 1;
      }
    }

    const avgR = rSum / total; const avgG = gSum / total; const avgB = bSum / total;
    const avgLuma = lumSum / total;
    const lumaStd = Math.sqrt(Math.max(0, lumSqSum / total - avgLuma * avgLuma));
    const avgSat = satSum / total;
    const edgeDensity = edgeStrong / total;
    const warmth = (warmCount - coolCount) / total;
    const centerSkinRatio = centerCount ? centerSkinLike / centerCount : 0;
    const palette = swatches.map((s) => rgbToHex(s.r / s.count, s.g / s.count, s.b / s.count));

    return {
      width: w,
      height: h,
      aspectRatio: w / h,
      averageRgb: [Math.round(avgR), Math.round(avgG), Math.round(avgB)],
      averageHex: rgbToHex(avgR, avgG, avgB),
      averageLuma: avgLuma,
      lumaStd,
      averageSaturation: avgSat,
      edgeDensity,
      warmth,
      centerSkinRatio,
      palette,
      featureScores: {
        portrait: clamp(centerSkinRatio * 1.8 + (0.5 - Math.abs(0.78 - w / h)) * 0.25 + avgSat * 0.2, 0, 1.5),
        scene: clamp(edgeDensity * 1.4 + lumaStd / 255 * 0.4 + Math.abs(w / h - 1) * 0.25, 0, 1.5),
        'product-poster': clamp(avgSat * 0.8 + Math.abs(warmth) * 0.9 + edgeDensity * 0.5, 0, 1.5)
      }
    };
  }

  function inferSubject(features, config) {
    if (config.subjectMode && config.subjectMode !== 'auto') return config.subjectMode;
    const scores = features.featureScores;
    let bestKey = 'portrait'; let bestValue = -Infinity;
    Object.keys(scores).forEach((key) => {
      if (scores[key] > bestValue) { bestKey = key; bestValue = scores[key]; }
    });
    return bestKey;
  }

  function stylePalette(style, averageHex, featurePalette, warmthBias) {
    const bases = {
      'flat-commercial': { background: '#f5f8ff', surface: '#ffffff', line: '#23314a', accent: '#5aa7ff', accent2: '#ffd979', glow: '#dceeff' },
      anime: { background: '#f8f0ff', surface: '#fffafe', line: '#2d2241', accent: '#ff7ab6', accent2: '#7ab8ff', glow: '#ffd9ef' },
      storybook: { background: '#fff7ea', surface: '#fffdf8', line: '#5b4a3e', accent: '#e39a63', accent2: '#8ab77d', glow: '#ffe9c9' },
      painterly: { background: '#eef1f6', surface: '#fbfbfd', line: '#394454', accent: '#6a88c9', accent2: '#d39a6a', glow: '#d8e3f0' },
      'splash-art-lite': { background: '#161b2b', surface: '#26314d', line: '#f5f6fb', accent: '#62d5ff', accent2: '#ffb96a', glow: '#3550a6' }
    };
    const p = deepClone(bases[style] || bases.painterly);
    const avg = averageHex || '#9db4d8';
    const palette = featurePalette || [avg, p.accent, p.accent2, p.glow];
    p.background = blendHex(p.background, palette[0], style === 'splash-art-lite' ? 0.18 : 0.10);
    p.surface = blendHex(p.surface, palette[1] || palette[0], 0.10);
    p.accent = blendHex(p.accent, palette[2] || avg, 0.35 + warmthBias * 0.05);
    p.accent2 = blendHex(p.accent2, palette[3] || avg, 0.30 - warmthBias * 0.05);
    p.glow = blendHex(p.glow, avg, 0.25 + warmthBias * 0.12);
    return p;
  }


  function downsampleImage(image, maxSide) {
    const limit = Math.max(32, Math.round(maxSide || 220));
    const dims = resizeDimensions(image.width, image.height, limit);
    if (dims.width === image.width && dims.height === image.height) {
      return { width: image.width, height: image.height, data: new Uint8ClampedArray(image.data) };
    }
    const out = new Uint8ClampedArray(dims.width * dims.height * 4);
    for (let y = 0; y < dims.height; y += 1) {
      const sy0 = Math.floor(y * image.height / dims.height);
      const sy1 = Math.max(sy0 + 1, Math.floor((y + 1) * image.height / dims.height));
      for (let x = 0; x < dims.width; x += 1) {
        const sx0 = Math.floor(x * image.width / dims.width);
        const sx1 = Math.max(sx0 + 1, Math.floor((x + 1) * image.width / dims.width));
        let r = 0; let g = 0; let b = 0; let a = 0; let count = 0;
        for (let sy = sy0; sy < Math.min(image.height, sy1); sy += 1) {
          for (let sx = sx0; sx < Math.min(image.width, sx1); sx += 1) {
            const idx = getIndex(sx, sy, image.width);
            r += image.data[idx]; g += image.data[idx + 1]; b += image.data[idx + 2]; a += image.data[idx + 3]; count += 1;
          }
        }
        const oi = getIndex(x, y, dims.width);
        out[oi] = Math.round(r / count); out[oi + 1] = Math.round(g / count); out[oi + 2] = Math.round(b / count); out[oi + 3] = Math.round(a / count);
      }
    }
    return { width: dims.width, height: dims.height, data: out };
  }

  function extractDominantPalette(image, maxColors) {
    const bins = new Map();
    const colors = Math.max(4, Math.round(maxColors || 16));
    for (let y = 0; y < image.height; y += 1) {
      for (let x = 0; x < image.width; x += 1) {
        const idx = getIndex(x, y, image.width);
        if (image.data[idx + 3] < 32) continue;
        const r = image.data[idx] >> 4;
        const g = image.data[idx + 1] >> 4;
        const b = image.data[idx + 2] >> 4;
        const key = (r << 8) | (g << 4) | b;
        bins.set(key, (bins.get(key) || 0) + 1);
      }
    }
    const ranked = [...bins.entries()].sort((a, b) => b[1] - a[1]).slice(0, colors);
    if (!ranked.length) return ['#ffffff', '#000000'];
    return ranked.map(([key]) => {
      const r = ((key >> 8) & 15) * 16 + 8;
      const g = ((key >> 4) & 15) * 16 + 8;
      const b = (key & 15) * 16 + 8;
      return rgbToHex(r, g, b);
    });
  }

  function nearestPaletteIndex(r, g, b, paletteRgb) {
    let best = 0; let bestD = Infinity;
    for (let i = 0; i < paletteRgb.length; i += 1) {
      const p = paletteRgb[i];
      const dr = r - p[0]; const dg = g - p[1]; const db = b - p[2];
      const d = dr * dr + dg * dg + db * db;
      if (d < bestD) { bestD = d; best = i; }
    }
    return best;
  }

  function buildRegionMap(image, options) {
    const opts = options || {};
    const sampled = downsampleImage(image, opts.maxSide || 220);
    const palette = extractDominantPalette(sampled, opts.maxColors || 16);
    const paletteRgb = palette.map(hexToRgb);
    const labels = new Uint8Array(sampled.width * sampled.height);
    for (let y = 0; y < sampled.height; y += 1) {
      for (let x = 0; x < sampled.width; x += 1) {
        const idx = getIndex(x, y, sampled.width);
        labels[y * sampled.width + x] = nearestPaletteIndex(sampled.data[idx], sampled.data[idx + 1], sampled.data[idx + 2], paletteRgb);
      }
    }

    const rows = [];
    const edgeRows = [];
    for (let y = 0; y < sampled.height; y += 1) {
      const row = [];
      let start = 0; let current = labels[y * sampled.width];
      for (let x = 1; x <= sampled.width; x += 1) {
        const next = x < sampled.width ? labels[y * sampled.width + x] : -1;
        if (next !== current) {
          row.push([start, x - start, current]);
          start = x; current = next;
        }
      }
      rows.push(row);

      const edge = [];
      let edgeStart = -1;
      for (let x = 0; x < sampled.width; x += 1) {
        const here = labels[y * sampled.width + x];
        const isEdge = (x > 0 && labels[y * sampled.width + x - 1] !== here) ||
          (x + 1 < sampled.width && labels[y * sampled.width + x + 1] !== here) ||
          (y > 0 && labels[(y - 1) * sampled.width + x] !== here) ||
          (y + 1 < sampled.height && labels[(y + 1) * sampled.width + x] !== here);
        if (isEdge && edgeStart < 0) edgeStart = x;
        if ((!isEdge || x === sampled.width - 1) && edgeStart >= 0) {
          const end = isEdge && x === sampled.width - 1 ? x + 1 : x;
          edge.push([edgeStart, end - edgeStart]); edgeStart = -1;
        }
      }
      edgeRows.push(edge);
    }

    const visited = new Uint8Array(labels.length);
    const queue = new Int32Array(labels.length);
    const regions = [];
    for (let y0 = 0; y0 < sampled.height; y0 += 1) {
      for (let x0 = 0; x0 < sampled.width; x0 += 1) {
        const seed = y0 * sampled.width + x0;
        if (visited[seed]) continue;
        const label = labels[seed];
        let head = 0; let tail = 0;
        queue[tail++] = seed; visited[seed] = 1;
        let area = 0; let minX = x0; let maxX = x0; let minY = y0; let maxY = y0; let sumX = 0; let sumY = 0;
        while (head < tail) {
          const pos = queue[head++];
          const x = pos % sampled.width; const y = Math.floor(pos / sampled.width);
          area += 1; sumX += x; sumY += y;
          if (x < minX) minX = x; if (x > maxX) maxX = x; if (y < minY) minY = y; if (y > maxY) maxY = y;
          if (x > 0) { const n = pos - 1; if (!visited[n] && labels[n] === label) { visited[n] = 1; queue[tail++] = n; } }
          if (x + 1 < sampled.width) { const n = pos + 1; if (!visited[n] && labels[n] === label) { visited[n] = 1; queue[tail++] = n; } }
          if (y > 0) { const n = pos - sampled.width; if (!visited[n] && labels[n] === label) { visited[n] = 1; queue[tail++] = n; } }
          if (y + 1 < sampled.height) { const n = pos + sampled.width; if (!visited[n] && labels[n] === label) { visited[n] = 1; queue[tail++] = n; } }
        }
        if (area >= (opts.minRegionArea || 3)) {
          regions.push({
            paletteIndex: label,
            area,
            bbox: [minX, minY, maxX - minX + 1, maxY - minY + 1],
            centroid: [Number((sumX / area).toFixed(2)), Number((sumY / area).toFixed(2))]
          });
        }
      }
    }
    regions.sort((a, b) => b.area - a.area);
    const limited = regions.slice(0, opts.maxRegions || 180).map((region, index) => ({ ...region, id: `REGION_${String(index + 1).padStart(3, '0')}` }));
    return {
      kind: 'region-map',
      method: 'quantized-rle-regions-v1',
      sourceWidth: image.width,
      sourceHeight: image.height,
      width: sampled.width,
      height: sampled.height,
      palette,
      rows,
      edgeRows,
      regions: limited
    };
  }

  function hueWrap(h) {
    let out = h;
    while (out < 0) out += 1;
    while (out > 1) out -= 1;
    return out;
  }

  function styleRegionColor(hex, style, scene) {
    const probe = scene && scene.probe ? scene.probe : { mood: 0.5, detail: 0.5, energy: 0.5 };
    let [r, g, b] = hexToRgb(hex);
    let [h, s, l] = rgbToHsl(r, g, b);
    if (style === 'anime') {
      h = hueWrap(h + 0.015 + probe.energy * 0.01);
      s = clamp(s * (1.25 + probe.mood * 0.1), 0, 1);
      l = clamp(l * 1.03 + 0.01, 0, 1);
    } else if (style === 'storybook') {
      h = hueWrap(h - 0.01);
      s = clamp(s * 0.72, 0, 1);
      l = clamp(l * 1.06 + 0.015, 0, 1);
      [r, g, b] = hslToRgb(h, s, l);
      return blendHex(rgbToHex(r, g, b), '#f1dfbf', 0.22 + probe.mood * 0.08);
    } else if (style === 'painterly') {
      h = hueWrap(h + 0.006);
      s = clamp(s * 0.88, 0, 1);
      l = clamp(l * 1.01, 0, 1);
    } else if (style === 'splash-art-lite') {
      h = hueWrap(h - 0.02);
      s = clamp(s * (1.34 + probe.energy * 0.08), 0, 1);
      l = clamp(l * 0.90, 0, 1);
    } else {
      s = clamp(s * (1.02 + probe.mood * 0.04), 0, 1);
      l = clamp(l * 1.01, 0, 1);
    }
    [r, g, b] = hslToRgb(h, s, l);
    return rgbToHex(r, g, b);
  }

  function computeReconstructionOptions(config, features) {
    const detail01 = clamp(0.5 + config.detailBias * 0.5 + features.edgeDensity * 0.8, 0, 1);
    return {
      maxSide: Math.round(220 + detail01 * 160),
      maxColors: Math.round(10 + detail01 * 16),
      maxRegions: Math.round(120 + detail01 * 220),
      minRegionArea: Math.round(5 - detail01 * 3)
    };
  }

  function drawReconstructionSubject(ctx, scene, width, height, profile, motion) {
    const rec = scene.reconstruction;
    if (!rec || rec.kind !== 'region-map') return;
    const left = Math.max(560, width * 0.40);
    const top = 88;
    const boxW = width - left - 58;
    const boxH = height - top - 72;
    const scale = Math.min(boxW / rec.width, boxH / rec.height);
    const drawW = rec.width * scale;
    const drawH = rec.height * scale;
    const ox = left + (boxW - drawW) / 2 + scene.probe.composition * 30;
    const oy = top + (boxH - drawH) / 2 + motion.floatY * 0.18;

    ctx.save();
    ctx.fillStyle = applyAlpha(scene.palette.surface, profile.name === 'splash-art-lite' ? 0.10 : 0.46);
    roundRect(ctx, ox - 20, oy - 20, drawW + 40, drawH + 40, profile.cornerRadius + 4);
    ctx.fill();
    ctx.shadowColor = applyAlpha('#000000', 0.14);
    ctx.shadowBlur = 24;
    ctx.shadowOffsetY = 12;
    ctx.fillStyle = applyAlpha('#000000', 0.04);
    roundRect(ctx, ox - 10, oy - 10, drawW + 20, drawH + 20, profile.cornerRadius);
    ctx.fill();
    ctx.shadowColor = 'transparent';

    const styledPalette = rec.palette.map((hex) => styleRegionColor(hex, scene.probe.style, scene));
    for (let y = 0; y < rec.rows.length; y += 1) {
      const row = rec.rows[y];
      for (const run of row) {
        const [x, len, pi] = run;
        ctx.fillStyle = styledPalette[pi] || rec.palette[pi] || '#000000';
        ctx.fillRect(ox + x * scale, oy + y * scale, Math.ceil(len * scale) + 0.6, Math.ceil(scale) + 0.6);
      }
    }

    const edgeAlpha = scene.probe.style === 'painterly' ? 0.12 : scene.probe.style === 'storybook' ? 0.20 : scene.probe.style === 'anime' ? 0.40 : 0.34;
    ctx.fillStyle = applyAlpha(scene.palette.line, edgeAlpha);
    const edgeThickness = scene.probe.style === 'anime' ? Math.max(1.2, scale * 0.70) : scene.probe.style === 'splash-art-lite' ? Math.max(1.0, scale * 0.58) : Math.max(0.75, scale * 0.45);
    for (let y = 0; y < rec.edgeRows.length; y += 1) {
      for (const run of rec.edgeRows[y]) {
        const [x, len] = run;
        ctx.fillRect(ox + x * scale, oy + y * scale, Math.max(0.8, len * scale), edgeThickness);
      }
    }

    if (scene.probe.style === 'anime') {
      ctx.strokeStyle = applyAlpha(scene.palette.accent, 0.18 + scene.probe.energy * 0.08);
      ctx.lineWidth = 3.5;
      for (let i = 0; i < 10; i += 1) {
        const yy = oy + drawH * (0.05 + i * 0.10);
        ctx.beginPath();
        ctx.moveTo(ox - 8, yy);
        ctx.lineTo(ox + drawW + 8, yy - 10 + i * 0.8);
        ctx.stroke();
      }
    } else if (scene.probe.style === 'storybook') {
      ctx.fillStyle = applyAlpha('#ecd9b8', 0.12);
      for (let i = 0; i < 120; i += 1) {
        const px = ox + (i * 67 % Math.max(1, Math.floor(drawW)));
        const py = oy + (i * 53 % Math.max(1, Math.floor(drawH)));
        ctx.fillRect(px, py, 1.6, 1.6);
      }
    } else if (scene.probe.style === 'splash-art-lite') {
      ctx.strokeStyle = applyAlpha(scene.palette.glow, 0.25);
      ctx.lineWidth = 2.6;
      for (let i = 0; i < 12; i += 1) {
        ctx.beginPath();
        ctx.moveTo(ox - 12, oy + drawH * (i / 12));
        ctx.lineTo(ox + drawW + 14, oy + drawH * (i / 12) - 8);
        ctx.stroke();
      }
    }

    if (profile.brushiness > 0.2) {
      ctx.strokeStyle = applyAlpha(scene.palette.glow, 0.11 + profile.brushiness * 0.10);
      ctx.lineWidth = 6 + profile.brushiness * 7;
      for (let i = 0; i < 9; i += 1) {
        const yy = oy + drawH * (0.08 + i * 0.105);
        ctx.beginPath();
        ctx.moveTo(ox + 12, yy);
        ctx.quadraticCurveTo(ox + drawW * 0.42, yy - 18 + i * 2, ox + drawW - 10, yy + 8);
        ctx.stroke();
      }
    }
    ctx.restore();
  }

  function baseSymbols(subject) {
    const common = ['SCENE_ROOT', 'STYLE_PROFILE', 'COPY_BLOCK', 'TITLE_TEXT', 'BADGE_CHIP', 'CTA_CHIP', 'ACCENT_ORB_1', 'ACCENT_ORB_2'];
    const subjectMap = {
      portrait: ['PORTRAIT_HEAD', 'PORTRAIT_HAIR', 'PORTRAIT_EYE_L', 'PORTRAIT_EYE_R', 'PORTRAIT_TORSO', 'PORTRAIT_PROP'],
      scene: ['ROOM_FLOOR', 'ROOM_DESK', 'ROOM_WINDOW', 'ROOM_BOOK', 'ROOM_LAMP', 'ROOM_PLANT'],
      'product-poster': ['PRODUCT_CORE', 'PRODUCT_CAP', 'PRODUCT_LABEL', 'PRODUCT_SHADOW', 'POSTER_RING', 'POSTER_SPARK']
    };
    return common.concat(subjectMap[subject] || subjectMap.portrait);
  }

  function compileScene(features, config, sourceImage) {
    validateCompilerConfig(config);
    const subject = inferSubject(features, config);
    const style = config.targetStyle;
    const mood = clamp(0.5 + (features.averageSaturation - 0.35) * 0.7 + config.moodBias * 0.4 + features.warmth * 0.2, 0, 1);
    const detail = clamp(0.45 + features.edgeDensity * 1.4 + (features.lumaStd / 255) * 0.35 + config.detailBias * 0.4, 0, 1);
    const energy = clamp(0.4 + features.edgeDensity * 1.1 + Math.abs(features.warmth) * 0.2 + config.energyBias * 0.45, 0, 1);
    const composition = clamp((features.aspectRatio > 1 ? 0.08 : -0.04) + config.compositionBias * 0.4, -1, 1);
    const warmthBias = clamp(config.warmthBias + features.warmth, -1, 1);
    const palette = stylePalette(style, features.averageHex, features.palette, warmthBias);
    const reconstructionOptions = computeReconstructionOptions(config, features);
    const reconstruction = sourceImage ? buildRegionMap(sourceImage, reconstructionOptions) : null;

    const scene = {
      meta: {
        brand: 'EVEMISSLAB / Generative Symbol Compiler',
        title: '',
        subtitle: '',
        badge: '',
        cta: ''
      },
      probe: { subject: reconstruction ? 'reconstruction' : subject, style, mood, detail, energy, composition },
      palette,
      animation: {
        autoplay: true,
        speed: clamp(0.9 + energy * 0.7, 0.3, 2.2),
        floatAmp: Math.round(6 + mood * 5 + energy * 8),
        pulseAmp: clamp(0.12 + energy * 0.22, 0.08, 0.45)
      },
      reconstruction,
      compiler: {
        source: {
          width: features.width,
          height: features.height,
          averageHex: features.averageHex
        },
        inferredSubject: subject,
        style,
        controls: { moodBias: config.moodBias, detailBias: config.detailBias, energyBias: config.energyBias, warmthBias: config.warmthBias, compositionBias: config.compositionBias },
        highFidelity: sourceImage ? { enabled: true, mode: 'source-preserving-1to1', sourceWidth: sourceImage.width, sourceHeight: sourceImage.height } : null,
        reconstruction: reconstruction ? { kind: reconstruction.kind, method: reconstruction.method, width: reconstruction.width, height: reconstruction.height, regionCount: reconstruction.regions.length, paletteSize: reconstruction.palette.length, options: reconstructionOptions } : null,
        featureSnapshot: {
          averageLuma: Number(features.averageLuma.toFixed(3)),
          lumaStd: Number(features.lumaStd.toFixed(3)),
          averageSaturation: Number(features.averageSaturation.toFixed(3)),
          edgeDensity: Number(features.edgeDensity.toFixed(4)),
          warmth: Number(features.warmth.toFixed(4)),
          centerSkinRatio: Number(features.centerSkinRatio.toFixed(4))
        }
      },
      symbols: reconstruction ? ['SCENE_ROOT', 'STYLE_PROFILE', 'SOURCE_REGION_MAP', ...reconstruction.regions.map((r) => r.id)] : baseSymbols(subject)
    };

    if (subject === 'portrait') {
      scene.meta.title = style === 'anime' ? 'Compiled Portrait: Luminous Persona' : style === 'storybook' ? 'Compiled Portrait: Quiet Figure' : style === 'splash-art-lite' ? 'Compiled Portrait: Hero Frame' : style === 'flat-commercial' ? 'Compiled Portrait: Brand Character' : 'Compiled Portrait: Painterly Study';
      scene.meta.subtitle = 'Scene reconstructed from source image features, then compiled into a symbol-native half-body portrait.';
      scene.meta.badge = 'PORTRAIT COMPILER';
      scene.meta.cta = 'Inspect symbolic reconstruction';
    } else if (subject === 'scene') {
      scene.meta.title = style === 'anime' ? 'Compiled Scene: Creative Corner' : style === 'storybook' ? 'Compiled Scene: Warm Interior' : style === 'splash-art-lite' ? 'Compiled Scene: Dramatic Base' : style === 'flat-commercial' ? 'Compiled Scene: Lifestyle Set' : 'Compiled Scene: Quiet Studio';
      scene.meta.subtitle = 'Source image reduced into a scene-level structure with depth, props, and environmental layout cues.';
      scene.meta.badge = 'SCENE COMPILER';
      scene.meta.cta = 'Check structural retention';
    } else {
      scene.meta.title = style === 'anime' ? 'Compiled Poster: Spark Tonic' : style === 'storybook' ? 'Compiled Poster: Amber Blend' : style === 'splash-art-lite' ? 'Compiled Poster: Nova Burst' : style === 'flat-commercial' ? 'Compiled Poster: Calm Brew' : 'Compiled Poster: Studio Elixir';
      scene.meta.subtitle = 'Source features compiled into a symbolic product-poster layout instead of direct pixel substitution.';
      scene.meta.badge = 'POSTER COMPILER';
      scene.meta.cta = 'Evaluate commercial plausibility';
    }
    if (reconstruction) {
      scene.meta.title = `Compiled 1:1 Reconstruction: ${style.replace(/-/g, ' ')}`;
      scene.meta.subtitle = 'High-fidelity source-preserving reconstruction near input resolution; symbol-native styling is applied after structural compilation.';
      scene.meta.badge = 'HF 1:1 COMPILER';
      scene.meta.cta = 'Inspect high-fidelity retention';
    }
    if (sourceImage) {
      const semanticPlan = computeSemanticLayerPlan(sourceImage, scene);
      scene.semantic = {
        mode: 'multi-layer-semantic-v0.9',
        plan: semanticPlan,
        layers: [
          { id: 'background', label: 'Background', blend: 'normal', role: 'world-base' },
          { id: 'subject', label: 'Subject', blend: 'normal', role: 'primary-identity' },
          { id: 'glow', label: 'Glow FX', blend: 'screen', role: 'light-atmosphere' },
          { id: 'foreground', label: 'Foreground', blend: 'overlay', role: 'props-depth' },
          { id: 'panel', label: 'Panel', blend: 'normal', role: 'ui-copy' }
        ]
      };
      scene.compiler.layerVisibility = { background: true, subject: true, glow: true, foreground: true, panel: true };
      if (scene.compiler.highFidelity) scene.compiler.highFidelity.mode = 'multi-layer-semantic-v0.9';
      scene.meta.badge = 'ML SEMANTIC COMPILER';
      scene.meta.cta = 'Inspect layered semantic retention';
    }
    return scene;
  }

  function validateScene(scene) {
    if (!scene || typeof scene !== 'object') throw new Error('Scene must be an object');
    if (!scene.meta || !scene.probe || !scene.palette || !scene.animation || !Array.isArray(scene.symbols)) {
      throw new Error('Scene requires meta, probe, palette, animation, and symbols');
    }
    return true;
  }

  function sceneToJson(scene) { return JSON.stringify(scene, null, 2); }
  function parseSceneJson(text) {
    const scene = JSON.parse(text);
    validateScene(scene);
    return scene;
  }

  function computeStyleProfile(scene) {
    validateScene(scene);
    const style = scene.probe.style;
    const mood = clamp(scene.probe.mood, 0, 1);
    const detail = clamp(scene.probe.detail, 0, 1);
    const energy = clamp(scene.probe.energy, 0, 1);
    const composition = clamp(scene.probe.composition, -1, 1);
    const base = {
      name: style,
      lineWidth: 4,
      eyeScale: 1,
      shadowAlpha: 0.16,
      softAlpha: 0.12,
      ornamentDensity: 0.4,
      dynamicSkew: 0,
      celShade: false,
      brushiness: 0,
      cornerRadius: 24,
      compositionShift: composition,
      bgPattern: 'orbs'
    };
    if (style === 'anime') Object.assign(base, { lineWidth: 4.8, eyeScale: 1.28, shadowAlpha: 0.12, ornamentDensity: 0.65, dynamicSkew: 0.12, celShade: true, bgPattern: 'speedlines' });
    if (style === 'storybook') Object.assign(base, { lineWidth: 3.2, eyeScale: 0.95, shadowAlpha: 0.10, softAlpha: 0.25, ornamentDensity: 0.42, brushiness: 0.18, bgPattern: 'paper' });
    if (style === 'painterly') Object.assign(base, { lineWidth: 2.4, eyeScale: 0.9, shadowAlpha: 0.24, softAlpha: 0.33, ornamentDensity: 0.36, brushiness: 0.65, bgPattern: 'brush' });
    if (style === 'splash-art-lite') Object.assign(base, { lineWidth: 4.4, eyeScale: 1.08, shadowAlpha: 0.28, ornamentDensity: 0.78, dynamicSkew: 0.28, celShade: true, bgPattern: 'burst' });
    base.lineWidth += detail * 0.6;
    base.eyeScale += (mood - 0.5) * 0.18;
    base.ornamentDensity = clamp(base.ornamentDensity + detail * 0.2, 0, 1);
    base.dynamicSkew += (energy - 0.5) * 0.08;
    base.cornerRadius = Math.round(lerp(14, 30, 1 - energy * 0.5));
    return base;
  }

  function computeMotionState(scene, timeSec) {
    validateScene(scene);
    const speed = clamp(scene.animation.speed || 1, 0.05, 5);
    const ts = (Number.isFinite(timeSec) ? timeSec : 0) * speed;
    const floatAmp = scene.animation.floatAmp || 0;
    const pulseAmp = scene.animation.pulseAmp || 0;
    return {
      timeSec: Number.isFinite(timeSec) ? timeSec : 0,
      speed,
      floatY: Math.sin(ts * Math.PI * 2 * 0.35) * floatAmp,
      pulse: 1 + Math.sin(ts * Math.PI * 2 * 0.7) * pulseAmp,
      drift: Math.sin(ts * Math.PI * 2 * 0.22) * 22,
      orbit: Math.cos(ts * Math.PI * 2 * 0.48) * 18
    };
  }

  function roundRect(ctx, x, y, w, h, r) {
    const radius = Math.min(r, w / 2, h / 2);
    ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.arcTo(x + w, y, x + w, y + h, radius);
    ctx.arcTo(x + w, y + h, x, y + h, radius);
    ctx.arcTo(x, y + h, x, y, radius);
    ctx.arcTo(x, y, x + w, y, radius);
    ctx.closePath();
  }

  function triangle(ctx, x1, y1, x2, y2, x3, y3) { ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.lineTo(x3, y3); ctx.closePath(); }
  function drawCircleAccent(ctx, x, y, r, fill) { ctx.fillStyle = fill; ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill(); }
  function drawStar(ctx, x, y, points, inner, outer, fill) {
    ctx.fillStyle = fill; ctx.beginPath();
    for (let i = 0; i < points * 2; i += 1) {
      const angle = (Math.PI / points) * i - Math.PI / 2;
      const radius = i % 2 === 0 ? outer : inner;
      const px = x + Math.cos(angle) * radius;
      const py = y + Math.sin(angle) * radius;
      if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
    }
    ctx.closePath(); ctx.fill();
  }
  function wrapText(ctx, text, x, y, maxWidth, lineHeight) {
    const words = String(text).split(/\s+/); let line = ''; let cursorY = y;
    for (const word of words) {
      const trial = line ? `${line} ${word}` : word;
      if (ctx.measureText(trial).width > maxWidth && line) {
        ctx.fillText(line, x, cursorY); line = word; cursorY += lineHeight;
      } else line = trial;
    }
    if (line) ctx.fillText(line, x, cursorY);
  }

  function drawBackground(ctx, scene, width, height, profile, motion) {
    const p = scene.palette;
    const bg = ctx.createLinearGradient(0, 0, width, height);
    bg.addColorStop(0, p.background);
    bg.addColorStop(1, blendHex(p.background, p.accent, profile.name === 'splash-art-lite' ? 0.35 : 0.12));
    ctx.fillStyle = bg; ctx.fillRect(0, 0, width, height);
    if (profile.bgPattern === 'speedlines' || profile.bgPattern === 'burst') {
      ctx.save();
      ctx.translate(width * 0.72, height * 0.44);
      ctx.rotate(profile.dynamicSkew);
      ctx.strokeStyle = applyAlpha(p.glow, profile.bgPattern === 'burst' ? 0.28 : 0.18);
      ctx.lineWidth = profile.bgPattern === 'burst' ? 8 : 5;
      for (let i = 0; i < 14; i += 1) {
        const angle = -1.0 + i * 0.14;
        const len = 240 + i * 22;
        ctx.beginPath(); ctx.moveTo(Math.cos(angle) * 50, Math.sin(angle) * 50); ctx.lineTo(Math.cos(angle) * len, Math.sin(angle) * len); ctx.stroke();
      }
      ctx.restore();
    }
    if (profile.bgPattern === 'paper' || profile.bgPattern === 'brush') {
      ctx.save();
      const layers = profile.bgPattern === 'brush' ? 28 : 18;
      for (let i = 0; i < layers; i += 1) {
        ctx.fillStyle = applyAlpha(i % 2 === 0 ? p.glow : p.surface, profile.bgPattern === 'brush' ? 0.08 : 0.05);
        ctx.beginPath(); ctx.ellipse(120 + i * 44, 90 + (i % 4) * 52, 70 + i * 3, 22 + (i % 3) * 8, i * 0.13, 0, Math.PI * 2); ctx.fill();
      }
      ctx.restore();
    }
    ctx.save(); ctx.globalAlpha = 0.55;
    drawCircleAccent(ctx, width * 0.18 + motion.drift * 0.2, height * 0.20, 94 * motion.pulse, applyAlpha(p.glow, 0.38));
    drawCircleAccent(ctx, width * 0.86 - motion.drift * 0.15, height * 0.78, 122, applyAlpha(p.accent2, 0.12));
    if (profile.ornamentDensity > 0.55) drawStar(ctx, width * 0.83, height * 0.16, 6, 8, 16 * motion.pulse, applyAlpha(p.accent, 0.85));
    ctx.restore();
  }

  function drawCopyPanel(ctx, scene, width, height, profile) {
    const p = scene.palette;
    const x = 54; const y = 54; const w = 480; const h = 300;
    ctx.save();
    ctx.fillStyle = applyAlpha(p.surface, profile.name === 'splash-art-lite' ? 0.12 : 0.82);
    roundRect(ctx, x, y, w, h, profile.cornerRadius); ctx.fill();
    ctx.strokeStyle = applyAlpha(profile.name === 'splash-art-lite' ? p.glow : p.line, 0.22); ctx.lineWidth = 2; ctx.stroke();
    ctx.fillStyle = profile.name === 'splash-art-lite' ? '#ffffff' : p.line;
    ctx.font = '700 22px system-ui, sans-serif'; ctx.fillText(scene.meta.brand, x + 24, y + 34);
    const badgeW = ctx.measureText(scene.meta.badge).width + 30;
    ctx.fillStyle = p.accent; roundRect(ctx, x + 24, y + 52, badgeW, 36, 18); ctx.fill();
    ctx.fillStyle = profile.name === 'splash-art-lite' ? '#0d1324' : '#0f1726'; ctx.font = '700 15px system-ui, sans-serif'; ctx.fillText(scene.meta.badge, x + 40, y + 75);
    ctx.fillStyle = profile.name === 'splash-art-lite' ? '#ffffff' : p.line;
    ctx.font = '700 50px system-ui, sans-serif'; wrapText(ctx, scene.meta.title, x + 24, y + 135, w - 48, 54);
    ctx.fillStyle = applyAlpha(profile.name === 'splash-art-lite' ? '#ffffff' : p.line, 0.82);
    ctx.font = '400 22px system-ui, sans-serif'; wrapText(ctx, scene.meta.subtitle, x + 24, y + 210, w - 48, 30);
    ctx.fillStyle = profile.name === 'splash-art-lite' ? applyAlpha('#ffffff', 0.12) : p.line; roundRect(ctx, x + 24, y + h - 56, ctx.measureText(scene.meta.cta).width + 30, 34, 17); ctx.fill();
    ctx.fillStyle = '#ffffff'; ctx.font = '700 15px system-ui, sans-serif'; ctx.fillText(scene.meta.cta, x + 39, y + h - 34);
    ctx.restore();
  }

  function drawStatusBadge(ctx, scene, width, profile, motion) {
    ctx.save(); ctx.font = '700 14px system-ui, sans-serif';
    const label = `GEN-SYM COMPILER · ${scene.probe.subject} · ${scene.probe.style} · t=${motion.timeSec.toFixed(2)}s`;
    const w = ctx.measureText(label).width + 24;
    ctx.fillStyle = applyAlpha(profile.name === 'splash-art-lite' ? '#ffffff' : scene.palette.line, 0.84); roundRect(ctx, width - w - 34, 26, w, 34, 17); ctx.fill();
    ctx.fillStyle = profile.name === 'splash-art-lite' ? '#0d1324' : '#ffffff'; if (profile.name !== 'splash-art-lite') ctx.fillStyle = '#ffffff';
    ctx.fillText(label, width - w - 22, 48); ctx.restore();
  }

  function drawPortrait(ctx, scene, width, height, profile, motion) {
    const p = scene.palette; const cx = width * 0.76 + scene.probe.composition * 90; const cy = height * 0.56 + motion.floatY;
    const skin = profile.name === 'splash-art-lite' ? '#f6d6c7' : profile.name === 'storybook' ? '#f2d5bc' : '#f2d2c5';
    const hair = blendHex(p.line, p.accent2, profile.name === 'anime' ? 0.38 : profile.name === 'storybook' ? 0.22 : 0.18);
    ctx.save(); ctx.translate(cx, cy); ctx.rotate(profile.dynamicSkew * 0.45);
    ctx.fillStyle = blendHex(p.accent2, p.surface, 0.25); ctx.strokeStyle = p.line; ctx.lineWidth = profile.lineWidth;
    ctx.beginPath(); ctx.moveTo(-130, 180); ctx.quadraticCurveTo(-120, 80, 0, 88); ctx.quadraticCurveTo(118, 74, 140, 182); ctx.lineTo(-130, 180); ctx.fill(); ctx.stroke();
    ctx.fillStyle = skin; roundRect(ctx, -28, 58, 56, 66, 18); ctx.fill();
    ctx.beginPath(); ctx.ellipse(0, 10, 108, 132, 0, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    ctx.fillStyle = hair; ctx.beginPath(); ctx.ellipse(0, -10, 126, 150, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = skin; ctx.beginPath(); ctx.ellipse(0, 10, 108, 132, 0, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    ctx.fillStyle = hair; ctx.beginPath(); ctx.moveTo(-96, -78); ctx.quadraticCurveTo(-22, -132, 46, -84); ctx.quadraticCurveTo(88, -48, 90, -4); ctx.quadraticCurveTo(52, -36, 10, -30); ctx.quadraticCurveTo(-30, -24, -58, -4); ctx.quadraticCurveTo(-80, -20, -96, -78); ctx.fill();
    const eyeY = profile.name === 'anime' ? -4 : 8; const eyeRX = 13 * profile.eyeScale; const eyeRY = (profile.name === 'anime' ? 20 : 12) * profile.eyeScale;
    ctx.fillStyle = p.line; ctx.beginPath(); ctx.ellipse(-38, eyeY, eyeRX, eyeRY * motion.pulse * 0.95, 0, 0, Math.PI * 2); ctx.fill(); ctx.beginPath(); ctx.ellipse(38, eyeY, eyeRX, eyeRY * motion.pulse * 0.95, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.arc(-34, eyeY - 4, 4, 0, Math.PI * 2); ctx.arc(42, eyeY - 4, 4, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = p.line; ctx.lineWidth = Math.max(2, profile.lineWidth - 1.5); ctx.beginPath(); ctx.moveTo(0, 28); ctx.lineTo(-6, 40); ctx.lineTo(6, 40); ctx.stroke(); ctx.beginPath(); ctx.moveTo(-18, 62); ctx.quadraticCurveTo(0, 76 + scene.probe.mood * 6, 18, 62); ctx.stroke();
    ctx.fillStyle = applyAlpha(p.accent, 0.18 + scene.probe.mood * 0.1); ctx.beginPath(); ctx.ellipse(-72, 46, 18, 10, -0.2, 0, Math.PI * 2); ctx.ellipse(72, 46, 18, 10, 0.2, 0, Math.PI * 2); ctx.fill();
    if (profile.name === 'painterly') { ctx.fillStyle = p.accent2; ctx.strokeStyle = p.line; ctx.lineWidth = 3; roundRect(ctx, 118, 44, 20, 84, 9); ctx.fill(); ctx.stroke(); ctx.fillStyle = '#e7c9a1'; triangle(ctx, 128, 38, 118, 58, 138, 58); ctx.fill(); }
    else if (profile.name === 'anime') drawStar(ctx, 114, -76, 5, 8, 16, p.accent2);
    else if (profile.name === 'storybook') { ctx.fillStyle = p.accent2; triangle(ctx, -112, -46, -76, -62, -80, -20); ctx.fill(); }
    if (profile.celShade) { ctx.fillStyle = applyAlpha(p.glow, 0.16); ctx.beginPath(); ctx.ellipse(30, 58, 34, 20, -0.2, 0, Math.PI * 2); ctx.fill(); }
    if (profile.brushiness > 0.2) { ctx.strokeStyle = applyAlpha(p.line, 0.12 + profile.brushiness * 0.15); ctx.lineWidth = 10; for (let i = 0; i < 6; i += 1) { ctx.beginPath(); ctx.moveTo(-140 + i * 28, -146 + i * 8); ctx.quadraticCurveTo(-60 + i * 6, -184 + i * 3, 44 + i * 8, -136 + i * 5); ctx.stroke(); } }
    ctx.restore();
  }

  function drawSceneSubject(ctx, scene, width, height, profile, motion) {
    const p = scene.palette; const baseX = width * 0.70 + scene.probe.composition * 70; const baseY = height * 0.62 + motion.floatY * 0.5;
    ctx.save(); ctx.translate(baseX, baseY);
    ctx.fillStyle = blendHex(p.surface, p.accent2, 0.1); ctx.beginPath(); ctx.ellipse(0, 200, 280, 62, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = applyAlpha(p.glow, 0.42); roundRect(ctx, -20, -240, 200, 170, 24); ctx.fill(); ctx.strokeStyle = applyAlpha(p.line, 0.16); ctx.lineWidth = 6; ctx.stroke(); ctx.beginPath(); ctx.moveTo(80, -240); ctx.lineTo(80, -70); ctx.moveTo(-20, -155); ctx.lineTo(180, -155); ctx.stroke();
    ctx.fillStyle = blendHex(p.accent2, p.surface, 0.3); ctx.strokeStyle = p.line; ctx.lineWidth = profile.lineWidth; roundRect(ctx, -170, 30, 320, 76, 18); ctx.fill(); ctx.stroke(); ctx.fillRect(-140, 106, 18, 98); ctx.fillRect(102, 106, 18, 98);
    ctx.fillStyle = blendHex(p.accent, '#ffffff', 0.35); roundRect(ctx, -132 + motion.drift * 0.08, -2, 88, 44, 10); ctx.fill(); ctx.stroke(); ctx.fillStyle = applyAlpha(p.line, 0.15); ctx.fillRect(-88 + motion.drift * 0.08, 4, 4, 32);
    ctx.fillStyle = blendHex(p.accent2, '#ffffff', 0.28); roundRect(ctx, 32, -6, 46, 56, 10); ctx.fill(); ctx.stroke(); ctx.beginPath(); ctx.arc(82, 18, 12, -Math.PI / 2, Math.PI / 2); ctx.stroke();
    ctx.strokeStyle = p.line; ctx.lineWidth = profile.lineWidth; ctx.beginPath(); ctx.moveTo(138, -8); ctx.lineTo(180, -94); ctx.lineTo(142, -120); ctx.stroke(); ctx.fillStyle = blendHex(p.accent, p.glow, 0.5); triangle(ctx, 120, -4, 164, -30, 190, 14); ctx.fill(); ctx.stroke();
    ctx.fillStyle = blendHex(p.accent2, '#4faf68', 0.45); for (let i = 0; i < 5; i += 1) { ctx.beginPath(); ctx.ellipse(-204 + i * 10, 22 - i * 12, 12, 28, -0.3 + i * 0.15, 0, Math.PI * 2); ctx.fill(); }
    ctx.fillStyle = blendHex(p.accent2, p.line, 0.15); roundRect(ctx, -218, 30, 40, 34, 12); ctx.fill(); ctx.stroke();
    if (profile.brushiness > 0.2) { ctx.strokeStyle = applyAlpha(p.line, 0.08 + profile.brushiness * 0.12); ctx.lineWidth = 14; for (let i = 0; i < 7; i += 1) { ctx.beginPath(); ctx.moveTo(-210 + i * 60, -220 + i * 6); ctx.quadraticCurveTo(-120 + i * 20, -260 + i * 4, -10 + i * 16, -200 + i * 12); ctx.stroke(); } }
    if (profile.bgPattern === 'speedlines') { ctx.strokeStyle = applyAlpha(p.glow, 0.24); ctx.lineWidth = 4; for (let i = 0; i < 8; i += 1) { ctx.beginPath(); ctx.moveTo(-280, -180 + i * 34); ctx.lineTo(-40, -160 + i * 28); ctx.stroke(); } }
    ctx.restore();
  }

  function drawProductPoster(ctx, scene, width, height, profile, motion) {
    const p = scene.palette; const cx = width * 0.74 + scene.probe.composition * 88; const cy = height * 0.58 + motion.floatY * 0.75; const bottle = blendHex(p.accent, p.surface, 0.35);
    ctx.save(); ctx.translate(cx, cy); ctx.rotate(profile.dynamicSkew * 0.55);
    ctx.fillStyle = applyAlpha('#000000', 0.08 + profile.shadowAlpha); ctx.beginPath(); ctx.ellipse(0, 190, 110, 24, 0, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = applyAlpha(p.accent2, 0.36); ctx.lineWidth = 8; ctx.beginPath(); ctx.arc(0, 18, 162 + motion.orbit * 0.4, 0.2, Math.PI * 1.6); ctx.stroke(); ctx.beginPath(); ctx.arc(-12, 18, 124 - motion.orbit * 0.3, 1.0, Math.PI * 2.2); ctx.stroke();
    ctx.fillStyle = bottle; ctx.strokeStyle = p.line; ctx.lineWidth = profile.lineWidth; roundRect(ctx, -78, -110, 156, 250, 46); ctx.fill(); ctx.stroke(); ctx.fillStyle = blendHex(bottle, '#ffffff', 0.44); roundRect(ctx, -54, -54, 108, 122, 26); ctx.fill(); ctx.stroke(); ctx.fillStyle = blendHex(p.glow, '#ffffff', 0.3); roundRect(ctx, -20, -180, 40, 76, 18); ctx.fill(); ctx.stroke(); ctx.fillRect(-28, -112, 56, 18); ctx.strokeRect(-28, -112, 56, 18);
    ctx.fillStyle = applyAlpha(p.line, 0.14); ctx.fillRect(-30, -28, 60, 10); ctx.fillRect(-30, -2, 72, 8); ctx.fillRect(-30, 20, 52, 8); ctx.fillStyle = applyAlpha('#ffffff', profile.name === 'splash-art-lite' ? 0.42 : 0.28); ctx.beginPath(); ctx.ellipse(-34, 12, 16, 96, 0.14, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = p.accent2; roundRect(ctx, 110, -58, 110, 34, 17); ctx.fill(); ctx.fillStyle = profile.name === 'splash-art-lite' ? '#11182a' : '#ffffff'; ctx.font = '700 16px system-ui, sans-serif'; ctx.fillText('SCENE COMP', 122, -36);
    if (profile.name === 'splash-art-lite') { drawStar(ctx, -130, -120, 5, 10, 22 * motion.pulse, p.accent2); drawStar(ctx, 160, 112, 5, 8, 18 * motion.pulse, p.accent); }
    if (profile.brushiness > 0.3) { ctx.strokeStyle = applyAlpha(p.line, 0.12); ctx.lineWidth = 12; for (let i = 0; i < 5; i += 1) { ctx.beginPath(); ctx.moveTo(-168 + i * 28, -86 + i * 20); ctx.quadraticCurveTo(-54 + i * 16, -132 + i * 4, 124 + i * 10, -20 + i * 18); ctx.stroke(); } }
    ctx.restore();
  }

  function posterizeChannel(v, levels) {
    const lv = Math.max(2, Math.round(levels || 6));
    const q = Math.round((v / 255) * (lv - 1));
    return Math.round((q / (lv - 1)) * 255);
  }

  function mixChannel(a, b, t) { return Math.round(a * (1 - t) + b * t); }

  function buildStyledSourceImage(sourceImage, scene) {
    const style = scene.probe.style;
    const controls = scene.compiler && scene.compiler.controls ? scene.compiler.controls : {};
    const detail = clamp(scene.probe.detail || 0.5, 0, 1);
    const mood = clamp(scene.probe.mood || 0.5, 0, 1);
    const energy = clamp(scene.probe.energy || 0.5, 0, 1);
    const warmthBias = clamp(controls.warmthBias || 0, -1, 1);
    const edges = sobelEdges(sourceImage);
    const out = new Uint8ClampedArray(sourceImage.data.length);
    for (let y = 0; y < sourceImage.height; y += 1) {
      for (let x = 0; x < sourceImage.width; x += 1) {
        const idx = getIndex(x, y, sourceImage.width);
        let r = sourceImage.data[idx];
        let g = sourceImage.data[idx + 1];
        let b = sourceImage.data[idx + 2];
        const a = sourceImage.data[idx + 3];
        let [h, s, l] = rgbToHsl(r, g, b);
        h = hueWrap(h + warmthBias * 0.018);
        if (style === 'anime') {
          s = clamp(s * (1.20 + mood * 0.08), 0, 1);
          l = clamp(l * 1.03, 0, 1);
          [r, g, b] = hslToRgb(h, s, l);
          const levels = 5 + Math.round(detail * 3);
          r = posterizeChannel(r, levels); g = posterizeChannel(g, levels); b = posterizeChannel(b, levels);
          if (edges[y * sourceImage.width + x] > 78 - detail * 16) {
            const [lr, lg, lb] = hexToRgb(scene.palette.line);
            r = mixChannel(r, lr, 0.62); g = mixChannel(g, lg, 0.62); b = mixChannel(b, lb, 0.62);
          }
        } else if (style === 'storybook') {
          s = clamp(s * 0.76, 0, 1);
          l = clamp(l * 1.06 + 0.01, 0, 1);
          [r, g, b] = hslToRgb(hueWrap(h - 0.01), s, l);
          r = mixChannel(r, 241, 0.18 + mood * 0.06);
          g = mixChannel(g, 223, 0.18 + mood * 0.06);
          b = mixChannel(b, 191, 0.18 + mood * 0.06);
        } else if (style === 'painterly') {
          s = clamp(s * 0.92, 0, 1);
          l = clamp(l * 1.01, 0, 1);
          [r, g, b] = hslToRgb(hueWrap(h + 0.004), s, l);
          const levels = 10 + Math.round(detail * 4);
          r = posterizeChannel(r, levels); g = posterizeChannel(g, levels); b = posterizeChannel(b, levels);
          if (edges[y * sourceImage.width + x] > 120) {
            r = mixChannel(r, 235, 0.08); g = mixChannel(g, 232, 0.08); b = mixChannel(b, 228, 0.08);
          }
        } else if (style === 'splash-art-lite') {
          s = clamp(s * (1.28 + energy * 0.06), 0, 1);
          l = clamp(l * 0.94, 0, 1);
          [r, g, b] = hslToRgb(hueWrap(h - 0.015), s, l);
          const contrast = 1.12 + energy * 0.18;
          r = clamp((r - 128) * contrast + 128, 0, 255);
          g = clamp((g - 128) * contrast + 128, 0, 255);
          b = clamp((b - 128) * contrast + 128, 0, 255);
          if (edges[y * sourceImage.width + x] > 96) {
            r = mixChannel(r, 255, 0.12); g = mixChannel(g, 255, 0.12); b = mixChannel(b, 255, 0.12);
          }
        } else {
          s = clamp(s * (1.04 + mood * 0.03), 0, 1);
          l = clamp(l * 1.01, 0, 1);
          [r, g, b] = hslToRgb(h, s, l);
        }
        out[idx] = Math.round(r);
        out[idx + 1] = Math.round(g);
        out[idx + 2] = Math.round(b);
        out[idx + 3] = a;
      }
    }
    return { width: sourceImage.width, height: sourceImage.height, data: out };
  }


  function computeSemanticLayerPlan(sourceImage, scene) {
    const detail = clamp(scene.probe.detail || 0.5, 0, 1);
    const mood = clamp(scene.probe.mood || 0.5, 0, 1);
    const energy = clamp(scene.probe.energy || 0.5, 0, 1);
    return {
      subjectThreshold: clamp(0.46 - detail * 0.10 + energy * 0.02, 0.28, 0.58),
      glowThreshold: clamp(0.62 - mood * 0.05 - energy * 0.04, 0.42, 0.76),
      foregroundThreshold: clamp(0.52 - detail * 0.06, 0.34, 0.72),
      foregroundStartY: clamp(0.62 - scene.probe.composition * 0.10, 0.48, 0.82),
      edgeBoost: clamp(0.72 + detail * 0.36, 0.6, 1.2),
      centerBias: clamp(0.90 + mood * 0.18, 0.75, 1.18),
      glowBoost: clamp(0.92 + energy * 0.28, 0.8, 1.3),
      sourceWidth: sourceImage.width,
      sourceHeight: sourceImage.height
    };
  }

  function createBlankImageLike(image) {
    return { width: image.width, height: image.height, data: new Uint8ClampedArray(image.data.length) };
  }

  function buildSemanticRenderBundle(sourceImage, scene) {
    const styled = buildStyledSourceImage(sourceImage, scene);
    const plan = (scene.semantic && scene.semantic.plan) ? scene.semantic.plan : computeSemanticLayerPlan(sourceImage, scene);
    const edges = sobelEdges(sourceImage);
    const background = createBlankImageLike(styled);
    const subject = createBlankImageLike(styled);
    const glow = createBlankImageLike(styled);
    const foreground = createBlankImageLike(styled);
    const [avgR, avgG, avgB] = hexToRgb(scene.compiler && scene.compiler.source ? scene.compiler.source.averageHex : '#808080');
    const [glowR, glowG, glowB] = hexToRgb(scene.palette.glow);
    const [accR, accG, accB] = hexToRgb(scene.palette.accent);
    let counts = { background: 0, subject: 0, glow: 0, foreground: 0 };
    const w = sourceImage.width;
    const h = sourceImage.height;
    for (let y = 0; y < h; y += 1) {
      for (let x = 0; x < w; x += 1) {
        const idx = getIndex(x, y, w);
        const sr = styled.data[idx], sg = styled.data[idx + 1], sb = styled.data[idx + 2], sa = styled.data[idx + 3];
        const r = sourceImage.data[idx], g = sourceImage.data[idx + 1], b = sourceImage.data[idx + 2];
        const edge = edges[y * w + x] / 255;
        const luma = computeLuma(r, g, b) / 255;
        const [_, sat] = rgbToHsl(r, g, b);
        const nx = w > 1 ? x / (w - 1) : 0.5;
        const ny = h > 1 ? y / (h - 1) : 0.5;
        const dx = nx - 0.5;
        const dy = ny - 0.5;
        const center = clamp(1 - Math.sqrt(dx * dx * 1.15 + dy * dy) * 1.55, 0, 1) * plan.centerBias;
        const colorDist = Math.sqrt((r - avgR) ** 2 + (g - avgG) ** 2 + (b - avgB) ** 2) / 441.6729559;
        const bottomFactor = clamp((ny - plan.foregroundStartY) / Math.max(0.0001, 1 - plan.foregroundStartY), 0, 1);
        const subjectScore = clamp(edge * 0.28 * plan.edgeBoost + sat * 0.18 + center * 0.26 + colorDist * 0.28, 0, 1);
        const glowScore = clamp(luma * 0.46 + sat * 0.22 + colorDist * 0.12 + (1 - edge) * 0.08 + Math.max(0, luma - 0.55) * 0.24 * plan.glowBoost, 0, 1);
        const foregroundScore = clamp(edge * 0.30 + sat * 0.14 + colorDist * 0.14 + bottomFactor * 0.42, 0, 1);
        const subjectAlpha = subjectScore > plan.subjectThreshold ? clamp((subjectScore - plan.subjectThreshold) / Math.max(0.001, 1 - plan.subjectThreshold), 0, 1) : 0;
        const glowAlpha = glowScore > plan.glowThreshold ? clamp((glowScore - plan.glowThreshold) / Math.max(0.001, 1 - plan.glowThreshold), 0, 1) : 0;
        const foregroundAlpha = foregroundScore > plan.foregroundThreshold ? clamp((foregroundScore - plan.foregroundThreshold) / Math.max(0.001, 1 - plan.foregroundThreshold), 0, 1) : 0;
        const backgroundAlpha = clamp(0.96 - subjectAlpha * 0.72 - foregroundAlpha * 0.35, 0.10, 1);

        background.data[idx] = mixChannel(sr, avgR, 0.06);
        background.data[idx + 1] = mixChannel(sg, avgG, 0.06);
        background.data[idx + 2] = mixChannel(sb, avgB, 0.06);
        background.data[idx + 3] = Math.round(sa * backgroundAlpha);
        counts.background += background.data[idx + 3] > 0 ? 1 : 0;

        if (subjectAlpha > 0) {
          subject.data[idx] = mixChannel(sr, accR, 0.04);
          subject.data[idx + 1] = mixChannel(sg, accG, 0.04);
          subject.data[idx + 2] = mixChannel(sb, accB, 0.04);
          subject.data[idx + 3] = Math.round(sa * clamp(0.30 + subjectAlpha * 0.90, 0, 1));
          counts.subject += 1;
        }

        if (glowAlpha > 0) {
          glow.data[idx] = mixChannel(sr, glowR, 0.42);
          glow.data[idx + 1] = mixChannel(sg, glowG, 0.42);
          glow.data[idx + 2] = mixChannel(sb, glowB, 0.42);
          glow.data[idx + 3] = Math.round(255 * clamp(glowAlpha * (0.32 + scene.probe.energy * 0.38), 0, 0.88));
          counts.glow += 1;
        }

        if (foregroundAlpha > 0) {
          foreground.data[idx] = mixChannel(sr, 255, 0.04);
          foreground.data[idx + 1] = mixChannel(sg, 255, 0.04);
          foreground.data[idx + 2] = mixChannel(sb, 255, 0.04);
          foreground.data[idx + 3] = Math.round(sa * clamp(0.20 + foregroundAlpha * 0.85, 0, 1));
          counts.foreground += 1;
        }
      }
    }
    return {
      mode: 'multi-layer-semantic-v0.9',
      width: w,
      height: h,
      styled,
      layers: { background, subject, glow, foreground },
      plan,
      stats: {
        backgroundCoverage: Number((counts.background / (w * h)).toFixed(4)),
        subjectCoverage: Number((counts.subject / (w * h)).toFixed(4)),
        glowCoverage: Number((counts.glow / (w * h)).toFixed(4)),
        foregroundCoverage: Number((counts.foreground / (w * h)).toFixed(4))
      }
    };
  }

  function drawSemanticBundle(ctx, scene, width, height, profile, motion, bundle) {
    if (!bundle || !bundle.styledCanvas) return;
    const vis = scene.compiler && scene.compiler.layerVisibility ? scene.compiler.layerVisibility : { background: true, subject: true, glow: true, foreground: true, panel: true };
    const left = Math.max(560, width * 0.37);
    const top = 82;
    const boxW = width - left - 54;
    const boxH = height - top - 64;
    const scale = Math.min(boxW / bundle.width, boxH / bundle.height);
    const drawW = bundle.width * scale;
    const drawH = bundle.height * scale;
    const ox = left + (boxW - drawW) / 2 + scene.probe.composition * 34;
    const oy = top + (boxH - drawH) / 2 + motion.floatY * 0.08;
    ctx.save();
    ctx.fillStyle = applyAlpha(scene.palette.surface, profile.name === 'splash-art-lite' ? 0.10 : 0.46);
    roundRect(ctx, ox - 18, oy - 18, drawW + 36, drawH + 36, profile.cornerRadius + 4);
    ctx.fill();
    ctx.shadowColor = applyAlpha('#000000', 0.18);
    ctx.shadowBlur = 30;
    ctx.shadowOffsetY = 14;
    ctx.fillStyle = applyAlpha('#000000', 0.04);
    roundRect(ctx, ox - 8, oy - 8, drawW + 16, drawH + 16, profile.cornerRadius);
    ctx.fill();
    ctx.shadowColor = 'transparent';

    if (vis.background !== false && bundle.layers.backgroundCanvas) ctx.drawImage(bundle.layers.backgroundCanvas, ox, oy, drawW, drawH);
    if (vis.glow !== false && bundle.layers.glowCanvas) {
      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      if ('filter' in ctx) ctx.filter = `blur(${Math.max(6, Math.round(scale * 6))}px) brightness(1.08)`;
      ctx.drawImage(bundle.layers.glowCanvas, ox, oy, drawW, drawH);
      ctx.restore();
    }
    if (vis.subject !== false && bundle.layers.subjectCanvas) ctx.drawImage(bundle.layers.subjectCanvas, ox, oy + motion.floatY * 0.04, drawW, drawH);
    if (vis.foreground !== false && bundle.layers.foregroundCanvas) {
      ctx.save();
      ctx.globalCompositeOperation = 'overlay';
      ctx.drawImage(bundle.layers.foregroundCanvas, ox, oy, drawW, drawH);
      ctx.restore();
      ctx.drawImage(bundle.layers.foregroundCanvas, ox, oy, drawW, drawH);
    }

    ctx.strokeStyle = applyAlpha(scene.palette.line, profile.name === 'anime' ? 0.34 : 0.22);
    ctx.lineWidth = profile.name === 'anime' ? 3 : 2;
    roundRect(ctx, ox, oy, drawW, drawH, 14);
    ctx.stroke();

    const chips = (scene.semantic && Array.isArray(scene.semantic.layers) ? scene.semantic.layers : []).filter((layer) => vis[layer.id] !== false);
    let chipX = ox + 12;
    const chipY = oy + drawH + 16;
    ctx.font = '700 12px system-ui, sans-serif';
    for (const layer of chips) {
      const label = layer.label.toUpperCase();
      const tw = ctx.measureText(label).width;
      ctx.fillStyle = applyAlpha(scene.palette.surface, 0.84);
      roundRect(ctx, chipX, chipY, tw + 18, 24, 12);
      ctx.fill();
      ctx.fillStyle = scene.palette.line;
      ctx.fillText(label, chipX + 9, chipY + 16);
      chipX += tw + 26;
      if (chipX > ox + drawW - 120) break;
    }
    ctx.restore();
  }

  function drawHighFidelitySubject(ctx, scene, width, height, profile, motion, renderedSource) {
    if (!renderedSource) return;
    const left = Math.max(560, width * 0.37);
    const top = 82;
    const boxW = width - left - 54;
    const boxH = height - top - 64;
    const scale = Math.min(boxW / renderedSource.width, boxH / renderedSource.height);
    const drawW = renderedSource.width * scale;
    const drawH = renderedSource.height * scale;
    const ox = left + (boxW - drawW) / 2 + scene.probe.composition * 34;
    const oy = top + (boxH - drawH) / 2 + motion.floatY * 0.10;
    ctx.save();
    ctx.fillStyle = applyAlpha(scene.palette.surface, profile.name === 'splash-art-lite' ? 0.12 : 0.52);
    roundRect(ctx, ox - 18, oy - 18, drawW + 36, drawH + 36, profile.cornerRadius + 4);
    ctx.fill();
    ctx.shadowColor = applyAlpha('#000000', 0.16);
    ctx.shadowBlur = 30;
    ctx.shadowOffsetY = 14;
    ctx.fillStyle = applyAlpha('#000000', 0.04);
    roundRect(ctx, ox - 8, oy - 8, drawW + 16, drawH + 16, profile.cornerRadius);
    ctx.fill();
    ctx.shadowColor = 'transparent';
    ctx.drawImage(renderedSource, ox, oy, drawW, drawH);
    ctx.strokeStyle = applyAlpha(scene.palette.line, profile.name === 'anime' ? 0.34 : 0.22);
    ctx.lineWidth = profile.name === 'anime' ? 3 : 2;
    roundRect(ctx, ox, oy, drawW, drawH, 14);
    ctx.stroke();
    if (profile.bgPattern === 'speedlines') {
      ctx.strokeStyle = applyAlpha(scene.palette.accent, 0.16);
      ctx.lineWidth = 3;
      for (let i = 0; i < 10; i += 1) {
        ctx.beginPath();
        ctx.moveTo(ox - 8, oy + drawH * (i / 10));
        ctx.lineTo(ox + drawW + 10, oy + drawH * (i / 10) - 10);
        ctx.stroke();
      }
    }
    if (profile.brushiness > 0.2) {
      ctx.strokeStyle = applyAlpha(scene.palette.glow, 0.10 + profile.brushiness * 0.10);
      ctx.lineWidth = 5 + profile.brushiness * 6;
      for (let i = 0; i < 8; i += 1) {
        const yy = oy + drawH * (0.08 + i * 0.11);
        ctx.beginPath();
        ctx.moveTo(ox + 12, yy);
        ctx.quadraticCurveTo(ox + drawW * 0.48, yy - 20 + i * 2, ox + drawW - 8, yy + 6);
        ctx.stroke();
      }
    }
    if (profile.name === 'storybook') {
      ctx.fillStyle = applyAlpha('#e8d8ba', 0.10);
      for (let i = 0; i < 140; i += 1) {
        const px = ox + (i * 61 % Math.max(1, Math.floor(drawW)));
        const py = oy + (i * 47 % Math.max(1, Math.floor(drawH)));
        ctx.fillRect(px, py, 1.4, 1.4);
      }
    }
    ctx.restore();
  }


  function drawProductionOutput(ctx, scene, width, height, renderBundle, options) {
    validateScene(scene);
    const profile = computeStyleProfile(scene);
    const bundle = renderBundle || null;
    const vis = scene.compiler && scene.compiler.layerVisibility ? scene.compiler.layerVisibility : { background: true, subject: true, glow: true, foreground: true, panel: true };
    const opts = options || {};
    const transparent = !!opts.transparentBackground;
    if (!transparent) {
      ctx.fillStyle = scene.palette.background || '#ffffff';
      ctx.fillRect(0, 0, width, height);
    } else {
      ctx.clearRect(0, 0, width, height);
    }

    if (bundle && bundle.mode && String(bundle.mode).startsWith('multi-layer-semantic')) {
      if (vis.background !== false && bundle.layers.backgroundCanvas) ctx.drawImage(bundle.layers.backgroundCanvas, 0, 0, width, height);
      if (vis.glow !== false && bundle.layers.glowCanvas) {
        ctx.save();
        ctx.globalCompositeOperation = 'screen';
        if ('filter' in ctx) ctx.filter = `blur(${Math.max(1, Math.round(Math.max(width / bundle.width, height / bundle.height) * 2))}px) brightness(1.04)`;
        ctx.drawImage(bundle.layers.glowCanvas, 0, 0, width, height);
        ctx.restore();
      }
      if (vis.subject !== false && bundle.layers.subjectCanvas) ctx.drawImage(bundle.layers.subjectCanvas, 0, 0, width, height);
      if (vis.foreground !== false && bundle.layers.foregroundCanvas) {
        ctx.save();
        ctx.globalCompositeOperation = 'overlay';
        ctx.drawImage(bundle.layers.foregroundCanvas, 0, 0, width, height);
        ctx.restore();
        ctx.drawImage(bundle.layers.foregroundCanvas, 0, 0, width, height);
      }
    } else if (bundle && bundle.styledCanvas) {
      ctx.drawImage(bundle.styledCanvas, 0, 0, width, height);
    }

    if (profile.name === 'storybook') {
      ctx.save();
      ctx.fillStyle = applyAlpha('#ead9bb', 0.05);
      for (let i = 0; i < 240; i += 1) {
        const px = (i * 97) % Math.max(1, Math.floor(width));
        const py = (i * 71) % Math.max(1, Math.floor(height));
        ctx.fillRect(px, py, 1.2, 1.2);
      }
      ctx.restore();
    } else if (profile.name === 'anime') {
      ctx.save();
      ctx.strokeStyle = applyAlpha(scene.palette.line, 0.10);
      ctx.lineWidth = 2;
      for (let i = 0; i < 8; i += 1) {
        const y = height * (i / 8);
        ctx.beginPath();
        ctx.moveTo(0, y + 8);
        ctx.lineTo(width, y - 6);
        ctx.stroke();
      }
      ctx.restore();
    } else if (profile.name === 'painterly') {
      ctx.save();
      ctx.strokeStyle = applyAlpha(scene.palette.glow, 0.06);
      ctx.lineWidth = 5;
      for (let i = 0; i < 10; i += 1) {
        const yy = height * (0.08 + i * 0.09);
        ctx.beginPath();
        ctx.moveTo(width * 0.02, yy);
        ctx.quadraticCurveTo(width * 0.45, yy - 12 + i * 2, width * 0.98, yy + 10);
        ctx.stroke();
      }
      ctx.restore();
    }
  }

  function drawScene(ctx, scene, width, height, timeSec, renderBundle) {
    validateScene(scene);
    const profile = computeStyleProfile(scene);
    const motion = computeMotionState(scene, timeSec);
    drawBackground(ctx, scene, width, height, profile, motion);
    const panelVisible = !(scene.compiler && scene.compiler.layerVisibility && scene.compiler.layerVisibility.panel === false);
    if (panelVisible) drawCopyPanel(ctx, scene, width, height, profile);
    drawStatusBadge(ctx, scene, width, profile, motion);
    if (renderBundle && renderBundle.mode && String(renderBundle.mode).startsWith('multi-layer-semantic')) drawSemanticBundle(ctx, scene, width, height, profile, motion, renderBundle);
    else if (renderBundle && renderBundle.styledCanvas && scene.compiler && scene.compiler.highFidelity && scene.compiler.highFidelity.enabled) drawHighFidelitySubject(ctx, scene, width, height, profile, motion, renderBundle.styledCanvas);
    else if (scene.reconstruction && scene.reconstruction.kind === 'region-map') drawReconstructionSubject(ctx, scene, width, height, profile, motion);
    else if (scene.probe.subject === 'portrait') drawPortrait(ctx, scene, width, height, profile, motion);
    else if (scene.probe.subject === 'scene') drawSceneSubject(ctx, scene, width, height, profile, motion);
    else drawProductPoster(ctx, scene, width, height, profile, motion);
    return motion;
  }

  function strictRgbaKey(r, g, b, a) {
    return `${r},${g},${b},${a}`;
  }

  function validateStrictImageObject(image) {
    if (!image || typeof image !== 'object') throw new Error('Strict symbolic compile requires an image object');
    const width = Number(image.width);
    const height = Number(image.height);
    if (!Number.isInteger(width) || width <= 0 || !Number.isInteger(height) || height <= 0) {
      throw new Error('Strict symbolic image dimensions must be positive integers');
    }
    if (!image.data || typeof image.data.length !== 'number' || image.data.length !== width * height * 4) {
      throw new Error('Strict symbolic image requires RGBA data with width * height * 4 entries');
    }
    return { width, height };
  }

  function buildStrictRegions(indexGrid, width, height) {
    const total = width * height;
    const regionIds = new Int32Array(total);
    regionIds.fill(-1);
    const queue = new Int32Array(total);
    const regions = [];
    let nextRegion = 0;

    for (let start = 0; start < total; start += 1) {
      if (regionIds[start] !== -1) continue;
      const paletteIndex = indexGrid[start];
      const regionId = nextRegion++;
      let head = 0;
      let tail = 0;
      queue[tail++] = start;
      regionIds[start] = regionId;
      let area = 0;
      let minX = width;
      let minY = height;
      let maxX = -1;
      let maxY = -1;
      let sumX = 0;
      let sumY = 0;

      while (head < tail) {
        const pos = queue[head++];
        const x = pos % width;
        const y = Math.floor(pos / width);
        area += 1;
        sumX += x;
        sumY += y;
        if (x < minX) minX = x;
        if (x > maxX) maxX = x;
        if (y < minY) minY = y;
        if (y > maxY) maxY = y;

        const tryEnqueue = (n) => {
          if (regionIds[n] === -1 && indexGrid[n] === paletteIndex) {
            regionIds[n] = regionId;
            queue[tail++] = n;
          }
        };
        if (x > 0) tryEnqueue(pos - 1);
        if (x + 1 < width) tryEnqueue(pos + 1);
        if (y > 0) tryEnqueue(pos - width);
        if (y + 1 < height) tryEnqueue(pos + width);
      }

      regions.push({
        id: `REGION_${String(regionId).padStart(4, '0')}`,
        paletteIndex,
        area,
        bbox: { x: minX, y: minY, width: maxX - minX + 1, height: maxY - minY + 1 },
        centroid: { x: Number((sumX / area).toFixed(4)), y: Number((sumY / area).toFixed(4)) }
      });
    }

    const adjacencyKeys = new Set();
    for (let y = 0; y < height; y += 1) {
      for (let x = 0; x < width; x += 1) {
        const pos = y * width + x;
        const a = regionIds[pos];
        if (x + 1 < width) {
          const b = regionIds[pos + 1];
          if (a !== b) adjacencyKeys.add(a < b ? `${a}:${b}` : `${b}:${a}`);
        }
        if (y + 1 < height) {
          const b = regionIds[pos + width];
          if (a !== b) adjacencyKeys.add(a < b ? `${a}:${b}` : `${b}:${a}`);
        }
      }
    }

    const adjacency = Array.from(adjacencyKeys).map((key) => {
      const [a, b] = key.split(':').map(Number);
      return { a: regions[a].id, b: regions[b].id };
    });
    return { regions, adjacency, regionIds };
  }


  function extractStrictContourAnchors(mask, bbox, centroid) {
    const keyOf = (x, y) => `${x},${y}`;
    const anchorMap = new Map();
    const width = bbox.width;
    const height = bbox.height;

    function occupied(x, y) {
      if (x < 0 || y < 0 || x >= width || y >= height) return 0;
      return mask[y * width + x] ? 1 : 0;
    }

    function addAnchor(x, y, type, source = 'corner') {
      const key = keyOf(x, y);
      if (!anchorMap.has(key)) {
        anchorMap.set(key, { x, y, type, source });
      } else {
        const existing = anchorMap.get(key);
        if (existing.source !== 'corner' && source === 'corner') anchorMap.set(key, { x, y, type, source });
      }
    }

    for (let y = 0; y < height; y += 1) {
      for (let x = 0; x < width; x += 1) {
        if (!occupied(x, y)) continue;
        const n = !occupied(x, y - 1);
        const e = !occupied(x + 1, y);
        const s = !occupied(x, y + 1);
        const w = !occupied(x - 1, y);
        if (n && w) addAnchor(bbox.x + x, bbox.y + y, 'NW');
        if (n && e) addAnchor(bbox.x + x + 1, bbox.y + y, 'NE');
        if (s && e) addAnchor(bbox.x + x + 1, bbox.y + y + 1, 'SE');
        if (s && w) addAnchor(bbox.x + x, bbox.y + y + 1, 'SW');
      }
    }

    if (anchorMap.size < 4) {
      let north = null; let east = null; let south = null; let west = null;
      for (let y = 0; y < height; y += 1) {
        for (let x = 0; x < width; x += 1) {
          if (!occupied(x, y)) continue;
          const gx = bbox.x + x + 0.5;
          const gy = bbox.y + y + 0.5;
          if (!north || gy < north.y || (gy === north.y && gx < north.x)) north = { x: gx, y: gy, type: 'N' };
          if (!east || gx > east.x || (gx === east.x && gy < east.y)) east = { x: gx, y: gy, type: 'E' };
          if (!south || gy > south.y || (gy === south.y && gx < south.x)) south = { x: gx, y: gy, type: 'S' };
          if (!west || gx < west.x || (gx === west.x && gy < west.y)) west = { x: gx, y: gy, type: 'W' };
        }
      }
      for (const point of [north, east, south, west]) {
        if (point) addAnchor(point.x, point.y, point.type, 'extrema');
      }
    }

    const anchors = Array.from(anchorMap.values()).map((point) => {
      const angle = Math.atan2(point.y - centroid.y, point.x - centroid.x);
      return { ...point, angle: Number(angle.toFixed(6)) };
    });
    anchors.sort((a, b) => a.angle - b.angle || a.y - b.y || a.x - b.x);
    return {
      orderedAnchors: anchors,
      turningPoints: anchors.map(({ x, y, type, angle, source }) => ({ x, y, type, angle, source })),
      anchorCount: anchors.length,
      turnCount: anchors.length
    };
  }



  function extractStrictSkeletonGraph(medial, bbox, options = {}) {
    const empty = {
      algorithm: 'skeleton-graph-v0.1',
      nodes: [],
      edges: [],
      nodeCount: 0,
      edgeCount: 0,
      branchlessPathCount: 0,
      skipped: !medial || Boolean(medial && medial.skipped)
    };
    if (!medial || medial.skipped || !Array.isArray(medial.skeletonPixels) || medial.skeletonPixels.length === 0) return empty;

    const pointMap = new Map();
    for (const point of medial.skeletonPixels) {
      const degree = Number.isInteger(point.degree) ? point.degree : 0;
      pointMap.set(`${point.x},${point.y}`, { x: point.x, y: point.y, radius: point.radius, degree });
    }
    const neighborOffsets = [
      [-1, -1], [0, -1], [1, -1],
      [-1, 0],            [1, 0],
      [-1, 1],  [0, 1],  [1, 1]
    ];
    const getNeighbors = (key) => {
      const point = pointMap.get(key);
      if (!point) return [];
      const out = [];
      for (const [dx, dy] of neighborOffsets) {
        const nk = `${point.x + dx},${point.y + dy}`;
        if (pointMap.has(nk)) out.push(nk);
      }
      return out;
    };
    const edgeVisitKey = (a, b) => (a < b ? `${a}|${b}` : `${b}|${a}`);
    const visitedAdj = new Set();

    const nodeKeyToId = new Map();
    const nodes = [];
    function ensureNode(key, kindOverride = null) {
      if (nodeKeyToId.has(key)) return nodeKeyToId.get(key);
      const point = pointMap.get(key);
      const kind = kindOverride || (point.degree <= 1 ? 'endpoint' : point.degree >= 3 ? 'junction' : 'cycle-anchor');
      const id = `n${nodes.length}`;
      nodes.push({ id, kind, x: point.x, y: point.y, radius: point.radius, degree: point.degree });
      nodeKeyToId.set(key, id);
      return id;
    }

    for (const point of medial.endpointPixels || []) ensureNode(`${point.x},${point.y}`, 'endpoint');
    for (const point of medial.junctionPixels || []) ensureNode(`${point.x},${point.y}`, 'junction');
    for (const point of medial.skeletonPixels) {
      if (point.degree === 0) ensureNode(`${point.x},${point.y}`, 'isolated');
    }

    const edges = [];
    const addEdge = (fromKey, toKey, polyline) => {
      const fromId = ensureNode(fromKey);
      const toId = ensureNode(toKey);
      edges.push({
        id: `e${edges.length}`,
        from: fromId,
        to: toId,
        length: polyline.length,
        polyline: polyline.map((key) => {
          const point = pointMap.get(key);
          return { x: point.x, y: point.y, radius: point.radius };
        })
      });
    };

    const nodeKeys = Array.from(nodeKeyToId.keys()).sort();
    for (const startKey of nodeKeys) {
      for (const nextKey of getNeighbors(startKey)) {
        const firstStepKey = edgeVisitKey(startKey, nextKey);
        if (visitedAdj.has(firstStepKey)) continue;
        const polyline = [startKey, nextKey];
        visitedAdj.add(firstStepKey);
        let prevKey = startKey;
        let currentKey = nextKey;
        const guard = pointMap.size * 4;
        let steps = 0;
        while (!nodeKeyToId.has(currentKey) && steps < guard) {
          const candidates = getNeighbors(currentKey).filter((key) => key !== prevKey);
          if (!candidates.length) break;
          const next = candidates.sort()[0];
          const segmentKey = edgeVisitKey(currentKey, next);
          if (visitedAdj.has(segmentKey)) break;
          visitedAdj.add(segmentKey);
          prevKey = currentKey;
          currentKey = next;
          polyline.push(currentKey);
          steps += 1;
        }
        addEdge(startKey, currentKey, polyline);
      }
    }

    const remainingKeys = Array.from(pointMap.keys()).sort();
    for (const startKey of remainingKeys) {
      const neighbors = getNeighbors(startKey);
      if (!neighbors.length) continue;
      const allVisited = neighbors.every((neighbor) => visitedAdj.has(edgeVisitKey(startKey, neighbor)));
      if (allVisited) continue;
      ensureNode(startKey, 'cycle-anchor');
      const polyline = [startKey];
      let prevKey = null;
      let currentKey = startKey;
      const guard = pointMap.size * 8;
      let steps = 0;
      while (steps < guard) {
        const candidates = getNeighbors(currentKey).filter((key) => key !== prevKey).sort();
        if (!candidates.length) break;
        let next = candidates.find((key) => !visitedAdj.has(edgeVisitKey(currentKey, key)));
        if (!next) next = candidates[0];
        visitedAdj.add(edgeVisitKey(currentKey, next));
        prevKey = currentKey;
        currentKey = next;
        polyline.push(currentKey);
        steps += 1;
        if (currentKey === startKey) break;
      }
      addEdge(startKey, startKey, polyline);
    }

    return {
      algorithm: 'skeleton-graph-v0.1',
      nodes,
      edges,
      nodeCount: nodes.length,
      edgeCount: edges.length,
      branchlessPathCount: edges.length,
      skipped: false
    };
  }

  function extractStrictMedialHints(mask, bbox, options = {}) {
    const width = bbox.width;
    const height = bbox.height;
    const skip = Boolean(options.skip);
    const empty = {
      algorithm: 'zhang-suen+manhattan-distance-v0.1',
      skeletonPixels: [],
      endpointPixels: [],
      junctionPixels: [],
      skeletonPixelCount: 0,
      endpointCount: 0,
      junctionCount: 0,
      maxRadius: 0,
      meanRadius: 0,
      thinningIterations: 0,
      graph: { algorithm: 'skeleton-graph-v0.1', nodes: [], edges: [], nodeCount: 0, edgeCount: 0, branchlessPathCount: 0, skipped: skip },
      skipped: skip
    };
    if (skip || !mask || width <= 0 || height <= 0) return empty;

    let occupiedCount = 0;
    for (let i = 0; i < mask.length; i += 1) if (mask[i]) occupiedCount += 1;
    if (!occupiedCount) return empty;

    const paddedWidth = width + 2;
    const paddedHeight = height + 2;
    const inf = width + height + 8;
    const distance = new Int32Array(paddedWidth * paddedHeight);
    for (let y = 0; y < paddedHeight; y += 1) {
      for (let x = 0; x < paddedWidth; x += 1) {
        const p = y * paddedWidth + x;
        if (x === 0 || y === 0 || x === paddedWidth - 1 || y === paddedHeight - 1) {
          distance[p] = 0;
        } else {
          distance[p] = mask[(y - 1) * width + (x - 1)] ? inf : 0;
        }
      }
    }
    for (let y = 1; y < paddedHeight - 1; y += 1) {
      for (let x = 1; x < paddedWidth - 1; x += 1) {
        const p = y * paddedWidth + x;
        if (distance[p] !== 0) distance[p] = Math.min(distance[p], distance[p - 1] + 1, distance[p - paddedWidth] + 1);
      }
    }
    for (let y = paddedHeight - 2; y >= 1; y -= 1) {
      for (let x = paddedWidth - 2; x >= 1; x -= 1) {
        const p = y * paddedWidth + x;
        if (distance[p] !== 0) distance[p] = Math.min(distance[p], distance[p + 1] + 1, distance[p + paddedWidth] + 1);
      }
    }

    const skeleton = new Uint8Array(mask);
    const at = (x, y) => (x < 0 || y < 0 || x >= width || y >= height ? 0 : skeleton[y * width + x]);
    const neighbors = (x, y) => [
      at(x, y - 1), at(x + 1, y - 1), at(x + 1, y), at(x + 1, y + 1),
      at(x, y + 1), at(x - 1, y + 1), at(x - 1, y), at(x - 1, y - 1)
    ];
    const transitionCount = (n) => {
      let transitions = 0;
      for (let i = 0; i < 8; i += 1) if (n[i] === 0 && n[(i + 1) % 8] === 1) transitions += 1;
      return transitions;
    };

    let thinningIterations = 0;
    let changed = true;
    const maxIterations = Math.max(1, width * height);
    while (changed && thinningIterations < maxIterations) {
      changed = false;
      thinningIterations += 1;
      for (let phase = 0; phase < 2; phase += 1) {
        const remove = [];
        for (let y = 0; y < height; y += 1) {
          for (let x = 0; x < width; x += 1) {
            if (!at(x, y)) continue;
            const n = neighbors(x, y);
            const count = n.reduce((sum, value) => sum + value, 0);
            if (count < 2 || count > 6 || transitionCount(n) !== 1) continue;
            const p2 = n[0]; const p4 = n[2]; const p6 = n[4]; const p8 = n[6];
            const phaseOk = phase === 0
              ? (p2 * p4 * p6 === 0 && p4 * p6 * p8 === 0)
              : (p2 * p4 * p8 === 0 && p2 * p6 * p8 === 0);
            if (phaseOk) remove.push(y * width + x);
          }
        }
        if (remove.length) {
          changed = true;
          for (const pos of remove) skeleton[pos] = 0;
        }
      }
    }

    const skeletonPixels = [];
    for (let y = 0; y < height; y += 1) {
      for (let x = 0; x < width; x += 1) {
        if (!skeleton[y * width + x]) continue;
        const radius = distance[(y + 1) * paddedWidth + (x + 1)];
        skeletonPixels.push({ x: bbox.x + x, y: bbox.y + y, radius });
      }
    }

    const skeletonAt = (x, y) => (x < 0 || y < 0 || x >= width || y >= height ? 0 : skeleton[y * width + x]);
    const endpointPixels = [];
    const junctionPixels = [];
    for (let i = 0; i < skeletonPixels.length; i += 1) {
      const point = skeletonPixels[i];
      const lx = point.x - bbox.x;
      const ly = point.y - bbox.y;
      let degree = 0;
      for (let dy = -1; dy <= 1; dy += 1) {
        for (let dx = -1; dx <= 1; dx += 1) {
          if (dx === 0 && dy === 0) continue;
          degree += skeletonAt(lx + dx, ly + dy);
        }
      }
      const enriched = { ...point, degree };
      skeletonPixels[i] = enriched;
      if (degree <= 1) endpointPixels.push(enriched);
      if (degree >= 3) junctionPixels.push(enriched);
    }

    let maxRadius = 0;
    let radiusSum = 0;
    for (const point of skeletonPixels) {
      if (point.radius > maxRadius) maxRadius = point.radius;
      radiusSum += point.radius;
    }
    const graph = extractStrictSkeletonGraph({
      skeletonPixels,
      endpointPixels,
      junctionPixels,
      skipped: false
    }, bbox);
    return {
      algorithm: 'zhang-suen+manhattan-distance-v0.1',
      skeletonPixels,
      endpointPixels,
      junctionPixels,
      skeletonPixelCount: skeletonPixels.length,
      endpointCount: endpointPixels.length,
      junctionCount: junctionPixels.length,
      maxRadius,
      meanRadius: skeletonPixels.length ? Number((radiusSum / skeletonPixels.length).toFixed(4)) : 0,
      thinningIterations,
      graph,
      skipped: false
    };
  }

  function extractStrictTopology(indexGrid, width, height, regions, adjacency, regionIds, palette) {
    const regionById = regions.map((region) => ({ ...region }));
    const totalRegions = regionById.length;

    function regionIndexAt(x, y) {
      return regionIds[y * width + x];
    }

    function computeHoleCount(regionIndex, bbox) {
      const localW = bbox.width + 2;
      const localH = bbox.height + 2;
      const occupied = new Uint8Array(localW * localH);
      for (let ly = 0; ly < bbox.height; ly += 1) {
        for (let lx = 0; lx < bbox.width; lx += 1) {
          const gx = bbox.x + lx;
          const gy = bbox.y + ly;
          if (regionIndexAt(gx, gy) === regionIndex) occupied[(ly + 1) * localW + (lx + 1)] = 1;
        }
      }
      const visited = new Uint8Array(localW * localH);
      const queue = new Int32Array(localW * localH);
      function floodZeros(start) {
        let head = 0; let tail = 0;
        queue[tail++] = start;
        visited[start] = 1;
        while (head < tail) {
          const pos = queue[head++];
          const x = pos % localW;
          const y = Math.floor(pos / localW);
          const neighbors = [[x - 1, y], [x + 1, y], [x, y - 1], [x, y + 1]];
          for (const [nx, ny] of neighbors) {
            if (nx < 0 || ny < 0 || nx >= localW || ny >= localH) continue;
            const np = ny * localW + nx;
            if (!visited[np] && !occupied[np]) {
              visited[np] = 1;
              queue[tail++] = np;
            }
          }
        }
      }
      for (let x = 0; x < localW; x += 1) {
        const top = x; const bottom = (localH - 1) * localW + x;
        if (!occupied[top] && !visited[top]) floodZeros(top);
        if (!occupied[bottom] && !visited[bottom]) floodZeros(bottom);
      }
      for (let y = 0; y < localH; y += 1) {
        const left = y * localW; const right = y * localW + (localW - 1);
        if (!occupied[left] && !visited[left]) floodZeros(left);
        if (!occupied[right] && !visited[right]) floodZeros(right);
      }
      let holes = 0;
      for (let pos = 0; pos < occupied.length; pos += 1) {
        if (!occupied[pos] && !visited[pos]) {
          holes += 1;
          floodZeros(pos);
        }
      }
      return holes;
    }

    function computeSymmetryScore(mask, bboxWidth, bboxHeight, axis) {
      let matches = 0;
      let total = 0;
      for (let y = 0; y < bboxHeight; y += 1) {
        for (let x = 0; x < bboxWidth; x += 1) {
          const mx = axis === 'vertical' ? (bboxWidth - 1 - x) : x;
          const my = axis === 'horizontal' ? (bboxHeight - 1 - y) : y;
          if (axis === 'vertical' && x > mx) continue;
          if (axis === 'horizontal' && y > my) continue;
          const a = mask[y * bboxWidth + x];
          const b = mask[my * bboxWidth + mx];
          if (a === b) matches += 1;
          total += 1;
        }
      }
      return total ? Number((matches / total).toFixed(4)) : 1;
    }

    let totalBoundaryPixels = 0;
    let totalPerimeter = 0;
    let totalHoles = 0;
    let totalContourAnchors = 0;
    let totalTurningPoints = 0;
    let totalSkeletonPixels = 0;
    let totalSkeletonEndpoints = 0;
    let totalSkeletonJunctions = 0;
    let totalSkeletonGraphNodes = 0;
    let totalSkeletonGraphEdges = 0;
    let totalSkeletonBranchlessPaths = 0;
    let maxMedialRadius = 0;
    let weightedVertical = 0;
    let weightedHorizontal = 0;
    let weightedArea = 0;

    for (let regionIndex = 0; regionIndex < totalRegions; regionIndex += 1) {
      const region = regionById[regionIndex];
      const bbox = region.bbox;
      const boundary = [];
      let perimeter = 0;
      const mask = new Uint8Array(bbox.width * bbox.height);
      const paletteEntry = palette && palette[region.paletteIndex] ? palette[region.paletteIndex] : [0, 0, 0, 255];
      const isTransparent = paletteEntry[3] === 0;

      for (let y = bbox.y; y < bbox.y + bbox.height; y += 1) {
        for (let x = bbox.x; x < bbox.x + bbox.width; x += 1) {
          if (regionIndexAt(x, y) !== regionIndex) continue;
          mask[(y - bbox.y) * bbox.width + (x - bbox.x)] = 1;
          let exposed = 0;
          const neighbors = [[x - 1, y], [x + 1, y], [x, y - 1], [x, y + 1]];
          for (const [nx, ny] of neighbors) {
            if (nx < 0 || ny < 0 || nx >= width || ny >= height || regionIndexAt(nx, ny) !== regionIndex) exposed += 1;
          }
          if (exposed > 0) {
            boundary.push([x, y]);
            perimeter += exposed;
          }
        }
      }

      const holeCount = computeHoleCount(regionIndex, bbox);
      const symmetry = {
        vertical: computeSymmetryScore(mask, bbox.width, bbox.height, 'vertical'),
        horizontal: computeSymmetryScore(mask, bbox.width, bbox.height, 'horizontal')
      };
      const contour = extractStrictContourAnchors(mask, bbox, region.centroid);
      const medial = extractStrictMedialHints(mask, bbox, { skip: isTransparent });
      region.topology = {
        boundary,
        boundaryPixelCount: boundary.length,
        perimeter,
        holeCount,
        fillRatio: Number((region.area / (bbox.width * bbox.height)).toFixed(4)),
        symmetry,
        contour,
        medial,
        isTransparent
      };
      totalBoundaryPixels += boundary.length;
      totalPerimeter += perimeter;
      totalHoles += holeCount;
      totalContourAnchors += contour.anchorCount;
      totalTurningPoints += contour.turnCount;
      totalSkeletonPixels += medial.skeletonPixelCount;
      totalSkeletonEndpoints += medial.endpointCount;
      totalSkeletonJunctions += medial.junctionCount;
      totalSkeletonGraphNodes += medial.graph ? medial.graph.nodeCount : 0;
      totalSkeletonGraphEdges += medial.graph ? medial.graph.edgeCount : 0;
      totalSkeletonBranchlessPaths += medial.graph ? medial.graph.branchlessPathCount : 0;
      if (medial.maxRadius > maxMedialRadius) maxMedialRadius = medial.maxRadius;
      if (!isTransparent) {
        weightedVertical += symmetry.vertical * region.area;
        weightedHorizontal += symmetry.horizontal * region.area;
        weightedArea += region.area;
      }
    }

    const partGrammar = extractStrictPartGrammar(regionById, adjacency, palette);
    return {
      regions: regionById,
      adjacency,
      topology: {
        regionCount: totalRegions,
        adjacencyCount: adjacency.length,
        totalBoundaryPixels,
        totalPerimeter,
        totalHoles,
        totalContourAnchors,
        totalTurningPoints,
        totalSkeletonPixels,
        totalSkeletonEndpoints,
        totalSkeletonJunctions,
        totalSkeletonGraphNodes,
        totalSkeletonGraphEdges,
        totalSkeletonBranchlessPaths,
        maxMedialRadius,
        symmetry: {
          vertical: Number(((weightedArea ? weightedVertical / weightedArea : 1)).toFixed(4)),
          horizontal: Number(((weightedArea ? weightedHorizontal / weightedArea : 1)).toFixed(4))
        }
      },
      partGrammar
    };
  }



  function extractStrictPartGrammar(regions, adjacency, palette) {
    const adjacencyMap = new Map();
    for (const region of regions) adjacencyMap.set(region.id, new Set());
    for (const edge of adjacency || []) {
      if (adjacencyMap.has(edge.a)) adjacencyMap.get(edge.a).add(edge.b);
      if (adjacencyMap.has(edge.b)) adjacencyMap.get(edge.b).add(edge.a);
    }

    const opaqueRegions = regions.filter((region) => !(region.topology && region.topology.isTransparent));
    const opaqueSorted = [...opaqueRegions].sort((a, b) => b.area - a.area || a.id.localeCompare(b.id));
    const areaRank = new Map(opaqueSorted.map((region, index) => [region.id, index + 1]));
    const maxOpaqueArea = opaqueSorted.length ? opaqueSorted[0].area : 0;

    function inferPrimitive(region) {
      const topology = region.topology || {};
      const medial = topology.medial || {};
      const graph = medial.graph || {};
      const bbox = region.bbox || { width: 1, height: 1 };
      const aspect = bbox.height ? bbox.width / bbox.height : bbox.width;
      if (topology.isTransparent) return 'carrier';
      if (topology.holeCount > 0) return 'ring';
      if (region.area <= 2) return 'dot';
      if ((medial.junctionCount || 0) > 0 || (graph.edgeCount || 0) >= 3 || (graph.nodeCount || 0) >= 5) return 'junction';
      if (bbox.width === 1 || bbox.height === 1) return 'bar';
      if ((graph.edgeCount || 0) === 1 && (graph.nodeCount || 0) <= 2 && (aspect >= 1.8 || aspect <= (1 / 1.8) || topology.fillRatio <= 0.5)) return 'bar';
      if (topology.fillRatio >= 0.75 && Math.abs(bbox.width - bbox.height) <= 1) return 'block';
      return 'blob';
    }

    function inferOrientation(region, primitive) {
      const topology = region.topology || {};
      const medial = topology.medial || {};
      const graph = medial.graph || {};
      const bbox = region.bbox || { width: 1, height: 1 };
      if (primitive === 'carrier') return 'background';
      if (primitive === 'ring' || primitive === 'junction') {
        if (topology.symmetry && topology.symmetry.vertical >= 0.85 && topology.symmetry.horizontal >= 0.85) return 'radial';
        return 'mixed';
      }
      const ratio = bbox.height ? bbox.width / bbox.height : bbox.width;
      if (primitive === 'bar' && Array.isArray(graph.edges) && graph.edges[0] && Array.isArray(graph.edges[0].polyline) && graph.edges[0].polyline.length >= 2) {
        const start = graph.edges[0].polyline[0];
        const end = graph.edges[0].polyline[graph.edges[0].polyline.length - 1];
        const dx = Math.abs(end.x - start.x);
        const dy = Math.abs(end.y - start.y);
        if (dx > dy * 1.5) return 'horizontal';
        if (dy > dx * 1.5) return 'vertical';
        if (dx > 0 && dy > 0) return 'diagonal';
      }
      if (ratio >= 1.5) return 'horizontal';
      if (ratio <= (1 / 1.5)) return 'vertical';
      if (Math.abs(bbox.width - bbox.height) <= 1) return 'square';
      return 'mixed';
    }

    function inferRole(region, primitive, rank, adjacencyDegree) {
      const topology = region.topology || {};
      if (topology.isTransparent) return 'background-carrier';
      if (primitive === 'ring') return 'loop-feature';
      if (primitive === 'junction') return 'connector';
      if (primitive === 'dot') return 'detail-mark';
      if (rank === 1 && region.area >= Math.max(1, Math.floor(maxOpaqueArea * 0.6))) return 'primary-mass';
      if (primitive === 'bar') return adjacencyDegree >= 2 ? 'connector' : 'limb-like';
      if (primitive === 'block' || primitive === 'blob') return rank <= 2 ? 'primary-mass' : 'secondary-mass';
      return 'secondary-mass';
    }

    function inferSymmetryClass(region) {
      const symmetry = region.topology && region.topology.symmetry ? region.topology.symmetry : { vertical: 0, horizontal: 0 };
      if (symmetry.vertical >= 0.9 && symmetry.horizontal >= 0.9) return 'bilateral';
      if (symmetry.vertical >= 0.9 || symmetry.horizontal >= 0.9) return 'axial';
      return 'asymmetric';
    }

    const countsByPrimitive = {};
    const countsByRole = {};
    let transparentPartCount = 0;
    let opaquePartCount = 0;

    const parts = regions.map((region, index) => {
      const adjacencyDegree = adjacencyMap.get(region.id) ? adjacencyMap.get(region.id).size : 0;
      const rank = areaRank.get(region.id) || null;
      const primitive = inferPrimitive(region);
      const orientation = inferOrientation(region, primitive);
      const role = inferRole(region, primitive, rank, adjacencyDegree);
      const part = {
        id: `PART_${String(index).padStart(4, '0')}`,
        regionId: region.id,
        paletteIndex: region.paletteIndex,
        primitive,
        orientation,
        role,
        symmetryClass: inferSymmetryClass(region),
        areaRank: rank,
        adjacencyDegree,
        attachments: Array.from(adjacencyMap.get(region.id) || []).sort(),
        bbox: { ...region.bbox },
        area: region.area,
        holeCount: region.topology ? region.topology.holeCount : 0,
        fillRatio: region.topology ? region.topology.fillRatio : 0,
        graphNodeCount: region.topology && region.topology.medial && region.topology.medial.graph ? region.topology.medial.graph.nodeCount : 0,
        graphEdgeCount: region.topology && region.topology.medial && region.topology.medial.graph ? region.topology.medial.graph.edgeCount : 0
      };
      region.partGrammar = part;
      countsByPrimitive[primitive] = (countsByPrimitive[primitive] || 0) + 1;
      countsByRole[role] = (countsByRole[role] || 0) + 1;
      if (region.topology && region.topology.isTransparent) transparentPartCount += 1;
      else opaquePartCount += 1;
      return part;
    });

    return {
      grammarVersion: 'part-grammar-v0.1',
      partCount: parts.length,
      opaquePartCount,
      transparentPartCount,
      countsByPrimitive,
      countsByRole,
      primaryPartIds: opaqueSorted.slice(0, 3).map((region) => region.id),
      parts
    };
  }

  function createStrictImageLike(image) {
    const { width, height } = validateStrictImageObject(image);
    return { width, height, data: new Uint8ClampedArray(width * height * 4) };
  }

  function collectStrictPaletteStats(image) {
    const counts = new Map();
    const { width, height } = validateStrictImageObject(image);
    for (let pixel = 0; pixel < width * height; pixel += 1) {
      const i = pixel * 4;
      const key = strictRgbaKey(image.data[i], image.data[i + 1], image.data[i + 2], image.data[i + 3]);
      counts.set(key, (counts.get(key) || 0) + 1);
    }
    return counts;
  }

  function rgbaDistanceSq(a, b) {
    const dr = a[0] - b[0];
    const dg = a[1] - b[1];
    const db = a[2] - b[2];
    const da = a[3] - b[3];
    return dr * dr + dg * dg + db * db + da * da * 4;
  }

  function normalizePixelLikeImage(image, options = {}) {
    const { width, height } = validateStrictImageObject(image);
    const alphaThreshold = options.alphaThreshold == null ? 127 : Number(options.alphaThreshold);
    const paletteSize = options.paletteSize == null || options.paletteSize === '' ? null : Number(options.paletteSize);
    const despeckle = Boolean(options.despeckle);
    if (!Number.isFinite(alphaThreshold) || alphaThreshold < 0 || alphaThreshold > 255) throw new Error('Pixel normalizer alphaThreshold must be within 0..255');
    if (paletteSize != null && (!Number.isInteger(paletteSize) || paletteSize <= 0)) throw new Error('Pixel normalizer paletteSize must be a positive integer');

    const normalized = createStrictImageLike(image);
    normalized.data.set(image.data);
    let alphaSnappedTransparent = 0;
    let alphaSnappedOpaque = 0;

    for (let pixel = 0; pixel < width * height; pixel += 1) {
      const i = pixel * 4;
      const a = normalized.data[i + 3];
      if (a === 0 || a === 255) continue;
      if (a < alphaThreshold) {
        normalized.data[i] = 0;
        normalized.data[i + 1] = 0;
        normalized.data[i + 2] = 0;
        normalized.data[i + 3] = 0;
        alphaSnappedTransparent += 1;
      } else {
        normalized.data[i + 3] = 255;
        alphaSnappedOpaque += 1;
      }
    }

    let despeckledPixels = 0;
    if (despeckle && width >= 3 && height >= 3) {
      const source = new Uint8ClampedArray(normalized.data);
      for (let y = 1; y < height - 1; y += 1) {
        for (let x = 1; x < width - 1; x += 1) {
          const idx = getIndex(x, y, width);
          const center = [source[idx], source[idx + 1], source[idx + 2], source[idx + 3]];
          const neighborCoords = [[x, y - 1], [x - 1, y], [x + 1, y], [x, y + 1]];
          const counts = new Map();
          for (const [nx, ny] of neighborCoords) {
            const ni = getIndex(nx, ny, width);
            const key = strictRgbaKey(source[ni], source[ni + 1], source[ni + 2], source[ni + 3]);
            counts.set(key, (counts.get(key) || 0) + 1);
          }
          let bestKey = null; let bestCount = 0;
          for (const [key, count] of counts.entries()) {
            if (count > bestCount || (count === bestCount && key < bestKey)) { bestKey = key; bestCount = count; }
          }
          const centerKey = strictRgbaKey(center[0], center[1], center[2], center[3]);
          if (bestCount >= 3 && bestKey && bestKey !== centerKey) {
            const repl = bestKey.split(',').map(Number);
            normalized.data[idx] = repl[0];
            normalized.data[idx + 1] = repl[1];
            normalized.data[idx + 2] = repl[2];
            normalized.data[idx + 3] = repl[3];
            despeckledPixels += 1;
          }
        }
      }
    }

    const originalPaletteCounts = collectStrictPaletteStats(normalized);
    const originalPaletteSize = originalPaletteCounts.size;
    let quantizedPixels = 0;
    let quantizedPalette = [];

    if (paletteSize != null && originalPaletteSize > paletteSize) {
      const entries = Array.from(originalPaletteCounts.entries()).map(([key, count]) => ({ key, count, rgba: key.split(',').map(Number) }));
      entries.sort((a, b) => b.count - a.count || (a.key < b.key ? -1 : a.key > b.key ? 1 : 0));

      const transparentEntry = entries.find((entry) => entry.rgba[3] === 0) || null;
      const anchors = [];
      if (transparentEntry && paletteSize >= 1) anchors.push(transparentEntry);
      for (const entry of entries) {
        if (anchors.length >= paletteSize) break;
        if (transparentEntry && entry.key === transparentEntry.key) continue;
        anchors.push(entry);
      }
      quantizedPalette = anchors.map((entry) => entry.rgba.slice());
      const opaqueAnchors = anchors.filter((entry) => entry.rgba[3] !== 0);
      const transparentAnchor = anchors.find((entry) => entry.rgba[3] === 0) || null;

      for (let pixel = 0; pixel < width * height; pixel += 1) {
        const i = pixel * 4;
        const rgba = [normalized.data[i], normalized.data[i + 1], normalized.data[i + 2], normalized.data[i + 3]];
        let target = null;
        if (rgba[3] === 0 && transparentAnchor) {
          target = transparentAnchor.rgba;
        } else {
          let best = null; let bestDist = Infinity; let bestKey = null;
          for (const anchor of (opaqueAnchors.length ? opaqueAnchors : anchors)) {
            const dist = rgbaDistanceSq(rgba, anchor.rgba);
            const anchorKey = anchor.key || strictRgbaKey(anchor.rgba[0], anchor.rgba[1], anchor.rgba[2], anchor.rgba[3]);
            if (dist < bestDist || (dist === bestDist && (bestKey == null || anchorKey < bestKey))) {
              best = anchor;
              bestDist = dist;
              bestKey = anchorKey;
            }
          }
          target = (best || anchors[0]).rgba;
        }
        if (rgba[0] !== target[0] || rgba[1] !== target[1] || rgba[2] !== target[2] || rgba[3] !== target[3]) quantizedPixels += 1;
        normalized.data[i] = target[0];
        normalized.data[i + 1] = target[1];
        normalized.data[i + 2] = target[2];
        normalized.data[i + 3] = target[3];
      }
    } else {
      quantizedPalette = Array.from(originalPaletteCounts.keys()).map((key) => key.split(',').map(Number));
    }

    const normalizedPaletteCounts = collectStrictPaletteStats(normalized);
    const normalizedPaletteSize = normalizedPaletteCounts.size;
    return {
      image: normalized,
      options: { alphaThreshold, paletteSize, despeckle },
      stats: {
        alphaSnappedTransparent,
        alphaSnappedOpaque,
        despeckledPixels,
        quantizedPixels,
        originalPaletteSize,
        normalizedPaletteSize
      },
      palette: Array.from(normalizedPaletteCounts.keys()).map((key) => key.split(',').map(Number))
    };
  }

  function compileNormalizedStrictSymbolicAsset(image, options = {}) {
    const normalization = normalizePixelLikeImage(image, options);
    const strictMaxPalette = options.maxPalette == null ? 256 : Number(options.maxPalette);
    const asset = compileStrictSymbolicAsset(normalization.image, { maxPalette: strictMaxPalette });
    asset.version = '0.7';
    asset.normalization = {
      gate: 'pixel-normalizer-v0.2',
      options: normalization.options,
      stats: normalization.stats
    };
    validateStrictSymbolicAsset(asset);
    return asset;
  }

  function compileStrictSymbolicAsset(image, options = {}) {
    const { width, height } = validateStrictImageObject(image);
    const maxPalette = options.maxPalette == null ? 256 : Number(options.maxPalette);
    if (!Number.isInteger(maxPalette) || maxPalette <= 0) throw new Error('Strict symbolic maxPalette must be a positive integer');

    const palette = [];
    const paletteMap = new Map();
    const indexGrid = new Int32Array(width * height);

    for (let pixel = 0; pixel < width * height; pixel += 1) {
      const i = pixel * 4;
      const r = Number(image.data[i]);
      const g = Number(image.data[i + 1]);
      const b = Number(image.data[i + 2]);
      const a = Number(image.data[i + 3]);
      const key = strictRgbaKey(r, g, b, a);
      let paletteIndex = paletteMap.get(key);
      if (paletteIndex === undefined) {
        if (palette.length >= maxPalette) {
          throw new Error(`Strict symbolic palette limit exceeded: more than ${maxPalette} exact RGBA colors`);
        }
        paletteIndex = palette.length;
        paletteMap.set(key, paletteIndex);
        palette.push([r, g, b, a]);
      }
      indexGrid[pixel] = paletteIndex;
    }

    const tokens = [];
    for (let y = 0; y < height; y += 1) {
      let x = 0;
      while (x < width) {
        const paletteIndex = indexGrid[y * width + x];
        let length = 1;
        while (x + length < width && indexGrid[y * width + x + length] === paletteIndex) length += 1;
        tokens.push({ op: 'RUN', y, x, length, paletteIndex });
        x += length;
      }
    }

    const regionGraph = buildStrictRegions(indexGrid, width, height);
    const topologyBundle = extractStrictTopology(indexGrid, width, height, regionGraph.regions, regionGraph.adjacency, regionGraph.regionIds, palette);
    const asset = {
      schema: 'evemisslab.symbolic-image',
      version: '0.7',
      mode: 'strict-source-blind',
      encoding: 'palette-runs',
      canvas: { width, height, pixelAspect: 1 },
      palette,
      tokens,
      regions: topologyBundle.regions,
      adjacency: topologyBundle.adjacency,
      topology: topologyBundle.topology,
      partGrammar: topologyBundle.partGrammar,
      stats: {
        pixelCount: width * height,
        paletteSize: palette.length,
        runCount: tokens.length,
        regionCount: topologyBundle.regions.length,
        rawRgbaBytes: width * height * 4
      }
    };
    validateStrictSymbolicAsset(asset);
    return asset;
  }

  function rejectStrictSourcePayload(value, path = 'asset') {
    if (typeof value === 'string') {
      if (/^data:image\//i.test(value)) throw new Error(`Strict symbolic asset contains forbidden source payload at ${path}`);
      return;
    }
    if (!value || typeof value !== 'object') return;
    if (Array.isArray(value)) {
      for (let i = 0; i < value.length; i += 1) rejectStrictSourcePayload(value[i], `${path}[${i}]`);
      return;
    }
    const forbidden = /^(sourceData|sourceImage|sourcePixels|pixelBuffer|dataUrl|sourceDataUrl)$/i;
    for (const [key, child] of Object.entries(value)) {
      if (forbidden.test(key)) throw new Error(`Strict symbolic asset contains forbidden source payload field: ${path}.${key}`);
      rejectStrictSourcePayload(child, `${path}.${key}`);
    }
  }

  function validateStrictSymbolicAsset(asset) {
    if (!asset || typeof asset !== 'object') throw new Error('Strict symbolic asset must be an object');
    rejectStrictSourcePayload(asset);
    if (asset.schema !== 'evemisslab.symbolic-image') throw new Error('Invalid strict symbolic schema');
    if (asset.version !== '0.1' && asset.version !== '0.2' && asset.version !== '0.3' && asset.version !== '0.4' && asset.version !== '0.5' && asset.version !== '0.6' && asset.version !== '0.7') throw new Error('Unsupported strict symbolic version');
    if (asset.encoding !== 'palette-runs') throw new Error('Unsupported strict symbolic encoding');
    if (!asset.canvas || !Number.isInteger(asset.canvas.width) || asset.canvas.width <= 0 || !Number.isInteger(asset.canvas.height) || asset.canvas.height <= 0) {
      throw new Error('Strict symbolic asset requires positive integer canvas dimensions');
    }
    if (!Array.isArray(asset.palette) || asset.palette.length === 0) throw new Error('Strict symbolic asset requires a palette');
    for (const color of asset.palette) {
      if (!Array.isArray(color) || color.length !== 4 || color.some((v) => !Number.isInteger(v) || v < 0 || v > 255)) {
        throw new Error('Strict symbolic palette entries must be RGBA byte arrays');
      }
    }
    if (!Array.isArray(asset.tokens) || asset.tokens.length === 0) throw new Error('Strict symbolic asset requires RUN tokens');

    const width = asset.canvas.width;
    const height = asset.canvas.height;
    let expectedY = 0;
    let expectedX = 0;
    for (const token of asset.tokens) {
      if (!token || token.op !== 'RUN') throw new Error('Strict symbolic token must use RUN op');
      if (!Number.isInteger(token.y) || !Number.isInteger(token.x) || !Number.isInteger(token.length) || token.length <= 0) {
        throw new Error('Strict symbolic RUN coordinates must be positive integer geometry');
      }
      if (!Number.isInteger(token.paletteIndex) || token.paletteIndex < 0 || token.paletteIndex >= asset.palette.length) {
        throw new Error('Strict symbolic RUN references an invalid palette index');
      }
      if (token.y !== expectedY || token.x !== expectedX || token.x + token.length > width) {
        throw new Error('Strict symbolic RUN stream must exactly and sequentially cover each row');
      }
      expectedX += token.length;
      if (expectedX === width) {
        expectedX = 0;
        expectedY += 1;
      }
    }
    if (expectedY !== height || expectedX !== 0) throw new Error('Strict symbolic RUN stream does not cover the entire canvas');
    if (asset.regions != null && !Array.isArray(asset.regions)) throw new Error('Strict symbolic regions must be an array');
    if (asset.adjacency != null && !Array.isArray(asset.adjacency)) throw new Error('Strict symbolic adjacency must be an array');
    if (asset.topology != null) {
      if (!asset.topology || typeof asset.topology !== 'object') throw new Error('Strict symbolic topology metadata must be an object');
      if (!Number.isInteger(asset.topology.regionCount) || !Number.isInteger(asset.topology.adjacencyCount)) throw new Error('Strict symbolic topology summary must contain integer region / adjacency counts');
      if (!Number.isInteger(asset.topology.totalBoundaryPixels) || !Number.isInteger(asset.topology.totalPerimeter) || !Number.isInteger(asset.topology.totalHoles) || !Number.isInteger(asset.topology.totalContourAnchors) || !Number.isInteger(asset.topology.totalTurningPoints) || !Number.isInteger(asset.topology.totalSkeletonPixels) || !Number.isInteger(asset.topology.totalSkeletonEndpoints) || !Number.isInteger(asset.topology.totalSkeletonJunctions) || !Number.isInteger(asset.topology.totalSkeletonGraphNodes) || !Number.isInteger(asset.topology.totalSkeletonGraphEdges) || !Number.isInteger(asset.topology.totalSkeletonBranchlessPaths) || !Number.isInteger(asset.topology.maxMedialRadius)) throw new Error('Strict symbolic topology summary must contain integer totals');
      if (asset.topology.symmetry && (typeof asset.topology.symmetry !== 'object' || typeof asset.topology.symmetry.vertical !== 'number' || typeof asset.topology.symmetry.horizontal !== 'number')) throw new Error('Strict symbolic topology symmetry must provide numeric scores');
    }
    if (asset.regions != null) {
      for (const region of asset.regions) {
        if (region.topology != null) {
          if (!Array.isArray(region.topology.boundary)) throw new Error('Strict symbolic region topology boundary must be an array');
          if (!Number.isInteger(region.topology.boundaryPixelCount) || !Number.isInteger(region.topology.perimeter) || !Number.isInteger(region.topology.holeCount)) throw new Error('Strict symbolic region topology must contain integer boundary/perimeter/hole data');
          if (typeof region.topology.fillRatio !== 'number') throw new Error('Strict symbolic region topology fillRatio must be numeric');
          if (!region.topology.symmetry || typeof region.topology.symmetry.vertical !== 'number' || typeof region.topology.symmetry.horizontal !== 'number') throw new Error('Strict symbolic region topology symmetry must be numeric');
          if (region.topology.contour != null) {
            if (!Number.isInteger(region.topology.contour.anchorCount) || !Number.isInteger(region.topology.contour.turnCount)) throw new Error('Strict symbolic region contour metadata must contain integer counts');
            if (!Array.isArray(region.topology.contour.orderedAnchors) || !Array.isArray(region.topology.contour.turningPoints)) throw new Error('Strict symbolic region contour metadata must contain orderedAnchors and turningPoints arrays');
          }
          if (region.topology.medial != null) {
            const medial = region.topology.medial;
            if (!Array.isArray(medial.skeletonPixels) || !Array.isArray(medial.endpointPixels) || !Array.isArray(medial.junctionPixels)) throw new Error('Strict symbolic medial metadata must contain skeleton / endpoint / junction arrays');
            if (!Number.isInteger(medial.skeletonPixelCount) || !Number.isInteger(medial.endpointCount) || !Number.isInteger(medial.junctionCount) || !Number.isInteger(medial.maxRadius)) throw new Error('Strict symbolic medial metadata must contain integer counts / radius');
            if (typeof medial.meanRadius !== 'number' || !Number.isInteger(medial.thinningIterations)) throw new Error('Strict symbolic medial metadata must contain meanRadius / thinningIterations');
            if (medial.graph != null) {
              if (!Array.isArray(medial.graph.nodes) || !Array.isArray(medial.graph.edges)) throw new Error('Strict symbolic skeleton graph must contain nodes and edges arrays');
              if (!Number.isInteger(medial.graph.nodeCount) || !Number.isInteger(medial.graph.edgeCount) || !Number.isInteger(medial.graph.branchlessPathCount)) throw new Error('Strict symbolic skeleton graph must contain integer node/edge/path counts');
            }
          }
        }
        if (region.partGrammar != null) {
          if (typeof region.partGrammar.primitive !== 'string' || typeof region.partGrammar.orientation !== 'string' || typeof region.partGrammar.role !== 'string') throw new Error('Strict symbolic region partGrammar must contain primitive/orientation/role strings');
          if (!Array.isArray(region.partGrammar.attachments) || !Number.isInteger(region.partGrammar.adjacencyDegree)) throw new Error('Strict symbolic region partGrammar must contain attachments and adjacencyDegree');
        }
      }
    }
    if (asset.partGrammar != null) {
      if (!asset.partGrammar || typeof asset.partGrammar !== 'object') throw new Error('Strict symbolic partGrammar must be an object');
      if (typeof asset.partGrammar.grammarVersion !== 'string' || !Number.isInteger(asset.partGrammar.partCount)) throw new Error('Strict symbolic partGrammar must contain grammarVersion and partCount');
      if (!asset.partGrammar.countsByPrimitive || typeof asset.partGrammar.countsByPrimitive !== 'object' || !asset.partGrammar.countsByRole || typeof asset.partGrammar.countsByRole !== 'object') throw new Error('Strict symbolic partGrammar must contain countsByPrimitive and countsByRole');
      if (!Array.isArray(asset.partGrammar.parts)) throw new Error('Strict symbolic partGrammar must contain parts array');
    }
    if (asset.normalization != null) {
      if (!asset.normalization || typeof asset.normalization !== 'object') throw new Error('Strict symbolic normalization metadata must be an object');
      if (asset.normalization.options && typeof asset.normalization.options !== 'object') throw new Error('Strict symbolic normalization options must be an object');
      if (asset.normalization.stats && typeof asset.normalization.stats !== 'object') throw new Error('Strict symbolic normalization stats must be an object');
    }
    return true;
  }

  function renderStrictSymbolicAsset(asset, options = {}) {
    validateStrictSymbolicAsset(asset);
    const scale = options.scale == null ? 1 : Number(options.scale);
    if (!Number.isInteger(scale) || scale <= 0 || scale > 64) throw new Error('Strict symbolic render scale must be an integer from 1 to 64');
    const sourceWidth = asset.canvas.width;
    const sourceHeight = asset.canvas.height;
    const width = sourceWidth * scale;
    const height = sourceHeight * scale;
    const data = new Uint8ClampedArray(width * height * 4);

    for (const token of asset.tokens) {
      const rgba = asset.palette[token.paletteIndex];
      const startX = token.x * scale;
      const endX = (token.x + token.length) * scale;
      const startY = token.y * scale;
      const endY = (token.y + 1) * scale;
      for (let y = startY; y < endY; y += 1) {
        for (let x = startX; x < endX; x += 1) {
          const i = (y * width + x) * 4;
          data[i] = rgba[0];
          data[i + 1] = rgba[1];
          data[i + 2] = rgba[2];
          data[i + 3] = rgba[3];
        }
      }
    }
    return { width, height, data };
  }


  function buildStrictIndexGridFromAsset(asset) {
    const width = asset.canvas.width;
    const height = asset.canvas.height;
    const grid = new Int16Array(width * height);
    grid.fill(-1);
    for (const token of asset.tokens) {
      for (let x = token.x; x < token.x + token.length; x += 1) {
        grid[token.y * width + x] = token.paletteIndex;
      }
    }
    return { width, height, grid };
  }

  function buildStrictLocalMask(regionIds, width, height, region, regionIndexById) {
    const localWidth = region.bbox.width;
    const localHeight = region.bbox.height;
    const mask = new Uint8Array(localWidth * localHeight);
    const regionIndex = regionIndexById.get(region.id);
    if (regionIndex == null) return { width: localWidth, height: localHeight, mask };
    for (let y = region.bbox.y; y < region.bbox.y + region.bbox.height; y += 1) {
      for (let x = region.bbox.x; x < region.bbox.x + region.bbox.width; x += 1) {
        if (regionIds[y * width + x] === regionIndex) {
          mask[(y - region.bbox.y) * localWidth + (x - region.bbox.x)] = 1;
        }
      }
    }
    return { width: localWidth, height: localHeight, mask };
  }

  function clampUnit(value) {
    return value < 0 ? 0 : value > 1 ? 1 : value;
  }

  function smoothstepUnit(value) {
    const t = clampUnit(value);
    return t * t * (3 - 2 * t);
  }

  function inferStrictEnhancedRegionMeta(region) {
    const part = region.partGrammar || {};
    const topology = region.topology || {};
    const contour = topology.contour || {};
    const medial = topology.medial || {};
    const graph = medial.graph || {};
    let smoothingWidth = 0.34;
    switch (part.primitive) {
      case 'bar': smoothingWidth = 0.42; break;
      case 'junction': smoothingWidth = 0.48; break;
      case 'ring': smoothingWidth = 0.30; break;
      case 'block': smoothingWidth = 0.26; break;
      case 'dot': smoothingWidth = 0.22; break;
      case 'carrier': smoothingWidth = 0.18; break;
      case 'blob': smoothingWidth = 0.35; break;
      default: smoothingWidth = 0.34; break;
    }
    smoothingWidth += Math.min(0.14, (medial.maxRadius || 0) * 0.04);
    smoothingWidth += Math.min(0.06, (graph.edgeCount || 0) * 0.015);
    const turnDensity = contour.anchorCount ? ((contour.turnCount || 0) / Math.max(1, contour.anchorCount)) : 0;
    smoothingWidth -= Math.min(0.05, turnDensity * 0.05);
    let bias = 0;
    if (part.primitive === 'bar' || part.primitive === 'junction') bias += 0.08;
    if (part.primitive === 'ring') bias -= 0.02;
    if (part.primitive === 'dot') bias -= 0.05;
    if (part.orientation === 'horizontal' || part.orientation === 'vertical') bias += 0.01;
    return {
      smoothingWidth: clamp(0.16, smoothingWidth, 0.78),
      bias,
      emphasis: graph.edgeCount || 0,
      turnCount: contour.turnCount || 0
    };
  }

  function buildStrictEnhancedFeaturePoints(region) {
    const bbox = region.bbox || { x: 0, y: 0 };
    const boundary = Array.isArray(region.topology && region.topology.boundary) ? region.topology.boundary : [];
    const contour = region.topology && region.topology.contour ? region.topology.contour : {};
    const anchors = Array.isArray(contour.orderedAnchors) ? contour.orderedAnchors : [];
    const turns = Array.isArray(contour.turningPoints) ? contour.turningPoints : [];
    const points = [];
    const seen = new Set();
    function pushPoint(point) {
      if (!point || !Number.isInteger(point.x) || !Number.isInteger(point.y)) return;
      const key = `${point.x},${point.y}`;
      if (seen.has(key)) return;
      seen.add(key);
      points.push({ x: point.x - bbox.x + 0.5, y: point.y - bbox.y + 0.5 });
    }
    for (const point of boundary) pushPoint(point);
    for (const point of anchors) pushPoint(point);
    for (const point of turns) pushPoint(point);
    return points.length ? points : [{ x: 0.5, y: 0.5 }];
  }

  function sampleStrictEnhancedAlpha(maskInfo, featurePoints, localX, localY, meta) {
    const localWidth = maskInfo.width;
    const localHeight = maskInfo.height;
    const ix = Math.floor(localX);
    const iy = Math.floor(localY);
    const inside = ix >= 0 && iy >= 0 && ix < localWidth && iy < localHeight && maskInfo.mask[iy * localWidth + ix] === 1;
    let minDistSq = Infinity;
    for (const point of featurePoints) {
      const dx = localX - point.x;
      const dy = localY - point.y;
      const distSq = dx * dx + dy * dy;
      if (distSq < minDistSq) minDistSq = distSq;
    }
    const distance = Math.sqrt(minDistSq === Infinity ? 999999 : minDistSq);
    const signedDistance = (inside ? -distance : distance) - meta.bias;
    return smoothstepUnit(0.5 - signedDistance / (2 * meta.smoothingWidth));
  }

  function alphaBlendOver(data, index, rgba, alpha) {
    const srcA = clampUnit((rgba[3] / 255) * alpha);
    if (srcA <= 0) return;
    const dstA = data[index + 3] / 255;
    const outA = srcA + dstA * (1 - srcA);
    if (outA <= 0) return;
    data[index] = Math.round(((rgba[0] * srcA) + (data[index] * dstA * (1 - srcA))) / outA);
    data[index + 1] = Math.round(((rgba[1] * srcA) + (data[index + 1] * dstA * (1 - srcA))) / outA);
    data[index + 2] = Math.round(((rgba[2] * srcA) + (data[index + 2] * dstA * (1 - srcA))) / outA);
    data[index + 3] = Math.round(outA * 255);
  }

  function renderEnhancedStrictSymbolicAsset(asset, options = {}) {
    validateStrictSymbolicAsset(asset);
    const scale = options.scale == null ? 1 : Number(options.scale);
    if (!Number.isInteger(scale) || scale <= 0 || scale > 64) throw new Error('Enhanced strict symbolic render scale must be an integer from 1 to 64');
    const exact = renderStrictSymbolicAsset(asset, { scale });
    const width = exact.width;
    const height = exact.height;
    const data = new Uint8ClampedArray(exact.data);
    const sourceWidth = asset.canvas.width;
    const sourceHeight = asset.canvas.height;
    const rebuilt = buildStrictRegions(buildStrictIndexGridFromAsset(asset).grid, sourceWidth, sourceHeight);
    const regionIndexById = new Map(rebuilt.regions.map((region, index) => [region.id, index]));

    for (const region of asset.regions) {
      const rgba = asset.palette[region.paletteIndex];
      if (!rgba || rgba[3] === 0) continue;
      const maskInfo = buildStrictLocalMask(rebuilt.regionIds, sourceWidth, sourceHeight, region, regionIndexById);
      const featurePoints = buildStrictEnhancedFeaturePoints(region);
      const meta = inferStrictEnhancedRegionMeta(region);
      const padding = Math.max(1, Math.ceil((meta.smoothingWidth + Math.abs(meta.bias) + 0.85) * scale));
      const startX = Math.max(0, Math.floor(region.bbox.x * scale - padding));
      const endX = Math.min(width, Math.ceil((region.bbox.x + region.bbox.width) * scale + padding));
      const startY = Math.max(0, Math.floor(region.bbox.y * scale - padding));
      const endY = Math.min(height, Math.ceil((region.bbox.y + region.bbox.height) * scale + padding));

      for (let y = startY; y < endY; y += 1) {
        const localY = (y + 0.5) / scale - region.bbox.y;
        for (let x = startX; x < endX; x += 1) {
          const localX = (x + 0.5) / scale - region.bbox.x;
          const coverage = sampleStrictEnhancedAlpha(maskInfo, featurePoints, localX, localY, meta);
          if (coverage <= 0.001) continue;
          alphaBlendOver(data, (y * width + x) * 4, rgba, coverage);
        }
      }
    }
    return { width, height, data };
  }


  function createBlankImage(width, height) {
    return { width, height, data: new Uint8ClampedArray(width * height * 4) };
  }

  function blitImageObject(source, target, offsetX, offsetY) {
    for (let y = 0; y < source.height; y += 1) {
      for (let x = 0; x < source.width; x += 1) {
        const srcIndex = (y * source.width + x) * 4;
        const dstX = offsetX + x;
        const dstY = offsetY + y;
        const dstIndex = (dstY * target.width + dstX) * 4;
        target.data[dstIndex] = source.data[srcIndex];
        target.data[dstIndex + 1] = source.data[srcIndex + 1];
        target.data[dstIndex + 2] = source.data[srcIndex + 2];
        target.data[dstIndex + 3] = source.data[srcIndex + 3];
      }
    }
  }

  function renderStrictAssetByMode(asset, renderMode, scale) {
    if (renderMode === 'enhanced') return renderEnhancedStrictSymbolicAsset(asset, { scale });
    return renderStrictSymbolicAsset(asset, { scale });
  }

  function buildRuntimeCollisionMask(asset) {
    const image = renderStrictSymbolicAsset(asset, { scale: 1 });
    const rows = [];
    for (let y = 0; y < image.height; y += 1) {
      const row = [];
      for (let x = 0; x < image.width; x += 1) {
        row.push(image.data[(y * image.width + x) * 4 + 3] > 0 ? 1 : 0);
      }
      rows.push(row);
    }
    return { width: image.width, height: image.height, rows };
  }

  function validateRpgMakerRuntimeBundle(bundle) {
    if (!bundle || typeof bundle !== 'object') throw new Error('Runtime bundle must be an object');
    if (bundle.schema !== 'evemisslab.rpgmaker-runtime-bundle') throw new Error('Runtime bundle schema mismatch');
    if (bundle.version !== '0.1') throw new Error('Runtime bundle version mismatch');
    if (bundle.engine !== 'rpgmaker-like') throw new Error('Runtime bundle engine mismatch');
    if (!['tile', 'character'].includes(bundle.assetKind)) throw new Error('Runtime bundle assetKind must be tile or character');
    if (!['exact', 'enhanced'].includes(bundle.renderMode)) throw new Error('Runtime bundle renderMode must be exact or enhanced');
    if (!bundle.frameSize || !Number.isInteger(bundle.frameSize.width) || !Number.isInteger(bundle.frameSize.height)) throw new Error('Runtime bundle frameSize must be integer dimensions');
    if (!bundle.sheet || !Number.isInteger(bundle.sheet.width) || !Number.isInteger(bundle.sheet.height) || !Number.isInteger(bundle.sheet.columns) || !Number.isInteger(bundle.sheet.rows)) throw new Error('Runtime bundle sheet metadata must be valid');
    if (!Array.isArray(bundle.frames) || bundle.frames.length === 0) throw new Error('Runtime bundle must contain frames');
    if (!bundle.texture || !Number.isInteger(bundle.texture.width) || !Number.isInteger(bundle.texture.height)) throw new Error('Runtime bundle texture metadata must be valid');
    if (bundle.texture.data != null && !(bundle.texture.data instanceof Uint8ClampedArray) && !Array.isArray(bundle.texture.data)) throw new Error('Runtime bundle texture data must be a Uint8ClampedArray or array');
    if (!bundle.runtime || typeof bundle.runtime !== 'object') throw new Error('Runtime bundle runtime metadata must exist');
    if (!bundle.runtime.collisionMask || !Number.isInteger(bundle.runtime.collisionMask.width) || !Number.isInteger(bundle.runtime.collisionMask.height) || !Array.isArray(bundle.runtime.collisionMask.rows)) throw new Error('Runtime bundle collision mask must be valid');
    if (!bundle.runtime.anchor || !Number.isInteger(bundle.runtime.anchor.x) || !Number.isInteger(bundle.runtime.anchor.y)) throw new Error('Runtime bundle anchor must be valid');
    return true;
  }

  function buildRpgMakerRuntimeBundle(asset, options = {}) {
    validateStrictSymbolicAsset(asset);
    const scale = options.scale == null ? 1 : Number(options.scale);
    if (!Number.isInteger(scale) || scale <= 0 || scale > 64) throw new Error('Runtime bundle scale must be an integer from 1 to 64');
    let assetKind = options.assetKind || 'tile';
    if (assetKind === 'auto') assetKind = asset.canvas.width <= 48 && asset.canvas.height <= 48 ? 'tile' : 'character';
    if (!['tile', 'character'].includes(assetKind)) throw new Error('Runtime bundle assetKind must be tile, character, or auto');
    const renderMode = options.renderMode === 'exact' ? 'exact' : 'enhanced';
    const frameImage = renderStrictAssetByMode(asset, renderMode, scale);
    const collisionMask = buildRuntimeCollisionMask(asset);
    const anchor = { x: Math.floor(frameImage.width / 2), y: frameImage.height - 1 };
    const runtimeBase = {
      adapterVersion: '0.1',
      collisionMask,
      anchor,
      sourceCanvas: { width: asset.canvas.width, height: asset.canvas.height }
    };
    let texture;
    let frames;
    let sheet;
    let runtime;
    if (assetKind === 'tile') {
      texture = { width: frameImage.width, height: frameImage.height, data: new Uint8ClampedArray(frameImage.data) };
      sheet = { width: texture.width, height: texture.height, columns: 1, rows: 1 };
      frames = [{ id: 'tile_0', index: 0, x: 0, y: 0, width: texture.width, height: texture.height, role: options.tileRole || 'A5', kind: 'tile' }];
      runtime = {
        ...runtimeBase,
        tileRole: options.tileRole || 'A5',
        passability: 'auto'
      };
    } else {
      const columns = 3;
      const rows = 4;
      texture = createBlankImage(frameImage.width * columns, frameImage.height * rows);
      const directions = ['down', 'left', 'right', 'up'];
      const patterns = [0, 1, 2];
      frames = [];
      let frameIndex = 0;
      for (let row = 0; row < rows; row += 1) {
        for (let col = 0; col < columns; col += 1) {
          const x = col * frameImage.width;
          const y = row * frameImage.height;
          blitImageObject(frameImage, texture, x, y);
          frames.push({
            id: `char_${directions[row]}_${patterns[col]}`,
            index: frameIndex++,
            x,
            y,
            width: frameImage.width,
            height: frameImage.height,
            direction: directions[row],
            pattern: patterns[col],
            role: 'character-frame',
            kind: 'character'
          });
        }
      }
      sheet = { width: texture.width, height: texture.height, columns, rows };
      runtime = {
        ...runtimeBase,
        characterMode: 'single-character-sheet',
        directions,
        patterns
      };
    }
    const bundle = {
      schema: 'evemisslab.rpgmaker-runtime-bundle',
      version: '0.1',
      engine: 'rpgmaker-like',
      sourceDependency: 'NONE',
      sourceAssetSchema: asset.schema,
      sourceAssetVersion: asset.version,
      assetKind,
      renderMode,
      scale,
      frameSize: { width: frameImage.width, height: frameImage.height },
      sheet,
      frames,
      texture,
      runtime
    };
    validateRpgMakerRuntimeBundle(bundle);
    return bundle;
  }

  function runtimeBundleToJson(bundle, options = {}) {
    validateRpgMakerRuntimeBundle(bundle);
    const includeTextureData = options.includeTextureData === true;
    const jsonReady = JSON.parse(JSON.stringify(bundle, (key, value) => {
      if (key === 'data') return includeTextureData ? Array.from(value) : undefined;
      return value;
    }));
    if (!includeTextureData && jsonReady.texture) jsonReady.texture.hasTextureData = true;
    return JSON.stringify(jsonReady, null, 2);
  }

  function parseRuntimeBundleJson(text) {
    const bundle = JSON.parse(text);
    if (bundle.texture && Array.isArray(bundle.texture.data)) bundle.texture.data = new Uint8ClampedArray(bundle.texture.data);
    validateRpgMakerRuntimeBundle(bundle);
    return bundle;
  }


  function cloneImageObject(image) {
    return { width: image.width, height: image.height, data: new Uint8ClampedArray(image.data) };
  }

  function applyAutotileNeighborMask(image, neighborMask, scale) {
    const out = cloneImageObject(image);
    const north = (neighborMask & 1) !== 0;
    const east = (neighborMask & 2) !== 0;
    const south = (neighborMask & 4) !== 0;
    const west = (neighborMask & 8) !== 0;
    const band = Math.max(1, Math.round(scale * 0.45));

    for (let y = 0; y < out.height; y += 1) {
      for (let x = 0; x < out.width; x += 1) {
        const i = (y * out.width + x) * 4;
        let factor = 1;
        if (!north && y < band) factor *= (y + 1) / (band + 1);
        if (!south && y >= out.height - band) factor *= (out.height - y) / (band + 1);
        if (!west && x < band) factor *= (x + 1) / (band + 1);
        if (!east && x >= out.width - band) factor *= (out.width - x) / (band + 1);
        if (factor < 1) out.data[i + 3] = Math.round(out.data[i + 3] * factor);
      }
    }
    return out;
  }

  function validateSymbolicAutotileRuntimeBundle(bundle) {
    if (!bundle || typeof bundle !== 'object') throw new Error('Autotile runtime bundle must be an object');
    if (bundle.schema !== 'evemisslab.symbolic-autotile-runtime-bundle') throw new Error('Autotile runtime bundle schema mismatch');
    if (bundle.version !== '0.1') throw new Error('Autotile runtime bundle version mismatch');
    if (bundle.sourceDependency !== 'NONE') throw new Error('Autotile runtime bundle must remain source-blind');
    if (!['exact', 'enhanced'].includes(bundle.renderMode)) throw new Error('Autotile runtime bundle renderMode must be exact or enhanced');
    if (!bundle.frameSize || !Number.isInteger(bundle.frameSize.width) || !Number.isInteger(bundle.frameSize.height)) throw new Error('Autotile runtime frameSize must be valid');
    if (!bundle.sheet || bundle.sheet.columns !== 4 || bundle.sheet.rows !== 4) throw new Error('Autotile runtime sheet must be 4x4');
    if (!Array.isArray(bundle.variants) || bundle.variants.length !== 16) throw new Error('Autotile runtime bundle must contain 16 variants');
    if (!Array.isArray(bundle.variantTextures) || bundle.variantTextures.length !== 16) throw new Error('Autotile runtime bundle must contain 16 variant textures');
    if (!bundle.texture || !Number.isInteger(bundle.texture.width) || !Number.isInteger(bundle.texture.height)) throw new Error('Autotile runtime bundle texture must be valid');
    return true;
  }

  function buildSymbolicAutotileRuntimeBundle(asset, options = {}) {
    validateStrictSymbolicAsset(asset);
    const scale = options.scale == null ? 1 : Number(options.scale);
    if (!Number.isInteger(scale) || scale <= 0 || scale > 64) throw new Error('Autotile runtime scale must be an integer from 1 to 64');
    const renderMode = options.renderMode === 'exact' ? 'exact' : 'enhanced';
    const base = renderStrictAssetByMode(asset, renderMode, scale);
    const columns = 4;
    const rows = 4;
    const texture = createBlankImage(base.width * columns, base.height * rows);
    const variants = [];
    const variantTextures = [];

    for (let mask = 0; mask < 16; mask += 1) {
      const variant = applyAutotileNeighborMask(base, mask, scale);
      variantTextures.push(variant);
      const col = mask % columns;
      const row = Math.floor(mask / columns);
      const x = col * base.width;
      const y = row * base.height;
      blitImageObject(variant, texture, x, y);
      variants.push({
        id: `autotile_${mask.toString(16).padStart(2, '0')}`,
        index: mask,
        neighborMask: mask,
        neighbors: {
          north: (mask & 1) !== 0,
          east: (mask & 2) !== 0,
          south: (mask & 4) !== 0,
          west: (mask & 8) !== 0
        },
        x,
        y,
        width: base.width,
        height: base.height,
        row,
        column: col
      });
    }

    const bundle = {
      schema: 'evemisslab.symbolic-autotile-runtime-bundle',
      version: '0.1',
      engine: 'rpgmaker-like',
      sourceDependency: 'NONE',
      sourceAssetSchema: asset.schema,
      sourceAssetVersion: asset.version,
      renderMode,
      scale,
      frameSize: { width: base.width, height: base.height },
      sheet: { width: texture.width, height: texture.height, columns, rows },
      ruleSet: {
        neighborhood: '4-neighbor',
        bits: { north: 1, east: 2, south: 4, west: 8 },
        variantCount: 16,
        semantics: 'connected-neighbor-mask'
      },
      variants,
      variantTextures,
      texture,
      runtime: {
        collisionMask: buildRuntimeCollisionMask(asset),
        anchor: { x: Math.floor(base.width / 2), y: base.height - 1 },
        cacheable: true
      }
    };
    validateSymbolicAutotileRuntimeBundle(bundle);
    return bundle;
  }

  function stableRuntimeStringify(value) {
    if (value === null || typeof value !== 'object') return JSON.stringify(value);
    if (ArrayBuffer.isView(value)) return `[${Array.from(value).map((v) => stableRuntimeStringify(v)).join(',')}]`;
    if (Array.isArray(value)) return `[${value.map((item) => stableRuntimeStringify(item)).join(',')}]`;
    const keys = Object.keys(value).sort();
    return `{${keys.map((key) => `${JSON.stringify(key)}:${stableRuntimeStringify(value[key])}`).join(',')}}`;
  }

  function fnv1a32(text) {
    let hash = 0x811c9dc5;
    for (let i = 0; i < text.length; i += 1) {
      hash ^= text.charCodeAt(i);
      hash = Math.imul(hash, 0x01000193) >>> 0;
    }
    return hash.toString(16).padStart(8, '0');
  }

  function computeRuntimeRenderCacheKey(asset, options = {}) {
    validateStrictSymbolicAsset(asset);
    const normalizedOptions = {
      assetKind: options.assetKind || 'tile',
      scale: options.scale == null ? 1 : Number(options.scale),
      renderMode: options.renderMode === 'exact' ? 'exact' : 'enhanced',
      tileRole: options.tileRole || 'A5'
    };
    return `gsc-cache-v0.1-${fnv1a32(stableRuntimeStringify({ asset, options: normalizedOptions }))}`;
  }

  function createRuntimeRenderCache(options = {}) {
    const maxEntries = options.maxEntries == null ? 32 : Number(options.maxEntries);
    if (!Number.isInteger(maxEntries) || maxEntries <= 0) throw new Error('Runtime render cache maxEntries must be a positive integer');
    return {
      schema: 'evemisslab.runtime-render-cache',
      version: '0.1',
      maxEntries,
      entries: {},
      order: [],
      stats: { hits: 0, misses: 0, evictions: 0 }
    };
  }

  function touchRuntimeCacheKey(cache, key) {
    const index = cache.order.indexOf(key);
    if (index >= 0) cache.order.splice(index, 1);
    cache.order.push(key);
  }

  function getOrBuildRuntimeBundleCached(cache, asset, options = {}) {
    if (!cache || cache.schema !== 'evemisslab.runtime-render-cache' || cache.version !== '0.1') throw new Error('Invalid runtime render cache');
    const key = computeRuntimeRenderCacheKey(asset, options);
    if (Object.prototype.hasOwnProperty.call(cache.entries, key)) {
      cache.stats.hits += 1;
      touchRuntimeCacheKey(cache, key);
      return { key, hit: true, bundle: cache.entries[key] };
    }
    cache.stats.misses += 1;
    const bundle = options.assetKind === 'autotile'
      ? buildSymbolicAutotileRuntimeBundle(asset, options)
      : buildRpgMakerRuntimeBundle(asset, options);
    cache.entries[key] = bundle;
    touchRuntimeCacheKey(cache, key);
    while (cache.order.length > cache.maxEntries) {
      const evicted = cache.order.shift();
      delete cache.entries[evicted];
      cache.stats.evictions += 1;
    }
    return { key, hit: false, bundle };
  }

  function autotileRuntimeBundleToJson(bundle, options = {}) {
    validateSymbolicAutotileRuntimeBundle(bundle);
    const includeTextureData = options.includeTextureData === true;
    const jsonReady = JSON.parse(JSON.stringify(bundle, (key, value) => {
      if (key === 'data') return includeTextureData ? Array.from(value) : undefined;
      if (key === 'variantTextures') return undefined;
      return value;
    }));
    if (!includeTextureData && jsonReady.texture) jsonReady.texture.hasTextureData = true;
    return JSON.stringify(jsonReady, null, 2);
  }


  function resolveBatchTilesetProfile(profile) {
    if (profile === 'rpgmaker-like-a5') {
      return {
        id: 'rpgmaker-like-a5',
        label: 'A5-like',
        columns: 8,
        maxRows: 16,
        slotCount: 128,
        compatibility: 'layout-profile-only'
      };
    }
    if (profile === 'rpgmaker-like-b-e') {
      return {
        id: 'rpgmaker-like-b-e',
        label: 'B-E-like',
        columns: 16,
        maxRows: 16,
        slotCount: 256,
        compatibility: 'layout-profile-only'
      };
    }
    throw new Error('Batch tileset profile must be rpgmaker-like-a5 or rpgmaker-like-b-e');
  }

  function normalizeBatchTilesetEntries(entries) {
    if (!Array.isArray(entries) || entries.length === 0) throw new Error('Batch tileset requires at least one AssetSymbol');
    const seenIds = new Set();
    return entries.map((entry, index) => {
      const wrapped = entry && entry.asset ? entry : { asset: entry };
      const asset = wrapped.asset;
      validateStrictSymbolicAsset(asset);
      const id = wrapped.id == null || wrapped.id === '' ? `asset_${String(index).padStart(4, '0')}` : String(wrapped.id);
      if (seenIds.has(id)) throw new Error(`Batch tileset contains duplicate asset id: ${id}`);
      seenIds.add(id);
      return { id, asset };
    });
  }

  function validateBatchTilesetRuntimeBundle(bundle) {
    if (!bundle || typeof bundle !== 'object') throw new Error('Batch tileset bundle must be an object');
    if (bundle.schema !== 'evemisslab.batch-tileset-runtime-bundle') throw new Error('Batch tileset schema mismatch');
    if (bundle.version !== '0.1') throw new Error('Batch tileset version mismatch');
    if (bundle.engine !== 'rpgmaker-like') throw new Error('Batch tileset engine mismatch');
    if (bundle.sourceDependency !== 'NONE') throw new Error('Batch tileset must remain source-blind');
    if (!['rpgmaker-like-a5', 'rpgmaker-like-b-e'].includes(bundle.profile)) throw new Error('Batch tileset profile mismatch');
    if (!['exact', 'enhanced'].includes(bundle.renderMode)) throw new Error('Batch tileset renderMode must be exact or enhanced');
    if (!Number.isInteger(bundle.scale) || bundle.scale <= 0) throw new Error('Batch tileset scale must be a positive integer');
    if (!Number.isInteger(bundle.tileCount) || bundle.tileCount <= 0) throw new Error('Batch tileset tileCount must be positive');
    if (!bundle.cellSize || !Number.isInteger(bundle.cellSize.width) || bundle.cellSize.width <= 0 || !Number.isInteger(bundle.cellSize.height) || bundle.cellSize.height <= 0) throw new Error('Batch tileset cellSize must be valid');
    if (!bundle.sheet || !Number.isInteger(bundle.sheet.columns) || !Number.isInteger(bundle.sheet.rows) || !Number.isInteger(bundle.sheet.width) || !Number.isInteger(bundle.sheet.height)) throw new Error('Batch tileset sheet metadata must be valid');
    if (!Array.isArray(bundle.tiles) || bundle.tiles.length !== bundle.tileCount) throw new Error('Batch tileset tiles must match tileCount');
    if (!bundle.texture || !Number.isInteger(bundle.texture.width) || !Number.isInteger(bundle.texture.height)) throw new Error('Batch tileset texture metadata must be valid');
    if (bundle.texture.data != null && !(bundle.texture.data instanceof Uint8ClampedArray) && !Array.isArray(bundle.texture.data)) throw new Error('Batch tileset texture data must be a Uint8ClampedArray or array');
    if (!bundle.adapter || typeof bundle.adapter !== 'object' || typeof bundle.adapter.profile !== 'string') throw new Error('Batch tileset adapter metadata must exist');
    const expectedColumns = bundle.profile === 'rpgmaker-like-a5' ? 8 : 16;
    if (bundle.sheet.columns !== expectedColumns) throw new Error('Batch tileset sheet columns do not match profile');
    if (bundle.sheet.width !== bundle.cellSize.width * bundle.sheet.columns || bundle.sheet.height !== bundle.cellSize.height * bundle.sheet.rows) throw new Error('Batch tileset sheet dimensions do not match cell grid');
    if (bundle.texture.width !== bundle.sheet.width || bundle.texture.height !== bundle.sheet.height) throw new Error('Batch tileset texture dimensions do not match sheet');
    const ids = new Set();
    for (const tile of bundle.tiles) {
      if (!tile || typeof tile.id !== 'string' || !tile.id) throw new Error('Batch tileset tile id must be a non-empty string');
      if (ids.has(tile.id)) throw new Error(`Batch tileset contains duplicate tile id: ${tile.id}`);
      ids.add(tile.id);
      if (!Number.isInteger(tile.index) || !Number.isInteger(tile.row) || !Number.isInteger(tile.column)) throw new Error('Batch tileset tile mapping must use integer indices');
      if (!Number.isInteger(tile.x) || !Number.isInteger(tile.y) || !Number.isInteger(tile.width) || !Number.isInteger(tile.height)) throw new Error('Batch tileset tile geometry must use integer values');
      if (!Number.isInteger(tile.drawOffsetX) || !Number.isInteger(tile.drawOffsetY)) throw new Error('Batch tileset draw offsets must be integers');
    }
    return true;
  }

  function buildBatchTilesetRuntimeBundle(entries, options = {}) {
    const normalizedEntries = normalizeBatchTilesetEntries(entries);
    const profile = resolveBatchTilesetProfile(options.profile || 'rpgmaker-like-a5');
    const scale = options.scale == null ? 1 : Number(options.scale);
    if (!Number.isInteger(scale) || scale <= 0 || scale > 64) throw new Error('Batch tileset scale must be an integer from 1 to 64');
    const renderMode = options.renderMode === 'exact' ? 'exact' : 'enhanced';
    const cache = options.cache || null;
    const cacheStatsBefore = cache && cache.stats ? { hits: cache.stats.hits, misses: cache.stats.misses, evictions: cache.stats.evictions } : null;
    const renderedEntries = normalizedEntries.map((entry) => {
      if (cache) {
        const cached = getOrBuildRuntimeBundleCached(cache, entry.asset, {
          assetKind: 'tile',
          scale,
          renderMode,
          tileRole: profile.id
        });
        return { ...entry, rendered: cached.bundle.texture, cacheKey: cached.key, cacheHit: cached.hit };
      }
      return { ...entry, rendered: renderStrictAssetByMode(entry.asset, renderMode, scale), cacheKey: null, cacheHit: false };
    });
    let naturalCellWidth = 1;
    let naturalCellHeight = 1;
    for (const entry of renderedEntries) {
      naturalCellWidth = Math.max(naturalCellWidth, entry.rendered.width);
      naturalCellHeight = Math.max(naturalCellHeight, entry.rendered.height);
    }
    const cellWidth = options.cellWidth == null ? naturalCellWidth : Number(options.cellWidth);
    const cellHeight = options.cellHeight == null ? naturalCellHeight : Number(options.cellHeight);
    if (!Number.isInteger(cellWidth) || !Number.isInteger(cellHeight) || cellWidth <= 0 || cellHeight <= 0) throw new Error('Batch tileset cell dimensions must be positive integers');
    if (cellWidth < naturalCellWidth || cellHeight < naturalCellHeight) throw new Error('Batch tileset cell dimensions cannot be smaller than rendered assets');
    const rows = Math.max(1, Math.ceil(renderedEntries.length / profile.columns));
    if (rows > profile.maxRows) throw new Error(`Batch tileset exceeds ${profile.label} capacity of ${profile.slotCount} tiles`);
    const texture = createBlankImage(cellWidth * profile.columns, cellHeight * rows);
    const tiles = [];
    for (let index = 0; index < renderedEntries.length; index += 1) {
      const entry = renderedEntries[index];
      const row = Math.floor(index / profile.columns);
      const column = index % profile.columns;
      const cellX = column * cellWidth;
      const cellY = row * cellHeight;
      const drawOffsetX = Math.floor((cellWidth - entry.rendered.width) / 2);
      const drawOffsetY = Math.floor((cellHeight - entry.rendered.height) / 2);
      const drawX = cellX + drawOffsetX;
      const drawY = cellY + drawOffsetY;
      blitImageObject(entry.rendered, texture, drawX, drawY);
      tiles.push({
        id: entry.id,
        index,
        row,
        column,
        x: cellX,
        y: cellY,
        width: cellWidth,
        height: cellHeight,
        drawOffsetX,
        drawOffsetY,
        renderedWidth: entry.rendered.width,
        renderedHeight: entry.rendered.height,
        sourceAssetSchema: entry.asset.schema,
        sourceAssetVersion: entry.asset.version,
        runtime: {
          collisionMask: buildRuntimeCollisionMask(entry.asset),
          anchor: { x: Math.floor(cellWidth / 2), y: cellHeight - 1 }
        }
      });
    }
    const bundle = {
      schema: 'evemisslab.batch-tileset-runtime-bundle',
      version: '0.1',
      engine: 'rpgmaker-like',
      sourceDependency: 'NONE',
      profile: profile.id,
      renderMode,
      scale,
      tileCount: tiles.length,
      cellSize: { width: cellWidth, height: cellHeight },
      sheet: {
        columns: profile.columns,
        rows,
        width: texture.width,
        height: texture.height,
        order: 'row-major'
      },
      tiles,
      texture,
      adapter: {
        version: '0.1',
        profile: profile.label,
        profileId: profile.id,
        tileIndexBase: 0,
        coordinateOrigin: 'top-left',
        order: 'row-major',
        maxRows: profile.maxRows,
        slotCount: profile.slotCount,
        nativeCompatibility: profile.compatibility
      },
      cacheReuse: cache ? {
        enabled: true,
        hits: cache.stats.hits - cacheStatsBefore.hits,
        misses: cache.stats.misses - cacheStatsBefore.misses,
        evictions: cache.stats.evictions - cacheStatsBefore.evictions,
        keys: renderedEntries.map((entry) => entry.cacheKey)
      } : { enabled: false, hits: 0, misses: 0, evictions: 0, keys: [] }
    };
    validateBatchTilesetRuntimeBundle(bundle);
    return bundle;
  }

  function batchTilesetRuntimeBundleToJson(bundle, options = {}) {
    validateBatchTilesetRuntimeBundle(bundle);
    const includeTextureData = options.includeTextureData === true;
    const jsonReady = JSON.parse(JSON.stringify(bundle, (key, value) => {
      if (key === 'data') return includeTextureData ? Array.from(value) : undefined;
      return value;
    }));
    if (!includeTextureData && jsonReady.texture) jsonReady.texture.hasTextureData = true;
    return JSON.stringify(jsonReady, null, 2);
  }

  function parseBatchTilesetRuntimeBundleJson(text) {
    const bundle = JSON.parse(text);
    if (bundle.texture && Array.isArray(bundle.texture.data)) bundle.texture.data = new Uint8ClampedArray(bundle.texture.data);
    validateBatchTilesetRuntimeBundle(bundle);
    return bundle;
  }



  function normalizeNativeImportBaseName(baseName, profile) {
    let name = baseName == null ? '' : String(baseName).trim();
    if (!name) throw new Error('Native import baseName must be a non-empty filename');
    if (name.toLowerCase().endsWith('.png')) name = name.slice(0, -4);
    if (!name || name === '.' || name === '..' || name.includes('/') || name.includes('\\') || name.includes('..') || /[\u0000-\u001f]/.test(name)) {
      throw new Error('Native import baseName contains an unsafe filename/path sequence');
    }
    if (profile === 'character-single') {
      name = name.replace(/^\$+/, '');
      if (!name) throw new Error('Native import character baseName must contain characters after $');
      return `$${name}`;
    }
    return name.replace(/^\$+/, '');
  }

  function resolveRpgMakerNativeImportProfile(engine, profile) {
    if (!['rmmz', 'rmmv'].includes(engine)) throw new Error('Native import engine must be rmmz or rmmv');
    if (profile === 'a5') {
      return {
        profile: 'a5', folder: 'img/tilesets', tileSize: 48,
        columns: 8, rows: 16, width: 384, height: 768,
        slotCount: 128, reservedSlots: [], label: 'A5'
      };
    }
    if (['b', 'c', 'd', 'e'].includes(profile)) {
      return {
        profile, folder: 'img/tilesets', tileSize: 48,
        columns: 16, rows: 16, width: 768, height: 768,
        slotCount: 256, reservedSlots: profile === 'b' ? [0] : [], label: profile.toUpperCase()
      };
    }
    if (profile === 'character-single') {
      return {
        profile, folder: 'img/characters', tileSize: 48,
        columns: 3, rows: 4, width: null, height: null,
        slotCount: 12, reservedSlots: [], label: 'Single Character 3x4'
      };
    }
    throw new Error('Native import profile must be a5, b, c, d, e, or character-single');
  }

  function renderNativeTilesetCell(asset, renderMode, tileSize) {
    validateStrictSymbolicAsset(asset);
    if (asset.canvas.width > tileSize || asset.canvas.height > tileSize) {
      throw new Error(`Native tileset asset is too large for the ${tileSize}x${tileSize} native cell`);
    }
    const renderScale = Math.max(1, Math.min(
      Math.floor(tileSize / asset.canvas.width),
      Math.floor(tileSize / asset.canvas.height)
    ));
    const rendered = renderStrictAssetByMode(asset, renderMode, renderScale);
    if (rendered.width > tileSize || rendered.height > tileSize) throw new Error('Rendered native tileset asset exceeds native cell');
    return {
      rendered,
      renderScale,
      drawOffsetX: Math.floor((tileSize - rendered.width) / 2),
      drawOffsetY: Math.floor((tileSize - rendered.height) / 2)
    };
  }

  function validateRpgMakerNativeImportPackage(pkg) {
    if (!pkg || typeof pkg !== 'object') throw new Error('Native import package must be an object');
    if (pkg.schema !== 'evemisslab.rpgmaker-native-import-package') throw new Error('Native import package schema mismatch');
    if (pkg.version !== '0.1') throw new Error('Native import package version mismatch');
    if (!['rmmz', 'rmmv'].includes(pkg.engine)) throw new Error('Native import package engine mismatch');
    if (!['a5', 'b', 'c', 'd', 'e', 'character-single'].includes(pkg.profile)) throw new Error('Native import package profile mismatch');
    if (pkg.sourceDependency !== 'NONE') throw new Error('Native import package must remain source-blind');
    if (!['exact', 'enhanced'].includes(pkg.renderMode)) throw new Error('Native import package renderMode mismatch');
    if (!pkg.target || typeof pkg.target.fileName !== 'string' || typeof pkg.target.relativePath !== 'string') throw new Error('Native import package target metadata is required');
    if (!pkg.texture || !Number.isInteger(pkg.texture.width) || !Number.isInteger(pkg.texture.height)) throw new Error('Native import package texture dimensions are required');
    if (pkg.texture.data != null && !(pkg.texture.data instanceof Uint8ClampedArray) && !Array.isArray(pkg.texture.data)) throw new Error('Native import package texture data must be Uint8ClampedArray or array');
    if (!pkg.sheet || !Number.isInteger(pkg.sheet.columns) || !Number.isInteger(pkg.sheet.rows)) throw new Error('Native import package sheet metadata is required');
    if (!Array.isArray(pkg.reservedSlots) || !Array.isArray(pkg.mappings)) throw new Error('Native import package reservedSlots/mappings are required');
    if (!pkg.engineConstraints || !Number.isInteger(pkg.engineConstraints.tileSize)) throw new Error('Native import package engine constraints are required');
    if (pkg.profile === 'a5') {
      if (pkg.texture.width !== 384 || pkg.texture.height !== 768 || pkg.sheet.columns !== 8 || pkg.sheet.rows !== 16) throw new Error('A5 native package must be 384x768 with an 8x16 grid');
      if (pkg.mappings.length > 128) throw new Error('A5 native package exceeds capacity');
    } else if (['b', 'c', 'd', 'e'].includes(pkg.profile)) {
      if (pkg.texture.width !== 768 || pkg.texture.height !== 768 || pkg.sheet.columns !== 16 || pkg.sheet.rows !== 16) throw new Error('B-E native package must be 768x768 with a 16x16 grid');
      if (pkg.profile === 'b' && !pkg.reservedSlots.includes(0)) throw new Error('B native package must reserve slot zero');
      const capacity = pkg.profile === 'b' ? 255 : 256;
      if (pkg.mappings.length > capacity) throw new Error(`${pkg.profile.toUpperCase()} native package exceeds capacity`);
    } else if (pkg.profile === 'character-single') {
      if (!pkg.target.fileName.startsWith('$')) throw new Error('Single-character native package filename must start with $');
      if (pkg.sheet.columns !== 3 || pkg.sheet.rows !== 4 || pkg.frameCount !== 12) throw new Error('Single-character native package must use a 3x4 sheet with 12 frames');
      if (!pkg.frameSize || !Number.isInteger(pkg.frameSize.width) || !Number.isInteger(pkg.frameSize.height)) throw new Error('Single-character native package frameSize is required');
      if (pkg.texture.width !== pkg.frameSize.width * 3 || pkg.texture.height !== pkg.frameSize.height * 4) throw new Error('Single-character native package texture does not match frameSize');
    }
    const ids = new Set();
    for (const mapping of pkg.mappings) {
      if (!mapping || typeof mapping.id !== 'string' || !mapping.id) throw new Error('Native import mapping id is required');
      if (ids.has(mapping.id)) throw new Error(`Native import package contains duplicate asset id: ${mapping.id}`);
      ids.add(mapping.id);
    }
    return true;
  }

  function buildRpgMakerNativeImportPackage(entries, options = {}) {
    const engine = options.engine || 'rmmz';
    const profileId = options.profile || 'a5';
    const profile = resolveRpgMakerNativeImportProfile(engine, profileId);
    const renderMode = options.renderMode === 'exact' ? 'exact' : 'enhanced';
    const normalizedEntries = normalizeBatchTilesetEntries(entries);
    const baseName = normalizeNativeImportBaseName(options.baseName || `GSC_${profile.label.replace(/\s+/g, '_')}`, profile.profile);
    const fileName = `${baseName}.png`;
    const target = {
      folder: profile.folder,
      fileName,
      relativePath: `${profile.folder}/${fileName}`,
      mimeType: 'image/png'
    };

    if (profile.profile === 'character-single') {
      if (normalizedEntries.length !== 1) throw new Error('Single-character native package requires exactly one AssetSymbol');
      const scale = options.scale == null ? 1 : Number(options.scale);
      if (!Number.isInteger(scale) || scale <= 0 || scale > 64) throw new Error('Native character scale must be an integer from 1 to 64');
      const runtimeBundle = buildRpgMakerRuntimeBundle(normalizedEntries[0].asset, {
        assetKind: 'character', scale, renderMode
      });
      const pkg = {
        schema: 'evemisslab.rpgmaker-native-import-package',
        version: '0.1',
        engine,
        engineLabel: engine === 'rmmz' ? 'RPG Maker MZ' : 'RPG Maker MV',
        profile: profile.profile,
        sourceDependency: 'NONE',
        renderMode,
        tileSize: 48,
        target,
        sheet: { columns: 3, rows: 4, width: runtimeBundle.texture.width, height: runtimeBundle.texture.height, order: 'row-major' },
        frameSize: { ...runtimeBundle.frameSize },
        frameCount: runtimeBundle.frames.length,
        reservedSlots: [],
        mappings: runtimeBundle.frames.map((frame) => ({ ...frame, id: frame.id })),
        texture: { width: runtimeBundle.texture.width, height: runtimeBundle.texture.height, data: new Uint8ClampedArray(runtimeBundle.texture.data) },
        engineConstraints: {
          tileSize: 48,
          characterFrameSize: 'arbitrary',
          standardFrameSize: { width: 48, height: 48 },
          directions: ['down', 'left', 'right', 'up'],
          patterns: [0, 1, 2],
          singleCharacterPrefix: '$',
          folder: 'img/characters'
        },
        adapter: { version: '0.1', compatibility: 'native-layout-baseline', importAction: 'copy-png-to-project-folder' }
      };
      validateRpgMakerNativeImportPackage(pkg);
      return pkg;
    }

    const capacity = profile.slotCount - profile.reservedSlots.length;
    if (normalizedEntries.length > capacity) throw new Error(`Native ${profile.label} package exceeds capacity of ${capacity} assets`);
    const texture = createBlankImage(profile.width, profile.height);
    const mappings = [];
    let slotCursor = 0;
    for (const entry of normalizedEntries) {
      while (profile.reservedSlots.includes(slotCursor)) slotCursor += 1;
      if (slotCursor >= profile.slotCount) throw new Error(`Native ${profile.label} package exceeds capacity`);
      const cell = renderNativeTilesetCell(entry.asset, renderMode, profile.tileSize);
      const row = Math.floor(slotCursor / profile.columns);
      const column = slotCursor % profile.columns;
      const cellX = column * profile.tileSize;
      const cellY = row * profile.tileSize;
      const drawX = cellX + cell.drawOffsetX;
      const drawY = cellY + cell.drawOffsetY;
      blitImageObject(cell.rendered, texture, drawX, drawY);
      mappings.push({
        id: entry.id,
        slotIndex: slotCursor,
        row,
        column,
        x: cellX,
        y: cellY,
        width: profile.tileSize,
        height: profile.tileSize,
        renderScale: cell.renderScale,
        renderedWidth: cell.rendered.width,
        renderedHeight: cell.rendered.height,
        drawOffsetX: cell.drawOffsetX,
        drawOffsetY: cell.drawOffsetY,
        sourceAssetSchema: entry.asset.schema,
        sourceAssetVersion: entry.asset.version
      });
      slotCursor += 1;
    }
    const pkg = {
      schema: 'evemisslab.rpgmaker-native-import-package',
      version: '0.1',
      engine,
      engineLabel: engine === 'rmmz' ? 'RPG Maker MZ' : 'RPG Maker MV',
      profile: profile.profile,
      sourceDependency: 'NONE',
      renderMode,
      tileSize: profile.tileSize,
      target,
      sheet: { columns: profile.columns, rows: profile.rows, width: profile.width, height: profile.height, order: 'row-major' },
      frameCount: mappings.length,
      reservedSlots: profile.reservedSlots.slice(),
      mappings,
      texture,
      engineConstraints: {
        tileSize: profile.tileSize,
        requiredWidth: profile.width,
        requiredHeight: profile.height,
        requiredColumns: profile.columns,
        requiredRows: profile.rows,
        reservedSlots: profile.reservedSlots.slice(),
        folder: 'img/tilesets'
      },
      adapter: {
        version: '0.1',
        compatibility: 'native-layout-baseline',
        importAction: 'copy-png-to-project-folder',
        profileLabel: profile.label,
        notes: profile.profile === 'b' ? ['slot 0 reserved blank'] : []
      }
    };
    validateRpgMakerNativeImportPackage(pkg);
    return pkg;
  }

  function rpgMakerNativeImportPackageToJson(pkg, options = {}) {
    validateRpgMakerNativeImportPackage(pkg);
    const includeTextureData = options.includeTextureData === true;
    const jsonReady = JSON.parse(JSON.stringify(pkg, (key, value) => {
      if (key === 'data') return includeTextureData ? Array.from(value) : undefined;
      return value;
    }));
    if (!includeTextureData && jsonReady.texture) jsonReady.texture.hasTextureData = true;
    return JSON.stringify(jsonReady, null, 2);
  }

  function parseRpgMakerNativeImportPackageJson(text) {
    const pkg = JSON.parse(text);
    if (pkg.texture && Array.isArray(pkg.texture.data)) pkg.texture.data = new Uint8ClampedArray(pkg.texture.data);
    validateRpgMakerNativeImportPackage(pkg);
    return pkg;
  }


  function getRpgMakerTilesetSlotForNativeProfile(profile) {
    const slots = {
      a5: { slotName: 'A5', slotIndex: 4 },
      b: { slotName: 'B', slotIndex: 5 },
      c: { slotName: 'C', slotIndex: 6 },
      d: { slotName: 'D', slotIndex: 7 },
      e: { slotName: 'E', slotIndex: 8 }
    };
    return slots[profile] || null;
  }

  function validateRpgMakerProjectBindingPlan(plan) {
    if (!plan || typeof plan !== 'object') throw new Error('Project binding plan must be an object');
    if (plan.schema !== 'evemisslab.rpgmaker-project-binding-plan') throw new Error('Project binding plan schema mismatch');
    if (plan.version !== '0.1') throw new Error('Project binding plan version mismatch');
    if (!['rmmz', 'rmmv'].includes(plan.engine)) throw new Error('Project binding plan engine mismatch');
    if (plan.safeMode !== 'preview-only' || plan.mutatesProject !== false) throw new Error('Project binding plan must remain preview-only and non-mutating');
    if (plan.sourceDependency !== 'NONE') throw new Error('Project binding plan must remain source-blind');
    if (!plan.nativePackage || typeof plan.nativePackage.profile !== 'string' || typeof plan.nativePackage.targetPath !== 'string') throw new Error('Project binding plan nativePackage metadata is required');
    if (!Array.isArray(plan.operations) || plan.operations.length < 1) throw new Error('Project binding plan requires operations');
    for (const operation of plan.operations) {
      if (!operation || operation.kind !== 'write-generated-texture') throw new Error('Project binding plan operation kind mismatch');
      if (typeof operation.relativePath !== 'string' || !operation.relativePath || operation.relativePath.startsWith('/') || operation.relativePath.includes('..')) throw new Error('Project binding plan operation relativePath is unsafe');
      if (!['prompt', 'skip', 'replace'].includes(operation.overwritePolicy)) throw new Error('Project binding plan overwritePolicy mismatch');
      if (operation.requiresUserConfirmation !== true) throw new Error('Project binding plan operations must require user confirmation');
    }
    if (!Array.isArray(plan.databasePatches)) throw new Error('Project binding plan databasePatches must be an array');
    for (const patch of plan.databasePatches) {
      if (!patch || patch.file !== 'data/Tilesets.json' || patch.operation !== 'set-tileset-image-slot') throw new Error('Project binding plan database patch mismatch');
      if (!Number.isInteger(patch.tilesetId) || patch.tilesetId <= 0) throw new Error('Project binding plan tilesetId must be a positive integer');
      if (!Number.isInteger(patch.slotIndex) || patch.slotIndex < 0 || patch.slotIndex > 8) throw new Error('Project binding plan slotIndex is invalid');
      if (typeof patch.slotName !== 'string' || typeof patch.value !== 'string' || !patch.value) throw new Error('Project binding plan patch slot/value metadata is invalid');
    }
    if (!plan.resourceRef || typeof plan.resourceRef !== 'object' || typeof plan.resourceRef.kind !== 'string') throw new Error('Project binding plan resourceRef is required');
    if (plan.resourceRef.kind === 'tileset') {
      if (!Number.isInteger(plan.resourceRef.tilesetId) || plan.resourceRef.tilesetId <= 0) throw new Error('Project binding plan tileset resourceRef requires tilesetId');
      if (!Number.isInteger(plan.resourceRef.slotIndex) || typeof plan.resourceRef.imageName !== 'string') throw new Error('Project binding plan tileset resourceRef is invalid');
    } else if (plan.resourceRef.kind === 'character') {
      if (typeof plan.resourceRef.characterName !== 'string' || !plan.resourceRef.characterName.startsWith('$')) throw new Error('Project binding plan character resourceRef must use $ single-character name');
    } else {
      throw new Error('Project binding plan resourceRef kind mismatch');
    }
    return true;
  }

  function buildRpgMakerProjectBindingPlan(nativePackage, options = {}) {
    validateRpgMakerNativeImportPackage(nativePackage);
    const overwritePolicy = options.overwritePolicy || 'prompt';
    if (!['prompt', 'skip', 'replace'].includes(overwritePolicy)) throw new Error('Project binding overwritePolicy must be prompt, skip, or replace');
    const profile = nativePackage.profile;
    const slot = getRpgMakerTilesetSlotForNativeProfile(profile);
    const imageName = nativePackage.target.fileName.replace(/\.png$/i, '');
    const operations = [{
      id: 'write-native-texture',
      kind: 'write-generated-texture',
      relativePath: nativePackage.target.relativePath,
      source: 'native-import-package.texture',
      overwritePolicy,
      requiresUserConfirmation: true
    }];
    const databasePatches = [];
    let resourceRef;
    if (slot) {
      const tilesetId = Number(options.tilesetId);
      if (!Number.isInteger(tilesetId) || tilesetId <= 0) throw new Error('Project binding tilesetId must be a positive integer for tileset profiles');
      const patch = {
        file: 'data/Tilesets.json',
        operation: 'set-tileset-image-slot',
        tilesetId,
        slotName: slot.slotName,
        slotIndex: slot.slotIndex,
        value: imageName
      };
      databasePatches.push(patch);
      resourceRef = {
        kind: 'tileset',
        tilesetId,
        slotName: slot.slotName,
        slotIndex: slot.slotIndex,
        imageName,
        relativePath: nativePackage.target.relativePath
      };
    } else if (profile === 'character-single') {
      resourceRef = {
        kind: 'character',
        characterName: imageName,
        relativePath: nativePackage.target.relativePath,
        frameLayout: '3x4-single-character'
      };
    } else {
      throw new Error('Project binding profile is unsupported');
    }
    const plan = {
      schema: 'evemisslab.rpgmaker-project-binding-plan',
      version: '0.1',
      engine: nativePackage.engine,
      engineLabel: nativePackage.engineLabel,
      safeMode: 'preview-only',
      mutatesProject: false,
      sourceDependency: 'NONE',
      nativePackage: {
        schema: nativePackage.schema,
        version: nativePackage.version,
        profile,
        targetPath: nativePackage.target.relativePath,
        fileName: nativePackage.target.fileName,
        texture: { width: nativePackage.texture.width, height: nativePackage.texture.height }
      },
      operations,
      databasePatches,
      resourceRef,
      projectRequirements: [
        'User must select the correct RPG Maker project root before applying this plan.',
        'Generated image write and database patch require explicit confirmation.',
        'Back up project data before any future in-place mutation step.'
      ]
    };
    validateRpgMakerProjectBindingPlan(plan);
    return plan;
  }

  function applyRpgMakerTilesetsPatchPreview(tilesetsSnapshot, plan) {
    validateRpgMakerProjectBindingPlan(plan);
    if (!Array.isArray(tilesetsSnapshot)) throw new Error('Tilesets patch preview requires a Tilesets.json array snapshot');
    const preview = deepClone(tilesetsSnapshot);
    for (const patch of plan.databasePatches) {
      const entry = preview.find((item) => item && Number(item.id) === patch.tilesetId) || preview[patch.tilesetId];
      if (!entry || typeof entry !== 'object') throw new Error(`Tilesets patch preview cannot find tilesetId ${patch.tilesetId}`);
      if (!Array.isArray(entry.tilesetNames)) throw new Error(`Tileset ${patch.tilesetId} does not contain tilesetNames array`);
      while (entry.tilesetNames.length < 9) entry.tilesetNames.push('');
      entry.tilesetNames[patch.slotIndex] = patch.value;
    }
    return preview;
  }

  function projectBindingPlanToJson(plan) {
    validateRpgMakerProjectBindingPlan(plan);
    return JSON.stringify(plan, null, 2);
  }

  function parseProjectBindingPlanJson(text) {
    const plan = JSON.parse(text);
    validateRpgMakerProjectBindingPlan(plan);
    return plan;
  }

  function strictSymbolicAssetToJson(asset) {
    validateStrictSymbolicAsset(asset);
    return JSON.stringify(asset, null, 2);
  }

  function parseStrictSymbolicAssetJson(text) {
    const asset = JSON.parse(text);
    validateStrictSymbolicAsset(asset);
    return asset;
  }

  function formatFeatures(features) {
    return JSON.stringify({
      width: features.width,
      height: features.height,
      aspectRatio: Number(features.aspectRatio.toFixed(4)),
      averageHex: features.averageHex,
      averageLuma: Number(features.averageLuma.toFixed(4)),
      lumaStd: Number(features.lumaStd.toFixed(4)),
      averageSaturation: Number(features.averageSaturation.toFixed(4)),
      edgeDensity: Number(features.edgeDensity.toFixed(6)),
      warmth: Number(features.warmth.toFixed(6)),
      centerSkinRatio: Number(features.centerSkinRatio.toFixed(6)),
      palette: features.palette,
      featureScores: Object.fromEntries(Object.entries(features.featureScores).map(([k, v]) => [k, Number(v.toFixed(4))]))
    }, null, 2);
  }

  function escapeHtml(text) {
    return String(text).replace(/[&<>"']/g, (m) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m]));
  }

  function buildStandaloneHtml(scene, sourceDataUrl) {
    validateScene(scene);
    const sceneJson = sceneToJson(scene).replace(/</g, '\u003c').replace(/<\//g, '<\/');
    const renderFn = drawScene.toString();
    const depCode = [
      clamp, lerp, hexToRgb, rgbToHex, blendHex, applyAlpha, rgbToHsl, hslToRgb, hueWrap, styleRegionColor, computeStyleProfile, computeMotionState, roundRect,
      triangle, drawCircleAccent, drawStar, wrapText, sobelEdges, buildStyledSourceImage, computeSemanticLayerPlan, createBlankImageLike, buildSemanticRenderBundle, drawBackground, drawCopyPanel, drawStatusBadge, drawPortrait,
      drawSceneSubject, drawProductPoster, drawReconstructionSubject, drawHighFidelitySubject, drawSemanticBundle, validateScene, getIndex, computeLuma, posterizeChannel, mixChannel
    ].map((fn) => fn.toString()).join('\n;\n');
    return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>${escapeHtml(scene.meta.title)}</title><style>body{margin:0;background:#11141b;color:#eef3fb;font-family:system-ui,sans-serif;padding:24px}.wrap{max-width:1540px;margin:0 auto}.grid{display:grid;grid-template-columns:minmax(0,.72fr) minmax(0,1fr);gap:18px}canvas,img{width:100%;height:auto;border-radius:14px;border:1px solid rgba(255,255,255,.12);background:#fff}pre{background:#0d1018;color:#f7fbff;border-radius:14px;padding:16px;font-family:Consolas,monospace;white-space:pre-wrap;overflow:auto}@media(max-width:1000px){.grid{grid-template-columns:1fr}}</style></head><body><div class="wrap"><h1>${escapeHtml(scene.meta.title)}</h1><p>${escapeHtml(scene.meta.subtitle)}</p><div class="grid"><div><h2>Source</h2><img id="srcimg" src="${sourceDataUrl}" alt="Source image"></div><div><h2>Compiled Preview</h2><canvas id="canvas" width="1600" height="1040"></canvas></div></div><h2>Scene JSON</h2><pre>${escapeHtml(sceneToJson(scene))}</pre></div><script>${depCode};const drawScene=${renderFn};const scene=${sceneJson};const canvas=document.getElementById('canvas');const ctx=canvas.getContext('2d');const srcimg=document.getElementById('srcimg');let renderBundle=null;let start=performance.now();function imageElToObject(img){const c=document.createElement('canvas');c.width=img.naturalWidth;c.height=img.naturalHeight;const cctx=c.getContext('2d');cctx.drawImage(img,0,0);const id=cctx.getImageData(0,0,c.width,c.height);return {width:c.width,height:c.height,data:new Uint8ClampedArray(id.data)};}function imageObjToCanvas(obj){const c=document.createElement('canvas');c.width=obj.width;c.height=obj.height;const cctx=c.getContext('2d');cctx.putImageData(new ImageData(obj.data,obj.width,obj.height),0,0);return c;}function materializeBundle(bundle){return {mode:bundle.mode,width:bundle.width,height:bundle.height,styledCanvas:imageObjToCanvas(bundle.styled),layers:{backgroundCanvas:imageObjToCanvas(bundle.layers.background),subjectCanvas:imageObjToCanvas(bundle.layers.subject),glowCanvas:imageObjToCanvas(bundle.layers.glow),foregroundCanvas:imageObjToCanvas(bundle.layers.foreground)},stats:bundle.stats,plan:bundle.plan};}function tick(now){drawScene(ctx,scene,canvas.width,canvas.height,(now-start)/1000,renderBundle);requestAnimationFrame(tick);}function init(){const obj=imageElToObject(srcimg);renderBundle=materializeBundle(buildSemanticRenderBundle(obj,scene));requestAnimationFrame(tick);}if(srcimg.complete&&srcimg.naturalWidth){init();}else{srcimg.addEventListener('load',init,{once:true});}</script></body></html>`;
  }



  global.GenerativeSymbolCompilerCore = {
    clamp,
    deepClone,
    rgbToHsl,
    hslToRgb,
    computeLuma,
    resizeDimensions,
    createCompilerConfig,
    validateCompilerConfig,
    configToJson,
    parseConfigJson,
    createDemoImage,
    sobelEdges,
    analyzeImage,
    inferSubject,
    downsampleImage,
    extractDominantPalette,
    buildRegionMap,
    styleRegionColor,
    computeReconstructionOptions,
    compileScene,
    validateScene,
    sceneToJson,
    parseSceneJson,
    computeStyleProfile,
    computeMotionState,
    buildStyledSourceImage,
    computeSemanticLayerPlan,
    buildSemanticRenderBundle,
    normalizePixelLikeImage,
    extractStrictContourAnchors,
    extractStrictSkeletonGraph,
    extractStrictMedialHints,
    extractStrictPartGrammar,
    extractStrictTopology,
    compileNormalizedStrictSymbolicAsset,
    compileStrictSymbolicAsset,
    validateStrictSymbolicAsset,
    renderStrictSymbolicAsset,
    renderEnhancedStrictSymbolicAsset,
    validateRpgMakerRuntimeBundle,
    buildRpgMakerRuntimeBundle,
    runtimeBundleToJson,
    parseRuntimeBundleJson,
    validateSymbolicAutotileRuntimeBundle,
    buildSymbolicAutotileRuntimeBundle,
    autotileRuntimeBundleToJson,
    computeRuntimeRenderCacheKey,
    createRuntimeRenderCache,
    getOrBuildRuntimeBundleCached,
    validateBatchTilesetRuntimeBundle,
    buildBatchTilesetRuntimeBundle,
    batchTilesetRuntimeBundleToJson,
    parseBatchTilesetRuntimeBundleJson,
    validateRpgMakerNativeImportPackage,
    buildRpgMakerNativeImportPackage,
    rpgMakerNativeImportPackageToJson,
    parseRpgMakerNativeImportPackageJson,
    validateRpgMakerProjectBindingPlan,
    buildRpgMakerProjectBindingPlan,
    applyRpgMakerTilesetsPatchPreview,
    projectBindingPlanToJson,
    parseProjectBindingPlanJson,
    strictSymbolicAssetToJson,
    parseStrictSymbolicAssetJson,
    drawProductionOutput,
    drawScene,
    formatFeatures,
    buildStandaloneHtml
  };
})(window);

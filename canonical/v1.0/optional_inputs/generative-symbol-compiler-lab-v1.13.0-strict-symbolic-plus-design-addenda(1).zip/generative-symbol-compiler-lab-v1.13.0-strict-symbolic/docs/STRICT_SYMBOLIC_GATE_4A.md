# STRICT_SYMBOLIC_GATE_4A

## 目標

Gate 4A 先不直接做 skeleton，而是先建立一個更穩定的中介層：

$$
\text{region mask} \to \text{ordered contour anchors} \to \text{turning points}.
$$

這一層的作用是把原本僅有的 boundary pixel set，提升成帶順序的外形支點資訊，供後續：

- corner-aware rerender
- skeleton hints
- sprite part grammar
- tile edge grammar

使用。

## 目前輸出

對每個 region，`region.topology.contour` 現在包含：

- `orderedAnchors`
- `turningPoints`
- `anchorCount`
- `turnCount`

其中 anchor 目前以 boundary corner exposure 與必要時的 extrema fallback 組成，再依相對於 region centroid 的角度排序。

## 目前定位

這是 **baseline ordered contour representation**，不是最終的精確輪廓追蹤器。它的任務是先為 Gate 4 / Gate 5 提供穩定、可驗證、可序列化的幾何支點。

## 已驗證

- ring-shaped region 至少能得到一組有序 anchors 與 turning points
- solid rectangle 至少能得到四個 turning points
- asset summary 會統計總 contour anchors 與總 turning points

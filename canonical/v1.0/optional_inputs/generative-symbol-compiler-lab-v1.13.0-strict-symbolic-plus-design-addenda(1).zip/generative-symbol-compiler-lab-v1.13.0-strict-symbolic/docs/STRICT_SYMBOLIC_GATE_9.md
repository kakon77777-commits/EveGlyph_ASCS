# STRICT_SYMBOLIC_GATE_9

## 目標

Gate 9 將多個 canonical AssetSymbol 組成 engine-facing batch tileset：

$$
\{S_1,S_2,\ldots,S_n\} \to B_{\mathrm{tileset}}.
$$

## Baseline profiles

- `rpgmaker-like-a5`：8 columns / up to 16 rows
- `rpgmaker-like-b-e`：16 columns / up to 16 rows

## 目前能力

- deterministic row-major tile mapping
- mixed-size frame centering into a common cell
- exact / enhanced render mode selection
- Gate 8 runtime cache reuse
- JSON manifest / PNG sheet export
- source-blind consumer layer

## 已驗證

- A5-like mapping
- B-E-like 16-column rollover
- mixed-size centering
- duplicate id rejection
- JSON round-trip
- runtime cache reuse
- local UI batch queue / export controls

## 非宣稱

這一版不宣稱已完成 RPG Maker MV/MZ 原生 tileset packaging、真正 A1–A5 quadrant rules 或 plugin injection。它是 engine-facing batch layout baseline。

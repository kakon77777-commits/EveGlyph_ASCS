const fs = require('fs');
const vm = require('vm');
const sharp = require('sharp');

(async () => {
  const coreCode = fs.readFileSync('/mnt/data/generative-symbol-compiler-lab-v0.6.1/src/core.js','utf8');
  const sandbox = { window: {} };
  vm.createContext(sandbox);
  vm.runInContext(coreCode, sandbox);
  const core = sandbox.window.GenerativeSymbolCompilerCore;
  const inputPath = '/mnt/data/generative-symbol-compiler-lab-v0.6.1/examples/user-regression-source.png';
  const { data, info } = await sharp(inputPath).ensureAlpha().raw().toBuffer({ resolveWithObject: true });
  const image = { width: info.width, height: info.height, data: new Uint8ClampedArray(data) };
  const features = core.analyzeImage(image);
  const cfg = core.createCompilerConfig();
  cfg.targetStyle = 'painterly';
  const scene = core.compileScene(features, cfg, image);
  fs.writeFileSync('/mnt/data/generative-symbol-compiler-lab-v0.6.1/examples/user-regression-scene.json', core.sceneToJson(scene));
  console.log(JSON.stringify({
    compiledSubject: scene.probe.subject,
    inferred: scene.compiler.inferredSubject,
    reconstruction: scene.compiler.reconstruction,
    symbols: scene.symbols.length,
    hasPortraitHead: scene.symbols.includes('PORTRAIT_HEAD'),
    title: scene.meta.title
  }, null, 2));
})();

# STRICT_SYMBOLIC_GATE_4C

## 目標

Gate 4C 的目標是把 Gate 4B 的 pixel-level skeleton hints 轉成 structural skeleton graph：

$$
K \to G_K=(V_K,E_K).
$$

## 目前資料模型

`region.topology.medial.graph`：

- `nodes`
- `edges`
- `nodeCount`
- `edgeCount`
- `branchlessPathCount`

目前的 `nodes` 主要是：

- `endpoint`
- `junction`
- `isolated`
- `cycle-anchor`

而 `edges` 則沿 skeleton 追蹤 branchless path，並保存 polyline 座標與 segment 長度。

## 已驗證

- 一像素寬水平線會壓成 2 個 node + 1 個 edge
- plus-shape 會形成以 junction 為核心的骨架圖
- asset summary 會統計總 node / edge / path 數量

## 作用

這一層提供後續：

- skeleton graph simplification
- part grammar
- pose / symmetry reasoning
- topology-aware rerender

所需的最小結構圖。

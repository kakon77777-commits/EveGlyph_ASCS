# STRICT_SYMBOLIC_GATE_4B

## 目標

Gate 4B 的目標是為每個可見 region 建立一個 deterministic、可序列化的 skeleton / medial hint baseline：

$$
\text{region mask}
\to
(\text{skeleton},\text{endpoints},\text{junctions},\rho).
$$

這裡的 $\rho$ 表示 skeleton point 到 region 外部的離散距離提示。

## Skeleton baseline

目前使用 Zhang–Suen thinning：

- 保留單像素線；
- 對厚實 region 反覆 thinning；
- 產生 1-pixel digital skeleton baseline；
- 非最終 skeleton graph。

## Medial radius baseline

同一個 region mask 另外計算 Manhattan distance transform。

每個 skeleton point：

```json
{
  "x": 12,
  "y": 8,
  "radius": 3
}
```

其中 `radius` 是離散格點下的 boundary-distance hint。

## Branch hints

基於 skeleton 的 8-neighbor degree：

- degree <= 1：endpoint hint
- degree >= 3：junction hint

這些仍是 pixel-level hints；junction clustering / skeleton graph compression 留到下一 sub-gate。

## 透明 region

透明 region 目前標記為 `skipped: true`，不進行 skeletonization。原因是透明背景通常只是承載域，而不是應進入生成幾何的視覺部件。

## AssetSymbol v0.5

新增：

```text
region.topology.medial
asset.topology.totalSkeletonPixels
asset.topology.totalSkeletonEndpoints
asset.topology.totalSkeletonJunctions
asset.topology.maxMedialRadius
```

## 已驗證

- 5×5 solid square 會收斂成非空 skeleton，中心 medial radius >= 3
- 1×5 line 保留完整 skeleton 並產生 2 endpoints
- plus shape 產生 branch/junction hints
- JSON round-trip 與 source-blind reconstruction 維持成立

## 下一步

建議下一 sub-gate：

**Gate 4C — Skeleton Graph / Segment Compression**

把 pixel-level skeleton hints 壓縮成 node-edge graph，再進入 part grammar。

# STRICT_SYMBOLIC_GATE_7

## 目標

Gate 7 引入 RPG Maker-like visual runtime baseline：

$$
S 	o B_R,
$$

其中 $S$ 是 canonical `AssetSymbol`，$B_R$ 是 engine-facing runtime bundle。

## 目前提供

- tile runtime bundle
- character 3×4 single-character sheet
- frame manifest / sheet metadata
- collision mask
- anchor metadata
- runtime texture image data

## 已驗證

- 可從 `AssetSymbol` 直接建立 runtime bundle
- 可從 `AssetSymbol JSON` 建立 runtime bundle
- exact / enhanced render modes 在 runtime bundle 上仍可切換
- runtime bundle JSON round-trip 可驗證 metadata

## 仍未完成

- autotile decomposition
- runtime render cache strategy
- true RPG Maker plugin / engine injection
- engine-specific animation semantics beyond the baseline 3×4 sheet

# STRICT_SYMBOLIC_GATE_2

## 命題

Gate 2 不再直接要求：

$$
R(S)=I.
$$

而是改成先顯式引入正規化算子：

$$
I \xrightarrow{N} I_N \xrightarrow{C} S,\qquad \cancel I,\qquad S\xrightarrow{R}\hat I,
$$

並驗證：

$$
\hat I = I_N.
$$

也就是說，若輸入只是 **pixel-like** 而非乾淨 finite-palette pixel art，則必須先經過 canonical normalization，再交給 strict symbolic compiler。

## 目前實作的 normalizer

### 1. alpha 二值化
- 將中間 alpha 壓到 $0$ 或 $255$
- 避免半透明雜訊在 strict domain 內造成不必要 palette 爆炸

### 2. 有限 palette 量化
- 以頻率最高的色作 anchor
- 其餘顏色映射到最近 anchor
- 讓近似重複色可回收到有限 palette

### 3. isolated-pixel despeckle
- 用 4-neighbor 多數決處理單點雜訊
- 目前是單輪、保守式平滑

## API

- `normalizePixelLikeImage(image, options)`
- `compileNormalizedStrictSymbolicAsset(image, options)`

其中 `options` 目前包含：

```js
{
  alphaThreshold: 127,
  paletteSize: 64,
  despeckle: false,
  maxPalette: 64
}
```

## UI workflow

`strict-symbolic.html` 現在提供兩條 compile route：

- `Gate 1 · Exact`
- `Gate 2 · Normalized`

當走 Gate 2 時，頁面會直接顯示：

$$
\text{Source} \rightarrow \text{Normalized target} \rightarrow R(S)
$$

這樣可以直接觀察「變形」到底發生在 normalizer，還是發生在 symbolic representation / renderer。

## 目前限制

- 尚未做 lattice inference / scale inference
- 尚未做 contour-aware normalization
- palette 量化是輕量 deterministic anchor mapping，不是完整最佳化色彩分群
- despeckle 目前只處理非常局部、明顯的 isolated noise

## 下一關

Gate 3 將往：

- contour
- corner
- skeleton
- hole count
- symmetry

推進，開始從 `RUN geometry` 萃取更高階的 topology。

# VALIDATION

Fresh verification target for `v1.13.0-strict-symbolic`:

```bash
node --test tests/core.test.js tests/strict-symbolic.test.js
node --check src/core.js
node --check strict-symbolic-app.js
node --check app.js
```

Current result at packaging time:

- 105 / 105 automated tests passing
- strict path includes Gate 1 through Gate 11
- Gate 11 binding plan remains preview-only and does not mutate project data
- Tilesets.json patch preview operates on a cloned snapshot
- character binding does not create a Tilesets.json database patch

Additional invariants:

- strict exact renderer remains source-blind and bit-faithful
- normalized compile path still reconstructs the explicit normalized target
- enhanced renderer remains source-blind
- native import packages remain consumer-layer artifacts over AssetSymbol
- project binding plans remain non-mutating review artifacts
- AssetSymbol v0.7 remains the canonical representation

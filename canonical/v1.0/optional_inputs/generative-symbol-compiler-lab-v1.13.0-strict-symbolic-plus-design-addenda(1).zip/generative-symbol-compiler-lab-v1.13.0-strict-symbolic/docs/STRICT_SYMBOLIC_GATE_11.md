# STRICT_SYMBOLIC_GATE_11

## Goal

Gate 11 introduces a preview-only RPG Maker project binding layer:

$$
P_{\mathrm{native}} \to B_{\mathrm{project}}.
$$

## Current capabilities

- native PNG target path planning
- Tilesets.json slot patch planning for A5 / B / C / D / E
- `$` single-character resource reference
- non-mutating Tilesets.json patch preview
- JSON serialize / parse / validation

## Safety boundary

- `safeMode = preview-only`
- `mutatesProject = false`
- no File System Access API writes
- no automatic overwrite
- no plugin injection
- no project database mutation

## Next

Gate 12 should add an explicitly confirmed transactional apply layer with backup / rollback guards.

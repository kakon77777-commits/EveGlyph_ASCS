# STRICT_SYMBOLIC_GATE_6

## 目標

Gate 6 引入第一個保守的 enhanced rerender baseline：

$$
R_{\mathrm{enhanced}}(S;\,\text{topology},\text{contour},\text{medial},G_K,P).
$$

## 性質

- 只吃 canonical `AssetSymbol`
- 不讀取原始 source image
- Gate 1 exact renderer 保留不變
- 主要作用於 preview / upscale path

## 目前使用的 metadata

- region boundary
- contour ordered anchors / turning points
- medial max radius
- skeleton graph edge count
- part grammar primitive / orientation / role

## 已驗證

- enhanced output 與 exact block scaling 有可觀察差異
- output dimensions 可控
- silhouette 會出現 partial alpha
- ring hole 能維持透明
- 改變 `partGrammar.primitive` 會影響 enhanced output

## 下一步

將 Gate 6 baseline 逐步推向更穩定的 topology-aware production renderer，並讓 Gate 7 runtime 可以直接消費 enhanced 或 cached texture outputs。

# Identity Retention Regression

## v0.6.0 symptom

輸入為明確藍白卡通角色，但輸出變成預製人物半身像。

根因：

```text
image -> global features -> inferred subject -> fixed renderer template
```

沒有任何 source geometry / color regions 進入 renderer。

## v0.6.1 fix

```text
image
-> downsampled structural map
-> dominant palette
-> quantized RLE map
-> connected region metadata
-> REGION symbols
-> reconstruction renderer
```

實際使用者回歸樣本結果：

- source crop: 432 × 486
- reconstruction map: approximately 284 × 320
- palette: 20 colors
- region metadata: up to 260 regions
- template symbol `PORTRAIT_HEAD`: absent
- `probe.subject`: reconstruction
- classifier inference remains metadata only

比較圖見 `examples/user-regression-comparison.png`。

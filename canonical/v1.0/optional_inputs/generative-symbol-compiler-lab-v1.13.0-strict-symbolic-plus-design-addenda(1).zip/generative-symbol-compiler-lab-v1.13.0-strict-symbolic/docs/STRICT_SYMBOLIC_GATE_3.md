# STRICT_SYMBOLIC_GATE_3

## 命題

在 Gate 1 與 Gate 2 之後，我們已經有：

$$
I \xrightarrow{C} S
$$

以及

$$
I \xrightarrow{N} I_N \xrightarrow{C} S.
$$

Gate 3 的目的不是改變 renderer，而是從 `RUN geometry` 與 connected regions 中額外抽出 topology metadata，讓 representation 開始具備更高階結構資訊。

## 目前抽出的 topology metadata

### region-level
- `boundary`: boundary pixel coordinates
- `boundaryPixelCount`
- `perimeter`
- `holeCount`
- `fillRatio`
- `symmetry.vertical`
- `symmetry.horizontal`
- `isTransparent`

### asset-level
- `regionCount`
- `adjacencyCount`
- `totalBoundaryPixels`
- `totalPerimeter`
- `totalHoles`
- `symmetry.vertical`
- `symmetry.horizontal`

## 作用

這一層目前主要是給後續關卡使用：

- contour-aware rerender
- skeleton extraction
- shape grammar
- tile / sprite part grammar

也就是說，現在的 `S` 已經不只是可逆 raster symbol，也開始攜帶可供生成增強使用的 shape/topology hints。

## 已驗證

- hole detection on ring-shaped region
- symmetry scoring on demo sprite
- topology summary embedded in AssetSymbol JSON

## 下一關

Gate 4 將往：

- skeleton / medial hints
- corner / turning-point extraction
- part grammar
- tile adjacency semantics

推進。

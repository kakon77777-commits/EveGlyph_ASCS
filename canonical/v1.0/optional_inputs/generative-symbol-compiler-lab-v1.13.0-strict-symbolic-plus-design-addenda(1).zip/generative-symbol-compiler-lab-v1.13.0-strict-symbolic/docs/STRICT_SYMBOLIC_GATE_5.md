# STRICT_SYMBOLIC_GATE_5

## 目標

Gate 5 把已存在的 region / topology / contour / medial / skeleton graph，提升成 part-level grammar baseline：

$$
(\text{region},\text{topology},\text{medial},G_K) \to P.
$$

## 目前資料模型

每個 region 會帶有 `partGrammar`，目前最小欄位包含：

- `primitive`
- `orientation`
- `role`
- `symmetryClass`
- `attachments`
- `adjacencyDegree`

asset-level 則新增 `partGrammar` summary 與 `parts` 集合。

## primitive baseline

目前實作的 primitive baseline：

- `carrier`
- `dot`
- `bar`
- `block`
- `ring`
- `junction`
- `blob`

## 已驗證

- 一像素水平線可分類為 `bar` + `horizontal`
- ring-shape 可分類為 `ring` + `loop-feature`
- plus-shape 可分類為 `junction` + `connector`
- asset-level summary 可做 JSON round-trip 並通過 validator

## 作用

這一層讓後續 enhanced rerender / sprite grammar / tile grammar 可以直接吃 part token，而不需要從像素或純 skeleton graph 重新推一次。 

# Strict Symbolic Reconstruction — Gate 1

## Research question

Can a symbolic representation carry all information required to reconstruct a finite-palette pixel-art image after the original pixel buffer becomes unavailable?

The tested pipeline is:

$$
I \xrightarrow{C} S,\qquad \cancel{I},\qquad S \xrightarrow{R} \hat I.
$$

Gate 1 requires:

$$
\hat I = I
$$

byte-for-byte in RGBA space for the accepted domain.

## Accepted domain

An input belongs to Gate 1 when it is an RGBA raster with positive integer dimensions and no more than the configured exact palette limit. The default limit is 256 exact RGBA tuples.

No implicit quantization is allowed. If the input exceeds the palette limit, compilation fails explicitly. This prevents the experiment from silently changing the proposition from exact reconstruction to lossy approximation.

## Canonical symbolic payload

The reconstruction payload is:

$$
S_R=(W,H,P,T),
$$

where $P$ is an ordered RGBA palette and $T$ is a sequential stream of horizontal RUN tokens. A token is:

$$
t=(y,x,\ell,p),
$$

meaning palette entry $p$ occupies the interval:

$$
[x,x+\ell)
$$

on row $y$.

Validator invariants require the token stream to cover every row exactly once, contiguously, in sequence. Therefore the renderer does not need the source image, a Data URL, a hidden cache, or a semantic render bundle.

## Topology side-channel

The compiler additionally derives 4-connected components of equal palette index:

$$
G_R=(V,E).
$$

Each vertex stores palette index, area, bounding box, and centroid. $E$ records region adjacency. Gate 1 reconstruction does not depend on this graph; it is intentionally redundant metadata for later contour, skeleton, part, tile, and sprite grammar experiments.

## Source-blind proof mechanism

The automated regression test performs:

1. Compile source image into $S$.
2. Save the expected RGBA values only inside the test assertion fixture.
3. Overwrite `source.data` after compilation.
4. Call `renderStrictSymbolicAsset(S)`; the renderer API has no source argument.
5. Compare every output byte against the original expected RGBA sequence.

This proves source independence for the tested function path.

## Non-claims

Gate 1 does **not** yet claim that RUN encoding is a minimal representation, a semantic compression optimum, or a superior general image codec. It establishes a deliberately narrow existence result for the first target domain:

$$
\text{finite-palette pixel art}.
$$

The next research question is whether the exact representation can be progressively lifted into contour / topology / part grammar while retaining sufficient reconstructability and enabling high-resolution re-rendering that is no longer equivalent to nearest-neighbor block scaling.

# STRICT_SYMBOLIC_GATE_10

## 目標

Gate 10 將 Gate 9 的 generic engine-profile batch sheet 收緊成 RPG Maker MV/MZ native import packaging baseline。

## Native profiles

- A5: 384×768, 8×16, tile size 48×48
- B–E: 768×768, 16×16, tile size 48×48
- B slot 0 reserved blank
- `$` single-character: 3×4 frame sheet under `img/characters`

## Packaging invariants

- source dependency remains `NONE`
- tileset source canvases larger than 48×48 are rejected
- smaller tiles use deterministic integer-contain scaling and centering
- unsafe path-like base filenames are rejected
- manifest JSON is separately serializable from PNG texture bytes

## Non-goals

Gate 10 does not automatically edit RPG Maker database JSON, register tilesets in a project, or inject a plugin. Those are project-binding tasks for the next gate.

# STRICT_SYMBOLIC_GATE_8

## 目標

Gate 8 建立：

$$
S \to A_{16}
$$

以及

$$
(S,\theta_R) \to k_{\mathrm{cache}} \to C_R.
$$

## Autotile baseline

使用四鄰接 bit mask：

- North = 1
- East = 2
- South = 4
- West = 8

生成 16 種 connectivity variants，排成 4×4 runtime sheet。

## Runtime cache baseline

- deterministic stable serialization
- FNV-1a 32-bit cache key
- bounded entry count
- hit / miss / eviction stats
- LRU-like touch order

## 已驗證

- 16 variants / 4×4 sheet
- disconnected / fully-connected masks 產生不同 output
- cache key 對 option key order 穩定
- cache miss → hit
- capacity eviction
- UI autotile runtime export option

## 尚未完成

- full RPG Maker autotile format compatibility
- multi-asset batch tileset export
- persistent disk cache
- actual RPG Maker plugin injection

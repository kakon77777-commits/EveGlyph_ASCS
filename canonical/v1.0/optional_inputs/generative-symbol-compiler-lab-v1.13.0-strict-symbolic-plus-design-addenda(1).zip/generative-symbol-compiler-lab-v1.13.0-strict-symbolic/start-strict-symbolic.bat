@echo off
start "" "%~dp0strict-symbolic.html"

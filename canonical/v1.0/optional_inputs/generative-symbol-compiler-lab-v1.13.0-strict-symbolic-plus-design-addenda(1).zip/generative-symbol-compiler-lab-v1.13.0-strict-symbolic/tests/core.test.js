const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');

const code = fs.readFileSync(path.join(__dirname, '..', 'src', 'core.js'), 'utf8');
const sandbox = { window: {} };
vm.createContext(sandbox);
vm.runInContext(code, sandbox);
const core = sandbox.window.GenerativeSymbolCompilerCore;

test('createCompilerConfig returns complete config', () => {
  const cfg = core.createCompilerConfig();
  assert.equal(cfg.subjectMode, 'auto');
  assert.equal(typeof cfg.maxSize, 'number');
});

test('config JSON round-trip preserves values', () => {
  const cfg = core.createCompilerConfig();
  cfg.targetStyle = 'anime';
  cfg.moodBias = 0.25;
  const parsed = core.parseConfigJson(core.configToJson(cfg));
  assert.equal(parsed.targetStyle, 'anime');
  assert.equal(parsed.moodBias, 0.25);
});

test('createDemoImage returns RGBA image object', () => {
  const image = core.createDemoImage(64, 80);
  assert.equal(image.width, 64);
  assert.equal(image.height, 80);
  assert.equal(image.data.length, 64 * 80 * 4);
});

test('analyzeImage returns feature snapshot', () => {
  const image = core.createDemoImage(96, 120);
  const features = core.analyzeImage(image);
  assert.equal(features.width, 96);
  assert.equal(typeof features.edgeDensity, 'number');
  assert.equal(features.palette.length, 4);
});

test('inferSubject honors manual subject mode', () => {
  const image = core.createDemoImage(96, 120);
  const features = core.analyzeImage(image);
  const cfg = core.createCompilerConfig();
  cfg.subjectMode = 'scene';
  assert.equal(core.inferSubject(features, cfg), 'scene');
});

test('compileScene returns valid scene object', () => {
  const features = core.analyzeImage(core.createDemoImage(96, 120));
  const scene = core.compileScene(features, core.createCompilerConfig());
  assert.equal(typeof scene.meta.title, 'string');
  assert.ok(Array.isArray(scene.symbols));
  assert.ok(scene.symbols.length > 0);
});

test('scene JSON round-trip preserves subject and style', () => {
  const features = core.analyzeImage(core.createDemoImage(96, 120));
  const cfg = core.createCompilerConfig();
  cfg.subjectMode = 'product-poster';
  cfg.targetStyle = 'splash-art-lite';
  const scene = core.compileScene(features, cfg);
  const parsed = core.parseSceneJson(core.sceneToJson(scene));
  assert.equal(parsed.probe.subject, 'product-poster');
  assert.equal(parsed.probe.style, 'splash-art-lite');
});

test('buildStandaloneHtml includes scene title', () => {
  const features = core.analyzeImage(core.createDemoImage(96, 120));
  const scene = core.compileScene(features, core.createCompilerConfig());
  const html = core.buildStandaloneHtml(scene, 'data:image/png;base64,abc');
  assert.match(html, /Compiled/);
  assert.match(html, /Source/);
});


test('compileScene with source image emits source-derived reconstruction regions instead of template-only subject', () => {
  const image = core.createDemoImage(96, 120);
  const features = core.analyzeImage(image);
  const scene = core.compileScene(features, core.createCompilerConfig(), image);
  assert.ok(scene.reconstruction, 'expected reconstruction payload');
  assert.equal(scene.reconstruction.kind, 'region-map');
  assert.equal(scene.probe.subject, 'reconstruction', 'compiled subject should report source-derived reconstruction, not classifier template');
  assert.ok(Array.isArray(scene.reconstruction.regions));
  assert.ok(scene.reconstruction.regions.length >= 4, 'expected multiple source-derived regions');
  assert.ok(scene.symbols.some((s) => /^REGION_/.test(s)), 'expected REGION_* symbols');
  assert.ok(!scene.symbols.includes('PORTRAIT_HEAD'), 'must not replace source with portrait template');
});


test('detail bias changes reconstruction complexity for source-derived compilation', () => {
  const image = core.createDemoImage(220, 260);
  const features = core.analyzeImage(image);
  const low = core.createCompilerConfig();
  low.detailBias = -1;
  const high = core.createCompilerConfig();
  high.detailBias = 1;
  const lowScene = core.compileScene(features, low, image);
  const highScene = core.compileScene(features, high, image);
  assert.ok(lowScene.compiler.reconstruction.options.maxColors < highScene.compiler.reconstruction.options.maxColors);
  assert.ok(lowScene.compiler.reconstruction.options.maxRegions < highScene.compiler.reconstruction.options.maxRegions);
  assert.ok(lowScene.reconstruction.width < highScene.reconstruction.width || lowScene.reconstruction.height < highScene.reconstruction.height);
});

test('different styles produce materially different reconstruction colors', () => {
  const image = core.createDemoImage(220, 260);
  const features = core.analyzeImage(image);
  const animeCfg = core.createCompilerConfig();
  animeCfg.targetStyle = 'anime';
  const storyCfg = core.createCompilerConfig();
  storyCfg.targetStyle = 'storybook';
  const animeScene = core.compileScene(features, animeCfg, image);
  const storyScene = core.compileScene(features, storyCfg, image);
  const animeColor = core.styleRegionColor(animeScene.reconstruction.palette[0], 'anime', animeScene);
  const storyColor = core.styleRegionColor(storyScene.reconstruction.palette[0], 'storybook', storyScene);
  assert.notEqual(animeColor, storyColor);
  assert.notEqual(animeScene.palette.background, storyScene.palette.background);
});


test('buildStyledSourceImage preserves source dimensions', () => {
  const image = core.createDemoImage(128, 96);
  const features = core.analyzeImage(image);
  const scene = core.compileScene(features, core.createCompilerConfig(), image);
  const styled = core.buildStyledSourceImage(image, scene);
  assert.equal(styled.width, image.width);
  assert.equal(styled.height, image.height);
  assert.equal(styled.data.length, image.data.length);
});

test('buildStyledSourceImage differs across styles', () => {
  const image = core.createDemoImage(96, 72);
  const features = core.analyzeImage(image);
  const animeCfg = core.createCompilerConfig();
  animeCfg.targetStyle = 'anime';
  const painterlyCfg = core.createCompilerConfig();
  painterlyCfg.targetStyle = 'painterly';
  const animeScene = core.compileScene(features, animeCfg, image);
  const painterlyScene = core.compileScene(features, painterlyCfg, image);
  const anime = core.buildStyledSourceImage(image, animeScene);
  const painterly = core.buildStyledSourceImage(image, painterlyScene);
  let diff = 0;
  for (let i = 0; i < anime.data.length; i += 64) {
    diff += Math.abs(anime.data[i] - painterly.data[i]) + Math.abs(anime.data[i+1] - painterly.data[i+1]) + Math.abs(anime.data[i+2] - painterly.data[i+2]);
  }
  assert.ok(diff > 0, 'styled source images should differ across styles');
});

test('compileScene emits semantic layer metadata when source image is provided', () => {
  const image = core.createDemoImage(128, 160);
  const features = core.analyzeImage(image);
  const scene = core.compileScene(features, core.createCompilerConfig(), image);
  assert.ok(scene.semantic, 'expected semantic metadata');
  assert.equal(scene.semantic.mode, 'multi-layer-semantic-v0.9');
  assert.ok(Array.isArray(scene.semantic.layers));
  assert.ok(scene.semantic.layers.some((layer) => layer.id === 'subject'));
  assert.equal(scene.compiler.layerVisibility.background, true);
});

test('buildSemanticRenderBundle returns multi-layer coverage stats', () => {
  const image = core.createDemoImage(120, 96);
  const features = core.analyzeImage(image);
  const scene = core.compileScene(features, core.createCompilerConfig(), image);
  const bundle = core.buildSemanticRenderBundle(image, scene);
  assert.equal(bundle.mode, 'multi-layer-semantic-v0.9');
  assert.equal(bundle.width, image.width);
  assert.equal(bundle.height, image.height);
  assert.equal(bundle.layers.background.width, image.width);
  assert.ok(bundle.stats.backgroundCoverage > 0);
  assert.ok(bundle.stats.subjectCoverage >= 0);
  assert.ok(bundle.stats.glowCoverage >= 0);
  assert.ok(bundle.stats.foregroundCoverage >= 0);
});

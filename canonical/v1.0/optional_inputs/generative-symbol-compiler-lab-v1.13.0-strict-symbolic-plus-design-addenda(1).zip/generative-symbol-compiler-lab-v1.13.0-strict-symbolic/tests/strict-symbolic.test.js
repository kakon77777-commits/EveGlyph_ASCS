const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');

const code = fs.readFileSync(path.join(__dirname, '..', 'src', 'core.js'), 'utf8');
const sandbox = { window: {} };
vm.createContext(sandbox);
vm.runInContext(code, sandbox);
const core = sandbox.window.GenerativeSymbolCompilerCore;

function imageFromRows(rows) {
  const height = rows.length;
  const width = rows[0].length;
  const data = new Uint8ClampedArray(width * height * 4);
  let i = 0;
  for (const row of rows) {
    assert.equal(row.length, width);
    for (const rgba of row) {
      data[i++] = rgba[0];
      data[i++] = rgba[1];
      data[i++] = rgba[2];
      data[i++] = rgba[3];
    }
  }
  return { width, height, data };
}

const T = [0, 0, 0, 0];
const K = [18, 22, 31, 255];
const B = [47, 128, 237, 255];
const W = [240, 247, 255, 255];

function sampleSprite() {
  return imageFromRows([
    [T, T, K, K, T, T],
    [T, K, B, B, K, T],
    [K, B, W, W, B, K],
    [K, B, B, B, B, K],
    [T, K, B, B, K, T],
    [T, T, K, K, T, T]
  ]);
}

test('strict symbolic API is exposed by the compiler core', () => {
  assert.equal(typeof core.compileStrictSymbolicAsset, 'function');
  assert.equal(typeof core.renderStrictSymbolicAsset, 'function');
  assert.equal(typeof core.validateStrictSymbolicAsset, 'function');
});

test('strict compiler emits palette + RUN tokens without embedding source pixels', () => {
  const asset = core.compileStrictSymbolicAsset(sampleSprite());
  assert.equal(asset.schema, 'evemisslab.symbolic-image');
  assert.equal(asset.version, '0.7');
  assert.equal(asset.encoding, 'palette-runs');
  assert.equal(asset.canvas.width, 6);
  assert.equal(asset.canvas.height, 6);
  assert.ok(asset.palette.length >= 4);
  assert.ok(asset.tokens.length > 0);
  assert.ok(asset.tokens.every((token) => token.op === 'RUN'));
  assert.equal(Object.prototype.hasOwnProperty.call(asset, 'data'), false);
  assert.equal(Object.prototype.hasOwnProperty.call(asset, 'sourceData'), false);
  assert.doesNotMatch(JSON.stringify(asset), /sourceData|data:image\//);
});

test('strict source-blind renderer exactly reconstructs a pixel-art sprite', () => {
  const image = sampleSprite();
  const original = Array.from(image.data);
  const asset = core.compileStrictSymbolicAsset(image);
  image.data.fill(123); // destroy source after compilation
  const rendered = core.renderStrictSymbolicAsset(asset);
  assert.equal(rendered.width, 6);
  assert.equal(rendered.height, 6);
  assert.deepEqual(Array.from(rendered.data), original);
});

test('strict symbolic JSON round-trip remains exactly reconstructable', () => {
  const image = sampleSprite();
  const asset = core.compileStrictSymbolicAsset(image);
  const json = core.strictSymbolicAssetToJson(asset);
  const parsed = core.parseStrictSymbolicAssetJson(json);
  const rendered = core.renderStrictSymbolicAsset(parsed);
  assert.deepEqual(Array.from(rendered.data), Array.from(image.data));
});

test('strict renderer scales from symbolic RUN geometry without interpolation', () => {
  const image = sampleSprite();
  const asset = core.compileStrictSymbolicAsset(image);
  const rendered = core.renderStrictSymbolicAsset(asset, { scale: 3 });
  assert.equal(rendered.width, 18);
  assert.equal(rendered.height, 18);

  const sourcePixel = (2 * image.width + 2) * 4;
  const scaledPixel = ((2 * 3) * rendered.width + (2 * 3)) * 4;
  assert.deepEqual(
    Array.from(rendered.data.slice(scaledPixel, scaledPixel + 4)),
    Array.from(image.data.slice(sourcePixel, sourcePixel + 4))
  );
});

test('strict asset exposes connected-region topology metadata', () => {
  const asset = core.compileStrictSymbolicAsset(sampleSprite());
  assert.ok(Array.isArray(asset.regions));
  assert.ok(asset.regions.length >= 4);
  assert.ok(asset.regions.every((region) => Number.isInteger(region.area) && region.area > 0));
  assert.ok(asset.regions.every((region) => region.bbox && Number.isInteger(region.bbox.x)));
  assert.ok(Array.isArray(asset.adjacency));
});

test('strict compiler rejects an image that exceeds the explicit palette limit', () => {
  const image = imageFromRows([[
    [1, 0, 0, 255],
    [2, 0, 0, 255],
    [3, 0, 0, 255]
  ]]);
  assert.throws(
    () => core.compileStrictSymbolicAsset(image, { maxPalette: 2 }),
    /palette limit/i
  );
});

test('strict validator rejects hidden source payload fields in canonical AssetSymbol', () => {
  const asset = core.compileStrictSymbolicAsset(sampleSprite());
  asset.sourceData = 'data:image/png;base64,forbidden';
  assert.throws(
    () => core.validateStrictSymbolicAsset(asset),
    /forbidden source payload/i
  );
});


test('pixel normalizer API is exposed by the compiler core', () => {
  assert.equal(typeof core.normalizePixelLikeImage, 'function');
  assert.equal(typeof core.compileNormalizedStrictSymbolicAsset, 'function');
});

test('pixel normalizer snaps alpha to transparent or opaque boundaries', () => {
  const image = imageFromRows([
    [[10, 20, 30, 90], [40, 50, 60, 180]]
  ]);
  const normalized = core.normalizePixelLikeImage(image, { alphaThreshold: 128 });
  assert.deepEqual(Array.from(normalized.image.data), [
    0, 0, 0, 0,
    40, 50, 60, 255
  ]);
  assert.equal(normalized.stats.alphaSnappedTransparent, 1);
  assert.equal(normalized.stats.alphaSnappedOpaque, 1);
});

test('pixel normalizer reduces a near-duplicate palette to a requested limit', () => {
  const image = imageFromRows([[
    [200, 10, 10, 255],
    [201, 10, 10, 255],
    [10, 200, 10, 255],
    [10, 201, 10, 255]
  ]]);
  const normalized = core.normalizePixelLikeImage(image, { paletteSize: 2 });
  const colors = new Set();
  for (let i = 0; i < normalized.image.data.length; i += 4) {
    colors.add(Array.from(normalized.image.data.slice(i, i + 4)).join(','));
  }
  assert.equal(colors.size, 2);
  assert.equal(normalized.stats.originalPaletteSize, 4);
  assert.equal(normalized.stats.normalizedPaletteSize, 2);
});

test('pixel normalizer removes a single isolated opaque speck when despeckle is enabled', () => {
  const R = [220, 40, 40, 255];
  const B = [30, 60, 200, 255];
  const image = imageFromRows([
    [R, R, R],
    [R, B, R],
    [R, R, R]
  ]);
  const normalized = core.normalizePixelLikeImage(image, { despeckle: true });
  const center = Array.from(normalized.image.data.slice((1 * 3 + 1) * 4, (1 * 3 + 1) * 4 + 4));
  assert.deepEqual(center, R);
  assert.equal(normalized.stats.despeckledPixels, 1);
});

test('normalized strict compiler can rescue a noisy pixel-like image into a bounded palette AssetSymbol', () => {
  const image = imageFromRows([[
    [200, 10, 10, 255],
    [201, 10, 10, 255],
    [10, 200, 10, 255],
    [10, 201, 10, 255]
  ]]);
  assert.throws(() => core.compileStrictSymbolicAsset(image, { maxPalette: 2 }), /palette limit/i);
  const asset = core.compileNormalizedStrictSymbolicAsset(image, { paletteSize: 2, maxPalette: 2 });
  assert.ok(asset.normalization);
  assert.equal(asset.normalization.stats.normalizedPaletteSize, 2);
  const rendered = core.renderStrictSymbolicAsset(asset);
  const colors = new Set();
  for (let i = 0; i < rendered.data.length; i += 4) colors.add(Array.from(rendered.data.slice(i, i + 4)).join(','));
  assert.equal(colors.size, 2);
});


test('strict topology API is exposed by the compiler core', () => {
  assert.equal(typeof core.extractStrictTopology, 'function');
});

test('strict asset carries topology summary metadata', () => {
  const asset = core.compileStrictSymbolicAsset(sampleSprite());
  assert.ok(asset.topology);
  assert.equal(asset.topology.regionCount, asset.regions.length);
  assert.equal(asset.topology.adjacencyCount, asset.adjacency.length);
  assert.ok(Number.isInteger(asset.topology.totalBoundaryPixels));
  assert.ok(Number.isInteger(asset.topology.totalHoles));
  assert.ok(asset.topology.symmetry);
});

test('strict topology detects a hole inside a ring-shaped region', () => {
  const R = [200, 80, 50, 255];
  const T = [0, 0, 0, 0];
  const image = imageFromRows([
    [T, T, T, T, T],
    [T, R, R, R, T],
    [T, R, T, R, T],
    [T, R, R, R, T],
    [T, T, T, T, T]
  ]);
  const asset = core.compileStrictSymbolicAsset(image);
  const ring = asset.regions.find((region) => region.area === 8);
  assert.ok(ring);
  assert.equal(ring.topology.holeCount, 1);
  assert.ok(ring.topology.boundary.length > 0);
});

test('strict topology reports strong symmetry on the demo sprite', () => {
  const asset = core.compileStrictSymbolicAsset(sampleSprite());
  assert.ok(asset.topology.symmetry.vertical >= 0.95);
  assert.ok(asset.topology.symmetry.horizontal >= 0.8);
  const blueCore = asset.regions.find((region) => region.area === 8);
  assert.ok(blueCore);
  assert.ok(blueCore.topology.symmetry.vertical >= 0.9);
});


test('strict contour anchor API is exposed by the compiler core', () => {
  assert.equal(typeof core.extractStrictContourAnchors, 'function');
});

test('strict asset carries contour anchor totals in topology summary', () => {
  const asset = core.compileStrictSymbolicAsset(sampleSprite());
  assert.ok(Number.isInteger(asset.topology.totalContourAnchors));
  assert.ok(Number.isInteger(asset.topology.totalTurningPoints));
  assert.ok(asset.topology.totalContourAnchors >= asset.topology.totalTurningPoints);
});

test('ring-shaped region yields ordered contour anchors and turning points', () => {
  const R = [200, 80, 50, 255];
  const T = [0, 0, 0, 0];
  const image = imageFromRows([
    [T, T, T, T, T],
    [T, R, R, R, T],
    [T, R, T, R, T],
    [T, R, R, R, T],
    [T, T, T, T, T]
  ]);
  const asset = core.compileStrictSymbolicAsset(image);
  const ring = asset.regions.find((region) => region.area === 8);
  assert.ok(ring);
  assert.ok(ring.topology.contour);
  assert.ok(ring.topology.contour.anchorCount >= 4);
  assert.equal(ring.topology.contour.anchorCount, ring.topology.contour.orderedAnchors.length);
  assert.equal(ring.topology.contour.turnCount, ring.topology.contour.turningPoints.length);
  const first = ring.topology.contour.orderedAnchors[0];
  const last = ring.topology.contour.orderedAnchors.at(-1);
  assert.ok(first.angle <= last.angle);
});

test('rectangular solid region exposes at least four turning points', () => {
  const R = [120, 200, 80, 255];
  const image = imageFromRows([
    [R, R, R],
    [R, R, R],
    [R, R, R]
  ]);
  const asset = core.compileStrictSymbolicAsset(image);
  const region = asset.regions[0];
  assert.ok(region.topology.contour.turnCount >= 4);
});


test('strict medial hint API is exposed by the compiler core', () => {
  assert.equal(typeof core.extractStrictMedialHints, 'function');
});

test('solid square yields a non-empty topology-preserving skeleton with medial radius', () => {
  const R = [180, 90, 40, 255];
  const image = imageFromRows([
    [R, R, R, R, R],
    [R, R, R, R, R],
    [R, R, R, R, R],
    [R, R, R, R, R],
    [R, R, R, R, R]
  ]);
  const asset = core.compileStrictSymbolicAsset(image);
  const medial = asset.regions[0].topology.medial;
  assert.ok(medial);
  assert.ok(medial.skeletonPixelCount >= 1);
  assert.ok(medial.maxRadius >= 3);
  assert.ok(medial.skeletonPixels.every((point) => Number.isInteger(point.radius) && point.radius >= 1));
});

test('one-pixel horizontal bar preserves its line skeleton and two endpoints', () => {
  const R = [60, 160, 220, 255];
  const image = imageFromRows([[R, R, R, R, R]]);
  const asset = core.compileStrictSymbolicAsset(image);
  const medial = asset.regions[0].topology.medial;
  assert.equal(medial.skeletonPixelCount, 5);
  assert.equal(medial.endpointCount, 2);
  assert.equal(medial.junctionCount, 0);
});

test('plus-shaped region exposes branch junction and endpoints', () => {
  const R = [120, 220, 100, 255];
  const T = [0, 0, 0, 0];
  const image = imageFromRows([
    [T, T, R, T, T],
    [T, T, R, T, T],
    [R, R, R, R, R],
    [T, T, R, T, T],
    [T, T, R, T, T]
  ]);
  const asset = core.compileStrictSymbolicAsset(image);
  const plus = asset.regions.find((region) => region.area === 9);
  assert.ok(plus);
  assert.ok(plus.topology.medial.endpointCount >= 4);
  assert.ok(plus.topology.medial.junctionCount >= 1);
});

test('asset topology summary carries skeleton and medial totals', () => {
  const asset = core.compileStrictSymbolicAsset(sampleSprite());
  assert.ok(Number.isInteger(asset.topology.totalSkeletonPixels));
  assert.ok(Number.isInteger(asset.topology.totalSkeletonEndpoints));
  assert.ok(Number.isInteger(asset.topology.totalSkeletonJunctions));
  assert.ok(Number.isInteger(asset.topology.maxMedialRadius));
  assert.ok(asset.topology.totalSkeletonPixels > 0);
});


test('strict local UI keeps Gate 2 normalized compiler route wired', () => {
  const appSource = fs.readFileSync(path.join(__dirname, '..', 'strict-symbolic-app.js'), 'utf8');
  assert.match(appSource, /compileMode\.value/);
  assert.match(appSource, /compileNormalizedStrictSymbolicAsset/);
});

test('strict local UI reports Gate 4B skeleton totals', () => {
  const appSource = fs.readFileSync(path.join(__dirname, '..', 'strict-symbolic-app.js'), 'utf8');
  assert.match(appSource, /totalSkeletonPixels/);
  assert.match(appSource, /maxMedialRadius/);
});


test('strict skeleton graph API is exposed by the compiler core', () => {
  assert.equal(typeof core.extractStrictSkeletonGraph, 'function');
});

test('one-pixel horizontal bar compresses into a single skeleton segment edge', () => {
  const R = [60, 160, 220, 255];
  const image = imageFromRows([[R, R, R, R, R]]);
  const asset = core.compileStrictSymbolicAsset(image);
  const graph = asset.regions[0].topology.medial.graph;
  assert.ok(graph);
  assert.equal(graph.nodeCount, 2);
  assert.equal(graph.edgeCount, 1);
  assert.equal(graph.edges[0].length, 5);
  assert.equal(graph.edges[0].polyline.length, 5);
  assert.equal(graph.branchlessPathCount, 1);
});

test('plus-shaped region produces a junction-centered skeleton graph', () => {
  const R = [120, 220, 100, 255];
  const T = [0, 0, 0, 0];
  const image = imageFromRows([
    [T, T, R, T, T],
    [T, T, R, T, T],
    [R, R, R, R, R],
    [T, T, R, T, T],
    [T, T, R, T, T]
  ]);
  const asset = core.compileStrictSymbolicAsset(image);
  const plus = asset.regions.find((region) => region.area === 9);
  const graph = plus.topology.medial.graph;
  assert.ok(graph.nodeCount >= 5);
  assert.ok(graph.edgeCount >= 4);
  assert.ok(graph.nodes.some((node) => node.kind === 'junction'));
  assert.ok(graph.edges.every((edge) => edge.length >= 2));
});

test('asset topology summary carries skeleton graph totals', () => {
  const asset = core.compileStrictSymbolicAsset(sampleSprite());
  assert.ok(Number.isInteger(asset.topology.totalSkeletonGraphNodes));
  assert.ok(Number.isInteger(asset.topology.totalSkeletonGraphEdges));
  assert.ok(Number.isInteger(asset.topology.totalSkeletonBranchlessPaths));
});


test('strict local UI reports Gate 4C skeleton graph totals', () => {
  const appSource = fs.readFileSync(path.join(__dirname, '..', 'strict-symbolic-app.js'), 'utf8');
  assert.match(appSource, /Skeleton graph nodes \/ edges \/ paths/);
});


test('strict part grammar API is exposed by the compiler core', () => {
  assert.equal(typeof core.extractStrictPartGrammar, 'function');
});

test('one-pixel horizontal bar is classified as a horizontal bar part', () => {
  const R = [60, 160, 220, 255];
  const image = imageFromRows([[R, R, R, R, R]]);
  const asset = core.compileStrictSymbolicAsset(image);
  const part = asset.regions[0].partGrammar;
  assert.ok(part);
  assert.equal(part.primitive, 'bar');
  assert.equal(part.orientation, 'horizontal');
});

test('ring-shaped region is classified as a ring / loop feature part', () => {
  const R = [200, 80, 50, 255];
  const T = [0, 0, 0, 0];
  const image = imageFromRows([
    [T, T, T, T, T],
    [T, R, R, R, T],
    [T, R, T, R, T],
    [T, R, R, R, T],
    [T, T, T, T, T]
  ]);
  const asset = core.compileStrictSymbolicAsset(image);
  const ring = asset.regions.find((region) => region.area === 8);
  assert.ok(ring.partGrammar);
  assert.equal(ring.partGrammar.primitive, 'ring');
  assert.equal(ring.partGrammar.role, 'loop-feature');
});

test('plus-shaped region is classified as a junction / connector part', () => {
  const R = [120, 220, 100, 255];
  const T = [0, 0, 0, 0];
  const image = imageFromRows([
    [T, T, R, T, T],
    [T, T, R, T, T],
    [R, R, R, R, R],
    [T, T, R, T, T],
    [T, T, R, T, T]
  ]);
  const asset = core.compileStrictSymbolicAsset(image);
  const plus = asset.regions.find((region) => region.area === 9);
  assert.ok(plus.partGrammar);
  assert.equal(plus.partGrammar.primitive, 'junction');
  assert.equal(plus.partGrammar.role, 'connector');
});

test('asset carries part grammar summary', () => {
  const asset = core.compileStrictSymbolicAsset(sampleSprite());
  assert.ok(asset.partGrammar);
  assert.equal(asset.partGrammar.partCount, asset.regions.length);
  assert.ok(asset.partGrammar.countsByPrimitive);
  assert.ok(asset.partGrammar.countsByRole);
  assert.ok(Array.isArray(asset.partGrammar.parts));
});

test('strict local UI reports Gate 5 part grammar totals', () => {
  const appSource = fs.readFileSync(path.join(__dirname, '..', 'strict-symbolic-app.js'), 'utf8');
  assert.match(appSource, /Part grammar/);
});


test('enhanced strict renderer API is exposed by the compiler core', () => {
  assert.equal(typeof core.renderEnhancedStrictSymbolicAsset, 'function');
});

test('enhanced strict renderer preserves requested output dimensions', () => {
  const asset = core.compileStrictSymbolicAsset(sampleSprite());
  const rendered = core.renderEnhancedStrictSymbolicAsset(asset, { scale: 5 });
  assert.equal(rendered.width, 30);
  assert.equal(rendered.height, 30);
});

test('enhanced strict renderer differs from exact block scaling on a non-trivial sprite', () => {
  const asset = core.compileStrictSymbolicAsset(sampleSprite());
  const exact = core.renderStrictSymbolicAsset(asset, { scale: 6 });
  const enhanced = core.renderEnhancedStrictSymbolicAsset(asset, { scale: 6 });
  assert.notDeepEqual(Array.from(enhanced.data), Array.from(exact.data));
});

test('enhanced strict renderer introduces partial alpha on silhouette pixels', () => {
  const asset = core.compileStrictSymbolicAsset(sampleSprite());
  const enhanced = core.renderEnhancedStrictSymbolicAsset(asset, { scale: 8 });
  let partialAlphaCount = 0;
  for (let i = 3; i < enhanced.data.length; i += 4) {
    const a = enhanced.data[i];
    if (a > 0 && a < 255) partialAlphaCount += 1;
  }
  assert.ok(partialAlphaCount > 0);
});

test('enhanced strict renderer preserves the transparent hole inside a ring', () => {
  const R = [200, 80, 50, 255];
  const image = imageFromRows([
    [T, T, T, T, T],
    [T, R, R, R, T],
    [T, R, T, R, T],
    [T, R, R, R, T],
    [T, T, T, T, T]
  ]);
  const asset = core.compileStrictSymbolicAsset(image);
  const enhanced = core.renderEnhancedStrictSymbolicAsset(asset, { scale: 8 });
  const cx = Math.floor(enhanced.width / 2);
  const cy = Math.floor(enhanced.height / 2);
  const idx = (cy * enhanced.width + cx) * 4;
  assert.equal(enhanced.data[idx + 3], 0);
});

test('enhanced strict renderer behavior changes when part primitive metadata changes', () => {
  const R = [60, 160, 220, 255];
  const asset = core.compileStrictSymbolicAsset(imageFromRows([[T, R, R, R, R, R, T]]));
  const region = asset.regions.find((entry) => entry.area === 5);
  const part = asset.partGrammar.parts.find((entry) => entry.regionId === region.id);
  const variant = core.parseStrictSymbolicAssetJson(core.strictSymbolicAssetToJson(asset));
  const variantRegion = variant.regions.find((entry) => entry.id === region.id);
  const variantPart = variant.partGrammar.parts.find((entry) => entry.regionId === region.id);
  variantRegion.partGrammar.primitive = 'block';
  variantPart.primitive = 'block';
  const base = core.renderEnhancedStrictSymbolicAsset(asset, { scale: 10 });
  const altered = core.renderEnhancedStrictSymbolicAsset(variant, { scale: 10 });
  assert.notDeepEqual(Array.from(base.data), Array.from(altered.data));
});

test('strict local UI exposes enhanced render mode control', () => {
  const appSource = fs.readFileSync(path.join(__dirname, '..', 'strict-symbolic-app.js'), 'utf8');
  const htmlSource = fs.readFileSync(path.join(__dirname, '..', 'strict-symbolic.html'), 'utf8');
  assert.match(appSource, /renderMode/);
  assert.match(htmlSource, /Gate 6/);
});


test('rpg runtime bundle API is exposed by the compiler core', () => {
  assert.equal(typeof core.buildRpgMakerRuntimeBundle, 'function');
  assert.equal(typeof core.validateRpgMakerRuntimeBundle, 'function');
  assert.equal(typeof core.runtimeBundleToJson, 'function');
  assert.equal(typeof core.parseRuntimeBundleJson, 'function');
});

test('tile runtime bundle emits one engine-facing frame and collision mask', () => {
  const asset = core.compileStrictSymbolicAsset(sampleSprite());
  const bundle = core.buildRpgMakerRuntimeBundle(asset, { assetKind: 'tile', scale: 4, renderMode: 'enhanced' });
  assert.equal(bundle.schema, 'evemisslab.rpgmaker-runtime-bundle');
  assert.equal(bundle.assetKind, 'tile');
  assert.equal(bundle.frames.length, 1);
  assert.equal(bundle.texture.width, asset.canvas.width * 4);
  assert.equal(bundle.texture.height, asset.canvas.height * 4);
  assert.equal(bundle.frameSize.width, asset.canvas.width * 4);
  assert.equal(bundle.frameSize.height, asset.canvas.height * 4);
  assert.equal(bundle.runtime.collisionMask.width, asset.canvas.width);
  assert.equal(bundle.runtime.collisionMask.height, asset.canvas.height);
});

test('character runtime bundle emits a 3x4 single-character sheet manifest', () => {
  const asset = core.compileStrictSymbolicAsset(sampleSprite());
  const bundle = core.buildRpgMakerRuntimeBundle(asset, { assetKind: 'character', scale: 3, renderMode: 'exact' });
  assert.equal(bundle.assetKind, 'character');
  assert.equal(bundle.sheet.columns, 3);
  assert.equal(bundle.sheet.rows, 4);
  assert.equal(bundle.frames.length, 12);
  assert.equal(bundle.texture.width, bundle.frameSize.width * 3);
  assert.equal(bundle.texture.height, bundle.frameSize.height * 4);
  assert.deepEqual(Array.from(bundle.runtime.directions), ['down', 'left', 'right', 'up']);
  assert.deepEqual(Array.from(bundle.runtime.patterns), [0, 1, 2]);
  assert.equal(bundle.frames[0].direction, 'down');
  assert.equal(bundle.frames[11].direction, 'up');
});

test('runtime bundle respects exact versus enhanced render modes', () => {
  const asset = core.compileStrictSymbolicAsset(sampleSprite());
  const exact = core.buildRpgMakerRuntimeBundle(asset, { assetKind: 'tile', scale: 6, renderMode: 'exact' });
  const enhanced = core.buildRpgMakerRuntimeBundle(asset, { assetKind: 'tile', scale: 6, renderMode: 'enhanced' });
  assert.notDeepEqual(Array.from(exact.texture.data), Array.from(enhanced.texture.data));
});

test('runtime bundle JSON round-trip preserves runtime metadata', () => {
  const asset = core.compileStrictSymbolicAsset(sampleSprite());
  const bundle = core.buildRpgMakerRuntimeBundle(asset, { assetKind: 'character', scale: 2, renderMode: 'enhanced' });
  const json = core.runtimeBundleToJson(bundle);
  const parsed = core.parseRuntimeBundleJson(json);
  core.validateRpgMakerRuntimeBundle(parsed);
  assert.equal(parsed.assetKind, 'character');
  assert.equal(parsed.frameSize.width, bundle.frameSize.width);
  assert.equal(parsed.frames.length, bundle.frames.length);
  assert.equal(parsed.texture.width, bundle.texture.width);
  assert.equal(parsed.texture.height, bundle.texture.height);
});

test('runtime bundle can be built from AssetSymbol JSON only', () => {
  const asset = core.compileStrictSymbolicAsset(sampleSprite());
  const parsedAsset = core.parseStrictSymbolicAssetJson(core.strictSymbolicAssetToJson(asset));
  const bundle = core.buildRpgMakerRuntimeBundle(parsedAsset, { assetKind: 'tile', scale: 5, renderMode: 'enhanced' });
  assert.equal(bundle.sourceDependency, 'NONE');
  assert.equal(bundle.runtime.anchor.x, Math.floor(bundle.frameSize.width / 2));
});

test('strict local UI exposes runtime export controls', () => {
  const appSource = fs.readFileSync(path.join(__dirname, '..', 'strict-symbolic-app.js'), 'utf8');
  const htmlSource = fs.readFileSync(path.join(__dirname, '..', 'strict-symbolic.html'), 'utf8');
  assert.match(appSource, /runtimeKind/);
  assert.match(appSource, /downloadRuntimeJsonBtn/);
  assert.match(htmlSource, /Runtime export/);
});


test('autotile runtime and cache APIs are exposed by the compiler core', () => {
  assert.equal(typeof core.buildSymbolicAutotileRuntimeBundle, 'function');
  assert.equal(typeof core.computeRuntimeRenderCacheKey, 'function');
  assert.equal(typeof core.createRuntimeRenderCache, 'function');
  assert.equal(typeof core.getOrBuildRuntimeBundleCached, 'function');
});

test('autotile runtime bundle emits all 16 four-neighbor variants in a 4x4 sheet', () => {
  const R = [100, 180, 90, 255];
  const image = imageFromRows([
    [R, R, R, R],
    [R, R, R, R],
    [R, R, R, R],
    [R, R, R, R]
  ]);
  const asset = core.compileStrictSymbolicAsset(image);
  const bundle = core.buildSymbolicAutotileRuntimeBundle(asset, { scale: 4, renderMode: 'exact' });
  assert.equal(bundle.schema, 'evemisslab.symbolic-autotile-runtime-bundle');
  assert.equal(bundle.variants.length, 16);
  assert.equal(bundle.sheet.columns, 4);
  assert.equal(bundle.sheet.rows, 4);
  assert.equal(bundle.texture.width, bundle.frameSize.width * 4);
  assert.equal(bundle.texture.height, bundle.frameSize.height * 4);
  assert.deepEqual(Array.from(bundle.variants.map((variant) => variant.neighborMask)), Array.from({ length: 16 }, (_, i) => i));
});

test('autotile disconnected and fully-connected masks produce different textures', () => {
  const R = [100, 180, 90, 255];
  const image = imageFromRows([
    [R, R, R, R],
    [R, R, R, R],
    [R, R, R, R],
    [R, R, R, R]
  ]);
  const asset = core.compileStrictSymbolicAsset(image);
  const bundle = core.buildSymbolicAutotileRuntimeBundle(asset, { scale: 5, renderMode: 'enhanced' });
  const zero = bundle.variantTextures[0];
  const full = bundle.variantTextures[15];
  assert.notDeepEqual(Array.from(zero.data), Array.from(full.data));
  assert.equal(bundle.variants[0].neighbors.north, false);
  assert.equal(bundle.variants[15].neighbors.north, true);
  assert.equal(bundle.variants[15].neighbors.east, true);
  assert.equal(bundle.variants[15].neighbors.south, true);
  assert.equal(bundle.variants[15].neighbors.west, true);
});

test('runtime cache key is deterministic and changes with render options', () => {
  const asset = core.compileStrictSymbolicAsset(sampleSprite());
  const a = core.computeRuntimeRenderCacheKey(asset, { assetKind: 'tile', scale: 4, renderMode: 'exact' });
  const b = core.computeRuntimeRenderCacheKey(asset, { renderMode: 'exact', scale: 4, assetKind: 'tile' });
  const c = core.computeRuntimeRenderCacheKey(asset, { assetKind: 'tile', scale: 8, renderMode: 'exact' });
  assert.equal(a, b);
  assert.notEqual(a, c);
});

test('runtime render cache reports miss then hit for the same bundle request', () => {
  const asset = core.compileStrictSymbolicAsset(sampleSprite());
  const cache = core.createRuntimeRenderCache({ maxEntries: 4 });
  const first = core.getOrBuildRuntimeBundleCached(cache, asset, { assetKind: 'tile', scale: 4, renderMode: 'enhanced' });
  const second = core.getOrBuildRuntimeBundleCached(cache, asset, { assetKind: 'tile', scale: 4, renderMode: 'enhanced' });
  assert.equal(first.hit, false);
  assert.equal(second.hit, true);
  assert.equal(first.key, second.key);
  assert.equal(cache.stats.misses, 1);
  assert.equal(cache.stats.hits, 1);
});

test('runtime render cache evicts oldest entry at capacity', () => {
  const asset = core.compileStrictSymbolicAsset(sampleSprite());
  const cache = core.createRuntimeRenderCache({ maxEntries: 2 });
  const a = core.getOrBuildRuntimeBundleCached(cache, asset, { assetKind: 'tile', scale: 2, renderMode: 'exact' });
  core.getOrBuildRuntimeBundleCached(cache, asset, { assetKind: 'tile', scale: 3, renderMode: 'exact' });
  core.getOrBuildRuntimeBundleCached(cache, asset, { assetKind: 'autotile', scale: 4, renderMode: 'exact' });
  assert.equal(cache.order.length, 2);
  assert.equal(Object.prototype.hasOwnProperty.call(cache.entries, a.key), false);
  assert.equal(cache.stats.evictions, 1);
});

test('strict local UI exposes autotile runtime export option', () => {
  const appSource = fs.readFileSync(path.join(__dirname, '..', 'strict-symbolic-app.js'), 'utf8');
  const htmlSource = fs.readFileSync(path.join(__dirname, '..', 'strict-symbolic.html'), 'utf8');
  assert.match(appSource, /buildSymbolicAutotileRuntimeBundle/);
  assert.match(htmlSource, /Autotile 4×4 Sheet/);
});


test('batch tileset runtime APIs are exposed by the compiler core', () => {
  assert.equal(typeof core.buildBatchTilesetRuntimeBundle, 'function');
  assert.equal(typeof core.validateBatchTilesetRuntimeBundle, 'function');
  assert.equal(typeof core.batchTilesetRuntimeBundleToJson, 'function');
  assert.equal(typeof core.parseBatchTilesetRuntimeBundleJson, 'function');
});

test('A5-like batch tileset lays assets out row-major in an 8-column sheet', () => {
  const assetA = core.compileStrictSymbolicAsset(sampleSprite());
  const R = [100, 180, 90, 255];
  const assetB = core.compileStrictSymbolicAsset(imageFromRows([[R, R, R], [R, R, R], [R, R, R]]));
  const assetC = core.compileStrictSymbolicAsset(imageFromRows([[T, R, T], [R, R, R], [T, R, T]]));
  const bundle = core.buildBatchTilesetRuntimeBundle([
    { id: 'hero', asset: assetA },
    { id: 'grass', asset: assetB },
    { id: 'cross', asset: assetC }
  ], { profile: 'rpgmaker-like-a5', scale: 4, renderMode: 'enhanced' });
  assert.equal(bundle.schema, 'evemisslab.batch-tileset-runtime-bundle');
  assert.equal(bundle.profile, 'rpgmaker-like-a5');
  assert.equal(bundle.tileCount, 3);
  assert.equal(bundle.sheet.columns, 8);
  assert.equal(bundle.sheet.rows, 1);
  assert.equal(bundle.tiles[0].id, 'hero');
  assert.equal(bundle.tiles[0].column, 0);
  assert.equal(bundle.tiles[1].column, 1);
  assert.equal(bundle.tiles[2].column, 2);
  assert.equal(bundle.tiles[2].row, 0);
  assert.equal(bundle.texture.width, bundle.cellSize.width * 8);
  assert.equal(bundle.texture.height, bundle.cellSize.height);
  assert.equal(bundle.sourceDependency, 'NONE');
});

test('B-E-like batch tileset uses a 16-column engine profile', () => {
  const asset = core.compileStrictSymbolicAsset(sampleSprite());
  const entries = Array.from({ length: 17 }, (_, i) => ({ id: `tile_${i}`, asset }));
  const bundle = core.buildBatchTilesetRuntimeBundle(entries, { profile: 'rpgmaker-like-b-e', scale: 2, renderMode: 'exact' });
  assert.equal(bundle.sheet.columns, 16);
  assert.equal(bundle.sheet.rows, 2);
  assert.equal(bundle.tiles[16].row, 1);
  assert.equal(bundle.tiles[16].column, 0);
});

test('batch tileset centers differently-sized rendered assets inside a common cell', () => {
  const A = [220, 80, 80, 255];
  const B = [80, 160, 220, 255];
  const small = core.compileStrictSymbolicAsset(imageFromRows([[A, A], [A, A]]));
  const wide = core.compileStrictSymbolicAsset(imageFromRows([[B, B, B, B]]));
  const bundle = core.buildBatchTilesetRuntimeBundle([
    { id: 'small', asset: small },
    { id: 'wide', asset: wide }
  ], { profile: 'rpgmaker-like-a5', scale: 3, renderMode: 'exact' });
  assert.equal(bundle.cellSize.width, 12);
  assert.equal(bundle.cellSize.height, 6);
  assert.equal(bundle.tiles[0].drawOffsetX, 3);
  assert.equal(bundle.tiles[0].drawOffsetY, 0);
  assert.equal(bundle.tiles[1].drawOffsetX, 0);
  assert.equal(bundle.tiles[1].drawOffsetY, 1);
});

test('batch tileset rejects duplicate asset ids', () => {
  const asset = core.compileStrictSymbolicAsset(sampleSprite());
  assert.throws(() => core.buildBatchTilesetRuntimeBundle([
    { id: 'dup', asset },
    { id: 'dup', asset }
  ], { profile: 'rpgmaker-like-a5' }), /duplicate/i);
});

test('batch tileset JSON round-trip preserves adapter and mapping metadata', () => {
  const asset = core.compileStrictSymbolicAsset(sampleSprite());
  const bundle = core.buildBatchTilesetRuntimeBundle([
    { id: 'one', asset },
    { id: 'two', asset }
  ], { profile: 'rpgmaker-like-a5', scale: 4, renderMode: 'enhanced' });
  const json = core.batchTilesetRuntimeBundleToJson(bundle);
  const parsed = core.parseBatchTilesetRuntimeBundleJson(json);
  core.validateBatchTilesetRuntimeBundle(parsed);
  assert.equal(parsed.adapter.profile, 'A5-like');
  assert.equal(parsed.tiles.length, 2);
  assert.equal(parsed.tiles[1].id, 'two');
  assert.equal(parsed.sheet.columns, 8);
  assert.equal(parsed.cellSize.width, bundle.cellSize.width);
});

test('strict local UI exposes Gate 9 batch tileset queue and export controls', () => {
  const appSource = fs.readFileSync(path.join(__dirname, '..', 'strict-symbolic-app.js'), 'utf8');
  const htmlSource = fs.readFileSync(path.join(__dirname, '..', 'strict-symbolic.html'), 'utf8');
  assert.match(appSource, /batchTilesetAssets/);
  assert.match(appSource, /buildBatchTilesetRuntimeBundle/);
  assert.match(appSource, /downloadBatchTilesetJsonBtn/);
  assert.match(htmlSource, /Batch tileset/);
  assert.match(htmlSource, /rpgmaker-like-a5/);
});


test('batch tileset can reuse the Gate 8 runtime cache across repeated builds', () => {
  const assetA = core.compileStrictSymbolicAsset(sampleSprite());
  const R = [100, 180, 90, 255];
  const assetB = core.compileStrictSymbolicAsset(imageFromRows([[R, R], [R, R]]));
  const cache = core.createRuntimeRenderCache({ maxEntries: 8 });
  const entries = [{ id: 'a', asset: assetA }, { id: 'b', asset: assetB }];
  core.buildBatchTilesetRuntimeBundle(entries, { profile: 'rpgmaker-like-a5', scale: 4, renderMode: 'enhanced', cache });
  const missesAfterFirst = cache.stats.misses;
  const hitsAfterFirst = cache.stats.hits;
  core.buildBatchTilesetRuntimeBundle(entries, { profile: 'rpgmaker-like-a5', scale: 4, renderMode: 'enhanced', cache });
  assert.equal(missesAfterFirst, 2);
  assert.equal(cache.stats.misses, 2);
  assert.equal(cache.stats.hits, hitsAfterFirst + 2);
});


test('RPG Maker native import packaging APIs are exposed', () => {
  assert.equal(typeof core.buildRpgMakerNativeImportPackage, 'function');
  assert.equal(typeof core.validateRpgMakerNativeImportPackage, 'function');
  assert.equal(typeof core.rpgMakerNativeImportPackageToJson, 'function');
  assert.equal(typeof core.parseRpgMakerNativeImportPackageJson, 'function');
});

test('RPG Maker MZ A5 native package emits the official 384x768 8x16 sheet', () => {
  const asset = core.compileStrictSymbolicAsset(sampleSprite());
  const pkg = core.buildRpgMakerNativeImportPackage([{ id: 'grass', asset }], {
    engine: 'rmmz',
    profile: 'a5',
    baseName: 'GSC_A5',
    renderMode: 'exact'
  });
  assert.equal(pkg.schema, 'evemisslab.rpgmaker-native-import-package');
  assert.equal(pkg.engine, 'rmmz');
  assert.equal(pkg.profile, 'a5');
  assert.equal(pkg.target.relativePath, 'img/tilesets/GSC_A5.png');
  assert.equal(pkg.texture.width, 384);
  assert.equal(pkg.texture.height, 768);
  assert.equal(pkg.sheet.columns, 8);
  assert.equal(pkg.sheet.rows, 16);
  assert.equal(pkg.tileSize, 48);
  assert.equal(pkg.mappings[0].slotIndex, 0);
});

test('RPG Maker MZ B native package reserves the top-left blank slot', () => {
  const asset = core.compileStrictSymbolicAsset(sampleSprite());
  const pkg = core.buildRpgMakerNativeImportPackage([{ id: 'tree', asset }], {
    engine: 'rmmz',
    profile: 'b',
    baseName: 'GSC_B',
    renderMode: 'enhanced'
  });
  assert.equal(pkg.texture.width, 768);
  assert.equal(pkg.texture.height, 768);
  assert.equal(pkg.sheet.columns, 16);
  assert.equal(pkg.sheet.rows, 16);
  assert.equal(pkg.reservedSlots.includes(0), true);
  assert.equal(pkg.mappings[0].slotIndex, 1);
  assert.equal(pkg.mappings[0].column, 1);
  assert.equal(pkg.target.relativePath, 'img/tilesets/GSC_B.png');
});

test('RPG Maker MZ C native package starts at slot zero because C does not reserve the B blank slot', () => {
  const asset = core.compileStrictSymbolicAsset(sampleSprite());
  const pkg = core.buildRpgMakerNativeImportPackage([{ id: 'tree', asset }], {
    engine: 'rmmz',
    profile: 'c',
    baseName: 'GSC_C'
  });
  assert.equal(pkg.reservedSlots.length, 0);
  assert.equal(pkg.mappings[0].slotIndex, 0);
});

test('RPG Maker native A5 package rejects more than 128 assets', () => {
  const asset = core.compileStrictSymbolicAsset(sampleSprite());
  const entries = Array.from({ length: 129 }, (_, i) => ({ id: `tile_${i}`, asset }));
  assert.throws(() => core.buildRpgMakerNativeImportPackage(entries, {
    engine: 'rmmz', profile: 'a5', baseName: 'Overflow'
  }), /capacity/i);
});

test('RPG Maker native B package has capacity 255 because slot zero is reserved', () => {
  const asset = core.compileStrictSymbolicAsset(sampleSprite());
  const entries = Array.from({ length: 256 }, (_, i) => ({ id: `tile_${i}`, asset }));
  assert.throws(() => core.buildRpgMakerNativeImportPackage(entries, {
    engine: 'rmmz', profile: 'b', baseName: 'OverflowB'
  }), /capacity/i);
});

test('native tileset packaging uses integer-contain placement inside fixed 48x48 cells', () => {
  const A = [200, 80, 80, 255];
  const asset = core.compileStrictSymbolicAsset(imageFromRows([
    [A, A, A, A, A],
    [A, A, A, A, A],
    [A, A, A, A, A]
  ]));
  const pkg = core.buildRpgMakerNativeImportPackage([{ id: 'wide', asset }], {
    engine: 'rmmz', profile: 'a5', baseName: 'FitTest', renderMode: 'exact'
  });
  assert.equal(pkg.mappings[0].renderScale, 9);
  assert.equal(pkg.mappings[0].renderedWidth, 45);
  assert.equal(pkg.mappings[0].renderedHeight, 27);
  assert.equal(pkg.mappings[0].drawOffsetX, 1);
  assert.equal(pkg.mappings[0].drawOffsetY, 10);
});

test('native tileset packaging rejects a source asset larger than a 48x48 native cell', () => {
  const A = [200, 80, 80, 255];
  const rows = Array.from({ length: 49 }, () => Array.from({ length: 49 }, () => A));
  const asset = core.compileStrictSymbolicAsset(imageFromRows(rows));
  assert.throws(() => core.buildRpgMakerNativeImportPackage([{ id: 'too_big', asset }], {
    engine: 'rmmz', profile: 'a5', baseName: 'TooBig'
  }), /48x48|native cell|too large/i);
});

test('single-character native package uses img/characters and a $ filename with a 3x4 sheet', () => {
  const asset = core.compileStrictSymbolicAsset(sampleSprite());
  const pkg = core.buildRpgMakerNativeImportPackage([{ id: 'hero', asset }], {
    engine: 'rmmz',
    profile: 'character-single',
    baseName: 'Hero',
    scale: 4,
    renderMode: 'enhanced'
  });
  assert.equal(pkg.target.relativePath, 'img/characters/$Hero.png');
  assert.equal(pkg.sheet.columns, 3);
  assert.equal(pkg.sheet.rows, 4);
  assert.equal(pkg.frameCount, 12);
  assert.equal(pkg.texture.width, pkg.frameSize.width * 3);
  assert.equal(pkg.texture.height, pkg.frameSize.height * 4);
});

test('single-character native package normalizes an already-prefixed filename without duplicating $', () => {
  const asset = core.compileStrictSymbolicAsset(sampleSprite());
  const pkg = core.buildRpgMakerNativeImportPackage([{ id: 'hero', asset }], {
    engine: 'rmmz', profile: 'character-single', baseName: '$Hero'
  });
  assert.equal(pkg.target.fileName, '$Hero.png');
});

test('native import package rejects unsafe path-like base names', () => {
  const asset = core.compileStrictSymbolicAsset(sampleSprite());
  assert.throws(() => core.buildRpgMakerNativeImportPackage([{ id: 'hero', asset }], {
    engine: 'rmmz', profile: 'a5', baseName: '../bad'
  }), /filename|baseName|unsafe/i);
});

test('native import package JSON round-trip preserves adapter constraints and mappings', () => {
  const asset = core.compileStrictSymbolicAsset(sampleSprite());
  const pkg = core.buildRpgMakerNativeImportPackage([{ id: 'grass', asset }], {
    engine: 'rmmz', profile: 'a5', baseName: 'RoundTrip', renderMode: 'enhanced'
  });
  const json = core.rpgMakerNativeImportPackageToJson(pkg);
  const parsed = core.parseRpgMakerNativeImportPackageJson(json);
  core.validateRpgMakerNativeImportPackage(parsed);
  assert.equal(parsed.engineConstraints.tileSize, 48);
  assert.equal(parsed.engineConstraints.requiredWidth, 384);
  assert.equal(parsed.engineConstraints.requiredHeight, 768);
  assert.equal(parsed.mappings[0].id, 'grass');
});

test('strict local UI exposes Gate 10 native import controls', () => {
  const appSource = fs.readFileSync(path.join(__dirname, '..', 'strict-symbolic-app.js'), 'utf8');
  const htmlSource = fs.readFileSync(path.join(__dirname, '..', 'strict-symbolic.html'), 'utf8');
  assert.match(appSource, /nativeProfile/);
  assert.match(appSource, /downloadNativeManifestBtn/);
  assert.match(appSource, /downloadNativePngBtn/);
  assert.match(htmlSource, /Native import package/);
  assert.match(htmlSource, /RPG Maker MZ · A5/);
});


test('project binding plan API is exposed by the compiler core', () => {
  assert.equal(typeof core.buildRpgMakerProjectBindingPlan, 'function');
  assert.equal(typeof core.validateRpgMakerProjectBindingPlan, 'function');
  assert.equal(typeof core.projectBindingPlanToJson, 'function');
  assert.equal(typeof core.parseProjectBindingPlanJson, 'function');
  assert.equal(typeof core.applyRpgMakerTilesetsPatchPreview, 'function');
});

test('A5 project binding plan targets img/tilesets and tilesetNames slot 4', () => {
  const asset = core.compileStrictSymbolicAsset(sampleSprite());
  const pkg = core.buildRpgMakerNativeImportPackage([{ id: 'grass', asset }], {
    engine: 'rmmz', profile: 'a5', baseName: 'GSC_A5'
  });
  const plan = core.buildRpgMakerProjectBindingPlan(pkg, { tilesetId: 1 });
  assert.equal(plan.safeMode, 'preview-only');
  assert.equal(plan.mutatesProject, false);
  assert.equal(plan.operations[0].relativePath, 'img/tilesets/GSC_A5.png');
  assert.equal(plan.databasePatches.length, 1);
  assert.equal(plan.databasePatches[0].file, 'data/Tilesets.json');
  assert.equal(plan.databasePatches[0].tilesetId, 1);
  assert.equal(plan.databasePatches[0].slotName, 'A5');
  assert.equal(plan.databasePatches[0].slotIndex, 4);
  assert.equal(plan.databasePatches[0].value, 'GSC_A5');
});

test('B-E project binding slots map to tilesetNames indexes 5 through 8', () => {
  const asset = core.compileStrictSymbolicAsset(sampleSprite());
  const expected = { b: 5, c: 6, d: 7, e: 8 };
  for (const [profile, slotIndex] of Object.entries(expected)) {
    const pkg = core.buildRpgMakerNativeImportPackage([{ id: profile, asset }], {
      engine: 'rmmz', profile, baseName: `GSC_${profile.toUpperCase()}`
    });
    const plan = core.buildRpgMakerProjectBindingPlan(pkg, { tilesetId: 2 });
    assert.equal(plan.databasePatches[0].slotIndex, slotIndex);
    assert.equal(plan.databasePatches[0].slotName, profile.toUpperCase());
  }
});

test('single-character project binding plan emits character resource reference without Tilesets patch', () => {
  const asset = core.compileStrictSymbolicAsset(sampleSprite());
  const pkg = core.buildRpgMakerNativeImportPackage([{ id: 'hero', asset }], {
    engine: 'rmmz', profile: 'character-single', baseName: 'Hero', scale: 2
  });
  const plan = core.buildRpgMakerProjectBindingPlan(pkg);
  assert.equal(plan.operations[0].relativePath, 'img/characters/$Hero.png');
  assert.equal(plan.databasePatches.length, 0);
  assert.equal(plan.resourceRef.kind, 'character');
  assert.equal(plan.resourceRef.characterName, '$Hero');
});

test('Tilesets patch preview updates a cloned snapshot and preserves the original', () => {
  const asset = core.compileStrictSymbolicAsset(sampleSprite());
  const pkg = core.buildRpgMakerNativeImportPackage([{ id: 'grass', asset }], {
    engine: 'rmmz', profile: 'a5', baseName: 'GSC_A5'
  });
  const plan = core.buildRpgMakerProjectBindingPlan(pkg, { tilesetId: 1 });
  const snapshot = [null, {
    id: 1,
    name: 'Field',
    tilesetNames: ['', '', '', '', 'OldA5', 'OldB', '', '', '']
  }];
  const original = JSON.parse(JSON.stringify(snapshot));
  const preview = core.applyRpgMakerTilesetsPatchPreview(snapshot, plan);
  assert.equal(preview[1].tilesetNames[4], 'GSC_A5');
  assert.deepEqual(snapshot, original);
});

test('project binding plan rejects invalid tileset ids for tileset profiles', () => {
  const asset = core.compileStrictSymbolicAsset(sampleSprite());
  const pkg = core.buildRpgMakerNativeImportPackage([{ id: 'grass', asset }], {
    engine: 'rmmz', profile: 'a5', baseName: 'GSC_A5'
  });
  assert.throws(() => core.buildRpgMakerProjectBindingPlan(pkg, { tilesetId: 0 }), /tilesetId/i);
});

test('project binding plan JSON round-trip preserves safe import metadata', () => {
  const asset = core.compileStrictSymbolicAsset(sampleSprite());
  const pkg = core.buildRpgMakerNativeImportPackage([{ id: 'grass', asset }], {
    engine: 'rmmz', profile: 'b', baseName: 'GSC_B'
  });
  const plan = core.buildRpgMakerProjectBindingPlan(pkg, { tilesetId: 3, overwritePolicy: 'prompt' });
  const parsed = core.parseProjectBindingPlanJson(core.projectBindingPlanToJson(plan));
  core.validateRpgMakerProjectBindingPlan(parsed);
  assert.equal(parsed.safeMode, 'preview-only');
  assert.equal(parsed.operations[0].overwritePolicy, 'prompt');
  assert.equal(parsed.databasePatches[0].slotIndex, 5);
});

test('strict local UI exposes Gate 11 project binding preview controls', () => {
  const appSource = fs.readFileSync(path.join(__dirname, '..', 'strict-symbolic-app.js'), 'utf8');
  const htmlSource = fs.readFileSync(path.join(__dirname, '..', 'strict-symbolic.html'), 'utf8');
  assert.match(appSource, /projectTilesetId/);
  assert.match(appSource, /downloadProjectBindingPlanBtn/);
  assert.match(htmlSource, /Project binding preview/);
  assert.match(htmlSource, /Tileset database ID/);
});


test('strict local UI exposes Tilesets.json patch preview helper', () => {
  const appSource = fs.readFileSync(path.join(__dirname, '..', 'strict-symbolic-app.js'), 'utf8');
  const htmlSource = fs.readFileSync(path.join(__dirname, '..', 'strict-symbolic.html'), 'utf8');
  assert.match(appSource, /previewTilesetsPatchBtn/);
  assert.match(appSource, /applyRpgMakerTilesetsPatchPreview/);
  assert.match(htmlSource, /Tilesets\.json snapshot/);
  assert.match(htmlSource, /Patched preview/);
});

# Generative Symbol Compiler Lab Changelog

## v1.13.0-strict-symbolic
- 新增 Gate 11：Native Project Binding / Import Helper Baseline。
- 核心新增 `buildRpgMakerProjectBindingPlan()`、`validateRpgMakerProjectBindingPlan()`、`projectBindingPlanToJson()`、`parseProjectBindingPlanJson()`、`applyRpgMakerTilesetsPatchPreview()`。
- A5/B/C/D/E native packages 現在可轉成 `data/Tilesets.json` slot patch plan；slot mapping 為 A5=4、B=5、C=6、D=7、E=8。
- `$` single-character package 會生成 character resource reference，不修改 Tilesets database。
- binding plan 強制 `safeMode=preview-only`、`mutatesProject=false`，所有未來 write operations 都保留 explicit confirmation metadata。
- strict local UI 新增 Project binding preview panel，可下載 binding plan，並對貼入的 Tilesets.json snapshot 產生非破壞式 patched preview。
- 新增 Gate 11 regression tests：API exposure、A5/B–E slot mapping、character reference、non-mutating Tilesets preview、invalid tilesetId rejection、JSON round-trip、UI controls。
- 程式版本升至 `v1.13.0-strict-symbolic`；AssetSymbol schema 維持 `v0.7`；ProjectBindingPlan 為 `v0.1`。

## v1.12.0-strict-symbolic
- 新增 Gate 10：Native Import Packaging / Adapter Hardening Baseline。
- 新增 `buildRpgMakerNativeImportPackage()`、`validateRpgMakerNativeImportPackage()`、`rpgMakerNativeImportPackageToJson()`、`parseRpgMakerNativeImportPackageJson()`。
- 支援 RPG Maker MV/MZ native profiles：A5 384×768 / 8×16、B–E 768×768 / 16×16、48×48 tile cell，以及 `$` single-character 3×4 sheet。
- B profile 強制保留左上 slot 0 空白；A5 capacity 128，B effective capacity 255。
- Native tileset packaging 使用 integer-contain placement；超過 48×48 source canvas 會明確拒絕。
- strict local UI 新增 Native import package panel，可導出 native manifest JSON 與 PNG。
- 新增 Gate 10 regression tests：API exposure、A5/B/C native layout、capacity、fixed-cell placement、oversize rejection、single-character naming、unsafe filename rejection、JSON round-trip、UI controls。
- 程式版本升至 `v1.12.0-strict-symbolic`；AssetSymbol schema 維持 `v0.7`；NativeImportPackage 為 `v0.1`。

## v1.11.0-strict-symbolic
- 新增 Gate 9：Batch Tileset / Engine-specific Adapter Baseline。
- 核心新增 `buildBatchTilesetRuntimeBundle()`、`validateBatchTilesetRuntimeBundle()`、`batchTilesetRuntimeBundleToJson()`、`parseBatchTilesetRuntimeBundleJson()`。
- 新增 `rpgmaker-like-a5` 8-column profile 與 `rpgmaker-like-b-e` 16-column profile；mapping 採 deterministic row-major order。
- 不同 rendered asset 尺寸會自動置中到共同 cell，再組成單一 tileset texture / manifest。
- Gate 9 batch builder 可直接重用 Gate 8 runtime render cache。
- strict local UI 新增 Batch tileset queue、profile selector、Batch JSON / PNG export。
- 新增 Gate 9 regression tests：API exposure、A5/B-E layout、mixed-size centering、duplicate-id rejection、JSON round-trip、UI controls、cache reuse。
- 程式版本升至 `v1.11.0-strict-symbolic`；AssetSymbol schema 維持 `v0.7`；BatchTileset bundle 為 `v0.1`。

## v1.10.0-strict-symbolic
- 新增 Gate 8：Symbolic Autotile Runtime / Runtime Cache Baseline。
- 新增 `buildSymbolicAutotileRuntimeBundle()`：依四鄰接 bit mask 產生 16 個 autotile variants，並輸出 4×4 runtime sheet。
- 新增 `validateSymbolicAutotileRuntimeBundle()` 與 `autotileRuntimeBundleToJson()`。
- 新增 deterministic runtime cache：`computeRuntimeRenderCacheKey()`、`createRuntimeRenderCache()`、`getOrBuildRuntimeBundleCached()`。
- runtime cache 目前支援 bounded entry count、hit/miss/eviction stats 與 LRU-like touch order。
- strict local UI 的 Runtime export 新增 `Gate 8 · Autotile 4×4 Sheet`。
- 新增 Gate 8 regression tests：16-state sheet、neighbor-mask visual difference、deterministic cache key、cache hit/miss、eviction、UI autotile option。
- 程式版本升至 `v1.10.0-strict-symbolic`；AssetSymbol schema 維持 `v0.7`。

## v1.9.0-strict-symbolic
- 新增 Gate 7：RPG Maker Visual Runtime Baseline。
- 核心新增 `buildRpgMakerRuntimeBundle()`、`validateRpgMakerRuntimeBundle()`、`runtimeBundleToJson()`、`parseRuntimeBundleJson()`。
- Runtime bundle 可從 canonical `AssetSymbol` 直接導出 tile bundle 或 character 3×4 sheet，並附帶 frame manifest、sheet metadata、collision mask、anchor 與 engine-facing texture。
- strict local UI 新增 Runtime export control，可下載 runtime bundle JSON 與 runtime PNG。
- 新增 Gate 7 regression tests：runtime API exposure、tile bundle、character sheet manifest、exact/enhanced render mode difference、JSON round-trip、AssetSymbol-JSON-only bundle construction、UI controls。
- 程式版本升至 `v1.9.0-strict-symbolic`；AssetSymbol schema 維持 `v0.7`。

## v1.8.0-strict-symbolic
- 新增 Gate 6：`renderEnhancedStrictSymbolicAsset()`，在 source-blind 條件下直接消費 topology / contour / medial / skeleton graph / part grammar 做保守 enhanced rerender。
- Gate 1 exact renderer 維持不變，作為 exact / bit-faithful reference path。
- strict local UI 新增 `Render mode`，可在 `Gate 1 · Exact Renderer` 與 `Gate 6 · Enhanced Re-render` 間切換。
- 新增 Gate 6 regression tests：API exposure、output dimensions、difference from exact scaling、partial alpha、ring-hole preservation、primitive-sensitive behavior、UI control exposure。
- 程式版本升至 `v1.8.0-strict-symbolic`；AssetSymbol schema 維持 `v0.7`。

## v1.7.0-strict-symbolic
- 新增 Gate 5：`extractStrictPartGrammar()`，將 region + topology + skeleton graph 提升成 region-level part tokens。
- strict asset schema 預設升至 v0.7；每個 region 現在可保存 `partGrammar`，asset-level 新增 `partGrammar` summary。
- 目前 primitive baseline 包含 `carrier / dot / bar / block / ring / junction / blob`，並附 orientation / role / attachments 等 metadata。
- validator 已支援 region-level 與 asset-level part grammar metadata。
- strict local UI / JSON-only log 現在會顯示 part grammar summary。
- 新增 Gate 5 regression tests：API exposed、bar/ring/junction classification、asset summary、UI summary。

## v1.6.0-strict-symbolic
- 新增 Gate 4C：`extractStrictSkeletonGraph()`，把 skeleton / medial hints 壓成節點—邊結構圖。
- strict asset schema 預設升至 v0.6；每個 region 的 `topology.medial.graph` 現在保存 `nodes / edges / nodeCount / edgeCount / branchlessPathCount`。
- asset topology summary 新增 `totalSkeletonGraphNodes / totalSkeletonGraphEdges / totalSkeletonBranchlessPaths`。
- UI / JSON-only log 現在會顯示 skeleton graph totals。
- 新增 Gate 4C regression tests：API exposed、line segment compression、plus junction graph、summary totals。

## v1.5.0-strict-symbolic
- 新增 Gate 4B：`extractStrictMedialHints()`。
- 使用 Zhang–Suen thinning 建立 deterministic skeleton baseline。
- 使用 Manhattan distance transform 為 skeleton pixels 加入 medial radius。
- region topology 新增 skeletonPixels / endpointPixels / junctionPixels / maxRadius / meanRadius。
- asset topology summary 新增 totalSkeletonPixels / totalSkeletonEndpoints / totalSkeletonJunctions / maxMedialRadius。
- strict asset schema 預設升至 v0.5；validator 支援 Gate 4B medial metadata。
- 修復 strict local UI 的 Gate 2 regression：Compile Route 現在會真正呼叫 normalized compiler。
- UI / JSON-only log 新增 Gate 4A / 4B topology summary。
- 新增 Gate 4B 與 UI regression tests。

## v1.4.0-strict-symbolic
- 新增 Gate 4A：`extractStrictContourAnchors()`，從 region mask 中萃取 ordered contour anchors 與 turning points。
- strict asset schema 現在預設輸出 `v0.4`，在 region-level topology 中新增 `contour` 區塊。
- asset-level topology summary 新增 `totalContourAnchors` 與 `totalTurningPoints`。
- `strict-symbolic` UI / log 現在會顯示 contour anchor 與 turning-point 總量。
- 新增回歸測試：contour API exposed、summary totals、ring anchors、rectangle turning points。

## v1.3.0-strict-symbolic
- 新增正式架構文件 `docs/TECHNICAL_DESIGN_v0.1.md`；以已完成 Gate 1–3 為 implementation baseline，並正式區分 Gate 4–6 planned scope。
- 新增 Gate 3：`extractStrictTopology()`，從 RUN geometry / regions 抽出 contour、hole、symmetry 等 topology metadata。
- `compileStrictSymbolicAsset()` 與 `compileNormalizedStrictSymbolicAsset()` 現在預設輸出 schema v0.3 asset。
- region-level topology 現在保存 boundary、perimeter、holeCount、fillRatio、symmetry、isTransparent。
- asset-level topology summary 現在保存 totalBoundaryPixels、totalPerimeter、totalHoles、weighted symmetry。
- 新增回歸測試：topology API exposed、asset topology summary、ring hole detection、demo symmetry。

## v1.2.0-strict-symbolic
- 新增 `normalizePixelLikeImage()` 與 `compileNormalizedStrictSymbolicAsset()`。
- 新增 Gate 2：Pixel Normalizer，提供 alpha 二值化、有限 palette 量化、孤立噪點平滑。
- strict asset schema 現在支援 v0.2，允許附帶 `normalization` metadata；仍相容 v0.1 exact assets。
- `strict-symbolic.html` 新增 Compile Route 切換，可直接比較 `Source -> Normalized target -> R(S)`。
- 新增測試：alpha snap、palette reduction、despeckle、normalized compile rescue。

## v1.1.0-strict-symbolic
- 新增獨立 `strict-symbolic.html` 本地實驗頁。
- 新增 `compileStrictSymbolicAsset()`：把有限調色盤像素圖編譯成 palette + RUN tokens。
- 新增 `renderStrictSymbolicAsset()`：函式介面不接受 source image，支援 1×–64× 整數 symbolic re-rasterization。
- 新增 `evemisslab.symbolic-image` schema v0.1。
- 新增 4-neighbor connected-region metadata 與 region adjacency graph，作為 contour / topology / part grammar 前置層。
- 新增 strict JSON serialize / parse / validation。
- canonical strict validator 會拒絕 hidden source payload 欄位與 image Data URL，避免把原圖偷偷塞回 $S$。
- 新增回歸測試：compile 後破壞 source buffer，仍須 byte-for-byte exact reconstruction。
- 新增 JSON-only 本地工作流：不載 source image 也能重建。
- 研究節奏改以 Interaction Gates 記錄，不使用傳統開發時間估算。

## v1.0.0
- 正式進入 **Visual Operator Paper Mode**：把輸出尺寸、輸出格式與 DPI 一起納入正式流程。
- 新增 `Export DPI` 控制：72 / 96 / 150 / 300 / 600 / 1200。
- `Download Image` 現在會依 `format / scale / DPI / transparency` 輸出最終圖像。
- PNG 會寫入 `pHYs` DPI metadata；JPEG 會寫入 JFIF density metadata；WebP 保留像素輸出。
- Status / Semantic Summary 現在會顯示 `exportPx` 與對應 `printSize`（inch / mm）。
- v1.0 目標不是更多花式渲染，而是把視覺算子族轉成可重現、可比較、可寫論文的輸出機制。

## v0.9.0
- 輸出邏輯正式分成 **Production 1:1** 與 **Presentation Poster** 兩條路線。
- 右側預覽在 Production 模式下改成接近原圖尺寸的真正輸出，不再只是展示型縮小圖。
- 新增 `drawProductionOutput()`，直接輸出接近 source 尺寸的 semantic-layer composite。
- 新增輸出控制：`PNG / JPEG / WebP`、`1x / 2x / 4x`、`quality`、`transparent background`。
- Download Image 現在會依輸出模式與格式真正導出最終圖像，而不是只下載固定 PNG 預覽。
- UI / status / semantic summary 全部納入 output mode 與 export format 資訊，方便論文與實驗記錄。

## v0.8.0
- 新增 **Multi-Layer Semantic Symbol Renderer**：把 source-preserving reconstruction 分拆為 background / subject / glow / foreground / panel 五層語義結構。
- 新增 `scene.semantic` 與 `scene.compiler.layerVisibility`，Scene JSON 現在可保存語義層配置與開關狀態。
- 新增 `buildSemanticRenderBundle()`，以純資料結構生成 semantic render bundle，供 app 與 standalone HTML 共用。
- 新增前端 layer toggles，可即時開關 Background / Subject / Glow FX / Foreground / Panel。
- Preview 現在走 multi-layer composition，而不是單一 high-fidelity flat composite。
- 新增 semantic summary 面板，顯示 threshold / visibility / coverage。
- 新增測試：semantic metadata 與 semantic bundle coverage stats。

## v0.7.0
- 新增 High-Fidelity 1:1 renderer：保留 source image，直接做近原圖解析度的 symbol-native stylized reconstruction。
- renderer 現在可走 `source-preserving-1to1` 路線，不再只依賴 region-map preview。
- `style` 與 sliders 會直接作用在 full-resolution source stylization。
- output canvas 會依 source image 尺寸動態放大，下載 PNG 更接近一比一視覺測試。
- standalone HTML 也會自動從 embedded source image 建立 high-fidelity styled render。
- 新增 regression tests：`buildStyledSourceImage` 維持尺寸，且不同 style 會生成不同結果。

## v0.6.2
- 修正 style / slider 調整沒有即時反映的 UI 問題，現在控制項變更會自動重新 compile。
- 修正 reconstruction 模式下風格差異過弱的問題。style 會更明顯地改變 palette mapping、邊線、紙感 / 筆觸 / 動態線。
- reconstruction complexity 現在會受 detail bias 影響，改變 maxSide / maxColors / maxRegions / minRegionArea。
- 新增回歸測試：detail bias 必須改變 reconstruction complexity；不同 style 必須產生不同 reconstruction colors。

## v0.6.0
- 初始化 Generative Symbol Compiler Lab，將研究主線從 naive image translation 轉向 scene reconstruction。
- 新增輸入圖片分析器：擷取平均色、亮度、色彩方差、邊緣密度、中央色塊特徵、暖色比例等資訊。
- 新增 auto subject inference：portrait、scene、product-poster。
- 新增 Symbolic Scene Compiler：從分析結果生成 symbol-native scene JSON。
- 內建 symbol-native renderer，直接將 scene JSON 渲染成插畫風格預覽。
- 新增 target style、subject mode、mood/detail/energy/warmth bias 調整。
- 新增原圖 / compiled preview 對照、scene JSON 匯出、single-file HTML 匯出、compiled PNG 匯出。
- 新增純 JS 測試與驗證文件。

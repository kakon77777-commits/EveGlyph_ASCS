# Generative Symbol Compiler Lab v1.13.0-strict-symbolic

這個本地分支保留 v1.0.0 的 source-preserving / semantic renderer，並新增一條刻意隔離的 **Strict Symbolic Reconstruction** 實驗路徑。

> 正式技術設計基線：`docs/TECHNICAL_DESIGN_v0.1.md`。程式版本與設計文件版本分離管理。


核心命題改成：

$$
I \xrightarrow{C} S,\qquad \cancel{I},\qquad S \xrightarrow{R} \hat I.
$$

也就是 compiler 可以讀原圖，但 strict renderer 的函式介面只接受 symbolic asset $S$；compile 完成後即使原始 RGBA buffer 被破壞，仍必須能重建。

## 直接使用

1. 解壓縮。
2. 直接打開 `strict-symbolic.html`。
3. 使用內建 16×16 pixel demo，或載入自己的 pixel-art / pixel-like PNG。
4. 選擇 `Gate 1 · Exact` 或 `Gate 2 · Normalized`。
5. 若走 Gate 2，可設定 `Normalizer palette target / Alpha threshold / Despeckle`。
6. 點 `Compile → Cut Source`。
7. 確認 `Exact match = YES` 與 `Source buffer = CUT`；Gate 2 會同時顯示 `Normalized target`。
8. 改變 1× / 2× / 4× / 8× / 16×，所有縮放都只從 RUN symbols 重畫。
9. 可下載 `AssetSymbol JSON`；重新整理頁面後，不載任何圖片，只貼 JSON 並按 `Render JSON Only`，即可驗證 source-independent reconstruction。

`index.html` 仍保留 v1.0.0 的 legacy semantic/source-preserving renderer，方便 A/B 對照。

## Gate 1：Exact Symbolic Carry

目前 symbolic asset schema：

$$
S = (\text{canvas},\text{palette},\text{RUN tokens},\text{regions},\text{adjacency}).
$$

其中 renderer 的必要重建資訊只有：

$$
S_R=(\text{canvas},\text{palette},\text{RUN tokens}).
$$

`regions / adjacency` 是下一階段 topology / asset grammar 的前置 metadata。

### RUN token

每個 token 是一個水平離散區段：

```json
{
  "op": "RUN",
  "y": 4,
  "x": 7,
  "length": 5,
  "paletteIndex": 3
}
```

這不是把 source RGBA buffer 直接塞進 JSON；renderer 只解釋 palette 與 symbolic geometry token。Gate 1 的目標是先證明 representation sufficiency，不宣稱已完成高階語義壓縮。

## 互動關卡，而非傳統時間表

- **Gate 1 — Exact Symbolic Carry：已建立。** Palette + RUN token 可 source-blind bit-exact 重建，並提供 region topology metadata。
- **Gate 2 — Pixel Normalizer：已建立 v0.2 基線。** 目前提供 alpha 二值化、有限 palette 量化、孤立噪點平滑，讓 pixel-like 輸入先轉成 canonical compile target。
- **Gate 3 — Topology Lift：已建立。** 從 RUN geometry 抽 contour、holes、symmetry。
- **Gate 4A — Ordered Contour Anchors：已建立。**
- **Gate 4B — Skeleton / Medial Hints：已建立。**
- **Gate 4C — Skeleton Graph / Segment Compression：已建立基線。**
- **Gate 5 — Part Grammar Baseline：已建立。**
- **Gate 6 — Enhanced Re-render Baseline：已建立。**
- **Gate 7 — RPG Maker Visual Runtime Baseline：已建立。**
- **Gate 8 — Symbolic Autotile Runtime / Runtime Cache Baseline：已建立。**
- **Gate 9 — Batch Tileset / Engine-specific Adapter Baseline：已建立。**
- **Gate 10 — Native Import Packaging / Adapter Hardening Baseline：已建立。**
- **Gate 11 — Native Project Binding / Import Helper Baseline：已建立。**
- **Gate 12 — Transactional Project Apply / Rollback Guard：下一關。**

## Gate 1 驗證

```bash
node --test tests/core.test.js tests/strict-symbolic.test.js
node --check src/core.js
node --check strict-symbolic-app.js
```

Strict tests 會明確執行：

```text
compile image -> AssetSymbol -> destroy source.data -> render AssetSymbol -> byte-for-byte compare
```

## 目前限制

- Gate 1 是 **exact finite-palette pixel-art domain**。
- 預設最多 256 個精確 RGBA 色。超過上限會拒絕，而不是偷偷量化。
- 目前已完成 Gate 11 preview-only project binding baseline：Gate 10 native package 現在可轉成可審查的 copy operation、Tilesets.json slot patch plan 與 character resource reference；瀏覽器可對貼入的 Tilesets.json snapshot 產生 patched preview，但仍不自動寫入任何 RPG Maker project file。
- RUN tokens 先保證可逆；後續關卡才會逐步測試能否在維持視覺充分性的同時，降低表示冗餘並提升語義層級。

---

## Legacy v1.0.0 notes



這版想驗證：

$$
\text{symbol-native visual bottleneck}
$$

是否主要卡在：

$$
\text{pixel-to-symbol semantic compilation}
$$

而不是 renderer 本身。

## 功能

- 載入本地圖片
- 載入 demo image
- 自動特徵分析
- auto / manual subject 模式
  - portrait
  - scene
  - product-poster
- target style
  - flat-commercial
  - anime
  - storybook
  - painterly
  - splash-art-lite
- bias controls
  - mood bias
  - detail bias
  - energy bias
  - warmth bias
- 原圖 / compiled preview 對照
- scene JSON 編輯 / 匯出
- compiled PNG 匯出
- single-file HTML 匯出

## 使用方式

1. 解壓縮
2. 打開 `index.html`
3. 載入圖片或按 `Load Demo`
4. 選擇 target style 與 subject mode
5. 點 `Analyze + Compile`
6. 觀察右側 compiled preview 與分析資訊
7. 視需要微調 bias 或 scene JSON
8. 匯出 JSON / PNG / HTML

## 驗證

```bash
node --test tests/core.test.js
node --check src/core.js
node --check app.js
```

## 定位

這版更接近：

$$
\text{Generative Symbol Compiler Prototype}
$$

它不是完整的 vision model，但足以作為：

- structural baseline
- scene reconstruction baseline
- symbol-native renderer 研究中介層

的起點。


## v0.6.2 notes

- 調整滑桿與風格選單後，現在會自動重新編譯，不需要每次手動按 `Analyze + Compile`。
- `detail bias` 不只是 metadata，會直接影響 reconstruction complexity。
- reconstruction 預覽中的 style 差異已加強：`anime`、`storybook`、`painterly`、`splash-art-lite` 會有更明顯的視覺差異。


## v0.7.0 notes

- 這版的重點不是再做更粗的 symbol block，而是直接測試 **1:1 high-fidelity** 路線。
- 編譯後的 preview 會保留接近原圖解析度的主體資訊，再疊上 symbol-native style。
- `anime / storybook / painterly / splash-art-lite / flat-commercial` 會直接改變 full-resolution render。
- 如果要測更極端的一比一，可以直接丟入更高解析度圖片，下載 PNG 後比較。


## v0.8.0 notes

- 這版把高保真 renderer 進一步升級成 **Multi-Layer Semantic Symbol Renderer**。
- renderer 會把 source-preserving 結果拆成：`background / subject / glow / foreground / panel`。
- 每層都可以獨立開關，因此可直接測試：某些畫面強度到底來自主體、氛圍光效、還是前景層。
- Scene JSON 會保存 semantic layer metadata 與 layer visibility，方便後續做局部重編譯與可控式商業視覺實驗。
- `buildStandaloneHtml()` 也會內嵌 multi-layer semantic render，而不只是單張 flat render。


## v0.9.0 notes

- 這版的核心不是增加更多裝飾功能，而是把 **輸出本身** 做到更像真正可交付的圖像結果。
- `Production 1:1` 會讓右側輸出直接以 source-size 為基準渲染，不再只是一張展示縮圖。
- 現在可以直接選 `PNG / JPEG / WebP`，並設定 `1x / 2x / 4x` 輸出倍率與品質。
- 如果研究重點是比較原圖與編譯結果，建議使用 `Production 1:1 + 1x/2x`。
- 如果研究重點是展示與敘述，則可切回 `Presentation Poster`。
- 這版更接近你要的論文方向：把視覺算子族與輸出格式一起納入正式實驗框架。


## v1.0.0 notes

- 這版的核心是 **DPI-aware export**，不是再往展示層疊更多功能。
- 現在可以直接決定 `PNG / JPEG / WebP`、`1x / 2x / 4x`、以及 `72 / 96 / 150 / 300 / 600 / 1200 DPI`。
- `Production 1:1` 模式適合做原圖與編譯結果的直接比較；`Presentation Poster` 適合做報告或論文展示。
- Status 會同步顯示輸出像素尺寸與估計印刷尺寸，方便直接規劃論文插圖與海報版面。
- 若要做正式論文實驗，建議至少記錄：`style / scale / dpi / format / transparentBackground / layerVisibility`。


## Gate 2：Pixel Normalizer

目前新增：

$$
I \xrightarrow{N} I_N \xrightarrow{C} S,\qquad \cancel I,\qquad S\xrightarrow{R}\hat I.
$$

其中 $I_N$ 是 canonical compile target。當輸入不是乾淨有限 palette pixel art，而是帶有 alpha noise、近似重複色、或單點雜訊的 pixel-like 圖時，Gate 2 會先讓這些變換成顯式的 preprocessing，而不是在 renderer 內偷偷做。

目前 normalizer 包含：

- alpha 二值化
- 有限 palette 量化
- isolated pixel despeckle

這一關的驗證標準改成：

$$
R(S)=I_N
$$

而不是直接要求 $R(S)=I$。也就是說，Gate 2 證明的是：**正規化後的 canonical target 仍可由 symbolic representation 完整攜帶並 source-blind 重建。**


## Gate 3：Topology Lift

目前 strict symbolic asset 預設已帶有 topology metadata：

$$
S=(\text{canvas},\text{palette},\text{RUN tokens},\text{regions},\text{adjacency},\text{topology}).
$$

其中 `topology` 目前先包含：

- boundary / perimeter
- hole count
- fill ratio
- vertical / horizontal symmetry

因此這一版的目標不只是 source-blind exact carry，也開始把圖像中的局部 shape structure 從 raster token 中提升出來，作為下一輪 skeleton / part grammar 的入口。


## Gate 4A：Ordered Contour Anchors / Turning Points

目前每個 region 的 topology 已新增：

$$
\text{contour} = (\text{orderedAnchors},\text{turningPoints},\text{anchorCount},\text{turnCount}).
$$

這一層是為了把 boundary pixel set 轉成帶順序的支點表示，供後續 skeleton、corner-aware rerender 與 part grammar 使用。

目前這不是完整的輪廓追蹤器，而是 baseline ordered contour representation。


## Gate 4B：Skeleton / Medial Hints Baseline

Gate 4B 在每個非透明 region 上新增：

$$
\text{region mask}
\xrightarrow{\text{thinning}}
K
$$

以及：

$$
\text{region mask}
\xrightarrow{\text{distance transform}}
\rho.
$$

目前實作使用 deterministic Zhang–Suen thinning 作為 skeleton baseline，並使用 Manhattan distance transform 為每個 skeleton point 附上 medial radius。

`region.topology.medial` 目前包含：

- `skeletonPixels`
- `endpointPixels`
- `junctionPixels`
- `skeletonPixelCount`
- `endpointCount`
- `junctionCount`
- `maxRadius`
- `meanRadius`
- `thinningIterations`

asset-level topology 同時新增：

- `totalSkeletonPixels`
- `totalSkeletonEndpoints`
- `totalSkeletonJunctions`
- `maxMedialRadius`

透明 region 目前不做 skeletonization，避免背景透明域主導幾何統計。

這仍是 skeleton / medial **hint baseline**，不是宣稱已求得連續幾何意義下的精確 medial axis。


## Gate 4C：Skeleton Graph / Segment Compression

Gate 4C 把 Gate 4B 的逐 pixel skeleton hints 壓成：

$$
K \to G_K=(V_K,E_K).
$$

其中：

- $V_K$ = skeleton graph nodes（目前以 endpoint / junction / cycle-anchor 為主）
- $E_K$ = branchless path edges

每個非透明 region 現在會帶有：

```json
{
  "topology": {
    "medial": {
      "graph": {
        "nodes": [{"id":"n0","kind":"endpoint","x":0,"y":0,"radius":1,"degree":1}],
        "edges": [{"id":"e0","from":"n0","to":"n1","length":5,"polyline":[...]}],
        "nodeCount": 0,
        "edgeCount": 0,
        "branchlessPathCount": 0
      }
    }
  }
}
```

asset-level topology summary 也新增：

- `totalSkeletonGraphNodes`
- `totalSkeletonGraphEdges`
- `totalSkeletonBranchlessPaths`

這一層的目的，是讓後續 Gate 5 的 part grammar / topology-aware rerender 可以直接吃結構圖，而不是每次重掃所有 skeleton pixels。


## Gate 5：Part Grammar Baseline

Gate 5 先不直接跳到高語義角色標註，而是從 region-level structural metadata 抽出可重用 part token：

$$
(\text{region},\text{topology},\text{medial},G_K) \to \text{part token}.
$$

目前每個 region 都會新增 `partGrammar`，至少包含：

- `primitive`：例如 `carrier / dot / bar / block / ring / junction / blob`
- `orientation`：例如 `horizontal / vertical / square / radial / mixed`
- `role`：例如 `background-carrier / primary-mass / secondary-mass / connector / loop-feature / detail-mark / limb-like`
- `attachments` / `adjacencyDegree`

而 asset-level 則新增：

- `partGrammar.grammarVersion`
- `partGrammar.partCount`
- `partGrammar.countsByPrimitive`
- `partGrammar.countsByRole`
- `partGrammar.primaryPartIds`
- `partGrammar.parts`

這一層是後續 enhanced re-render / tile grammar / sprite grammar 的第一個可序列化基線。


## Gate 6：Enhanced Re-render Baseline

Gate 6 新增 `renderEnhancedStrictSymbolicAsset()`：

$$
R_{\mathrm{enhanced}}(S;\,\text{topology},\text{contour},\text{medial},G_K,P).
$$

它仍然只吃 canonical `AssetSymbol`，不讀取原始 source image，但在放大 preview 時，不再只是單純 block re-rasterization，而會利用：

- region boundary / contour anchors / turning points
- medial hints / skeleton graph counts
- part grammar primitive / orientation / role

來做保守的高解析度平滑重繪基線。

目前 UI 已提供 exact / enhanced render mode 切換，而 Gate 1 exact renderer 仍保留為 bit-faithful reference path。


## Gate 7：RPG Maker Visual Runtime Baseline

Gate 7 新增 runtime bundle layer：

$$
	ext{AssetSymbol } S 	o 	ext{RuntimeBundle } B_R.
$$

目前已提供：

- `buildRpgMakerRuntimeBundle()`
- `validateRpgMakerRuntimeBundle()`
- `runtimeBundleToJson()` / `parseRuntimeBundleJson()`

它可直接由 canonical `AssetSymbol` 生成：

- tile runtime bundle
- character 3×4 single-character sheet
- frame manifest / sheet metadata
- engine-facing texture image data
- simple collision mask / anchor metadata

這讓 Gate 1–6 的 source-blind representation，第一次真正接到 RPG Maker-like runtime consumption path。


## Gate 8：Symbolic Autotile Runtime / Runtime Cache Baseline

Gate 8 新增兩條 runtime 閉環：

$$
S \to A_{16}
$$

與

$$
(S,\theta_R) \to k_{\mathrm{cache}} \to C_R.
$$

其中 $A_{16}$ 是四鄰接 16-state autotile runtime sheet，$C_R$ 是 bounded runtime render cache。

### 目前 API

- `buildSymbolicAutotileRuntimeBundle()`
- `validateSymbolicAutotileRuntimeBundle()`
- `autotileRuntimeBundleToJson()`
- `computeRuntimeRenderCacheKey()`
- `createRuntimeRenderCache()`
- `getOrBuildRuntimeBundleCached()`

### Autotile baseline

以 bit mask：

- North = `1`
- East = `2`
- South = `4`
- West = `8`

建立 $0\ldots15$ 共 16 種鄰接狀態，並排成 4×4 sheet。

### Cache baseline

cache key 由 canonical `AssetSymbol` 與 runtime render options 共同決定，使用 deterministic stable serialization + FNV-1a 32-bit hash。cache 目前採 bounded LRU-like eviction baseline。


## Gate 9：Batch Tileset / Engine-specific Adapter Baseline

Gate 9 新增多資產組裝層：

$$
\{S_1,S_2,\ldots,S_n\}
\to
B_{\mathrm{tileset}}.
$$

目前提供：

- `buildBatchTilesetRuntimeBundle()`
- `validateBatchTilesetRuntimeBundle()`
- `batchTilesetRuntimeBundleToJson()`
- `parseBatchTilesetRuntimeBundleJson()`

Baseline engine profiles：

- `rpgmaker-like-a5`：8 columns / 16 row capacity
- `rpgmaker-like-b-e`：16 columns / 16 row capacity

不同尺寸的 AssetSymbol 會先依 exact / enhanced renderer 生成 frame，再置中到共同 cell，最後以 row-major mapping 組成 batch tileset texture。Gate 8 runtime cache 也可直接被 Gate 9 batch builder 重用。

> 重要：目前的 `A5-like / B–E-like` 是 engine-facing layout profile，不宣稱與 RPG Maker MV/MZ 原生匯入檔案格式逐位元相容。真正 native packaging / profile validation 留給下一關。


## Gate 10：Native Import Packaging / Adapter Hardening Baseline

Gate 10 將 Gate 9 的 generic engine-profile layout 收緊成 RPG Maker MV/MZ native asset-standard baseline：

$$
B_{\mathrm{tileset}} \to P_{\mathrm{native}}.
$$

目前提供：

- `buildRpgMakerNativeImportPackage()`
- `validateRpgMakerNativeImportPackage()`
- `rpgMakerNativeImportPackageToJson()`
- `parseRpgMakerNativeImportPackageJson()`

目前 native profiles：

- A5：$384\times768$，8×16，48×48 tile
- B–E：$768\times768$，16×16，48×48 tile
- B：slot 0 強制保留空白
- `$` single character：3×4 sheet，輸出至 `img/characters`

Tileset assets 採 integer-contain 放入 48×48 native cell；大於 native cell 的 source asset 會明確拒絕，而不是偷偷縮圖破壞像素語義。


## Gate 11：Native Project Binding / Import Helper Baseline

Gate 11 將 Gate 10 native package 再提升成 project-facing binding plan：

$$
P_{\mathrm{native}} \to B_{\mathrm{project}}.
$$

目前提供：

- `buildRpgMakerProjectBindingPlan()`
- `validateRpgMakerProjectBindingPlan()`
- `projectBindingPlanToJson()` / `parseProjectBindingPlanJson()`
- `applyRpgMakerTilesetsPatchPreview()`

Tileset profiles 使用 `Tilesets.json.tilesetNames` 的 native slot mapping：A5→4、B→5、C→6、D→7、E→8。單角色 profile 不修改 Tilesets database，而是輸出 `$CharacterName` resource reference。

Gate 11 明確維持：

- `safeMode = preview-only`
- `mutatesProject = false`
- image copy operation 需要未來顯式 confirmation
- database patch 目前只做 preview

因此它是「真正寫入 RPG Maker project」之前的最後一層安全 manifest。

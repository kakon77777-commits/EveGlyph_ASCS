(function () {
  'use strict';

  const core = window.GenerativeSymbolCompilerCore;
  const $ = (id) => document.getElementById(id);
  const ids = [
    'fileInput','loadDemoBtn','analyzeBtn','subjectModeInput','styleInput','moodBiasInput','detailBiasInput','energyBiasInput','warmthBiasInput','maxSizeInput','compositionBiasInput',
    'moodBiasValue','detailBiasValue','energyBiasValue','warmthBiasValue','maxSizeValue','compositionBiasValue',
    'outputModeInput','exportFormatInput','exportScaleInput','exportDpiInput','exportQualityInput','exportQualityValue','transparentBgInput',
    'bgLayerToggle','subjectLayerToggle','glowLayerToggle','foregroundLayerToggle','panelLayerToggle','semanticSummaryBox',
    'downloadPngBtn','downloadJsonBtn','downloadHtmlBtn','sceneJson','applyJsonBtn','resetJsonBtn','sourceCanvas','outputCanvas','statusBox','featureBox'
  ];
  const el = Object.fromEntries(ids.map((id) => [id, $(id)]));
  const srcCtx = el.sourceCanvas.getContext('2d');
  const outCtx = el.outputCanvas.getContext('2d');

  let config = core.createCompilerConfig();
  let sourceImage = core.createDemoImage(560, 720);
  let sourceDataUrl = null;
  let features = null;
  let scene = null;
  let startMs = performance.now();
  let rafId = null;
  let liveCompileTimer = null;
  let renderBundle = null;
  const outputPrefs = {
    previewMode: 'production-1to1',
    exportFormat: 'png',
    exportScale: 1,
    exportDpi: 300,
    exportQuality: 0.92,
    transparentBackground: false
  };

  function setCanvasSize(canvas, ctx, width, height) {
    canvas.width = width;
    canvas.height = height;
    ctx.clearRect(0, 0, width, height);
  }

  function imageObjectToImageData(obj) { return new ImageData(obj.data, obj.width, obj.height); }
  function drawImageObject(ctx, canvas, imageObj) {
    setCanvasSize(canvas, ctx, imageObj.width, imageObj.height);
    ctx.putImageData(imageObjectToImageData(imageObj), 0, 0);
  }

  function imageObjectToCanvas(imageObj) {
    const canvas = document.createElement('canvas');
    canvas.width = imageObj.width;
    canvas.height = imageObj.height;
    canvas.getContext('2d').putImageData(imageObjectToImageData(imageObj), 0, 0);
    return canvas;
  }

  function materializeRenderBundle(bundle) {
    if (!bundle) return null;
    return {
      mode: bundle.mode,
      width: bundle.width,
      height: bundle.height,
      styledCanvas: imageObjectToCanvas(bundle.styled),
      layers: {
        backgroundCanvas: imageObjectToCanvas(bundle.layers.background),
        subjectCanvas: imageObjectToCanvas(bundle.layers.subject),
        glowCanvas: imageObjectToCanvas(bundle.layers.glow),
        foregroundCanvas: imageObjectToCanvas(bundle.layers.foreground)
      },
      stats: bundle.stats,
      plan: bundle.plan
    };
  }

  function fitOutputCanvasForSource() {
    if (outputPrefs.previewMode === 'production-1to1') {
      setCanvasSize(el.outputCanvas, outCtx, sourceImage.width, sourceImage.height);
      return;
    }
    const panelW = 560;
    const width = Math.max(1500, Math.min(2800, sourceImage.width + panelW + 160));
    const height = Math.max(980, Math.min(2000, sourceImage.height + 180));
    setCanvasSize(el.outputCanvas, outCtx, width, height);
  }

  function updateLabels() {
    el.moodBiasValue.textContent = Number(el.moodBiasInput.value).toFixed(2);
    el.detailBiasValue.textContent = Number(el.detailBiasInput.value).toFixed(2);
    el.energyBiasValue.textContent = Number(el.energyBiasInput.value).toFixed(2);
    el.warmthBiasValue.textContent = Number(el.warmthBiasInput.value).toFixed(2);
    el.maxSizeValue.textContent = String(el.maxSizeInput.value);
    el.compositionBiasValue.textContent = Number(el.compositionBiasInput.value).toFixed(2);
    el.exportQualityValue.textContent = Number(el.exportQualityInput.value).toFixed(2);
  }

  function syncUiFromConfig() {
    el.subjectModeInput.value = config.subjectMode;
    el.styleInput.value = config.targetStyle;
    el.moodBiasInput.value = config.moodBias;
    el.detailBiasInput.value = config.detailBias;
    el.energyBiasInput.value = config.energyBias;
    el.warmthBiasInput.value = config.warmthBias;
    el.maxSizeInput.value = config.maxSize;
    el.compositionBiasInput.value = config.compositionBias;
    updateLabels();
  }

  function syncUiFromOutputPrefs() {
    el.outputModeInput.value = outputPrefs.previewMode;
    el.exportFormatInput.value = outputPrefs.exportFormat;
    el.exportScaleInput.value = String(outputPrefs.exportScale);
    el.exportDpiInput.value = String(outputPrefs.exportDpi);
    el.exportQualityInput.value = outputPrefs.exportQuality;
    el.transparentBgInput.checked = outputPrefs.transparentBackground;
    updateLabels();
  }

  function updateConfigFromUi() {
    config.subjectMode = el.subjectModeInput.value;
    config.targetStyle = el.styleInput.value;
    config.moodBias = parseFloat(el.moodBiasInput.value);
    config.detailBias = parseFloat(el.detailBiasInput.value);
    config.energyBias = parseFloat(el.energyBiasInput.value);
    config.warmthBias = parseFloat(el.warmthBiasInput.value);
    config.maxSize = parseInt(el.maxSizeInput.value, 10);
    config.compositionBias = parseFloat(el.compositionBiasInput.value);
    updateLabels();
  }

  function updateOutputPrefsFromUi() {
    outputPrefs.previewMode = el.outputModeInput.value;
    outputPrefs.exportFormat = el.exportFormatInput.value;
    outputPrefs.exportScale = Math.max(1, parseInt(el.exportScaleInput.value, 10) || 1);
    outputPrefs.exportDpi = Math.max(36, parseInt(el.exportDpiInput.value, 10) || 300);
    outputPrefs.exportQuality = Math.min(1, Math.max(0.1, parseFloat(el.exportQualityInput.value)));
    outputPrefs.transparentBackground = !!el.transparentBgInput.checked;
    updateLabels();
  }

  function refreshSourcePreview() {
    drawImageObject(srcCtx, el.sourceCanvas, sourceImage);
    sourceDataUrl = el.sourceCanvas.toDataURL('image/png');
  }

  function fitImageToConfig(img) {
    const dims = core.resizeDimensions(img.width, img.height, config.maxSize);
    const temp = document.createElement('canvas');
    temp.width = dims.width;
    temp.height = dims.height;
    const tctx = temp.getContext('2d');
    tctx.drawImage(img, 0, 0, dims.width, dims.height);
    const id = tctx.getImageData(0, 0, dims.width, dims.height);
    return { width: dims.width, height: dims.height, data: new Uint8ClampedArray(id.data) };
  }

  function scheduleLiveCompile() {
    if (liveCompileTimer !== null) clearTimeout(liveCompileTimer);
    liveCompileTimer = setTimeout(() => {
      liveCompileTimer = null;
      analyzeAndCompile();
    }, 120);
  }

  function syncLayerTogglesFromScene() {
    const vis = scene && scene.compiler && scene.compiler.layerVisibility ? scene.compiler.layerVisibility : { background: true, subject: true, glow: true, foreground: true, panel: true };
    el.bgLayerToggle.checked = vis.background !== false;
    el.subjectLayerToggle.checked = vis.subject !== false;
    el.glowLayerToggle.checked = vis.glow !== false;
    el.foregroundLayerToggle.checked = vis.foreground !== false;
    el.panelLayerToggle.checked = vis.panel !== false;
  }

  function applyLayerTogglesToScene() {
    if (!scene) return;
    scene.compiler = scene.compiler || {};
    scene.compiler.layerVisibility = {
      background: el.bgLayerToggle.checked,
      subject: el.subjectLayerToggle.checked,
      glow: el.glowLayerToggle.checked,
      foreground: el.foregroundLayerToggle.checked,
      panel: el.panelLayerToggle.checked
    };
  }

  function analyzeAndCompile() {
    updateConfigFromUi();
    updateOutputPrefsFromUi();
    fitOutputCanvasForSource();
    const t0 = performance.now();
    features = core.analyzeImage(sourceImage);
    scene = core.compileScene(features, config, sourceImage);
    renderBundle = materializeRenderBundle(core.buildSemanticRenderBundle(sourceImage, scene));
    const t1 = performance.now();
    startMs = performance.now();
    syncLayerTogglesFromScene();
    el.sceneJson.value = core.sceneToJson(scene);
    el.featureBox.textContent = core.formatFeatures(features);
    updateStatus((t1 - t0).toFixed(2));
    renderNow();
  }

  function estimateExportSizePx() {
    if (outputPrefs.previewMode === 'production-1to1') {
      return {
        width: Math.max(1, Math.round(sourceImage.width * outputPrefs.exportScale)),
        height: Math.max(1, Math.round(sourceImage.height * outputPrefs.exportScale))
      };
    }
    const panelW = 560;
    return {
      width: Math.max(1500, Math.round((sourceImage.width + panelW + 160) * outputPrefs.exportScale)),
      height: Math.max(980, Math.round((sourceImage.height + 180) * outputPrefs.exportScale))
    };
  }

  function formatPrintSize(pxW, pxH, dpi) {
    const wIn = pxW / dpi;
    const hIn = pxH / dpi;
    const wMm = wIn * 25.4;
    const hMm = hIn * 25.4;
    return {
      inches: `${wIn.toFixed(2)} x ${hIn.toFixed(2)} in`,
      mm: `${wMm.toFixed(1)} x ${hMm.toFixed(1)} mm`
    };
  }

  function updateStatus(ms) {
    const subject = scene ? scene.probe.subject : 'n/a';
    const style = scene ? scene.probe.style : config.targetStyle;
    const inferred = features ? core.inferSubject(features, config) : 'n/a';
    const exportPx = estimateExportSizePx();
    const printSize = formatPrintSize(exportPx.width, exportPx.height, outputPrefs.exportDpi);
    el.statusBox.textContent = [
      `targetStyle: ${style}`,
      `subjectMode: ${config.subjectMode}`,
      `compiledSubject: ${subject}`,
      `inferredSubject: ${inferred}`,
      `source: ${sourceImage.width}x${sourceImage.height}`,
      `analysisTimeMs: ${ms || 'n/a'}`,
      `previewMode: ${outputPrefs.previewMode}`,
      `export: ${outputPrefs.exportFormat.toUpperCase()} / ${outputPrefs.exportScale}x / ${outputPrefs.exportDpi} DPI / quality ${outputPrefs.exportQuality.toFixed(2)}`,
      `transparentBG: ${outputPrefs.transparentBackground ? 'yes' : 'no'}`,
      `exportPx: ${exportPx.width}x${exportPx.height}`,
      `printSize: ${printSize.inches} (${printSize.mm})`,
      `mood/detail/energy: ${scene ? `${scene.probe.mood.toFixed(2)} / ${scene.probe.detail.toFixed(2)} / ${scene.probe.energy.toFixed(2)}` : 'n/a'}`,
      `composition: ${scene ? scene.probe.composition.toFixed(2) : 'n/a'}`,
      `reconstruction: ${scene && scene.reconstruction ? `${scene.reconstruction.width}x${scene.reconstruction.height} / ${scene.reconstruction.regions.length} regions / ${scene.reconstruction.palette.length} colors` : 'template fallback'}`,
      `hfRender: ${scene && scene.compiler && scene.compiler.highFidelity ? `${scene.compiler.highFidelity.mode} / ${scene.compiler.highFidelity.sourceWidth}x${scene.compiler.highFidelity.sourceHeight}` : 'disabled'}`,
      `semanticLayers: ${scene && scene.semantic ? scene.semantic.layers.map((layer) => layer.id).join(', ') : 'n/a'}`,
      '',
      'Pipeline:',
      'Image -> Feature Analysis -> Scene Compilation -> Semantic Operator Family -> Production/Presentation Output'
    ].join('\n');

    el.semanticSummaryBox.textContent = (scene && scene.semantic && renderBundle) ? JSON.stringify({
      mode: scene.semantic.mode,
      thresholds: scene.semantic.plan,
      visibility: scene.compiler.layerVisibility,
      coverage: renderBundle.stats,
      output: outputPrefs,
      exportPx,
      printSize
    }, null, 2) : 'No semantic layer bundle yet.';
  }

  function renderNow() {
    if (!scene) return;
    applyLayerTogglesToScene();
    const t = (performance.now() - startMs) / 1000;
    if (outputPrefs.previewMode === 'production-1to1') {
      core.drawProductionOutput(outCtx, scene, el.outputCanvas.width, el.outputCanvas.height, renderBundle, {
        transparentBackground: outputPrefs.transparentBackground
      });
    } else {
      core.drawScene(outCtx, scene, el.outputCanvas.width, el.outputCanvas.height, t, renderBundle);
    }
  }

  function animationLoop() {
    renderNow();
    rafId = requestAnimationFrame(animationLoop);
  }

  function ensureLoop() { if (rafId === null) rafId = requestAnimationFrame(animationLoop); }

  function loadDemo() {
    sourceImage = core.createDemoImage(560, 720);
    refreshSourcePreview();
    analyzeAndCompile();
  }

  function handleFile(file) {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      updateConfigFromUi();
      sourceImage = fitImageToConfig(img);
      refreshSourcePreview();
      analyzeAndCompile();
      URL.revokeObjectURL(url);
    };
    img.src = url;
  }

  function downloadBlob(filename, blob) {
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  }

  function makeCRCTable() {
    const table = new Uint32Array(256);
    for (let n = 0; n < 256; n += 1) {
      let c = n;
      for (let k = 0; k < 8; k += 1) c = ((c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1));
      table[n] = c >>> 0;
    }
    return table;
  }
  const CRC_TABLE = makeCRCTable();
  function crc32(bytes) {
    let c = 0xFFFFFFFF;
    for (let i = 0; i < bytes.length; i += 1) c = CRC_TABLE[(c ^ bytes[i]) & 0xFF] ^ (c >>> 8);
    return (c ^ 0xFFFFFFFF) >>> 0;
  }
  function concatUint8Arrays(arrays) {
    let total = 0;
    arrays.forEach((a) => { total += a.length; });
    const out = new Uint8Array(total);
    let offset = 0;
    arrays.forEach((a) => { out.set(a, offset); offset += a.length; });
    return out;
  }
  function writeUint32BE(view, offset, value) {
    view[offset] = (value >>> 24) & 0xFF;
    view[offset + 1] = (value >>> 16) & 0xFF;
    view[offset + 2] = (value >>> 8) & 0xFF;
    view[offset + 3] = value & 0xFF;
  }
  function createPngChunk(type, data) {
    const typeBytes = new TextEncoder().encode(type);
    const length = new Uint8Array(4);
    writeUint32BE(length, 0, data.length);
    const crcInput = concatUint8Arrays([typeBytes, data]);
    const crcValue = crc32(crcInput);
    const crc = new Uint8Array(4);
    writeUint32BE(crc, 0, crcValue);
    return concatUint8Arrays([length, typeBytes, data, crc]);
  }
  function patchPngDpi(arrayBuffer, dpi) {
    const bytes = new Uint8Array(arrayBuffer);
    const signature = bytes.slice(0, 8);
    const chunks = [];
    let offset = 8;
    const ppm = Math.round(dpi / 0.0254);
    let inserted = false;
    while (offset + 12 <= bytes.length) {
      const length = (bytes[offset] << 24) | (bytes[offset + 1] << 16) | (bytes[offset + 2] << 8) | bytes[offset + 3];
      const type = String.fromCharCode(bytes[offset + 4], bytes[offset + 5], bytes[offset + 6], bytes[offset + 7]);
      const chunk = bytes.slice(offset, offset + 12 + length);
      chunks.push(chunk);
      offset += 12 + length;
      if (type === 'IHDR' && !inserted) {
        const data = new Uint8Array(9);
        writeUint32BE(data, 0, ppm);
        writeUint32BE(data, 4, ppm);
        data[8] = 1;
        chunks.push(createPngChunk('pHYs', data));
        inserted = true;
      }
    }
    return concatUint8Arrays([signature, ...chunks]).buffer;
  }
  function patchJpegDpi(arrayBuffer, dpi) {
    const bytes = new Uint8Array(arrayBuffer);
    if (!(bytes[0] === 0xFF && bytes[1] === 0xD8)) return arrayBuffer;
    let offset = 2;
    while (offset + 4 < bytes.length) {
      if (bytes[offset] !== 0xFF) break;
      const marker = bytes[offset + 1];
      if (marker === 0xDA || marker === 0xD9) break;
      const length = (bytes[offset + 2] << 8) | bytes[offset + 3];
      if (marker === 0xE0 && length >= 16) {
        const isJFIF = bytes[offset + 4] === 0x4A && bytes[offset + 5] === 0x46 && bytes[offset + 6] === 0x49 && bytes[offset + 7] === 0x46 && bytes[offset + 8] === 0x00;
        if (isJFIF) {
          bytes[offset + 11] = 1;
          bytes[offset + 12] = (dpi >>> 8) & 0xFF;
          bytes[offset + 13] = dpi & 0xFF;
          bytes[offset + 14] = (dpi >>> 8) & 0xFF;
          bytes[offset + 15] = dpi & 0xFF;
          return bytes.buffer;
        }
      }
      offset += 2 + length;
    }
    return arrayBuffer;
  }

  function buildExportCanvas() {
    if (!scene) analyzeAndCompile();
    const scale = outputPrefs.exportScale;
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (outputPrefs.previewMode === 'production-1to1') {
      canvas.width = Math.max(1, Math.round(sourceImage.width * scale));
      canvas.height = Math.max(1, Math.round(sourceImage.height * scale));
      core.drawProductionOutput(ctx, scene, canvas.width, canvas.height, renderBundle, {
        transparentBackground: outputPrefs.transparentBackground
      });
    } else {
      const panelW = 560;
      canvas.width = Math.max(1500, Math.round((sourceImage.width + panelW + 160) * scale));
      canvas.height = Math.max(980, Math.round((sourceImage.height + 180) * scale));
      const t = (performance.now() - startMs) / 1000;
      core.drawScene(ctx, scene, canvas.width, canvas.height, t, renderBundle);
    }
    return canvas;
  }

  async function downloadImage() {
    updateOutputPrefsFromUi();
    const exportCanvas = buildExportCanvas();
    const format = outputPrefs.exportFormat;
    const mime = format === 'jpeg' ? 'image/jpeg' : format === 'webp' ? 'image/webp' : 'image/png';
    const ext = format === 'jpeg' ? 'jpg' : format;
    const blob = await new Promise((resolve) => exportCanvas.toBlob(resolve, mime, outputPrefs.exportQuality));
    if (!blob) return;
    if (format === 'png' || format === 'jpeg') {
      let buffer = await blob.arrayBuffer();
      if (format === 'png') buffer = patchPngDpi(buffer, outputPrefs.exportDpi);
      if (format === 'jpeg') buffer = patchJpegDpi(buffer, outputPrefs.exportDpi);
      downloadBlob(`generative-symbol-output-${outputPrefs.exportDpi}dpi.${ext}`, new Blob([buffer], { type: mime }));
      return;
    }
    downloadBlob(`generative-symbol-output-${outputPrefs.exportDpi}dpi.${ext}`, blob);
  }

  function downloadJson() {
    if (!scene) analyzeAndCompile();
    downloadBlob('generative-symbol-scene.json', new Blob([core.sceneToJson(scene)], { type: 'application/json;charset=utf-8' }));
  }

  function downloadHtml() {
    if (!scene) analyzeAndCompile();
    const html = core.buildStandaloneHtml(scene, sourceDataUrl || el.sourceCanvas.toDataURL('image/png'));
    downloadBlob('generative-symbol-compiler-preview.html', new Blob([html], { type: 'text/html;charset=utf-8' }));
  }

  function applySceneJson() {
    try {
      scene = core.parseSceneJson(el.sceneJson.value);
      renderBundle = materializeRenderBundle(core.buildSemanticRenderBundle(sourceImage, scene));
      updateOutputPrefsFromUi();
      fitOutputCanvasForSource();
      syncLayerTogglesFromScene();
      startMs = performance.now();
      updateStatus('manual');
      renderNow();
    } catch (error) {
      alert(`Scene JSON error: ${error.message}`);
    }
  }

  function resetSceneJson() {
    if (scene) el.sceneJson.value = core.sceneToJson(scene);
  }

  el.fileInput.addEventListener('change', (event) => {
    const file = event.target.files && event.target.files[0];
    if (file) handleFile(file);
  });
  el.loadDemoBtn.addEventListener('click', loadDemo);
  el.analyzeBtn.addEventListener('click', analyzeAndCompile);
  el.downloadPngBtn.addEventListener('click', () => { downloadImage().catch((err) => alert(`Export error: ${err.message}`)); });
  el.downloadJsonBtn.addEventListener('click', downloadJson);
  el.downloadHtmlBtn.addEventListener('click', downloadHtml);
  el.applyJsonBtn.addEventListener('click', applySceneJson);
  el.resetJsonBtn.addEventListener('click', resetSceneJson);
  [
    'subjectModeInput','styleInput','moodBiasInput','detailBiasInput','energyBiasInput','warmthBiasInput','maxSizeInput','compositionBiasInput'
  ].forEach((id) => {
    const node = el[id];
    const handler = () => {
      updateConfigFromUi();
      scheduleLiveCompile();
    };
    node.addEventListener('input', handler);
    node.addEventListener('change', handler);
  });
  ['outputModeInput','exportFormatInput','exportScaleInput','exportDpiInput','exportQualityInput','transparentBgInput'].forEach((id) => {
    const node = el[id];
    const handler = () => {
      updateOutputPrefsFromUi();
      fitOutputCanvasForSource();
      updateStatus('output-change');
      renderNow();
    };
    node.addEventListener('input', handler);
    node.addEventListener('change', handler);
  });
  ['bgLayerToggle','subjectLayerToggle','glowLayerToggle','foregroundLayerToggle','panelLayerToggle'].forEach((id) => {
    el[id].addEventListener('change', () => {
      if (!scene) return;
      applyLayerTogglesToScene();
      el.sceneJson.value = core.sceneToJson(scene);
      updateStatus('live-layer');
      renderNow();
    });
  });

  syncUiFromConfig();
  syncUiFromOutputPrefs();
  refreshSourcePreview();
  analyzeAndCompile();
  ensureLoop();
})();

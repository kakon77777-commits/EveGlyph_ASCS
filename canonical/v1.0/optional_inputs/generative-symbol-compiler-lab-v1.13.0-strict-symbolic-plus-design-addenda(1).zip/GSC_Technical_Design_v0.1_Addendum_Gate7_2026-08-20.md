# GSC Technical Design v0.1 — Addendum: Gate 7 RPG Maker Visual Runtime Baseline

本附錄記錄 Gate 7 已落地的 implementation baseline。

## 核心命題

Gate 7 引入：

$$
S \to B_R,
$$

其中：

- $S$ 是 canonical AssetSymbol
- $B_R$ 是 engine-facing runtime bundle

## 目前已實作 API

- `buildRpgMakerRuntimeBundle()`
- `validateRpgMakerRuntimeBundle()`
- `runtimeBundleToJson()`
- `parseRuntimeBundleJson()`

## 基本能力

- tile bundle 導出
- character 3×4 sheet 導出
- frame manifest / sheet metadata
- collision mask
- anchor metadata
- source-blind runtime texture generation

## 與 Gate 6 的關係

- Gate 6 提供 exact / enhanced renderer
- Gate 7 直接消費 Gate 1–6 產生的 canonical AssetSymbol
- runtime bundle 不是新的 canonical source，而是 consumer layer artifact

## 已完成狀態

- runtime bundle 已可從 AssetSymbol 建立
- runtime bundle 已可從 AssetSymbol JSON 建立
- strict local UI 已新增 runtime export control
- regression tests 已覆蓋 tile / character / mode difference / round-trip / UI controls

## 下一步

建議進入 Gate 8：

- symbolic autotile runtime
- runtime render cache
- engine-specific adapter refinement

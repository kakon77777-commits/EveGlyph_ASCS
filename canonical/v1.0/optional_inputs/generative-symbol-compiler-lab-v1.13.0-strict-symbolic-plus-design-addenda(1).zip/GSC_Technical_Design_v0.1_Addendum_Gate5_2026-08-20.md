# GSC Technical Design v0.1 — Addendum: Gate 5 Part Grammar Baseline

本附錄記錄 Gate 5 已落地的 implementation baseline。

## 新增命題

在 Gate 4C 之後，我們已經有 structural skeleton graph：

$$
K \to G_K=(V_K,E_K).
$$

Gate 5 再進一步要求：

$$
(\text{region},\text{topology},\text{medial},G_K) \to P,
$$

其中 $P$ 是保守的 part token，而不是過度聲稱的完整高語義語法。

## 資料模型

每個 non-transparent / transparent region 現在都可帶有 `partGrammar`，最小欄位包含：

- `primitive`
- `orientation`
- `role`
- `symmetryClass`
- `attachments`
- `adjacencyDegree`

asset-level 則新增：

- `partGrammar.grammarVersion`
- `partGrammar.partCount`
- `partGrammar.countsByPrimitive`
- `partGrammar.countsByRole`
- `partGrammar.primaryPartIds`
- `partGrammar.parts`

## 已完成狀態

- `extractStrictPartGrammar()` 已實作
- strict asset 預設版本升至 `v0.7`
- validator 已支援 region-level / asset-level part grammar metadata
- UI / JSON-only log 已顯示 part grammar summary
- regression tests 已覆蓋 API exposure、bar/ring/junction classification、asset summary、UI summary

## 意義

這一層把 topology / contour / skeleton graph 結果抬升成 part-level token，使後續 enhanced re-render 與更高層 sprite / tile grammar 可以直接消費穩定的 canonical 結構，而不是每次回退到 pixel 或 raw skeleton 掃描。

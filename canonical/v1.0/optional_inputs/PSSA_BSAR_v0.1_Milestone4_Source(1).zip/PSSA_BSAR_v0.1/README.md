# PSSA-BSAR v0.1

Harness for **Blind Semantic Address Recovery**, the first experiment in the Pre-Symbolic Semantic Addressing (PSSA) research line.

## Evidence boundary

Two execution modes exist:

- **Milestone 1 deterministic mock** — validates dataset/build/freeze/recover/score plumbing only. Evidence status: `MOCK_PLUMBING_ONLY`.
- **Milestone 2 live protocol** — validates adapter isolation, strict output contracts, interaction ledgers, failure capture, and replay. Evidence status: `LIVE_PROTOCOL_ONLY_NOT_SCIENTIFIC`.
- **Milestone 3 Dataset v0.2** — adds opaque target IDs, hidden family/category metadata, canonical-identifier leakage checks, independent holdout paraphrases, adversarial near-neighbors, deterministic dataset hashing, and a versioned audit manifest. Passing the dataset audit does **not** by itself make mock or fixture-model scores scientific evidence.

Neither mode is evidence that a biological or model-internal pre-linguistic addressing layer exists.

## Install locally

```bash
python -m pip install -e . --no-build-isolation
```

No runtime dependencies are required beyond Python 3.11+.

## Run tests

```bash
pytest -q
```

## Milestone 1: deterministic mock

```bash
python -m pssa_bsar.cli run-mock \
  --output runs/mock \
  --seed 20260821 \
  --budget-bytes 900
```

## Milestone 3: leakage-audited Dataset v0.2

Audit the dataset before a model run:

```bash
python -m pssa_bsar.cli audit-dataset \
  --dataset-version v0.2 \
  --output runs/dataset-v02-audit \
  --seed 20260821
```

Run the deterministic harness against the audited surface:

```bash
python -m pssa_bsar.cli run-mock \
  --dataset-version v0.2 \
  --output runs/mock-v02 \
  --seed 20260821 \
  --budget-bytes 900
```

Dataset v0.2 preregistered audit checks include:

- opaque target IDs (`bsar2-NNN`);
- no builder-visible family/category label;
- no verbatim canonical anchor/constraint/relation-node/open-variable identifiers;
- no exact cross-split sentence reuse;
- maximum development↔evaluation bigram Jaccard of `0.30`;
- each adversarial negative must share at least one positive surface cue.

A v0.2 run emits `dataset_manifest.json`. Live v0.2 runs also emit the frozen hidden `targets.jsonl` and builder-visible `observations.jsonl` as reproducibility artifacts; these files are never inserted into recovery prompts.

## Milestone 2: external model command

The core harness is provider-agnostic. It launches an external command once per isolated builder/recovery request.

```bash
python -m pssa_bsar.cli run-live-command \
  --command-json '["python","my_model_wrapper.py"]' \
  --output runs/live \
  --seed 20260821 \
  --budget-bytes 900 \
  --timeout-seconds 120 \
  --dataset-version v0.2
```

### Adapter stdin contract

The wrapper receives one JSON object on stdin:

```json
{
  "request_id": "b:identity_continuity-00:address_first",
  "stage": "builder",
  "target_id": "identity_continuity-00",
  "condition": "address_first",
  "prompt": "...",
  "metadata": {"budget_bytes": 900}
}
```

### Adapter stdout contract

The wrapper must emit exactly one JSON object:

```json
{
  "request_id": "b:identity_continuity-00:address_first",
  "text": "{\"positive_anchors\":[...]}",
  "provider": "your-provider",
  "model": "your-model",
  "metadata": {}
}
```

`text` is the model's raw textual response. BSAR then applies its own strict condition-specific parser. Invalid JSON, invalid schema, request-ID mismatch, timeout, nonzero exit, or representation-budget overflow becomes an explicit failure record; output is never silently repaired or truncated.

## Replay a recorded run

```bash
python -m pssa_bsar.cli run-replay \
  --ledger runs/live/requests.jsonl \
  --output runs/replay \
  --seed 20260821 \
  --budget-bytes 900 \
  --dataset-version v0.2
```

Replay verifies each request's prompt SHA-256 before returning its recorded response. Prompt drift therefore cannot silently reuse stale responses.

## Live-protocol artifacts

- `requests.jsonl` — canonical interaction ledger containing prompts, hashes, raw responses, parse status, provider/model, and explicit errors;
- `frozen_representations.jsonl` — successfully parsed builder representations only;
- `recoveries.jsonl` — successfully parsed recovery outputs only;
- `failures.jsonl` — adapter/parser/budget failures as first-class records;
- `metrics.csv` — per-successful-recovery metric vectors;
- `summary.json` — aggregate counts and condition means;
- `REPORT.md` — human-readable protocol report.

## Isolation rule

Builder and recovery are separate requests with different request IDs. Recovery receives only:

1. the frozen representation;
2. public holdout/adversarial case descriptions with `label = null`.

It does not receive hidden target fields, development-case gold labels, builder chain-of-thought, or prior conversation state from the harness.

## Conditions

1. `definition_first`
2. `keyword_first`
3. `address_first`

## Milestone 4: preregistered controlled Gate 1

Milestone 4 separates **planning** from **execution**. First freeze the experiment:

```bash
python -m pssa_bsar.cli plan-controlled-run \
  --output runs/gate1-plan \
  --dataset-seed 20260821 \
  --schedule-seed 424242 \
  --trials-per-target 5 \
  --budget-bytes 900 \
  --expected-provider your-provider \
  --expected-model your-model-version \
  --sampling-json '{"temperature":0.0,"top_p":1.0,"seed_mode":"paired_trial"}' \
  --analysis-seed 777
```

This writes a hash-validated `control_manifest.json` containing the audited dataset SHA-256, model identity, sampling policy, success thresholds, trial count, trial seeds, and the full deterministic schedule. All six condition permutations are balanced across `(target, trial)` blocks to within one block.

Then execute **only** from that frozen manifest:

```bash
python -m pssa_bsar.cli run-controlled-live-command \
  --manifest runs/gate1-plan/control_manifest.json \
  --command-json '["python","my_model_wrapper.py"]' \
  --output runs/gate1-live \
  --timeout-seconds 120
```

Replay uses the same manifest:

```bash
python -m pssa_bsar.cli run-controlled-replay \
  --manifest runs/gate1-plan/control_manifest.json \
  --ledger runs/gate1-live/requests.jsonl \
  --output runs/gate1-replay
```

Every controlled request records:

- `control_manifest_sha256`;
- `schedule_sha256`;
- `trial_id`, `trial_index`, and paired `trial_seed`;
- condition position within the randomized/balanced block;
- the frozen sampling policy and expected provider/model.

A provider/model mismatch is a first-class failure and is never scored as a valid trial.

### Paired analysis

Milestone 4 emits:

- `trial_metrics.csv`;
- `paired_trial_differences.csv`;
- `paired_target_means.csv`;
- `paired_analysis.json`;
- `gate1_evaluation.json`.

The two preregistered contrasts are:

1. `address_first - definition_first`;
2. `address_first - keyword_first`.

Repeated trials are **not** treated as independent observations. The harness first averages paired deltas within each target and then performs target-level summaries and deterministic bootstrap confidence intervals across targets. This avoids inflating the apparent sample size from repeated trials.

`gate1_evaluation.json` applies the original experiment criteria, but it deliberately leaves the preregistered manual leakage review as `NOT_EVALUATED`; automatic Dataset v0.2 audit is not silently substituted for manual review.

## Next scientific milestone

The harness is now ready for the first genuinely controlled **real-model Gate 1** run. A fixture or replay result remains protocol evidence only; scientific interpretation requires validating the external wrapper, exact model/version, sampling behavior, and execution environment.

After Gate 1, the next conceptual benchmark remains **Address Error vs Projection Error**.

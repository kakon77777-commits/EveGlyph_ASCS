import json
from pathlib import Path

from pssa_bsar.adapters import ModelRequest, ModelResponse
from pssa_bsar.builders import build_address, build_definition, build_keywords
from pssa_bsar.dataset import generate_targets, make_observation
from pssa_bsar.live_pipeline import run_live_protocol
from pssa_bsar.models import Case, FrozenRepresentation
from pssa_bsar.recovery import recover


BUILDERS = {
    'definition_first': build_definition,
    'keyword_first': build_keywords,
    'address_first': build_address,
}


class DeterministicProtocolAdapter:
    def __init__(self, seed=20260821, malformed_request_id=None):
        self.observations = {t.target_id: make_observation(t) for t in generate_targets(seed=seed)}
        self.requests = []
        self.malformed_request_id = malformed_request_id

    def generate(self, request: ModelRequest) -> ModelResponse:
        self.requests.append(request)
        if request.request_id == self.malformed_request_id:
            return ModelResponse(request.request_id, '{bad json', 'fixture', 'protocol-v1', {})
        if request.stage == 'builder':
            obs = self.observations[request.target_id]
            budget = int(request.metadata['budget_bytes'])
            rep = BUILDERS[request.condition](obs, budget_bytes=budget)
            if request.condition == 'definition_first':
                text = json.dumps({'definition': rep.payload})
            elif request.condition == 'keyword_first':
                text = json.dumps({'keywords': rep.payload})
            else:
                text = json.dumps(rep.payload)
            return ModelResponse(request.request_id, text, 'fixture', 'protocol-v1', {})
        if request.stage == 'recovery':
            frozen_text = request.prompt.split('FROZEN REPRESENTATION\n', 1)[1].split('\n\nPUBLIC EVALUATION CASES\n', 1)[0]
            cases_text = request.prompt.split('PUBLIC EVALUATION CASES\n', 1)[1].split('\n\nOUTPUT CONTRACT\n', 1)[0]
            rep = FrozenRepresentation.from_dict(json.loads(frozen_text))
            cases = [Case.from_dict(x) for x in json.loads(cases_text)]
            result = recover(rep, cases)
            payload = result.to_dict()
            payload.pop('target_id')
            payload.pop('condition')
            return ModelResponse(request.request_id, json.dumps(payload), 'fixture', 'protocol-v1', {})
        raise AssertionError(request.stage)


def test_live_protocol_runs_isolated_builder_and_recovery_requests(tmp_path: Path):
    adapter = DeterministicProtocolAdapter()
    summary = run_live_protocol(tmp_path, adapter, seed=20260821, budget_bytes=900)
    required = {
        'requests.jsonl', 'frozen_representations.jsonl', 'recoveries.jsonl',
        'failures.jsonl', 'metrics.csv', 'summary.json', 'REPORT.md',
    }
    assert required <= {p.name for p in tmp_path.iterdir()}
    assert summary['evidence_status'] == 'LIVE_PROTOCOL_ONLY_NOT_SCIENTIFIC'
    assert summary['target_count'] == 30
    assert summary['builder_success_count'] == 90
    assert summary['recovery_success_count'] == 90
    assert len(adapter.requests) == 180
    assert len({r.request_id for r in adapter.requests}) == 180
    assert sum(r.stage == 'builder' for r in adapter.requests) == 90
    assert sum(r.stage == 'recovery' for r in adapter.requests) == 90

    for req in adapter.requests:
        if req.stage == 'recovery':
            assert '"development_cases"' not in req.prompt
            assert '"holdout_cases"' not in req.prompt
            assert '"adversarial_cases"' not in req.prompt
            assert '"label": true' not in req.prompt.lower()
            assert '"label": false' not in req.prompt.lower()


def test_live_protocol_records_builder_parse_failure_and_continues(tmp_path: Path):
    bad_id = 'b:identity_continuity-01:address_first'
    adapter = DeterministicProtocolAdapter(malformed_request_id=bad_id)
    summary = run_live_protocol(tmp_path, adapter, seed=20260821, budget_bytes=900)
    failures = [json.loads(x) for x in (tmp_path / 'failures.jsonl').read_text().splitlines() if x.strip()]
    assert summary['builder_failure_count'] == 1
    assert summary['builder_success_count'] == 89
    assert summary['recovery_success_count'] == 89
    assert any(row['request_id'] == bad_id and row['error_type'] == 'invalid_json' for row in failures)

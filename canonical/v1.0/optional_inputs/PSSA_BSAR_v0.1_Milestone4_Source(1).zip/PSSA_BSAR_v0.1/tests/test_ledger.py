from pathlib import Path

from pssa_bsar.ledger import InteractionRecord, RunLedger


def record(seq=0, status='ok', error_type=''):
    return InteractionRecord(
        sequence=seq,
        request_id=f'r{seq}',
        stage='builder',
        target_id='t1',
        condition='address_first',
        prompt_sha256='abc',
        prompt_bytes=12,
        raw_response='{}',
        response_bytes=2,
        status=status,
        error_type=error_type,
        error_message='bad' if error_type else '',
        provider='fixture',
        model='m1',
        timestamp_utc=None,
        request={'request_id': f'r{seq}'},
        response={'request_id': f'r{seq}', 'text': '{}'} if status == 'ok' else None,
    )


def test_ledger_round_trip_is_canonical(tmp_path: Path):
    ledger = RunLedger([record(0), record(1)])
    a = tmp_path / 'a.jsonl'
    b = tmp_path / 'b.jsonl'
    ledger.write_jsonl(a)
    loaded = RunLedger.from_jsonl(a)
    loaded.write_jsonl(b)
    assert loaded.records == ledger.records
    assert a.read_bytes() == b.read_bytes()


def test_failure_record_preserves_error_without_response():
    item = record(0, status='failed', error_type='schema')
    assert item.response is None
    assert item.error_type == 'schema'
    assert item.error_message == 'bad'

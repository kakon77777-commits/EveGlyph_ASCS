from pssa_bsar.models import (
    Case,
    FrozenRepresentation,
    GroundTruthTarget,
    MetricVector,
    ObservationBundle,
    RecoveryResult,
    Relation,
)


def test_relation_round_trip():
    relation = Relation("continuity", "supports", "responsibility", 1, 0.9)
    assert Relation.from_dict(relation.to_dict()) == relation


def test_ground_truth_target_round_trip_preserves_nested_types():
    relation = Relation("continuity", "supports", "responsibility", 1, 0.9)
    case = Case("h1", "continuity provenance", True, "holdout")
    target = GroundTruthTarget(
        target_id="identity-00",
        family="identity_continuity",
        positive_anchors=("continuity", "provenance"),
        negative_anchors=("visual_similarity",),
        relations=(relation,),
        constraints=("preserve_history",),
        open_variables=("continuity_threshold",),
        candidate_categories=("identity",),
        development_cases=(Case("d1", "continuity provenance", True, "development"),),
        holdout_cases=(case,),
        adversarial_cases=(Case("a1", "visual_similarity continuity", False, "adversarial"),),
    )
    assert GroundTruthTarget.from_dict(target.to_dict()) == target


def test_other_persisted_records_round_trip():
    obs = ObservationBundle(
        target_id="t1",
        family="identity_continuity",
        positive_examples=("continuity provenance",),
        negative_examples=("visual_similarity mere_copy",),
        minimal_contrasts=(("continuity", "mere_copy"),),
        unresolved_ambiguity="continuity_threshold",
        misleading_neighbor="visual_similarity",
        relation_probe="continuity supports responsibility",
        candidate_categories=("identity",),
    )
    frozen = FrozenRepresentation("t1", "address_first", {"positive_anchors": ["continuity"]}, 42, 3)
    recovery = RecoveryResult(
        "t1",
        "address_first",
        ("continuity",),
        ("visual_similarity",),
        (Relation("continuity", "supports", "responsibility", 1, 0.9),),
        ("preserve_history",),
        ("continuity_threshold",),
        {"h1": True},
        {"a1": False},
        "rendering",
    )
    metric = MetricVector("t1", "address_first", 1.0, 1.0, 1.0, 1.0, 1.0, 42, 1.0, 0.25)
    assert ObservationBundle.from_dict(obs.to_dict()) == obs
    assert FrozenRepresentation.from_dict(frozen.to_dict()) == frozen
    assert RecoveryResult.from_dict(recovery.to_dict()) == recovery
    assert MetricVector.from_dict(metric.to_dict()) == metric

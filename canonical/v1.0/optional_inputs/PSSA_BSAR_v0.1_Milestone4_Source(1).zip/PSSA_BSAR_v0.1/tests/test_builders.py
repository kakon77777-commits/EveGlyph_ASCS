from pssa_bsar.builders import build_address, build_definition, build_keywords
from pssa_bsar.dataset import generate_targets, make_observation
from pssa_bsar.freezer import freeze_representation, load_frozen


def _obs():
    return make_observation(generate_targets(17)[0])


def test_builders_are_deterministic_and_respect_budget():
    obs = _obs()
    builders = (build_definition, build_keywords, build_address)
    for builder in builders:
        a = builder(obs, budget_bytes=900)
        b = builder(obs, budget_bytes=900)
        assert a == b
        assert a.utf8_bytes <= 900
        assert a.utf8_bytes > 0


def test_address_builder_uses_fixed_typed_schema_without_name_or_definition():
    rep = build_address(_obs(), budget_bytes=900)
    assert rep.condition == "address_first"
    assert isinstance(rep.payload, dict)
    assert set(rep.payload) == {
        "positive_anchors",
        "negative_anchors",
        "relations",
        "constraints",
        "open_variables",
        "candidate_categories",
        "confidence",
    }
    assert "concept_name" not in rep.payload
    assert "definition" not in rep.payload
    assert rep.payload["relations"]
    assert isinstance(rep.payload["relations"][0], dict)


def test_definition_and_keyword_shapes_are_distinct():
    obs = _obs()
    definition = build_definition(obs, 900)
    keywords = build_keywords(obs, 900)
    assert definition.condition == "definition_first"
    assert isinstance(definition.payload, str)
    assert keywords.condition == "keyword_first"
    assert isinstance(keywords.payload, list)
    assert all(isinstance(x, str) for x in keywords.payload)


def test_freeze_load_round_trip(tmp_path):
    rep = build_address(_obs(), budget_bytes=900)
    path = tmp_path / "frozen.json"
    freeze_representation(rep, path)
    assert load_frozen(path) == rep

import json
from pathlib import Path

from pssa_bsar.cli import main

FIXTURE = Path(__file__).parent / "fixtures" / "adapter_protocol.sh"


def test_cli_run_mock_accepts_dataset_v02(tmp_path: Path):
    out = tmp_path / "mock-v02"
    assert main([
        "run-mock", "--output", str(out), "--seed", "77", "--budget-bytes", "900",
        "--dataset-version", "v0.2",
    ]) == 0
    summary = json.loads((out / "summary.json").read_text(encoding="utf-8"))
    assert summary["dataset_version"] == "v0.2"
    assert (out / "dataset_manifest.json").exists()


def test_cli_audit_dataset_writes_manifest_targets_and_observations(tmp_path: Path):
    out = tmp_path / "audit"
    assert main([
        "audit-dataset", "--output", str(out), "--seed", "20260821",
        "--dataset-version", "v0.2",
    ]) == 0
    manifest = json.loads((out / "dataset_manifest.json").read_text(encoding="utf-8"))
    assert manifest["pass_count"] == 30
    assert manifest["fail_count"] == 0
    assert (out / "targets.jsonl").exists()
    assert (out / "observations.jsonl").exists()


def test_cli_live_v02_then_replay_v02_are_byte_identical(tmp_path: Path):
    live = tmp_path / "live"
    replay = tmp_path / "replay"
    command = json.dumps(["/bin/sh", str(FIXTURE)])
    assert main([
        "run-live-command", "--command-json", command, "--output", str(live),
        "--seed", "20260821", "--budget-bytes", "900", "--timeout-seconds", "5",
        "--dataset-version", "v0.2",
    ]) == 0
    assert main([
        "run-replay", "--ledger", str(live / "requests.jsonl"), "--output", str(replay),
        "--seed", "20260821", "--budget-bytes", "900", "--dataset-version", "v0.2",
    ]) == 0
    for name in (
        "dataset_manifest.json", "summary.json", "metrics.csv", "frozen_representations.jsonl",
        "recoveries.jsonl", "requests.jsonl",
    ):
        assert (live / name).read_bytes() == (replay / name).read_bytes()


def test_cli_run_mock_v02_prints_summary_evidence_status(tmp_path: Path, capsys):
    out = tmp_path / "mock-v02-status"
    assert main([
        "run-mock", "--output", str(out), "--dataset-version", "v0.2",
        "--seed", "9", "--budget-bytes", "900",
    ]) == 0
    stdout = capsys.readouterr().out
    assert "Evidence status: MOCK_AUDITED_DATASET_NOT_SCIENTIFIC" in stdout
    assert "Evidence status: MOCK_PLUMBING_ONLY" not in stdout

from pssa_bsar.adapters import ModelRequest, ModelResponse, ReplayAdapter, prompt_sha256


def test_model_request_response_round_trip_and_hash():
    req = ModelRequest(
        request_id='r1', stage='builder', target_id='t1', condition='address_first',
        prompt='hello', metadata={'budget_bytes': 900},
    )
    resp = ModelResponse(
        request_id='r1', text='{"ok":true}', provider='replay', model='fixture', metadata={'x': 1},
    )
    assert ModelRequest.from_dict(req.to_dict()) == req
    assert ModelResponse.from_dict(resp.to_dict()) == resp
    assert prompt_sha256('hello') == prompt_sha256('hello')
    assert prompt_sha256('hello') != prompt_sha256('hello!')


def test_replay_adapter_returns_matching_response():
    response = ModelResponse('r1', 'answer', 'recorded', 'fixture', {})
    adapter = ReplayAdapter({'r1': response})
    request = ModelRequest('r1', 'builder', 't1', 'definition_first', 'prompt', {})
    assert adapter.generate(request) == response

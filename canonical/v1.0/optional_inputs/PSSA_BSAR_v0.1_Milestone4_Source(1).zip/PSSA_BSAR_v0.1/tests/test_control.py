from __future__ import annotations

import json
from collections import Counter

import pytest

from pssa_bsar.control import (
    CONDITIONS,
    build_control_manifest,
    load_control_manifest,
    write_control_manifest,
)
from pssa_bsar.datasets import load_dataset


def _manifest(trials: int = 5):
    targets, _, dataset_manifest = load_dataset("v0.2", seed=20260821, count=30)
    assert dataset_manifest is not None
    return build_control_manifest(
        targets=targets,
        dataset_manifest=dataset_manifest,
        dataset_seed=20260821,
        schedule_seed=424242,
        trials_per_target=trials,
        budget_bytes=900,
        expected_provider="fixture-provider",
        expected_model="fixture-model-v1",
        sampling_policy={"temperature": 0.0, "top_p": 1.0, "seed_mode": "paired_trial"},
        analysis_seed=777,
        success_thresholds={
            "hda_noninferiority_margin": 0.05,
            "ana_min_delta": 0.0,
            "meaningful_structural_delta": 0.05,
        },
    )


def test_manifest_is_deterministic_and_bound_to_dataset_and_model():
    first = _manifest()
    second = _manifest()
    assert first.to_dict() == second.to_dict()
    assert first.dataset_version == "v0.2"
    assert len(first.dataset_sha256) == 64
    assert first.expected_provider == "fixture-provider"
    assert first.expected_model == "fixture-model-v1"
    assert first.sampling_policy["temperature"] == 0.0
    assert len(first.schedule_sha256) == 64
    assert len(first.manifest_sha256) == 64


def test_schedule_covers_every_target_trial_and_balances_permutations():
    manifest = _manifest(trials=5)
    assert len(manifest.schedule) == 30 * 5
    keys = {(item.target_id, item.trial_index) for item in manifest.schedule}
    assert len(keys) == 150
    assert all(set(item.conditions) == set(CONDITIONS) for item in manifest.schedule)

    permutation_counts = Counter(item.conditions for item in manifest.schedule)
    assert len(permutation_counts) == 6
    assert max(permutation_counts.values()) - min(permutation_counts.values()) <= 1

    for position in range(3):
        position_counts = Counter(item.conditions[position] for item in manifest.schedule)
        assert max(position_counts.values()) - min(position_counts.values()) <= 1


def test_trial_seed_is_shared_across_conditions_and_stable():
    manifest = _manifest(trials=3)
    first_item = manifest.schedule[0]
    assert isinstance(first_item.trial_seed, int)
    assert 0 <= first_item.trial_seed <= 2**32 - 1
    rebuilt = _manifest(trials=3)
    assert [x.to_dict() for x in manifest.schedule] == [x.to_dict() for x in rebuilt.schedule]


def test_write_and_load_validate_manifest_and_schedule_hashes(tmp_path):
    path = tmp_path / "control_manifest.json"
    manifest = _manifest(trials=2)
    write_control_manifest(path, manifest)
    loaded = load_control_manifest(path)
    assert loaded.to_dict() == manifest.to_dict()

    data = json.loads(path.read_text(encoding="utf-8"))
    data["schedule"][0]["conditions"] = list(reversed(data["schedule"][0]["conditions"]))
    path.write_text(json.dumps(data), encoding="utf-8")
    with pytest.raises(ValueError, match="schedule hash mismatch"):
        load_control_manifest(path)


def test_manifest_rejects_non_audited_dataset_and_invalid_model_identity():
    targets, _, _ = load_dataset("v0.2", seed=20260821, count=30)
    with pytest.raises(ValueError, match="v0.2"):
        build_control_manifest(
            targets=targets,
            dataset_manifest={"dataset_version": "v0.1", "fail_count": 0, "dataset_sha256": "x" * 64},
            dataset_seed=1,
            schedule_seed=2,
            trials_per_target=1,
            budget_bytes=900,
            expected_provider="fixture-provider",
            expected_model="fixture-model-v1",
            sampling_policy={},
            analysis_seed=3,
            success_thresholds={},
        )

    _, _, dataset_manifest = load_dataset("v0.2", seed=20260821, count=30)
    assert dataset_manifest is not None
    with pytest.raises(ValueError, match="expected_model"):
        build_control_manifest(
            targets=targets,
            dataset_manifest=dataset_manifest,
            dataset_seed=1,
            schedule_seed=2,
            trials_per_target=1,
            budget_bytes=900,
            expected_provider="fixture-provider",
            expected_model="",
            sampling_policy={},
            analysis_seed=3,
            success_thresholds={},
        )

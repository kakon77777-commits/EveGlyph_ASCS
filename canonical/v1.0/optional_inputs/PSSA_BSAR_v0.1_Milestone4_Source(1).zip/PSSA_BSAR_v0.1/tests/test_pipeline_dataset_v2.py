from pathlib import Path

from pssa_bsar.pipeline import run_mock_experiment


def _file_bytes(directory: Path) -> dict[str, bytes]:
    return {p.name: p.read_bytes() for p in directory.iterdir() if p.is_file()}


def test_explicit_v01_is_byte_identical_to_default(tmp_path: Path):
    default = tmp_path / "default"
    explicit = tmp_path / "explicit"
    run_mock_experiment(default, seed=123, budget_bytes=900)
    run_mock_experiment(explicit, seed=123, budget_bytes=900, dataset_version="v0.1")
    assert _file_bytes(default) == _file_bytes(explicit)


def test_mock_pipeline_v02_emits_audited_dataset_manifest(tmp_path: Path):
    out = tmp_path / "v02"
    summary = run_mock_experiment(out, seed=20260821, budget_bytes=900, dataset_version="v0.2")
    assert summary["dataset_version"] == "v0.2"
    assert summary["dataset_audit_pass_count"] == 30
    assert summary["dataset_audit_fail_count"] == 0
    assert summary["evidence_status"] == "MOCK_AUDITED_DATASET_NOT_SCIENTIFIC"
    assert (out / "dataset_manifest.json").exists()
    assert (out / "targets.jsonl").exists()
    assert (out / "observations.jsonl").exists()
    report = (out / "REPORT.md").read_text(encoding="utf-8")
    assert "leakage-audited" in report.lower()
    assert "not scientific evidence" in report.lower()

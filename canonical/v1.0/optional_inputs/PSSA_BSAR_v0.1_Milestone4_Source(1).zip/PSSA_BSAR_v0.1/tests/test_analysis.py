from __future__ import annotations

import csv
import json
from pathlib import Path

from pssa_bsar.analysis import analyze_trial_metrics
from pssa_bsar.control import build_control_manifest
from pssa_bsar.datasets import load_dataset


METRIC_VALUES = {
    "hda": 0.7,
    "ana": 0.6,
    "relation_f1": 0.5,
    "constraint_f1": 0.5,
    "ups": 0.5,
    "representation_bytes": 400.0,
    "composite": 0.56,
    "efficiency": 0.08,
}


def _manifest():
    targets, _, dataset_manifest = load_dataset("v0.2", seed=20260821, count=30)
    assert dataset_manifest is not None
    return build_control_manifest(
        targets=targets,
        dataset_manifest=dataset_manifest,
        dataset_seed=20260821,
        schedule_seed=424242,
        trials_per_target=2,
        budget_bytes=900,
        expected_provider="fixture-provider",
        expected_model="fixture-model-v1",
        sampling_policy={"temperature": 0.0},
        analysis_seed=777,
        success_thresholds={
            "hda_noninferiority_margin": 0.05,
            "ana_min_delta": 0.0,
            "meaningful_structural_delta": 0.05,
        },
    )


def _row(target: str, trial: int, condition: str, **overrides):
    row = {
        "trial_id": f"{target}:t{trial:03d}",
        "target_id": target,
        "trial_index": trial,
        "trial_seed": 1,
        "condition": condition,
        **METRIC_VALUES,
    }
    row.update(overrides)
    return row


def test_analysis_pairs_within_trial_then_aggregates_to_target_level(tmp_path: Path):
    rows = [
        _row("t1", 0, "definition_first", hda=0.2),
        _row("t1", 0, "keyword_first", hda=0.3),
        _row("t1", 0, "address_first", hda=0.8),
        _row("t1", 1, "definition_first", hda=0.9),
        _row("t1", 1, "keyword_first", hda=0.9),
        _row("t1", 1, "address_first", hda=0.5),
        _row("t2", 0, "definition_first", hda=0.4),
        _row("t2", 0, "keyword_first", hda=0.4),
        _row("t2", 0, "address_first", hda=0.6),
    ]
    result = analyze_trial_metrics(rows, _manifest(), tmp_path)

    # t1 address-definition deltas are +0.6 and -0.4, so target mean is +0.1.
    target_rows = list(csv.DictReader((tmp_path / "paired_target_means.csv").open(encoding="utf-8")))
    t1 = next(r for r in target_rows if r["contrast"] == "address_vs_definition" and r["target_id"] == "t1")
    assert abs(float(t1["mean_delta_hda"]) - 0.1) < 1e-12
    assert int(t1["paired_trial_count"]) == 2

    metric = result["contrasts"]["address_vs_definition"]["hda"]
    assert metric["n_targets"] == 2
    assert metric["n_complete_trial_pairs"] == 3
    assert metric["wins"] == 2
    assert metric["losses"] == 0


def test_analysis_excludes_incomplete_pairs_without_treating_trials_as_independent(tmp_path: Path):
    rows = [
        _row("t1", 0, "definition_first", ana=0.2),
        _row("t1", 0, "address_first", ana=0.7),
        _row("t1", 1, "definition_first", ana=0.2),
        # address_first missing for t1 trial 1
        _row("t2", 0, "definition_first", ana=0.3),
        _row("t2", 0, "address_first", ana=0.6),
    ]
    result = analyze_trial_metrics(rows, _manifest(), tmp_path)
    metric = result["contrasts"]["address_vs_definition"]["ana"]
    assert metric["n_complete_trial_pairs"] == 2
    assert metric["n_targets"] == 2


def test_bootstrap_confidence_interval_is_deterministic(tmp_path: Path):
    rows = []
    for i in range(10):
        target = f"t{i}"
        rows.extend([
            _row(target, 0, "definition_first", composite=0.4),
            _row(target, 0, "keyword_first", composite=0.45),
            _row(target, 0, "address_first", composite=0.6 + i * 0.001),
        ])
    first = analyze_trial_metrics(rows, _manifest(), tmp_path / "a")
    second = analyze_trial_metrics(rows, _manifest(), tmp_path / "b")
    assert first == second
    ci = first["contrasts"]["address_vs_definition"]["composite"]["bootstrap_ci95"]
    assert len(ci) == 2
    assert ci[0] <= ci[1]


def test_gate1_evaluation_uses_preregistered_thresholds_and_requires_manual_audit(tmp_path: Path):
    rows = []
    for i in range(6):
        target = f"t{i}"
        rows.extend([
            _row(target, 0, "definition_first", hda=0.80, ana=0.40, relation_f1=0.45, ups=0.45, efficiency=0.05),
            _row(target, 0, "keyword_first", hda=0.75, ana=0.45, relation_f1=0.40, ups=0.40, efficiency=0.04),
            _row(target, 0, "address_first", hda=0.79, ana=0.60, relation_f1=0.55, ups=0.52, efficiency=0.06),
        ])
    analyze_trial_metrics(rows, _manifest(), tmp_path)
    gate = json.loads((tmp_path / "gate1_evaluation.json").read_text(encoding="utf-8"))
    assert gate["criteria"]["hda_noninferiority"]["passed"] is True
    assert gate["criteria"]["ana_advantage"]["passed"] is True
    assert gate["criteria"]["structural_advantage"]["passed"] is True
    assert gate["criteria"]["budget_normalized_advantage"]["passed"] is True
    assert gate["manual_leakage_audit"]["status"] == "NOT_EVALUATED"
    assert gate["overall_status"] == "REQUIRES_MANUAL_AUDIT"

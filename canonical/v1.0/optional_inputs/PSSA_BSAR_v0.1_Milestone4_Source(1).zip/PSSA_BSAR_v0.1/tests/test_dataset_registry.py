import pytest

from pssa_bsar.datasets import load_dataset


def test_load_dataset_v01_preserves_original_shape():
    targets, observations, manifest = load_dataset("v0.1", seed=17)
    assert len(targets) == 30
    assert len(observations) == 30
    assert manifest is None
    assert targets[0].target_id.startswith((
        "identity_continuity-", "causality_intervention-", "boundary_access-",
        "reconstruction_recoverability-", "intention_specification-",
    ))


def test_load_dataset_v02_returns_passing_audit_manifest():
    targets, observations, manifest = load_dataset("v0.2", seed=17)
    assert len(targets) == 30
    assert len(observations) == 30
    assert manifest is not None
    assert manifest["dataset_version"] == "v0.2"
    assert manifest["pass_count"] == 30
    assert manifest["fail_count"] == 0
    assert all(obs.family == "undisclosed" and obs.candidate_categories == () for obs in observations)


def test_load_dataset_rejects_unknown_version():
    with pytest.raises(ValueError, match="unsupported dataset version"):
        load_dataset("v9.9", seed=1)

import json
from pathlib import Path

from pssa_bsar.adapters import ModelRequest, ModelResponse
from pssa_bsar.live_pipeline import run_live_protocol


class MinimalValidAdapter:
    def generate(self, request: ModelRequest) -> ModelResponse:
        if request.stage == "builder":
            if request.condition == "definition_first":
                text = json.dumps({"definition": "compact neutral representation"})
            elif request.condition == "keyword_first":
                text = json.dumps({"keywords": ["compact", "neutral"]})
            else:
                text = json.dumps({
                    "positive_anchors": ["compact"],
                    "negative_anchors": ["decoy"],
                    "relations": [],
                    "constraints": [],
                    "open_variables": ["unresolved"],
                    "candidate_categories": [],
                    "confidence": {"anchors": 0.5},
                })
        else:
            text = json.dumps({
                "recovered_positive_anchors": [],
                "recovered_negative_anchors": [],
                "relations": [],
                "constraints": [],
                "open_variables": [],
                "holdout_predictions": {},
                "adversarial_predictions": {},
                "rendering": "minimal recovery",
            })
        return ModelResponse(request.request_id, text, "fixture", "minimal-v1", {})


def test_live_pipeline_v02_emits_audited_dataset_metadata(tmp_path: Path):
    summary = run_live_protocol(
        tmp_path,
        MinimalValidAdapter(),
        seed=20260821,
        budget_bytes=900,
        dataset_version="v0.2",
    )
    assert summary["dataset_version"] == "v0.2"
    assert summary["dataset_audit_pass_count"] == 30
    assert summary["dataset_audit_fail_count"] == 0
    assert (tmp_path / "dataset_manifest.json").exists()
    assert (tmp_path / "targets.jsonl").exists()
    assert (tmp_path / "observations.jsonl").exists()
    assert summary["builder_success_count"] == 90
    assert summary["recovery_success_count"] == 90

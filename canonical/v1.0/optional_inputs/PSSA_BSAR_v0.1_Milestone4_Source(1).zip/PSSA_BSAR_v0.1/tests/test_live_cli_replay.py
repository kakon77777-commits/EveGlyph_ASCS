import json
from pathlib import Path

from pssa_bsar.adapters import ModelRequest
from pssa_bsar.cli import main
from pssa_bsar.replay import replay_adapter_from_ledger

FIXTURE = Path(__file__).parent / 'fixtures' / 'adapter_protocol.sh'


def test_replay_adapter_rejects_prompt_drift(tmp_path: Path):
    ledger = tmp_path / 'requests.jsonl'
    ledger.write_text(json.dumps({
        'sequence': 0,
        'request_id': 'r1',
        'stage': 'builder',
        'target_id': 't1',
        'condition': 'definition_first',
        'prompt_sha256': 'not-the-real-hash',
        'prompt_bytes': 1,
        'raw_response': '{}',
        'response_bytes': 2,
        'status': 'ok',
        'error_type': '',
        'error_message': '',
        'provider': 'recorded',
        'model': 'm',
        'timestamp_utc': None,
        'request': {'request_id':'r1'},
        'response': {'request_id':'r1','text':'{}','provider':'recorded','model':'m','metadata':{}},
    }) + '\n')
    adapter = replay_adapter_from_ledger(ledger)
    req = ModelRequest('r1','builder','t1','definition_first','different prompt',{})
    try:
        adapter.generate(req)
    except ValueError as exc:
        assert 'prompt hash mismatch' in str(exc)
    else:
        raise AssertionError('expected prompt hash mismatch')


def test_live_command_then_replay_are_byte_identical(tmp_path: Path):
    live = tmp_path / 'live'
    replay = tmp_path / 'replay'
    command = json.dumps(['/bin/sh', str(FIXTURE)])
    assert main(['run-live-command','--command-json',command,'--output',str(live),'--seed','20260821','--budget-bytes','900','--timeout-seconds','5']) == 0
    assert main(['run-replay','--ledger',str(live/'requests.jsonl'),'--output',str(replay),'--seed','20260821','--budget-bytes','900']) == 0
    assert (live/'summary.json').read_bytes() == (replay/'summary.json').read_bytes()
    assert (live/'metrics.csv').read_bytes() == (replay/'metrics.csv').read_bytes()

from collections import Counter

from pssa_bsar.dataset_v2 import generate_targets_v2, make_observation_v2


def test_v2_generation_is_deterministic_balanced_and_opaque():
    a = generate_targets_v2(seed=7)
    b = generate_targets_v2(seed=7)
    assert [x.to_dict() for x in a] == [x.to_dict() for x in b]
    assert len(a) == 30
    assert Counter(x.family for x in a) == {
        "identity_continuity": 6,
        "causality_intervention": 6,
        "boundary_access": 6,
        "reconstruction_recoverability": 6,
        "intention_specification": 6,
    }
    assert all(target.target_id.startswith("bsar2-") for target in a)
    assert all(target.family not in target.target_id for target in a)


def test_v2_different_seed_changes_target_assignment():
    a = [x.to_dict() for x in generate_targets_v2(seed=7)]
    b = [x.to_dict() for x in generate_targets_v2(seed=8)]
    assert a != b


def test_v2_observation_hides_family_categories_and_scoring_splits():
    target = generate_targets_v2(seed=11)[0]
    obs = make_observation_v2(target)
    data = obs.to_dict()
    assert obs.target_id == target.target_id
    assert obs.family == "undisclosed"
    assert obs.candidate_categories == ()
    assert "holdout_cases" not in data
    assert "adversarial_cases" not in data
    assert "relations" not in data
    assert "constraints" not in data


def test_v2_case_counts_and_cross_split_descriptions_are_distinct():
    for target in generate_targets_v2(seed=13):
        assert len(target.development_cases) == 8
        assert len(target.holdout_cases) == 4
        assert len(target.adversarial_cases) == 2
        dev = {case.description for case in target.development_cases}
        holdout = {case.description for case in target.holdout_cases}
        adversarial = {case.description for case in target.adversarial_cases}
        assert dev.isdisjoint(holdout)
        assert dev.isdisjoint(adversarial)
        assert holdout.isdisjoint(adversarial)

import json
from pathlib import Path

from pssa_bsar.pipeline import run_mock_experiment


EXPECTED_FILES = {
    "targets.jsonl",
    "observations.jsonl",
    "frozen_representations.jsonl",
    "recoveries.jsonl",
    "metrics.csv",
    "summary.json",
    "REPORT.md",
}


def test_mock_pipeline_emits_complete_auditable_artifacts(tmp_path):
    out = tmp_path / "run"
    summary = run_mock_experiment(out, seed=20260821, budget_bytes=900)
    assert EXPECTED_FILES <= {p.name for p in out.iterdir()}
    assert summary["target_count"] == 30
    assert summary["conditions"] == ["definition_first", "keyword_first", "address_first"]
    assert summary["seed"] == 20260821
    assert summary["budget_bytes"] == 900
    assert summary["evidence_status"] == "MOCK_PLUMBING_ONLY"
    report = (out / "REPORT.md").read_text(encoding="utf-8")
    assert "MOCK_PLUMBING_ONLY" in report
    assert "not empirical evidence" in report


def test_mock_pipeline_is_byte_deterministic_for_same_seed(tmp_path):
    a = tmp_path / "a"
    b = tmp_path / "b"
    run_mock_experiment(a, seed=123, budget_bytes=900)
    run_mock_experiment(b, seed=123, budget_bytes=900)
    assert (a / "summary.json").read_bytes() == (b / "summary.json").read_bytes()
    assert (a / "metrics.csv").read_bytes() == (b / "metrics.csv").read_bytes()


def test_recovery_records_have_three_conditions_per_target(tmp_path):
    out = tmp_path / "run"
    run_mock_experiment(out, seed=5, budget_bytes=900)
    rows = [json.loads(line) for line in (out / "recoveries.jsonl").read_text(encoding="utf-8").splitlines()]
    assert len(rows) == 90
    counts = {}
    for row in rows:
        counts[row["target_id"]] = counts.get(row["target_id"], 0) + 1
    assert set(counts.values()) == {3}

from pathlib import Path
import sys

import pytest

from pssa_bsar.adapters import AdapterError, ModelRequest, SubprocessJsonAdapter

FIXTURE = Path(__file__).parent / 'fixtures' / 'adapter_echo.py'


def request(mode='success'):
    return ModelRequest('r1', 'builder', 't1', 'address_first', 'hello', {'fixture_mode': mode})


def test_subprocess_adapter_success():
    adapter = SubprocessJsonAdapter([sys.executable, str(FIXTURE)], timeout_seconds=3.0)
    response = adapter.generate(request())
    assert response.request_id == 'r1'
    assert response.text == 'hello'
    assert response.provider == 'fixture'


def test_subprocess_adapter_reports_nonzero_exit():
    adapter = SubprocessJsonAdapter([sys.executable, str(FIXTURE)], timeout_seconds=3.0)
    with pytest.raises(AdapterError, match='nonzero_exit'):
        adapter.generate(request('nonzero'))


def test_subprocess_adapter_reports_timeout():
    adapter = SubprocessJsonAdapter([sys.executable, str(FIXTURE)], timeout_seconds=0.05)
    with pytest.raises(AdapterError, match='timeout'):
        adapter.generate(request('timeout'))


def test_subprocess_adapter_reports_malformed_json():
    adapter = SubprocessJsonAdapter([sys.executable, str(FIXTURE)], timeout_seconds=3.0)
    with pytest.raises(AdapterError, match='malformed_json'):
        adapter.generate(request('malformed'))


def test_subprocess_adapter_rejects_request_id_mismatch():
    adapter = SubprocessJsonAdapter([sys.executable, str(FIXTURE)], timeout_seconds=3.0)
    with pytest.raises(AdapterError, match='request_id_mismatch'):
        adapter.generate(request('mismatch'))

import inspect

from pssa_bsar.builders import build_address
from pssa_bsar.dataset import generate_targets, make_observation
from pssa_bsar.models import FrozenRepresentation, RecoveryResult, Relation
from pssa_bsar.recovery import recover
from pssa_bsar.scoring import score


def test_recover_interface_does_not_accept_ground_truth():
    assert list(inspect.signature(recover).parameters) == ["rep", "eval_cases"]


def test_recovery_is_deterministic_from_frozen_representation_and_public_cases():
    target = generate_targets(19)[0]
    rep = build_address(make_observation(target), 900)
    cases = [case.public_view() for case in (*target.holdout_cases, *target.adversarial_cases)]
    assert recover(rep, cases) == recover(rep, cases)


def test_score_computes_expected_partial_relation_constraint_and_unknown_scores():
    target = generate_targets(23)[0]
    recovery = RecoveryResult(
        target_id=target.target_id,
        condition="address_first",
        recovered_positive_anchors=target.positive_anchors[:2],
        recovered_negative_anchors=target.negative_anchors[:1],
        relations=(target.relations[0],),
        constraints=(target.constraints[0],),
        open_variables=target.open_variables,
        holdout_predictions={c.case_id: bool(c.label) for c in target.holdout_cases},
        adversarial_predictions={c.case_id: bool(c.label) for c in target.adversarial_cases},
        rendering="mock",
    )
    metric = score(target, recovery, representation_bytes=100)
    assert metric.hda == 1.0
    assert metric.ana == 1.0
    assert 0.0 < metric.relation_f1 < 1.0
    assert 0.0 < metric.constraint_f1 < 1.0
    assert metric.ups == 1.0
    assert 0.0 < metric.composite <= 1.0
    assert metric.efficiency > 0.0


def test_unknown_preservation_is_zero_when_gold_unknown_is_collapsed():
    target = generate_targets(29)[0]
    recovery = RecoveryResult(
        target_id=target.target_id,
        condition="keyword_first",
        recovered_positive_anchors=(),
        recovered_negative_anchors=(),
        relations=(),
        constraints=(),
        open_variables=(),
        holdout_predictions={c.case_id: False for c in target.holdout_cases},
        adversarial_predictions={c.case_id: False for c in target.adversarial_cases},
        rendering="mock",
    )
    assert score(target, recovery, 50).ups == 0.0

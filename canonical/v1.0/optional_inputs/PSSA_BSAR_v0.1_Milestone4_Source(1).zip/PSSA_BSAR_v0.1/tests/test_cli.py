from pssa_bsar.cli import main


def test_cli_run_mock_creates_summary(tmp_path):
    out = tmp_path / "cli-run"
    exit_code = main(["run-mock", "--output", str(out), "--seed", "77", "--budget-bytes", "900"])
    assert exit_code == 0
    assert (out / "summary.json").exists()

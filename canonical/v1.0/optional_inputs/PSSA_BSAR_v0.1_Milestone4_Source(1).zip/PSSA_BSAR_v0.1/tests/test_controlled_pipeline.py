from __future__ import annotations

import json
from pathlib import Path

from pssa_bsar.adapters import ModelRequest, ModelResponse
from pssa_bsar.control import build_control_manifest
from pssa_bsar.controlled_pipeline import run_controlled_protocol
from pssa_bsar.datasets import load_dataset


class ControlledMinimalAdapter:
    def __init__(self, output_dir: Path, mismatch_request_id: str | None = None):
        self.output_dir = output_dir
        self.mismatch_request_id = mismatch_request_id
        self.requests: list[ModelRequest] = []

    def generate(self, request: ModelRequest) -> ModelResponse:
        assert (self.output_dir / "control_manifest.json").exists()
        assert (self.output_dir / "trial_schedule.jsonl").exists()
        self.requests.append(request)
        if request.stage == "builder":
            if request.condition == "definition_first":
                text = json.dumps({"definition": "compact neutral representation"})
            elif request.condition == "keyword_first":
                text = json.dumps({"keywords": ["compact", "neutral"]})
            else:
                text = json.dumps({
                    "positive_anchors": ["compact"],
                    "negative_anchors": ["decoy"],
                    "relations": [],
                    "constraints": [],
                    "open_variables": ["unresolved"],
                    "candidate_categories": [],
                    "confidence": {"anchors": 0.5},
                })
        else:
            text = json.dumps({
                "recovered_positive_anchors": [],
                "recovered_negative_anchors": [],
                "relations": [],
                "constraints": [],
                "open_variables": [],
                "holdout_predictions": {},
                "adversarial_predictions": {},
                "rendering": "minimal recovery",
            })
        model = "wrong-model" if request.request_id == self.mismatch_request_id else "fixture-model-v1"
        return ModelResponse(request.request_id, text, "fixture-provider", model, {})


def _manifest(trials: int = 2):
    targets, _, dataset_manifest = load_dataset("v0.2", seed=20260821, count=30)
    assert dataset_manifest is not None
    return build_control_manifest(
        targets=targets,
        dataset_manifest=dataset_manifest,
        dataset_seed=20260821,
        schedule_seed=424242,
        trials_per_target=trials,
        budget_bytes=900,
        expected_provider="fixture-provider",
        expected_model="fixture-model-v1",
        sampling_policy={"temperature": 0.0, "top_p": 1.0, "seed_mode": "paired_trial"},
        analysis_seed=777,
        success_thresholds={
            "hda_noninferiority_margin": 0.05,
            "ana_min_delta": 0.0,
            "meaningful_structural_delta": 0.05,
        },
    )


def test_controlled_protocol_follows_frozen_schedule_and_isolates_recovery(tmp_path: Path):
    manifest = _manifest(trials=2)
    adapter = ControlledMinimalAdapter(tmp_path)
    summary = run_controlled_protocol(tmp_path, manifest, adapter)

    assert summary["evidence_status"] == "CONTROLLED_RUN_REQUIRES_MODEL_VALIDATION"
    assert summary["manifest_sha256"] == manifest.manifest_sha256
    assert summary["trial_block_count"] == 60
    assert summary["builder_success_count"] == 180
    assert summary["recovery_success_count"] == 180
    assert len(adapter.requests) == 360

    first_block = manifest.schedule[0]
    first_builder = adapter.requests[0]
    first_recovery = adapter.requests[1]
    assert first_builder.request_id == f"b:{first_block.target_id}:t{first_block.trial_index:03d}:{first_block.conditions[0]}"
    assert first_recovery.request_id == f"r:{first_block.target_id}:t{first_block.trial_index:03d}:{first_block.conditions[0]}"

    for request in adapter.requests:
        assert request.metadata["control_manifest_sha256"] == manifest.manifest_sha256
        assert request.metadata["sampling_policy"] == manifest.sampling_policy
        assert request.metadata["trial_seed"] >= 0
        assert request.metadata["trial_index"] >= 0
        if request.stage == "recovery":
            lower = request.prompt.lower()
            assert '"development_cases"' not in lower
            assert '"holdout_cases"' not in lower
            assert '"adversarial_cases"' not in lower
            assert '"label": true' not in lower
            assert '"label": false' not in lower

    expected_files = {
        "control_manifest.json", "trial_schedule.jsonl", "dataset_manifest.json",
        "targets.jsonl", "observations.jsonl", "requests.jsonl",
        "frozen_representations.jsonl", "recoveries.jsonl", "failures.jsonl",
        "trial_metrics.csv", "summary.json", "REPORT.md",
    }
    assert expected_files <= {p.name for p in tmp_path.iterdir()}

    schedule_rows = [json.loads(x) for x in (tmp_path / "trial_schedule.jsonl").read_text(encoding="utf-8").splitlines()]
    assert schedule_rows == [item.to_dict() for item in manifest.schedule]


def test_controlled_protocol_records_model_identity_mismatch_and_continues(tmp_path: Path):
    manifest = _manifest(trials=1)
    first = manifest.schedule[0]
    bad_id = f"b:{first.target_id}:t{first.trial_index:03d}:{first.conditions[0]}"
    adapter = ControlledMinimalAdapter(tmp_path, mismatch_request_id=bad_id)
    summary = run_controlled_protocol(tmp_path, manifest, adapter)

    failures = [json.loads(x) for x in (tmp_path / "failures.jsonl").read_text(encoding="utf-8").splitlines() if x.strip()]
    assert summary["builder_failure_count"] == 1
    assert summary["builder_success_count"] == 89
    assert summary["recovery_success_count"] == 89
    assert any(row["request_id"] == bad_id and row["error_type"] == "model_identity_mismatch" for row in failures)


def test_trial_metric_rows_preserve_pairing_identity(tmp_path: Path):
    manifest = _manifest(trials=2)
    run_controlled_protocol(tmp_path, manifest, ControlledMinimalAdapter(tmp_path))
    header, *rows = (tmp_path / "trial_metrics.csv").read_text(encoding="utf-8").splitlines()
    assert header.startswith("trial_id,target_id,trial_index,trial_seed,condition,")
    assert len(rows) == 30 * 2 * 3
    assert "bsar2-" in rows[0]

import json

import pytest

from pssa_bsar.dataset import generate_targets, make_observation
from pssa_bsar.models import Case, FrozenRepresentation
from pssa_bsar.parsing import ParseError, parse_builder_response, parse_recovery_response
from pssa_bsar.prompts import builder_prompt, recovery_prompt


def obs():
    return make_observation(generate_targets(seed=7)[0])


def test_address_prompt_forbids_name_and_prose_definition():
    prompt = builder_prompt(obs(), 'address_first', 900)
    assert 'Do not output a concept name' in prompt
    assert 'Do not write a prose definition' in prompt
    assert 'positive_anchors' in prompt
    assert 'open_variables' in prompt


def test_definition_and_keyword_prompts_have_distinct_contracts():
    definition = builder_prompt(obs(), 'definition_first', 900)
    keywords = builder_prompt(obs(), 'keyword_first', 900)
    assert '"definition"' in definition
    assert '"keywords"' not in definition
    assert '"keywords"' in keywords
    contract = keywords.split('OUTPUT CONTRACT', 1)[1]
    assert '{"keywords"' in contract
    assert 'Do not output relations' in contract


def test_parse_valid_address_builder_response_preserves_unknowns():
    payload = {
        'positive_anchors': ['continuity'],
        'negative_anchors': ['replacement'],
        'relations': [{'source':'continuity','relation_type':'supports','target':'responsibility','polarity':1,'confidence':0.8}],
        'constraints': ['history_required'],
        'open_variables': ['threshold_unknown'],
        'candidate_categories': ['identity'],
        'confidence': {'anchors': 0.8},
    }
    rep = parse_builder_response('address_first', 't1', json.dumps(payload), 900)
    assert rep.condition == 'address_first'
    assert rep.payload['open_variables'] == ['threshold_unknown']


def test_builder_parser_rejects_prose_contamination_and_missing_fields():
    with pytest.raises(ParseError, match='invalid_json'):
        parse_builder_response('definition_first', 't1', 'Here is it: {"definition":"x"}', 900)
    with pytest.raises(ParseError, match='schema'):
        parse_builder_response('address_first', 't1', json.dumps({'positive_anchors':['x']}), 900)


def test_builder_parser_rejects_over_budget_payload():
    text = json.dumps({'definition': 'x' * 200})
    with pytest.raises(ParseError, match='over_budget'):
        parse_builder_response('definition_first', 't1', text, 40)


def test_recovery_prompt_contains_only_frozen_representation_and_public_cases():
    rep = FrozenRepresentation('t1', 'keyword_first', ['alpha','beta'], 16, 2)
    cases = [Case('h1', 'public holdout text', None, 'holdout')]
    prompt = recovery_prompt(rep, cases)
    assert 'alpha' in prompt and 'public holdout text' in prompt
    assert 'gold_label' not in prompt


def test_parse_recovery_response():
    payload = {
        'recovered_positive_anchors':['a'],
        'recovered_negative_anchors':['b'],
        'relations':[],
        'constraints':['c'],
        'open_variables':['u'],
        'holdout_predictions':{'h1': True},
        'adversarial_predictions':{'a1': False},
        'rendering':'short',
    }
    result = parse_recovery_response('t1', 'address_first', json.dumps(payload))
    assert result.open_variables == ('u',)
    assert result.holdout_predictions == {'h1': True}

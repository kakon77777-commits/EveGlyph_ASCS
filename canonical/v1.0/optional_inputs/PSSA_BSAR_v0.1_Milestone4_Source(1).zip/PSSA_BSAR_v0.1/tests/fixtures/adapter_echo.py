import json
import sys
import time

request = json.load(sys.stdin)
mode = request.get('metadata', {}).get('fixture_mode', 'success')
if mode == 'nonzero':
    print('fixture failure', file=sys.stderr)
    raise SystemExit(7)
if mode == 'timeout':
    time.sleep(2.0)
if mode == 'malformed':
    sys.stdout.write('{bad json')
    raise SystemExit(0)
request_id = request['request_id'] if mode != 'mismatch' else request['request_id'] + '-wrong'
json.dump({
    'request_id': request_id,
    'text': request.get('prompt', ''),
    'provider': 'fixture',
    'model': 'echo-v1',
    'metadata': {'mode': mode},
}, sys.stdout)

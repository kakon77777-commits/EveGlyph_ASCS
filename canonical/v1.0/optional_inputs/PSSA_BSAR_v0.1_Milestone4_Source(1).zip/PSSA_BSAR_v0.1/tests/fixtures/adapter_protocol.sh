#!/bin/sh
input=$(cat)
rid=$(printf '%s' "$input" | sed -n 's/.*"request_id": "\([^"]*\)".*/\1/p')
stage=$(printf '%s' "$input" | sed -n 's/.*"stage": "\([^"]*\)".*/\1/p')
condition=$(printf '%s' "$input" | sed -n 's/.*"condition": "\([^"]*\)".*/\1/p')
if [ "$stage" = "builder" ]; then
  case "$condition" in
    definition_first) text='{\"definition\":\"offline protocol fixture definition\"}' ;;
    keyword_first) text='{\"keywords\":[\"offline\",\"fixture\"]}' ;;
    address_first) text='{\"positive_anchors\":[\"offline\"],\"negative_anchors\":[\"decoy\"],\"relations\":[],\"constraints\":[],\"open_variables\":[\"unknown\"],\"candidate_categories\":[],\"confidence\":{\"anchors\":0.5}}' ;;
    *) exit 8 ;;
  esac
else
  text='{\"recovered_positive_anchors\":[],\"recovered_negative_anchors\":[],\"relations\":[],\"constraints\":[],\"open_variables\":[],\"holdout_predictions\":{},\"adversarial_predictions\":{},\"rendering\":\"offline replay fixture\"}'
fi
printf '{"request_id":"%s","text":"%s","provider":"fixture-shell","model":"protocol-v1","metadata":{}}' "$rid" "$text"

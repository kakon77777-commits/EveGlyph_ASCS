from collections import Counter

from pssa_bsar.dataset import generate_targets, make_observation


def test_generate_targets_is_deterministic_and_balanced():
    a = generate_targets(7)
    b = generate_targets(7)
    assert [x.to_dict() for x in a] == [x.to_dict() for x in b]
    assert len(a) == 30
    counts = Counter(x.family for x in a)
    assert len(counts) == 5
    assert sorted(counts.values()) == [6, 6, 6, 6, 6]


def test_different_seed_changes_variant_order_or_assignment():
    a = [x.to_dict() for x in generate_targets(7)]
    b = [x.to_dict() for x in generate_targets(8)]
    assert a != b


def test_each_target_has_required_case_counts_and_structure():
    for target in generate_targets(11):
        assert 3 <= len(target.positive_anchors) <= 6
        assert 2 <= len(target.negative_anchors) <= 5
        assert 3 <= len(target.relations) <= 8
        assert 2 <= len(target.constraints) <= 6
        assert 1 <= len(target.open_variables) <= 4
        assert len(target.development_cases) == 8
        assert len(target.holdout_cases) == 4
        assert len(target.adversarial_cases) == 2


def test_observation_omits_hidden_scoring_fields():
    target = generate_targets(13)[0]
    obs = make_observation(target)
    data = obs.to_dict()
    assert obs.target_id == target.target_id
    assert "holdout_cases" not in data
    assert "adversarial_cases" not in data
    assert "relations" not in data
    assert "constraints" not in data
    assert "positive_anchors" not in data
    assert "negative_anchors" not in data

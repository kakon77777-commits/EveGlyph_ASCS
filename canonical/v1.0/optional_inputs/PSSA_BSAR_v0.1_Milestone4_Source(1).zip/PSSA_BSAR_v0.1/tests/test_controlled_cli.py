from __future__ import annotations

import json
from pathlib import Path

from pssa_bsar.cli import main
from pssa_bsar.control import load_control_manifest


FIXTURE_COMMAND = json.dumps(["sh", "tests/fixtures/adapter_protocol.sh"])


def _plan(tmp_path: Path, provider: str = "fixture-shell", model: str = "protocol-v1") -> Path:
    out = tmp_path / "plan"
    code = main([
        "plan-controlled-run",
        "--output", str(out),
        "--dataset-seed", "20260821",
        "--schedule-seed", "424242",
        "--trials-per-target", "1",
        "--budget-bytes", "900",
        "--expected-provider", provider,
        "--expected-model", model,
        "--sampling-json", '{"temperature":0.0,"top_p":1.0,"seed_mode":"paired_trial"}',
        "--analysis-seed", "777",
    ])
    assert code == 0
    return out / "control_manifest.json"


def test_plan_controlled_run_freezes_manifest(tmp_path: Path):
    manifest_path = _plan(tmp_path)
    manifest = load_control_manifest(manifest_path)
    assert manifest.dataset_version == "v0.2"
    assert manifest.trials_per_target == 1
    assert manifest.expected_provider == "fixture-shell"
    assert manifest.expected_model == "protocol-v1"
    assert manifest.sampling_policy["temperature"] == 0.0
    assert len(manifest.schedule) == 30


def test_controlled_live_and_replay_are_byte_identical(tmp_path: Path):
    manifest_path = _plan(tmp_path)
    live = tmp_path / "live"
    replay = tmp_path / "replay"

    assert main([
        "run-controlled-live-command",
        "--manifest", str(manifest_path),
        "--command-json", FIXTURE_COMMAND,
        "--output", str(live),
        "--timeout-seconds", "10",
    ]) == 0

    assert main([
        "run-controlled-replay",
        "--manifest", str(manifest_path),
        "--ledger", str(live / "requests.jsonl"),
        "--output", str(replay),
    ]) == 0

    expected = {
        "control_manifest.json", "trial_schedule.jsonl", "dataset_manifest.json",
        "targets.jsonl", "observations.jsonl", "requests.jsonl",
        "frozen_representations.jsonl", "recoveries.jsonl", "failures.jsonl",
        "trial_metrics.csv", "paired_trial_differences.csv", "paired_target_means.csv",
        "paired_analysis.json", "gate1_evaluation.json", "summary.json", "REPORT.md",
    }
    assert expected <= {p.name for p in live.iterdir()}
    assert expected <= {p.name for p in replay.iterdir()}

    for name in sorted(expected - {"REPORT.md"}):
        assert (live / name).read_bytes() == (replay / name).read_bytes(), name


def test_controlled_model_identity_mismatch_is_explicit_failure(tmp_path: Path):
    manifest_path = _plan(tmp_path, provider="other-provider", model="other-model")
    out = tmp_path / "mismatch"
    assert main([
        "run-controlled-live-command",
        "--manifest", str(manifest_path),
        "--command-json", FIXTURE_COMMAND,
        "--output", str(out),
        "--timeout-seconds", "10",
    ]) == 0
    summary = json.loads((out / "summary.json").read_text(encoding="utf-8"))
    failures = [json.loads(line) for line in (out / "failures.jsonl").read_text(encoding="utf-8").splitlines() if line]
    assert summary["builder_success_count"] == 0
    assert summary["builder_failure_count"] == 90
    assert summary["recovery_success_count"] == 0
    assert failures
    assert {row["error_type"] for row in failures} == {"model_identity_mismatch"}

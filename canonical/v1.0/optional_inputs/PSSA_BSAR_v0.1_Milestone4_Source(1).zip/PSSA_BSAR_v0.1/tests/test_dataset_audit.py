from dataclasses import replace
from pathlib import Path

from pssa_bsar.dataset_audit import audit_dataset_v2, audit_target_v2, write_dataset_manifest
from pssa_bsar.dataset_v2 import generate_targets_v2, make_observation_v2


def test_v2_dataset_passes_leakage_audit():
    targets = generate_targets_v2(seed=20260821)
    observations = [make_observation_v2(t) for t in targets]
    report = audit_dataset_v2(targets, observations, seed=20260821)
    assert report["target_count"] == 30
    assert report["pass_count"] == 30
    assert report["fail_count"] == 0
    assert len(report["dataset_sha256"]) == 64
    assert all(row["passed"] for row in report["targets"])
    assert max(row["max_cross_split_bigram_jaccard"] for row in report["targets"]) <= 0.30


def test_audit_detects_canonical_identifier_leakage():
    target = generate_targets_v2(seed=7)[0]
    obs = make_observation_v2(target)
    leaked = replace(obs, relation_probe=f"probe {target.positive_anchors[0]}")
    row = audit_target_v2(target, leaked)
    assert row["passed"] is False
    assert target.positive_anchors[0] in row["sensitive_leaks"]


def test_audit_detects_cross_split_copy():
    target = generate_targets_v2(seed=7)[0]
    copied = replace(
        target,
        holdout_cases=(
            replace(target.holdout_cases[0], description=target.development_cases[0].description),
            *target.holdout_cases[1:],
        ),
    )
    row = audit_target_v2(copied, make_observation_v2(copied))
    assert row["passed"] is False
    assert "cross_split_exact_reuse" in row["failure_tags"]


def test_audit_requires_adversarial_negative_to_share_positive_surface_cue():
    target = generate_targets_v2(seed=7)[0]
    adversarial = tuple(
        replace(case, description="zebra quartz xylophone unrelated tokens") if case.label is False else case
        for case in target.adversarial_cases
    )
    changed = replace(target, adversarial_cases=adversarial)
    row = audit_target_v2(changed, make_observation_v2(changed))
    assert row["passed"] is False
    assert "adversarial_without_positive_surface_cue" in row["failure_tags"]


def test_dataset_manifest_is_deterministic(tmp_path: Path):
    targets = generate_targets_v2(seed=99)
    observations = [make_observation_v2(t) for t in targets]
    a = audit_dataset_v2(targets, observations, seed=99)
    b = audit_dataset_v2(targets, observations, seed=99)
    assert a == b
    p1 = tmp_path / "a.json"
    p2 = tmp_path / "b.json"
    write_dataset_manifest(p1, a)
    write_dataset_manifest(p2, b)
    assert p1.read_bytes() == p2.read_bytes()

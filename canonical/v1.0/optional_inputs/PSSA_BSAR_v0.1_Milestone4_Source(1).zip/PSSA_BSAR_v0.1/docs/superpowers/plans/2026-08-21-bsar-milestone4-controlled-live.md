# BSAR Milestone 4 Controlled Live Gate 1 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [x]`) syntax for tracking.

**Goal:** Add a preregistered, repeated-trial controlled live-model Gate 1 runner for Dataset v0.2 with deterministic scheduling, fixed model/sampling metadata, paired target-level analysis, and replay equivalence.

**Architecture:** A new control layer freezes an experimental manifest before any model request. A deterministic schedule balances all six condition permutations across target/trial blocks and assigns one paired trial seed to the three conditions in each block. The controlled runner executes builder/recovery requests from that frozen schedule, writes trial-aware artifacts, then performs target-level paired analysis so repeated trials are not treated as independent samples.

**Tech Stack:** Python 3.11+, standard library only, pytest, existing PSSA-BSAR adapters/parsers/scorers.

**Spec:** `docs/superpowers/specs/2026-08-21-PSSA-BSAR-v0.1-design.md` plus Dataset v0.2 rules in `README.md` and Milestone 3 verification record.

## Global Constraints

- Dataset must be `v0.2` for controlled Gate 1.
- Full control manifest is written and hashed before the first model request.
- Builder and recovery remain isolated requests; recovery receives no hidden gold fields.
- All three conditions use the same representation byte budget and sampling policy.
- Repeated trials are paired by `(target_id, trial_index)` and share one trial seed across conditions.
- Condition order must be deterministic and globally balanced across the six permutations to within one block.
- Statistical summaries operate on target-level mean deltas, not raw trial count, to avoid pseudo-replication.
- No provider-specific SDK dependency enters the core harness.
- Replay must validate prompt hashes and reproduce controlled artifacts byte-for-byte.
- Controlled protocol artifacts alone do not establish a pre-linguistic cognitive mechanism.

---

### Task 1: Control Manifest and Balanced Trial Schedule

**Files:**
- Create: `src/pssa_bsar/control.py`
- Create: `tests/test_control.py`

**Interfaces:**
- Produces: `ControlManifest`, `TrialScheduleItem`, `build_control_manifest(...)`, `write_control_manifest(...)`, `load_control_manifest(...)`.
- Schedule items expose `sequence`, `target_id`, `trial_index`, `trial_seed`, and ordered `conditions`.

- [x] Write tests that require deterministic manifest hashing, opaque dataset hash binding, equal model/sampling settings, deterministic schedule generation, six-permutation balance, and same trial seed across paired conditions.
- [x] Run `pytest tests/test_control.py -q` and verify RED because `pssa_bsar.control` does not exist.
- [x] Implement the minimal control dataclasses, canonical JSON hashing, balanced permutation scheduler, and manifest read/write validation.
- [x] Run `pytest tests/test_control.py -q` and verify GREEN.

### Task 2: Controlled Trial Runner

**Files:**
- Create: `src/pssa_bsar/controlled_pipeline.py`
- Create: `tests/test_controlled_pipeline.py`

**Interfaces:**
- Consumes: `ControlManifest`, `ModelAdapter`, existing Dataset v0.2 loader, prompts, parsers, scorer.
- Produces: `run_controlled_protocol(output_dir, manifest, adapter)`.

- [x] Write failing tests requiring request IDs with trial identity, frozen manifest hash on every request, schedule order adherence, model identity checking, sampling policy metadata propagation, recovery gold isolation, trial-aware JSONL/CSV artifacts, and single-request failure containment.
- [x] Run the focused test and verify RED.
- [x] Implement the minimal controlled runner without changing the old `run_live_protocol` path.
- [x] Run the focused test and verify GREEN.

### Task 3: Paired Target-Level Analysis

**Files:**
- Create: `src/pssa_bsar/analysis.py`
- Create: `tests/test_analysis.py`

**Interfaces:**
- Consumes: trial-aware metric rows.
- Produces: `paired_trial_differences.csv`, `paired_target_means.csv`, `paired_analysis.json`, `gate1_evaluation.json`.

- [x] Write failing tests for paired address-vs-definition and address-vs-keyword deltas, target-level aggregation across repeated trials, deterministic target bootstrap confidence intervals, win/tie/loss counts, incomplete-pair exclusion, and preregistered Gate 1 evaluation thresholds.
- [x] Run the focused test and verify RED.
- [x] Implement the minimal paired analysis using standard-library statistics/random only.
- [x] Run the focused test and verify GREEN.

### Task 4: Controlled Replay and CLI

**Files:**
- Modify: `src/pssa_bsar/cli.py`
- Create: `tests/test_controlled_cli.py`

**Interfaces:**
- Adds CLI commands: `plan-controlled-run`, `run-controlled-live-command`, `run-controlled-replay`.
- `plan-controlled-run` writes the frozen manifest; run commands consume it rather than reconstructing experimental parameters from CLI flags.

- [x] Write failing CLI tests for planning, live execution from manifest, replay from the same manifest, model mismatch failure reporting, and byte-identical live/replay artifacts.
- [x] Run the focused test and verify RED.
- [x] Implement the three CLI commands and controlled replay plumbing.
- [x] Run the focused test and verify GREEN.

### Task 5: Documentation, Compatibility, and Fresh Verification

**Files:**
- Modify: `README.md`
- Create: `docs/verification/2026-08-21-bsar-milestone4.md`

**Interfaces:**
- Documents the exact preregistration workflow and evidence boundary.

- [x] Add Milestone 4 usage, manifest schema summary, trial pairing rule, schedule balancing, and interpretation constraints to README.
- [x] Run full `pytest -q` and verify all legacy and new tests pass.
- [x] Generate one fixture controlled manifest with 3 trials/target, execute controlled live fixture and replay, and compare manifest/schedule/requests/representations/recoveries/metrics/paired-analysis artifacts byte-for-byte.
- [x] Verify recovery prompt leakage count is zero and recorded provider/model matches the frozen manifest.
- [x] Record exact commands and outputs in the verification note.
- [x] Run `git diff --check`, confirm a clean working tree after commit, and package source plus verification artifacts.

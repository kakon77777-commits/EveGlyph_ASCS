# PSSA BSAR Milestone 1 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [x]`) syntax for tracking.

**Goal:** Build a deterministic, offline, no-API end-to-end BSAR v0.1 harness that generates 30 synthetic hidden targets, produces three frozen mock representations, recovers structures, scores them, and emits auditable JSON/CSV reports.

**Architecture:** A small Python package with five isolated responsibilities: dataset generation, representation building/freezing, deterministic recovery, scoring, and pipeline/CLI orchestration. Ground truth and recovery are separated in code and persisted to different artifact files so the recovery stage consumes only frozen representations plus evaluation cases. Every behavior is added test-first.

**Tech Stack:** Python 3.13 standard library, `pytest` 9, JSON/JSONL/CSV, `argparse`; no network and no third-party runtime dependencies.

**Spec:** `docs/superpowers/specs/2026-08-21-PSSA-BSAR-v0.1-design.md`

## Global Constraints

- Milestone 1 must run with no API key and no network access.
- Generate exactly 30 deterministic targets across five families, six targets per family.
- Primary conditions are `definition_first`, `keyword_first`, and `address_first`.
- Address-first schema contains positive anchors, negative anchors, typed relations, constraints, open variables, candidate categories, and confidence.
- Recovery code must consume frozen representations rather than hidden ground truth.
- Reports must state that mock results validate plumbing only and are not empirical evidence for PSSA.
- All randomization must be controlled by an explicit integer seed.

---

### Task 1: Project skeleton and canonical data model

**Files:**
- Create: `pyproject.toml`
- Create: `src/pssa_bsar/__init__.py`
- Create: `src/pssa_bsar/models.py`
- Test: `tests/test_models.py`

**Interfaces:**
- Produces: `Relation`, `Case`, `GroundTruthTarget`, `ObservationBundle`, `FrozenRepresentation`, `RecoveryResult`, `MetricVector` dataclasses with `to_dict()` / `from_dict()` where persisted.

- [x] **Step 1: Write the failing model round-trip test**

```python
from pssa_bsar.models import Relation

def test_relation_round_trip():
    relation = Relation("continuity", "supports", "responsibility", 1, 0.9)
    assert Relation.from_dict(relation.to_dict()) == relation
```

- [x] **Step 2: Run `pytest tests/test_models.py -q` and confirm import/implementation failure.**
- [x] **Step 3: Implement immutable dataclasses and JSON-safe conversions in `models.py`.**
- [x] **Step 4: Re-run the test and confirm PASS.**
- [x] **Step 5: Commit `test+models` as `feat: add BSAR data model`.**

### Task 2: Deterministic synthetic dataset generator

**Files:**
- Create: `src/pssa_bsar/dataset.py`
- Test: `tests/test_dataset.py`

**Interfaces:**
- Consumes: data classes from Task 1.
- Produces: `generate_targets(seed: int = 20260821, count: int = 30) -> list[GroundTruthTarget]` and `make_observation(target) -> ObservationBundle`.

- [x] **Step 1: Write failing tests asserting 30 targets, 5 families x 6, deterministic equality for same seed, and required case counts (8 development, 4 holdout, 2 adversarial).**

```python
def test_generate_targets_is_deterministic_and_balanced():
    a = generate_targets(7)
    b = generate_targets(7)
    assert [x.to_dict() for x in a] == [x.to_dict() for x in b]
    assert len(a) == 30
    assert sorted(Counter(x.family for x in a).values()) == [6, 6, 6, 6, 6]
```

- [x] **Step 2: Run dataset tests and confirm failure because generator is absent.**
- [x] **Step 3: Implement five family templates and seeded variant generation.**
- [x] **Step 4: Add observation extraction that exposes examples/probes but omits hidden scoring fields.**
- [x] **Step 5: Re-run tests and commit `feat: add deterministic BSAR dataset`.**

### Task 3: Three builders and frozen representation boundary

**Files:**
- Create: `src/pssa_bsar/builders.py`
- Create: `src/pssa_bsar/freezer.py`
- Test: `tests/test_builders.py`

**Interfaces:**
- Produces: `build_definition(obs, budget_bytes)`, `build_keywords(obs, budget_bytes)`, `build_address(obs, budget_bytes)`, `freeze_representation(rep, path)`, `load_frozen(path)`.

- [x] **Step 1: Write failing tests asserting all three builders stay under a provided UTF-8 budget and address-first contains no `concept_name` or prose `definition` field.**
- [x] **Step 2: Write failing freeze/load equality test.**
- [x] **Step 3: Run tests and verify expected failures.**
- [x] **Step 4: Implement deterministic builders. Definition-first emits concise prose; Keyword-first emits an ordered keyword list; Address-first emits the fixed typed ledger.**
- [x] **Step 5: Implement canonical JSON freezing with sorted keys and UTF-8 byte measurement.**
- [x] **Step 6: Re-run tests and commit `feat: add BSAR representation builders`.**

### Task 4: Deterministic recovery and scorer

**Files:**
- Create: `src/pssa_bsar/recovery.py`
- Create: `src/pssa_bsar/scoring.py`
- Test: `tests/test_recovery_scoring.py`

**Interfaces:**
- Produces: `recover(rep: FrozenRepresentation, eval_cases: list[Case]) -> RecoveryResult`, `score(target: GroundTruthTarget, result: RecoveryResult, representation_bytes: int) -> MetricVector`.

- [x] **Step 1: Write failing F1/UPS unit tests with hand-constructed gold and recovery structures.**
- [x] **Step 2: Write failing test that recovery decisions are deterministic and do not accept a `GroundTruthTarget` parameter.**
- [x] **Step 3: Run tests and confirm failures.**
- [x] **Step 4: Implement parsers for each frozen condition and a lexical-overlap/mock rule classifier using only recovered structure plus evaluation case descriptions.**
- [x] **Step 5: Implement HDA, ANA, typed relation F1, constraint F1, UPS, composite score, and efficiency.**
- [x] **Step 6: Re-run tests and commit `feat: add deterministic recovery and scoring`.**

### Task 5: End-to-end pipeline, report, and CLI

**Files:**
- Create: `src/pssa_bsar/pipeline.py`
- Create: `src/pssa_bsar/cli.py`
- Create: `tests/test_pipeline.py`
- Create: `README.md`

**Interfaces:**
- Produces: `run_mock_experiment(output_dir: Path, seed: int = 20260821, budget_bytes: int = 900) -> dict` and CLI `python -m pssa_bsar.cli run-mock --output <dir> --seed <n> --budget-bytes <n>`.

- [x] **Step 1: Write failing end-to-end test requiring output files `targets.jsonl`, `observations.jsonl`, `frozen_representations.jsonl`, `recoveries.jsonl`, `metrics.csv`, `summary.json`, and `REPORT.md`.**
- [x] **Step 2: Require `summary.json` to contain exactly 30 targets, three conditions, deterministic seed, and `evidence_status = "MOCK_PLUMBING_ONLY"`.**
- [x] **Step 3: Run pipeline test and confirm failure.**
- [x] **Step 4: Implement orchestration and CSV/JSON aggregation.**
- [x] **Step 5: Implement CLI and concise README commands.**
- [x] **Step 6: Run `pytest -q`; then execute a full mock run and compare two same-seed `summary.json` files byte-for-byte.**
- [x] **Step 7: Commit `feat: complete BSAR milestone 1 deterministic harness`.**

## Final Verification

Run:

```bash
pytest -q
python -m pssa_bsar.cli run-mock --output runs/mock-a --seed 20260821 --budget-bytes 900
python -m pssa_bsar.cli run-mock --output runs/mock-b --seed 20260821 --budget-bytes 900
cmp runs/mock-a/summary.json runs/mock-b/summary.json
```

Expected:
- all tests pass;
- both mock runs finish without network/API access;
- summary files are byte-identical;
- report explicitly labels results as mock plumbing evidence only.

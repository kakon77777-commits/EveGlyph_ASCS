# BSAR Dataset v0.2 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [x]`) syntax for tracking.

**Goal:** Add a leakage-audited BSAR Dataset v0.2 that removes obvious lexical shortcuts while preserving the existing Milestone 1/2 harness and scoring interfaces.

**Architecture:** Keep v0.1 dataset generation untouched. Add a separate `dataset_v2` module that emits the same `GroundTruthTarget` / `ObservationBundle` data types, plus a deterministic audit module and manifest. Add dataset-version selection to live/mock pipelines and CLI without changing adapter or scorer contracts.

**Tech Stack:** Python 3.13, standard library only, pytest 9, JSON/JSONL/CSV artifacts.

**Spec:** `docs/superpowers/specs/2026-08-21-PSSA-BSAR-v0.1-design.md`

## Global Constraints

- Preserve all existing v0.1 behavior and tests.
- Dataset v0.2 uses 30 targets across the same five concept families, six targets per family.
- v0.2 target IDs are opaque and must not encode family names.
- Builder-visible observations must not expose family labels or candidate categories.
- Canonical gold anchor, constraint, relation-node, and open-variable identifiers must not occur verbatim in builder-visible observation text.
- Holdout and adversarial descriptions must be independent paraphrases, not development strings with changed prefixes.
- Every target must include at least one adversarial negative containing a positive surface cue.
- Dataset generation and auditing must be deterministic for a fixed seed.
- No network, API key, model SDK, or external dependency is allowed.
- Existing adapter, parser, recovery, and scorer interfaces remain unchanged.

---

### Task 1: Dataset v0.2 Generator

**Files:**
- Create: `src/pssa_bsar/dataset_v2.py`
- Test: `tests/test_dataset_v2.py`

**Interfaces:**
- Produces: `generate_targets_v2(seed: int = 20260821, count: int = 30) -> list[GroundTruthTarget]`
- Produces: `make_observation_v2(target: GroundTruthTarget) -> ObservationBundle`

- [x] **Step 1: Write failing tests** for opaque IDs, deterministic generation, balanced families, hidden observation family/categories, case counts, and no exact sentence reuse.
- [x] **Step 2: Run `pytest tests/test_dataset_v2.py -q` and verify RED.**
- [x] **Step 3: Implement minimal deterministic v0.2 templates** with independently phrased development/holdout/adversarial cases.
- [x] **Step 4: Run `pytest tests/test_dataset_v2.py -q` and verify GREEN.**
- [x] **Step 5: Commit** as `feat: add leakage-resistant BSAR dataset v0.2`.

### Task 2: Leakage Audit and Dataset Manifest

**Files:**
- Create: `src/pssa_bsar/dataset_audit.py`
- Test: `tests/test_dataset_audit.py`

**Interfaces:**
- Produces: `audit_target_v2(target, observation) -> dict`
- Produces: `audit_dataset_v2(targets, observations, seed) -> dict`
- Produces: `write_dataset_manifest(path: Path, report: dict) -> None`

- [x] **Step 1: Write failing tests** for canonical identifier leakage, opaque IDs, hidden family/category, cross-split exact reuse, bigram-overlap threshold, adversarial cue presence, and deterministic manifest hash.
- [x] **Step 2: Run audit tests and verify RED.**
- [x] **Step 3: Implement normalization, sensitive-term scan, split-overlap checks, adversarial-cue check, per-target verdicts, and canonical SHA-256 manifest hashing.**
- [x] **Step 4: Run audit tests and verify GREEN.**
- [x] **Step 5: Commit** as `feat: add deterministic BSAR dataset leakage audit`.

### Task 3: Dataset Registry and Pipeline Selection

**Files:**
- Create: `src/pssa_bsar/datasets.py`
- Modify: `src/pssa_bsar/pipeline.py`
- Modify: `src/pssa_bsar/live_pipeline.py`
- Test: `tests/test_dataset_registry.py`
- Test: `tests/test_pipeline_dataset_v2.py`

**Interfaces:**
- Produces: `load_dataset(version: str, seed: int, count: int = 30) -> tuple[list[GroundTruthTarget], list[ObservationBundle], dict | None]`
- Existing `run_mock_experiment(...)` gains optional `dataset_version: str = "v0.1"`.
- Existing `run_live_protocol(...)` gains optional `dataset_version: str = "v0.1"`.

- [x] **Step 1: Write failing tests** that v0.1 remains byte-compatible, v0.2 returns a passing audit report, and both pipelines emit dataset metadata.
- [x] **Step 2: Run tests and verify RED.**
- [x] **Step 3: Implement dataset registry and minimal pipeline wiring.**
- [x] **Step 4: Run tests and full suite; verify GREEN.**
- [x] **Step 5: Commit** as `feat: add dataset version selection to BSAR pipelines`.

### Task 4: CLI and Audit Artifact

**Files:**
- Modify: `src/pssa_bsar/cli.py`
- Modify: `README.md`
- Test: `tests/test_cli_dataset_v2.py`

**Interfaces:**
- Add `--dataset-version {v0.1,v0.2}` to run commands.
- Add `audit-dataset` command with `--dataset-version v0.2`, `--seed`, and `--output`.

- [x] **Step 1: Write failing CLI tests** for dataset selection and `audit-dataset` output.
- [x] **Step 2: Run tests and verify RED.**
- [x] **Step 3: Implement CLI flags/command and README documentation.**
- [x] **Step 4: Run targeted and full tests; verify GREEN.**
- [x] **Step 5: Commit** as `feat: expose BSAR dataset v0.2 audit CLI`.

### Task 5: Deterministic Verification Run

**Files:**
- Create: `docs/verification/2026-08-21-bsar-milestone3.md`

**Interfaces:**
- Produces audited dataset artifacts and a mock v0.2 report outside the source tree.

- [x] **Step 1: Run the full test suite.**
- [x] **Step 2: Run `audit-dataset` twice with the same seed and compare manifest byte-for-byte.**
- [x] **Step 3: Run deterministic mock v0.2 twice and compare targets, observations, manifest, summary, metrics, frozen representations, and recoveries byte-for-byte.**
- [x] **Step 4: Record exact verification evidence and limitations.**
- [x] **Step 5: Commit** as `docs: record BSAR milestone 3 verification`.

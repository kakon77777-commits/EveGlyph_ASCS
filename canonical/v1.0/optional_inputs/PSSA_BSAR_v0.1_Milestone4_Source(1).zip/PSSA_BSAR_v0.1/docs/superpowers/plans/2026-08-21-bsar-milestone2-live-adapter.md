# PSSA BSAR Milestone 2 Live-Adapter Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [x]`) syntax for tracking.

**Goal:** Add a provider-agnostic, live-capable but fully offline-testable model-adapter layer to BSAR, with isolated builder/recovery requests, strict prompt/output contracts, budget validation, replayable run ledgers, and failure capture.

**Architecture:** Keep Milestone 1 deterministic components unchanged. Add a request/response adapter protocol, a subprocess JSON adapter for real external model wrappers, and a replay adapter for deterministic offline verification. A live protocol runner generates prompts, invokes builders in isolated requests, freezes only parsed representations, invokes recovery in fresh requests, records every raw interaction, and scores only successfully recovered targets.

**Tech Stack:** Python 3.13 standard library, `pytest` 9, JSON/JSONL/CSV, `subprocess`, `hashlib`, `argparse`; no third-party runtime dependencies.

**Spec:** `docs/superpowers/specs/2026-08-21-PSSA-BSAR-v0.1-design.md`

## Global Constraints

- Milestone 2 must remain fully testable with no network and no API key.
- No provider-specific SDK is added.
- Builder and recovery calls are separate adapter invocations with unique request IDs.
- Recovery receives only the frozen representation and public evaluation cases.
- Every prompt, response, parse result, error, byte count, and hash is persisted.
- Invalid JSON/schema or over-budget builder output is recorded as a failure; it is never silently repaired or truncated.
- Replay of a recorded interaction ledger must reproduce the same parsed artifacts and summary byte-for-byte.
- Live-protocol outputs must use `evidence_status = "LIVE_PROTOCOL_ONLY_NOT_SCIENTIFIC"` until a leakage-audited dataset replaces Milestone 1 templates.

---

### Task 1: Adapter request/response protocol and replay adapter

**Files:**
- Create: `src/pssa_bsar/adapters.py`
- Test: `tests/test_adapters.py`

**Interfaces:**
- `ModelRequest(request_id: str, stage: str, target_id: str, condition: str, prompt: str, metadata: dict[str, object])`
- `ModelResponse(request_id: str, text: str, provider: str, model: str, metadata: dict[str, object])`
- `ModelAdapter.generate(request: ModelRequest) -> ModelResponse`
- `ReplayAdapter(responses: dict[str, ModelResponse])`

- [x] Write failing round-trip and replay tests.
- [x] Run tests and confirm missing implementation failure.
- [x] Implement immutable request/response dataclasses, SHA-256 prompt hashing helper, protocol, and replay adapter.
- [x] Re-run tests and commit `feat: add BSAR model adapter protocol`.

### Task 2: Subprocess JSON adapter

**Files:**
- Modify: `src/pssa_bsar/adapters.py`
- Test: `tests/test_subprocess_adapter.py`
- Create: `tests/fixtures/adapter_echo.py`

**Interfaces:**
- `SubprocessJsonAdapter(command: list[str], timeout_seconds: float = 120.0)`
- stdin request JSON; stdout response JSON with required `text` and optional `provider`, `model`, `metadata`.

- [x] Write failing success, nonzero-exit, timeout, malformed-JSON, and request-id-mismatch tests.
- [x] Run tests and confirm failures.
- [x] Implement subprocess adapter with captured stdout/stderr and typed `AdapterError`.
- [x] Re-run tests and commit `feat: add subprocess JSON model adapter`.

### Task 3: Prompt contracts and strict parsers

**Files:**
- Create: `src/pssa_bsar/prompts.py`
- Create: `src/pssa_bsar/parsing.py`
- Test: `tests/test_prompts_parsing.py`

**Interfaces:**
- `builder_prompt(obs, condition, budget_bytes) -> str`
- `recovery_prompt(rep, eval_cases) -> str`
- `parse_builder_response(condition, target_id, text, budget_bytes) -> FrozenRepresentation`
- `parse_recovery_response(target_id, condition, text) -> RecoveryResult`

- [x] Write failing tests for condition-specific prompt prohibitions and schemas.
- [x] Write failing parser tests for valid JSON, prose contamination, missing fields, over-budget output, and unknown-field preservation.
- [x] Implement minimal prompt templates and strict parsers.
- [x] Re-run tests and commit `feat: add live prompt and parsing contracts`.

### Task 4: Interaction ledger and failure records

**Files:**
- Create: `src/pssa_bsar/ledger.py`
- Test: `tests/test_ledger.py`

**Interfaces:**
- `InteractionRecord` with request ID, stage, target, condition, prompt hash, prompt bytes, raw response, response bytes, status, error type/message, provider/model, timestamps/sequence index.
- `RunLedger.write_jsonl(path)` / `RunLedger.from_jsonl(path)`.

- [x] Write failing deterministic serialization and failure-record tests.
- [x] Implement ledger with stable sequence numbers and canonical JSON.
- [x] Re-run tests and commit `feat: add BSAR interaction ledger`.

### Task 5: Live-protocol runner

**Files:**
- Create: `src/pssa_bsar/live_pipeline.py`
- Test: `tests/test_live_pipeline.py`

**Interfaces:**
- `run_live_protocol(output_dir: Path, adapter: ModelAdapter, seed: int = 20260821, budget_bytes: int = 900) -> dict`

- [x] Write failing end-to-end replay-backed test requiring `requests.jsonl`, `frozen_representations.jsonl`, `recoveries.jsonl`, `failures.jsonl`, `metrics.csv`, `summary.json`, and `REPORT.md`.
- [x] Assert 90 builder requests for 30 targets x 3 conditions and fresh recovery request IDs for successful builders.
- [x] Assert recovery prompts contain frozen representation + public eval cases but not hidden target fields.
- [x] Implement orchestration, scoring only for successful recoveries, and explicit failure aggregation.
- [x] Re-run tests and commit `feat: add live BSAR protocol runner`.

### Task 6: Replay determinism and CLI

**Files:**
- Modify: `src/pssa_bsar/cli.py`
- Create: `src/pssa_bsar/replay.py`
- Modify: `README.md`
- Test: `tests/test_live_cli_replay.py`

**Interfaces:**
- `recorded_responses_from_ledger(path: Path) -> dict[str, ModelResponse]`
- CLI `run-live-command --command-json <json-array> --output <dir> ...`
- CLI `run-replay --ledger <requests.jsonl> --output <dir> ...`

- [x] Write failing CLI/replay tests.
- [x] Implement command adapter CLI and replay loader.
- [x] Verify replay output summary and metrics are byte-identical to the original scripted run.
- [x] Update README with adapter stdin/stdout contract and evidence boundary.
- [x] Run full suite and commit `feat: complete BSAR milestone 2 live adapter harness`.

## Final Verification

Run:

```bash
pytest -q
python -m pssa_bsar.cli run-live-command \
  --command-json '["python","tests/fixtures/adapter_echo.py"]' \
  --output /mnt/data/bsar-live-a --seed 20260821 --budget-bytes 900
python -m pssa_bsar.cli run-replay \
  --ledger /mnt/data/bsar-live-a/requests.jsonl \
  --output /mnt/data/bsar-live-b --seed 20260821 --budget-bytes 900
cmp /mnt/data/bsar-live-a/summary.json /mnt/data/bsar-live-b/summary.json
cmp /mnt/data/bsar-live-a/metrics.csv /mnt/data/bsar-live-b/metrics.csv
```

Expected:
- all tests pass;
- command-adapter run completes without network/API access;
- replay reproduces parsed/scored outputs byte-for-byte;
- failures are explicit artifacts, never hidden;
- report states `LIVE_PROTOCOL_ONLY_NOT_SCIENTIFIC`.

# BSAR Milestone 4 Verification Record

Date: 2026-08-21
Branch: `feature/bsar-milestone4-controlled-live`
Scope: preregistered controlled Gate 1 scheduling, repeated trials, target-level paired analysis, controlled live/replay CLI.

## Full test suite

Command:

```bash
pytest -q
```

Observed before release artifact generation:

```text
73 passed in 11.06s
```

## Frozen fixture control manifest

Command:

```bash
python -m pssa_bsar.cli plan-controlled-run \
  --output /mnt/data/PSSA_BSAR_M4_final_plan \
  --dataset-seed 20260821 \
  --schedule-seed 424242 \
  --trials-per-target 3 \
  --budget-bytes 900 \
  --expected-provider fixture-shell \
  --expected-model protocol-v1 \
  --sampling-json '{"temperature":0.0,"top_p":1.0,"seed_mode":"paired_trial"}' \
  --analysis-seed 777
```

Observed manifest SHA-256:

```text
1915b34ae55e0911c6231bb26010dc8af68d325ef524bec6bd828b6ff20bc93d
```

Observed schedule SHA-256:

```text
7f16fc2780d419ab4a8ad5560e3f0a9f0384d6c84e609c9ef79019a769deee9c
```

Dataset SHA-256:

```text
13c3b9ce3368f92b25f59beb2578aef5ce3752c437b3fc0830f778caa758599e
```

## Controlled fixture live run

Command:

```bash
python -m pssa_bsar.cli run-controlled-live-command \
  --manifest /mnt/data/PSSA_BSAR_M4_final_plan/control_manifest.json \
  --command-json '["sh","tests/fixtures/adapter_protocol.sh"]' \
  --output /mnt/data/PSSA_BSAR_M4_final_live \
  --timeout-seconds 10
```

Observed:

```text
90 trial blocks
270 builder successes / 0 failures
270 recovery successes / 0 failures
540 isolated requests
provider/model identities: fixture-shell / protocol-v1 only
recovery hidden-gold leakage checks: 0
```

This fixture deliberately has no semantic recovery capability. Its quantitative Gate 1 status is therefore:

```text
QUANTITATIVE_FAIL
```

That result is expected and confirms that protocol success is not automatically converted into evidence for PSSA.

## Schedule balance

For 90 `(target, trial)` blocks, all six condition permutations occurred exactly 15 times each.

Each condition appeared exactly 30 times in each ordinal position 1, 2, and 3.

Thus condition-order balance is exact for this verification schedule.

## Controlled replay

Command:

```bash
python -m pssa_bsar.cli run-controlled-replay \
  --manifest /mnt/data/PSSA_BSAR_M4_final_plan/control_manifest.json \
  --ledger /mnt/data/PSSA_BSAR_M4_final_live/requests.jsonl \
  --output /mnt/data/PSSA_BSAR_M4_final_replay
```

Observed live/replay file sets were identical. The following 16 files were byte-for-byte identical:

```text
REPORT.md
control_manifest.json
dataset_manifest.json
failures.jsonl
frozen_representations.jsonl
gate1_evaluation.json
observations.jsonl
paired_analysis.json
paired_target_means.csv
paired_trial_differences.csv
recoveries.jsonl
requests.jsonl
summary.json
targets.jsonl
trial_metrics.csv
trial_schedule.jsonl
```

The copied manifest and schedule also matched the originally frozen planning artifacts byte-for-byte.

## Paired-analysis boundary

The analysis unit is:

```text
target_level_mean_across_repeated_trials
```

Repeated trials are paired within target before cross-target summaries. Raw trial count is not used as the independent sample count for bootstrap confidence intervals or win/tie/loss summaries.

`gate1_evaluation.json` retains the preregistered manual leakage review as:

```text
NOT_EVALUATED
```

Automatic Dataset v0.2 leakage audit is not substituted for that manual requirement.

## Evidence boundary

Milestone 4 demonstrates:

- preregistration-by-manifest;
- deterministic balanced scheduling;
- strict model identity checks;
- paired trial seeds and frozen sampling metadata;
- builder/recovery isolation;
- target-level paired analysis;
- byte-identical replay.

It does **not** demonstrate that PSSA is empirically superior, and it does not establish a biological or model-internal pre-linguistic semantic address mechanism.

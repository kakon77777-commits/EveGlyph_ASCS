# PSSA-BSAR Milestone 3 Verification Record

**Milestone:** Leakage-Audited Semantic Targets v0.2
**Date:** 2026-08-21
**Branch:** `feature/bsar-milestone3-dataset-v02`
**Evidence boundary:** Dataset audit and harness verification only. No claim of PSSA validity or model-internal pre-symbolic addressing is made from mock/fixture results.

## Fresh Verification

### Test suite

```text
58 passed in 5.19s
```

Command:

```bash
python -m pytest -q
```

`python -m compileall -q src` also completed successfully.

### Dataset v0.2 audit

Two independent deterministic audit runs with seed `20260821` were generated and compared byte-for-byte for:

- `dataset_manifest.json`
- `targets.jsonl`
- `observations.jsonl`

Result:

```text
30 pass / 0 fail
```

Canonical dataset content hash reported by the manifest:

```text
13c3b9ce3368f92b25f59beb2578aef5ce3752c437b3fc0830f778caa758599e
```

Maximum development-to-evaluation bigram Jaccard observed:

```text
0.236842105263
```

Preregistered threshold:

```text
<= 0.30
```

### Deterministic mock v0.2

Two independent runs with identical seed/budget were compared byte-for-byte for:

- `targets.jsonl`
- `observations.jsonl`
- `dataset_manifest.json`
- `frozen_representations.jsonl`
- `recoveries.jsonl`
- `metrics.csv`
- `summary.json`
- `REPORT.md`

Evidence status:

```text
MOCK_AUDITED_DATASET_NOT_SCIENTIFIC
```

Artifact SHA-256 values from the verified mock run:

```text
dataset_manifest.json e00708f1d3b3ea2adb9766f52b096218badaad0121b83c9051b3256423421bb0
summary.json          884538cb965cddefbf1c42a47a4a6d3841748c211f5626b24cb386db083d7454
metrics.csv           0803a06dd7bbdaf25b70756b930852014ce505c369664cd865c76394eea752a5
```

### Live fixture + replay v0.2

The provider-agnostic subprocess fixture completed:

```text
builder success/failure: 90 / 0
recovery success/failure: 90 / 0
total isolated requests: 180
```

The live run and replay run were byte-identical for:

- `targets.jsonl`
- `observations.jsonl`
- `dataset_manifest.json`
- `requests.jsonl`
- `frozen_representations.jsonl`
- `recoveries.jsonl`
- `failures.jsonl`
- `metrics.csv`
- `summary.json`
- `REPORT.md`

Recovery request scan found:

```text
hidden gold/development-label leakage = 0
```

### Dataset audit behavior verified by tests

The audit suite explicitly proves that the validator rejects:

- canonical identifier leakage into builder-visible observation text;
- exact development/holdout/adversarial sentence reuse;
- adversarial negatives with no positive surface cue;
- non-opaque target metadata through the normal v0.2 policy.

## Interpretation

Milestone 3 upgrades BSAR from a plumbing-grade synthetic surface to a deterministic leakage-audited synthetic benchmark surface. It does **not** yet establish a scientific advantage for Address-first representations. The built-in mock builders are deterministic plumbing fixtures, not experimental subjects.

The next empirical step is a controlled live-model Gate 1 run using Dataset v0.2 with frozen model/version, decoding policy, representation budget, repetition protocol, and preregistered comparison statistics.

# BSAR Milestone 2 Verification — 2026-08-21

Branch: `feature/bsar-milestone2-live`

## Fresh verification commands

```bash
python -m pip install -e . --no-build-isolation
pytest -q
python -m compileall -q src
python -m pssa_bsar.cli run-live-command \
  --command-json '["/bin/sh","tests/fixtures/adapter_protocol.sh"]' \
  --output /mnt/data/PSSA_BSAR_M2_verify_live \
  --seed 20260821 \
  --budget-bytes 900 \
  --timeout-seconds 5
python -m pssa_bsar.cli run-replay \
  --ledger /mnt/data/PSSA_BSAR_M2_verify_live/requests.jsonl \
  --output /mnt/data/PSSA_BSAR_M2_verify_replay \
  --seed 20260821 \
  --budget-bytes 900
cmp live/summary.json replay/summary.json
cmp live/metrics.csv replay/metrics.csv
cmp live/frozen_representations.jsonl replay/frozen_representations.jsonl
cmp live/recoveries.jsonl replay/recoveries.jsonl
cmp live/requests.jsonl replay/requests.jsonl
```

## Observed results

- `pytest`: **39 passed**.
- Live protocol: **30 targets**, **90 builder successes**, **90 recovery successes**, **0 failures**.
- Interaction ledger: **180 isolated requests**.
- Metrics: **90 rows**.
- Replay comparison: summary, metrics, frozen representations, recoveries, and interaction ledger were byte-identical.
- Evidence status remains `LIVE_PROTOCOL_ONLY_NOT_SCIENTIFIC` because the Milestone 1 synthetic surface is intentionally machine-readable and has not yet been replaced by a leakage-audited dataset.

## Review checks

- No provider-specific model SDK/runtime dependency in `src/`.
- Recovery prompt carries only frozen representation and public evaluation cases (`label = null`).
- Adapter/parser/budget failures are written as first-class ledger failures; no silent repair or truncation.
- Replay verifies prompt SHA-256 before returning a recorded response.
- No generated cache/run files are tracked by git.

from __future__ import annotations

import hashlib
import json
import subprocess
from dataclasses import asdict, dataclass
from typing import Any, Protocol


@dataclass(frozen=True)
class ModelRequest:
    request_id: str
    stage: str
    target_id: str
    condition: str
    prompt: str
    metadata: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ModelRequest":
        return cls(**data)


@dataclass(frozen=True)
class ModelResponse:
    request_id: str
    text: str
    provider: str
    model: str
    metadata: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ModelResponse":
        return cls(**data)


def prompt_sha256(prompt: str) -> str:
    return hashlib.sha256(prompt.encode("utf-8")).hexdigest()


class ModelAdapter(Protocol):
    def generate(self, request: ModelRequest) -> ModelResponse:
        ...


class ReplayAdapter:
    def __init__(
        self,
        responses: dict[str, ModelResponse],
        prompt_hashes: dict[str, str] | None = None,
    ):
        self._responses = dict(responses)
        self._prompt_hashes = dict(prompt_hashes or {})

    def generate(self, request: ModelRequest) -> ModelResponse:
        try:
            response = self._responses[request.request_id]
        except KeyError as exc:
            raise KeyError(f"no recorded response for request_id={request.request_id}") from exc
        expected_hash = self._prompt_hashes.get(request.request_id)
        if expected_hash is not None and prompt_sha256(request.prompt) != expected_hash:
            raise ValueError(f"prompt hash mismatch for request_id={request.request_id}")
        if response.request_id != request.request_id:
            raise ValueError("recorded response request_id mismatch")
        return response


class AdapterError(RuntimeError):
    def __init__(self, kind: str, message: str, *, stdout: str = "", stderr: str = ""):
        super().__init__(f"{kind}: {message}")
        self.kind = kind
        self.stdout = stdout
        self.stderr = stderr


class SubprocessJsonAdapter:
    def __init__(self, command: list[str], timeout_seconds: float = 120.0):
        if not command:
            raise ValueError("command must not be empty")
        if timeout_seconds <= 0:
            raise ValueError("timeout_seconds must be positive")
        self.command = list(command)
        self.timeout_seconds = float(timeout_seconds)

    def generate(self, request: ModelRequest) -> ModelResponse:
        payload = json.dumps(request.to_dict(), ensure_ascii=False, sort_keys=True)
        try:
            completed = subprocess.run(
                self.command,
                input=payload,
                text=True,
                capture_output=True,
                timeout=self.timeout_seconds,
                check=False,
            )
        except subprocess.TimeoutExpired as exc:
            raise AdapterError(
                "timeout",
                f"adapter exceeded {self.timeout_seconds}s",
                stdout=(exc.stdout or "") if isinstance(exc.stdout, str) else "",
                stderr=(exc.stderr or "") if isinstance(exc.stderr, str) else "",
            ) from exc
        if completed.returncode != 0:
            raise AdapterError(
                "nonzero_exit",
                f"adapter exited with code {completed.returncode}",
                stdout=completed.stdout,
                stderr=completed.stderr,
            )
        try:
            data = json.loads(completed.stdout)
        except json.JSONDecodeError as exc:
            raise AdapterError(
                "malformed_json", str(exc), stdout=completed.stdout, stderr=completed.stderr
            ) from exc
        try:
            response = ModelResponse.from_dict({
                "request_id": data["request_id"],
                "text": data["text"],
                "provider": data.get("provider", "subprocess"),
                "model": data.get("model", "external"),
                "metadata": data.get("metadata", {}),
            })
        except (KeyError, TypeError) as exc:
            raise AdapterError(
                "invalid_response_schema", str(exc), stdout=completed.stdout, stderr=completed.stderr
            ) from exc
        if response.request_id != request.request_id:
            raise AdapterError(
                "request_id_mismatch",
                f"expected {request.request_id}, got {response.request_id}",
                stdout=completed.stdout,
                stderr=completed.stderr,
            )
        return response

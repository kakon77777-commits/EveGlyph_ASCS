from __future__ import annotations

import argparse
import json
from pathlib import Path

from .adapters import SubprocessJsonAdapter
from .control import build_control_manifest, load_control_manifest, write_control_manifest
from .controlled_pipeline import run_controlled_protocol
from .datasets import SUPPORTED_DATASET_VERSIONS, load_dataset
from .live_pipeline import run_live_protocol
from .pipeline import run_mock_experiment
from .replay import replay_adapter_from_ledger


def _add_dataset_arg(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--dataset-version", choices=SUPPORTED_DATASET_VERSIONS, default="v0.1")


def _add_common_live_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--seed", type=int, default=20260821)
    parser.add_argument("--budget-bytes", type=int, default=900)
    _add_dataset_arg(parser)


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="pssa-bsar", description="PSSA Blind Semantic Address Recovery harness")
    sub = parser.add_subparsers(dest="command", required=True)

    mock = sub.add_parser("run-mock", help="run the deterministic no-API Milestone 1 pipeline")
    mock.add_argument("--output", type=Path, required=True)
    mock.add_argument("--seed", type=int, default=20260821)
    mock.add_argument("--budget-bytes", type=int, default=900)
    _add_dataset_arg(mock)

    audit = sub.add_parser("audit-dataset", help="generate and audit the leakage-controlled dataset")
    audit.add_argument("--output", type=Path, required=True)
    audit.add_argument("--seed", type=int, default=20260821)
    audit.add_argument("--dataset-version", choices=("v0.2",), default="v0.2")

    live = sub.add_parser("run-live-command", help="run live protocol through an external JSON stdin/stdout command")
    live.add_argument("--command-json", required=True, help='JSON array, e.g. ["python","wrapper.py"]')
    live.add_argument("--timeout-seconds", type=float, default=120.0)
    _add_common_live_args(live)

    replay = sub.add_parser("run-replay", help="replay recorded model responses with prompt-hash verification")
    replay.add_argument("--ledger", type=Path, required=True)
    _add_common_live_args(replay)

    plan = sub.add_parser("plan-controlled-run", help="freeze a preregistered Dataset v0.2 Gate 1 control manifest")
    plan.add_argument("--output", type=Path, required=True)
    plan.add_argument("--dataset-seed", type=int, default=20260821)
    plan.add_argument("--schedule-seed", type=int, default=424242)
    plan.add_argument("--trials-per-target", type=int, default=5)
    plan.add_argument("--budget-bytes", type=int, default=900)
    plan.add_argument("--expected-provider", required=True)
    plan.add_argument("--expected-model", required=True)
    plan.add_argument("--sampling-json", required=True, help="JSON object frozen into every request metadata record")
    plan.add_argument("--analysis-seed", type=int, default=777)
    plan.add_argument("--hda-noninferiority-margin", type=float, default=0.05)
    plan.add_argument("--ana-min-delta", type=float, default=0.0)
    plan.add_argument("--meaningful-structural-delta", type=float, default=0.05)

    controlled_live = sub.add_parser(
        "run-controlled-live-command",
        help="execute a preregistered controlled Gate 1 manifest through an external command",
    )
    controlled_live.add_argument("--manifest", type=Path, required=True)
    controlled_live.add_argument("--command-json", required=True)
    controlled_live.add_argument("--output", type=Path, required=True)
    controlled_live.add_argument("--timeout-seconds", type=float, default=120.0)

    controlled_replay = sub.add_parser(
        "run-controlled-replay",
        help="replay a preregistered controlled Gate 1 ledger using the same frozen manifest",
    )
    controlled_replay.add_argument("--manifest", type=Path, required=True)
    controlled_replay.add_argument("--ledger", type=Path, required=True)
    controlled_replay.add_argument("--output", type=Path, required=True)
    return parser


def _command_array(raw: str) -> list[str]:
    try:
        value = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise SystemExit(f"--command-json must be valid JSON: {exc}") from exc
    if not isinstance(value, list) or not value or any(not isinstance(x, str) or not x for x in value):
        raise SystemExit("--command-json must be a non-empty JSON array of non-empty strings")
    return value


def _json_object(raw: str, flag: str) -> dict:
    try:
        value = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise SystemExit(f"{flag} must be valid JSON: {exc}") from exc
    if not isinstance(value, dict):
        raise SystemExit(f"{flag} must be a JSON object")
    return value


def _write_jsonl(path: Path, rows) -> None:
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n")


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    if args.command == "run-mock":
        summary = run_mock_experiment(args.output, seed=args.seed, budget_bytes=args.budget_bytes, dataset_version=args.dataset_version)
        print(f"BSAR mock complete: {summary['target_count']} targets -> {args.output}")
        print(f"Evidence status: {summary['evidence_status']}")
        return 0
    if args.command == "audit-dataset":
        targets, observations, manifest = load_dataset(args.dataset_version, seed=args.seed, count=30)
        if manifest is None:
            raise SystemExit("selected dataset has no leakage-audit manifest")
        args.output.mkdir(parents=True, exist_ok=True)
        for name, rows in (("targets.jsonl", targets), ("observations.jsonl", observations)):
            with (args.output / name).open("w", encoding="utf-8", newline="\n") as handle:
                for row in rows:
                    handle.write(json.dumps(row.to_dict(), ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n")
        (args.output / "dataset_manifest.json").write_text(
            json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
            encoding="utf-8",
            newline="\n",
        )
        print(f"BSAR dataset audit complete: {manifest['pass_count']} pass / {manifest['fail_count']} fail -> {args.output}")
        return 0
    if args.command == "run-live-command":
        adapter = SubprocessJsonAdapter(_command_array(args.command_json), timeout_seconds=args.timeout_seconds)
        summary = run_live_protocol(args.output, adapter, seed=args.seed, budget_bytes=args.budget_bytes, dataset_version=args.dataset_version)
        print(f"BSAR live protocol complete: {summary['target_count']} targets -> {args.output}")
        print(f"Evidence status: {summary['evidence_status']}")
        return 0
    if args.command == "run-replay":
        adapter = replay_adapter_from_ledger(args.ledger)
        summary = run_live_protocol(args.output, adapter, seed=args.seed, budget_bytes=args.budget_bytes, dataset_version=args.dataset_version)
        print(f"BSAR replay complete: {summary['target_count']} targets -> {args.output}")
        print(f"Evidence status: {summary['evidence_status']}")
        return 0
    if args.command == "plan-controlled-run":
        targets, observations, dataset_manifest = load_dataset("v0.2", seed=args.dataset_seed, count=30)
        if dataset_manifest is None:
            raise SystemExit("Dataset v0.2 audit manifest missing")
        sampling_policy = _json_object(args.sampling_json, "--sampling-json")
        manifest = build_control_manifest(
            targets=targets,
            dataset_manifest=dataset_manifest,
            dataset_seed=args.dataset_seed,
            schedule_seed=args.schedule_seed,
            trials_per_target=args.trials_per_target,
            budget_bytes=args.budget_bytes,
            expected_provider=args.expected_provider,
            expected_model=args.expected_model,
            sampling_policy=sampling_policy,
            analysis_seed=args.analysis_seed,
            success_thresholds={
                "hda_noninferiority_margin": args.hda_noninferiority_margin,
                "ana_min_delta": args.ana_min_delta,
                "meaningful_structural_delta": args.meaningful_structural_delta,
            },
        )
        args.output.mkdir(parents=True, exist_ok=True)
        write_control_manifest(args.output / "control_manifest.json", manifest)
        _write_jsonl(args.output / "trial_schedule.jsonl", (item.to_dict() for item in manifest.schedule))
        (args.output / "dataset_manifest.json").write_text(
            json.dumps(dataset_manifest, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
            encoding="utf-8",
            newline="\n",
        )
        _write_jsonl(args.output / "observations.jsonl", (obs.to_dict() for obs in observations))
        print(f"BSAR controlled manifest frozen: {manifest.manifest_sha256} -> {args.output}")
        return 0
    if args.command == "run-controlled-live-command":
        manifest = load_control_manifest(args.manifest)
        adapter = SubprocessJsonAdapter(_command_array(args.command_json), timeout_seconds=args.timeout_seconds)
        summary = run_controlled_protocol(args.output, manifest, adapter)
        print(f"BSAR controlled live complete: {summary['trial_block_count']} blocks -> {args.output}")
        print(f"Evidence status: {summary['evidence_status']}")
        return 0
    if args.command == "run-controlled-replay":
        manifest = load_control_manifest(args.manifest)
        adapter = replay_adapter_from_ledger(args.ledger)
        summary = run_controlled_protocol(args.output, manifest, adapter)
        print(f"BSAR controlled replay complete: {summary['trial_block_count']} blocks -> {args.output}")
        print(f"Evidence status: {summary['evidence_status']}")
        return 0
    return 2


if __name__ == "__main__":
    raise SystemExit(main())

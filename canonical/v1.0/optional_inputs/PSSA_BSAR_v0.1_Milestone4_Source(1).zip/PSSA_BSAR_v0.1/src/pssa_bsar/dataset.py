from __future__ import annotations

import random
from dataclasses import dataclass

from .models import Case, GroundTruthTarget, ObservationBundle, Relation


@dataclass(frozen=True)
class _FamilySpec:
    family: str
    category: str
    positive: tuple[str, str, str]
    negative: tuple[str, str, str]
    relations: tuple[tuple[str, str, str, int], ...]
    constraints: tuple[str, str]
    open_variable: str
    variants: tuple[tuple[str, str], ...]


_FAMILY_SPECS = (
    _FamilySpec(
        "identity_continuity",
        "identity",
        ("continuity", "provenance", "responsibility"),
        ("mere_copy", "visual_similarity", "snapshot_equivalence"),
        (
            ("provenance", "supports", "continuity", 1),
            ("continuity", "supports", "responsibility", 1),
            ("mere_copy", "insufficient_for", "continuity", -1),
        ),
        ("history_must_be_traceable", "untracked_copy_is_insufficient"),
        "continuity_threshold",
        (
            ("lineage", "name_match"),
            ("state_transition", "shape_match"),
            ("accountability", "memoryless_clone"),
            ("temporal_link", "single_snapshot"),
            ("version_chain", "appearance_only"),
            ("causal_history", "token_identity"),
        ),
    ),
    _FamilySpec(
        "causality_intervention",
        "causality",
        ("intervention", "counterfactual", "mechanism"),
        ("correlation_only", "temporal_coincidence", "confounding"),
        (
            ("intervention", "changes", "outcome", 1),
            ("mechanism", "mediates", "outcome", 1),
            ("correlation_only", "insufficient_for", "causality", -1),
        ),
        ("controlled_change_required", "alternative_explanations_tracked"),
        "intervention_strength",
        (
            ("invariance_break", "co_movement"),
            ("causal_path", "sequence_only"),
            ("manipulability", "shared_trend"),
            ("response_shift", "selection_bias"),
            ("mechanism_trace", "common_cause"),
            ("counterfactual_gap", "posthoc_story"),
        ),
    ),
    _FamilySpec(
        "boundary_access",
        "boundary",
        ("access_control", "directionality", "threshold"),
        ("mere_difference", "unrestricted_passage", "symmetric_assumption"),
        (
            ("threshold", "conditions", "access_control", 1),
            ("directionality", "modulates", "passage", 1),
            ("mere_difference", "insufficient_for", "boundary_effect", -1),
        ),
        ("effect_channel_must_be_specified", "threshold_requires_context"),
        "boundary_strength",
        (
            ("selective_passage", "coordinate_difference"),
            ("one_way_gate", "bidirectional_default"),
            ("permission_edge", "visual_marker"),
            ("activation_limit", "arbitrary_cut"),
            ("transition_cost", "free_crossing"),
            ("reachability_limit", "label_only"),
        ),
    ),
    _FamilySpec(
        "reconstruction_recoverability",
        "reconstruction",
        ("recoverability", "redundancy", "provenance"),
        ("surface_similarity", "irreversible_loss", "guess_only"),
        (
            ("redundancy", "supports", "recoverability", 1),
            ("provenance", "constrains", "reconstruction", 1),
            ("guess_only", "insufficient_for", "recovery", -1),
        ),
        ("reconstruction_must_be_auditable", "uncertainty_must_be_marked"),
        "recoverability_threshold",
        (
            ("version_trace", "lookalike_output"),
            ("independent_evidence", "single_guess"),
            ("error_detection", "silent_corruption"),
            ("repair_path", "unverifiable_fill"),
            ("source_chain", "source_free_copy"),
            ("rollback_point", "irreversible_overwrite"),
        ),
    ),
    _FamilySpec(
        "intention_specification",
        "intention",
        ("goal", "constraint", "verification"),
        ("wish_only", "unbounded_command", "implicit_failure"),
        (
            ("constraint", "bounds", "goal", 1),
            ("verification", "checks", "goal", 1),
            ("wish_only", "insufficient_for", "specification", -1),
        ),
        ("failure_handling_must_be_explicit", "forbidden_paths_must_be_recorded"),
        "goal_tolerance",
        (
            ("acceptance_test", "vague_preference"),
            ("resource_bound", "infinite_budget"),
            ("rollback_rule", "fire_and_forget"),
            ("method_scope", "any_method"),
            ("success_criterion", "subjective_wish"),
            ("risk_boundary", "unstated_risk"),
        ),
    ),
)


def _case_set(spec: _FamilySpec, variant_pos: str, variant_neg: str, target_id: str) -> tuple[tuple[Case, ...], tuple[Case, ...], tuple[Case, ...]]:
    p0, p1, p2 = spec.positive
    n0, n1, n2 = spec.negative
    c0, c1 = spec.constraints
    r0 = spec.relations[0]

    development = (
        Case(f"{target_id}-d0", f"evidence {p0} {p1} {variant_pos} {c0}", True, "development"),
        Case(f"{target_id}-d1", f"pattern {p1} {p2} {c1}", True, "development"),
        Case(f"{target_id}-d2", f"state {p0} {p2} {variant_pos}", True, "development"),
        Case(f"{target_id}-d3", f"relation {r0[0]} {r0[1]} {r0[2]} {p2}", True, "development"),
        Case(f"{target_id}-d4", f"evidence {n0} {n1}", False, "development"),
        Case(f"{target_id}-d5", f"pattern {n1} {variant_neg} decoy_{p0}", False, "development"),
        Case(f"{target_id}-d6", f"state {n2} without_{p1}", False, "development"),
        Case(f"{target_id}-d7", f"neighbor {variant_neg} decoy_{p2}", False, "development"),
    )
    holdout = (
        Case(f"{target_id}-h0", f"holdout {p0} {p2} {variant_pos}", True, "holdout"),
        Case(f"{target_id}-h1", f"holdout {n0} decoy_{p0}", False, "holdout"),
        Case(f"{target_id}-h2", f"holdout {p1} {variant_pos} {c0}", True, "holdout"),
        Case(f"{target_id}-h3", f"holdout {variant_neg} {n2} decoy_{p1}", False, "holdout"),
    )
    adversarial = (
        Case(f"{target_id}-a0", f"adversarial {p0} {p1} {p2} {n0}", False, "adversarial"),
        Case(f"{target_id}-a1", f"adversarial {variant_pos} {p2} safe_context", True, "adversarial"),
    )
    return development, holdout, adversarial


def generate_targets(seed: int = 20260821, count: int = 30) -> list[GroundTruthTarget]:
    if count <= 0 or count % len(_FAMILY_SPECS) != 0:
        raise ValueError("count must be a positive multiple of five")
    per_family = count // len(_FAMILY_SPECS)
    if per_family > 6:
        raise ValueError("v0.1 provides at most six deterministic variants per family")

    rng = random.Random(seed)
    targets: list[GroundTruthTarget] = []
    for spec in _FAMILY_SPECS:
        variants = list(spec.variants)
        rng.shuffle(variants)
        for idx, (variant_pos, variant_neg) in enumerate(variants[:per_family]):
            target_id = f"{spec.family}-{idx:02d}"
            development, holdout, adversarial = _case_set(spec, variant_pos, variant_neg, target_id)
            positives = (*spec.positive, variant_pos)
            negatives = (*spec.negative, variant_neg)
            relations = tuple(Relation(src, rel, dst, polarity, 0.95) for src, rel, dst, polarity in spec.relations)
            targets.append(
                GroundTruthTarget(
                    target_id=target_id,
                    family=spec.family,
                    positive_anchors=positives,
                    negative_anchors=negatives,
                    relations=relations,
                    constraints=spec.constraints,
                    open_variables=(spec.open_variable,),
                    candidate_categories=(spec.category,),
                    development_cases=development,
                    holdout_cases=holdout,
                    adversarial_cases=adversarial,
                )
            )
    return targets


def make_observation(target: GroundTruthTarget) -> ObservationBundle:
    positive = tuple(case.description for case in target.development_cases if case.label)[:3]
    negative = tuple(case.description for case in target.development_cases if case.label is False)[:3]
    contrasts = ((positive[0], negative[0]), (positive[1], negative[1]))
    relation = target.relations[0]
    return ObservationBundle(
        target_id=target.target_id,
        family=target.family,
        positive_examples=positive,
        negative_examples=negative,
        minimal_contrasts=contrasts,
        unresolved_ambiguity=target.open_variables[0],
        misleading_neighbor=target.negative_anchors[-1],
        relation_probe=f"{relation.source} {relation.relation_type} {relation.target}",
        candidate_categories=target.candidate_categories,
    )

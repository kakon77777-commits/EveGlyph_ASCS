from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class InteractionRecord:
    sequence: int
    request_id: str
    stage: str
    target_id: str
    condition: str
    prompt_sha256: str
    prompt_bytes: int
    raw_response: str
    response_bytes: int
    status: str
    error_type: str
    error_message: str
    provider: str
    model: str
    timestamp_utc: str | None
    request: dict[str, Any]
    response: dict[str, Any] | None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "InteractionRecord":
        return cls(**data)


class RunLedger:
    def __init__(self, records: list[InteractionRecord] | None = None):
        self.records = list(records or [])

    def append(self, record: InteractionRecord) -> None:
        if record.sequence != len(self.records):
            raise ValueError(f"sequence must equal next index {len(self.records)}")
        self.records.append(record)

    def write_jsonl(self, path: Path) -> None:
        path = Path(path)
        with path.open("w", encoding="utf-8", newline="\n") as handle:
            for record in self.records:
                handle.write(json.dumps(record.to_dict(), ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n")

    @classmethod
    def from_jsonl(cls, path: Path) -> "RunLedger":
        rows: list[InteractionRecord] = []
        for line in Path(path).read_text(encoding="utf-8").splitlines():
            if line.strip():
                rows.append(InteractionRecord.from_dict(json.loads(line)))
        return cls(rows)

from __future__ import annotations

import json
from pathlib import Path

from .models import FrozenRepresentation


def freeze_representation(rep: FrozenRepresentation, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(rep.to_dict(), ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n",
        encoding="utf-8",
    )


def load_frozen(path: Path) -> FrozenRepresentation:
    return FrozenRepresentation.from_dict(json.loads(path.read_text(encoding="utf-8")))

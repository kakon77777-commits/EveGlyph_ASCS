from __future__ import annotations

from pathlib import Path

from .adapters import ModelResponse, ReplayAdapter
from .ledger import RunLedger


def recorded_responses_from_ledger(path: Path) -> dict[str, ModelResponse]:
    responses: dict[str, ModelResponse] = {}
    for record in RunLedger.from_jsonl(path).records:
        if record.response is not None:
            responses[record.request_id] = ModelResponse.from_dict(record.response)
    return responses


def replay_adapter_from_ledger(path: Path) -> ReplayAdapter:
    ledger = RunLedger.from_jsonl(path)
    responses: dict[str, ModelResponse] = {}
    hashes: dict[str, str] = {}
    for record in ledger.records:
        if record.response is not None:
            responses[record.request_id] = ModelResponse.from_dict(record.response)
            hashes[record.request_id] = record.prompt_sha256
    return ReplayAdapter(responses, prompt_hashes=hashes)

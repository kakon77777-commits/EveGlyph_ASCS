from __future__ import annotations

import json

from .models import Case, FrozenRepresentation, ObservationBundle


def _obs_json(obs: ObservationBundle) -> str:
    return json.dumps(obs.to_dict(), ensure_ascii=False, sort_keys=True, indent=2)


def builder_prompt(obs: ObservationBundle, condition: str, budget_bytes: int) -> str:
    common = (
        "You are building one frozen representation for a blind semantic recovery experiment.\n"
        f"Target ID: {obs.target_id}\n"
        f"Hard payload budget: {budget_bytes} UTF-8 bytes.\n"
        "Return exactly one JSON value and nothing else. No Markdown fences.\n\n"
        "OBSERVATION BUNDLE\n"
        f"{_obs_json(obs)}\n\n"
        "OUTPUT CONTRACT\n"
    )
    if condition == "definition_first":
        return common + (
            'Return exactly: {"definition":"<one concise natural-language definition>"}\n'
            "Do not emit the hidden structured schema.\n"
        )
    if condition == "keyword_first":
        return common + (
            'Return exactly: {"keywords":["term1","term2",...] }\n'
            "The list is untyped and unordered semantically. Do not output relations, constraints, exclusions, confidence, or prose definitions.\n"
        )
    if condition == "address_first":
        return common + (
            "Do not output a concept name.\n"
            "Do not write a prose definition.\n"
            "Return exactly one object with these keys and no others:\n"
            '{"positive_anchors":[],"negative_anchors":[],"relations":[],"constraints":[],"open_variables":[],"candidate_categories":[],"confidence":{}}\n'
            "Each relation object must contain source, relation_type, target, polarity, confidence. Preserve uncertainty in open_variables instead of guessing.\n"
        )
    raise ValueError(f"unknown condition: {condition}")


def recovery_prompt(rep: FrozenRepresentation, eval_cases: list[Case]) -> str:
    public_cases = [case.public_view().to_dict() for case in eval_cases]
    return (
        "You are the clean recovery stage of a blind semantic recovery experiment.\n"
        "You receive only one frozen representation plus public evaluation cases.\n"
        "Do not infer or invent hidden gold labels. Return exactly one JSON object and nothing else.\n\n"
        "FROZEN REPRESENTATION\n"
        f"{json.dumps(rep.to_dict(), ensure_ascii=False, sort_keys=True, indent=2)}\n\n"
        "PUBLIC EVALUATION CASES\n"
        f"{json.dumps(public_cases, ensure_ascii=False, sort_keys=True, indent=2)}\n\n"
        "OUTPUT CONTRACT\n"
        '{"recovered_positive_anchors":[],"recovered_negative_anchors":[],"relations":[],"constraints":[],"open_variables":[],"holdout_predictions":{},"adversarial_predictions":{},"rendering":""}\n'
        "Predictions must be JSON booleans keyed by case_id. Each relation must contain source, relation_type, target, polarity, confidence.\n"
    )

from __future__ import annotations

import csv
import hashlib
import json
import random
from collections import defaultdict
from pathlib import Path
from statistics import mean, median
from typing import Any

from .control import ControlManifest

PAIRWISE_METRICS = (
    "hda",
    "ana",
    "relation_f1",
    "constraint_f1",
    "ups",
    "representation_bytes",
    "composite",
    "efficiency",
)

CONTRASTS = {
    "address_vs_definition": ("address_first", "definition_first"),
    "address_vs_keyword": ("address_first", "keyword_first"),
}


def _stable_seed(base_seed: int, *parts: str) -> int:
    text = "|".join([str(base_seed), *parts]).encode("utf-8")
    return int.from_bytes(hashlib.sha256(text).digest()[:8], "big", signed=False)


def _bootstrap_ci(values: list[float], seed: int, draws: int = 2000) -> list[float]:
    if not values:
        return [0.0, 0.0]
    if len(values) == 1:
        value = round(values[0], 12)
        return [value, value]
    rng = random.Random(seed)
    n = len(values)
    boot = []
    for _ in range(draws):
        sample = [values[rng.randrange(n)] for _ in range(n)]
        boot.append(mean(sample))
    boot.sort()
    low = boot[int(0.025 * (draws - 1))]
    high = boot[int(0.975 * (draws - 1))]
    return [round(low, 12), round(high, 12)]


def _round(value: float) -> float:
    return round(float(value), 12)


def _trial_key(row: dict[str, Any]) -> tuple[str, int]:
    return str(row["target_id"]), int(row["trial_index"])


def _numeric(row: dict[str, Any], field: str) -> float:
    return float(row[field])


def _condition_target_means(rows: list[dict[str, Any]]) -> dict[str, dict[str, float]]:
    by_block: dict[tuple[str, int], dict[str, dict[str, Any]]] = defaultdict(dict)
    for row in rows:
        by_block[_trial_key(row)][str(row["condition"])] = row

    # Gate evaluation uses only complete three-condition blocks.
    by_target_condition: dict[str, dict[str, list[float]]] = defaultdict(lambda: defaultdict(list))
    for (target_id, _trial), conditions in by_block.items():
        if not all(condition in conditions for condition in ("definition_first", "keyword_first", "address_first")):
            continue
        for condition, row in conditions.items():
            for metric in PAIRWISE_METRICS:
                by_target_condition[f"{target_id}|{condition}"][metric].append(_numeric(row, metric))

    output: dict[str, dict[str, float]] = {}
    for key, metric_values in by_target_condition.items():
        output[key] = {metric: _round(mean(values)) for metric, values in metric_values.items()}
    return output


def _overall_condition_means(target_means: dict[str, dict[str, float]]) -> dict[str, dict[str, float]]:
    grouped: dict[str, dict[str, list[float]]] = defaultdict(lambda: defaultdict(list))
    for key, values in target_means.items():
        _, condition = key.rsplit("|", 1)
        for metric, value in values.items():
            grouped[condition][metric].append(value)
    return {
        condition: {metric: _round(mean(values)) for metric, values in metrics.items()}
        for condition, metrics in grouped.items()
    }


def _gate1_evaluation(
    overall: dict[str, dict[str, float]],
    manifest: ControlManifest,
) -> dict[str, Any]:
    thresholds = manifest.success_thresholds
    hda_margin = float(thresholds.get("hda_noninferiority_margin", 0.05))
    ana_min_delta = float(thresholds.get("ana_min_delta", 0.0))
    structural_delta = float(thresholds.get("meaningful_structural_delta", 0.05))

    required_conditions = ("definition_first", "keyword_first", "address_first")
    if not all(condition in overall for condition in required_conditions):
        criteria = {
            "hda_noninferiority": {"passed": False, "reason": "insufficient complete paired data"},
            "ana_advantage": {"passed": False, "reason": "insufficient complete paired data"},
            "structural_advantage": {"passed": False, "reason": "insufficient complete paired data"},
            "budget_normalized_advantage": {"passed": False, "reason": "insufficient complete paired data"},
        }
        return {
            "manifest_sha256": manifest.manifest_sha256,
            "thresholds": thresholds,
            "criteria": criteria,
            "manual_leakage_audit": {"status": "NOT_EVALUATED", "required_pass_count": 20, "target_count": manifest.target_count},
            "overall_status": "QUANTITATIVE_FAIL",
        }

    address = overall["address_first"]
    definition = overall["definition_first"]
    keyword = overall["keyword_first"]

    best_hda_baseline = max(definition["hda"], keyword["hda"])
    hda_delta = address["hda"] - best_hda_baseline
    hda_pass = hda_delta >= -hda_margin

    ana_deltas = {
        "vs_definition": address["ana"] - definition["ana"],
        "vs_keyword": address["ana"] - keyword["ana"],
    }
    ana_pass = any(delta > ana_min_delta for delta in ana_deltas.values())

    relation_deltas = (
        address["relation_f1"] - definition["relation_f1"],
        address["relation_f1"] - keyword["relation_f1"],
    )
    ups_deltas = (
        address["ups"] - definition["ups"],
        address["ups"] - keyword["ups"],
    )
    structural_metric = "relation_f1" if all(delta >= structural_delta for delta in relation_deltas) else None
    if structural_metric is None and all(delta >= structural_delta for delta in ups_deltas):
        structural_metric = "ups"
    structural_pass = structural_metric is not None

    efficiency_deltas = {
        "vs_definition": address["efficiency"] - definition["efficiency"],
        "vs_keyword": address["efficiency"] - keyword["efficiency"],
    }
    efficiency_pass = any(delta > 0.0 for delta in efficiency_deltas.values())

    criteria = {
        "hda_noninferiority": {
            "passed": hda_pass,
            "address_mean": address["hda"],
            "strongest_baseline_mean": best_hda_baseline,
            "delta": _round(hda_delta),
            "margin": hda_margin,
        },
        "ana_advantage": {
            "passed": ana_pass,
            "address_mean": address["ana"],
            "deltas": {k: _round(v) for k, v in ana_deltas.items()},
            "minimum_delta": ana_min_delta,
        },
        "structural_advantage": {
            "passed": structural_pass,
            "qualifying_metric": structural_metric,
            "relation_f1_deltas": [_round(x) for x in relation_deltas],
            "ups_deltas": [_round(x) for x in ups_deltas],
            "meaningful_delta": structural_delta,
        },
        "budget_normalized_advantage": {
            "passed": efficiency_pass,
            "deltas": {k: _round(v) for k, v in efficiency_deltas.items()},
        },
    }
    quantitative_pass = all(item["passed"] for item in criteria.values())
    return {
        "manifest_sha256": manifest.manifest_sha256,
        "thresholds": thresholds,
        "condition_target_means": overall,
        "criteria": criteria,
        "manual_leakage_audit": {
            "status": "NOT_EVALUATED",
            "required_pass_count": 20,
            "target_count": manifest.target_count,
            "note": "Automatic Dataset v0.2 audit is not a substitute for the preregistered manual leakage review.",
        },
        "overall_status": "REQUIRES_MANUAL_AUDIT" if quantitative_pass else "QUANTITATIVE_FAIL",
    }


def analyze_trial_metrics(
    rows: list[dict[str, Any]],
    manifest: ControlManifest,
    output_dir: Path,
) -> dict[str, Any]:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    by_block: dict[tuple[str, int], dict[str, dict[str, Any]]] = defaultdict(dict)
    for row in rows:
        by_block[_trial_key(row)][str(row["condition"])] = row

    trial_diff_rows: list[dict[str, Any]] = []
    for contrast_name, (left_condition, right_condition) in CONTRASTS.items():
        for (target_id, trial_index), condition_rows in sorted(by_block.items()):
            if left_condition not in condition_rows or right_condition not in condition_rows:
                continue
            left = condition_rows[left_condition]
            right = condition_rows[right_condition]
            row: dict[str, Any] = {
                "contrast": contrast_name,
                "target_id": target_id,
                "trial_index": trial_index,
                "trial_id": str(left.get("trial_id", f"{target_id}:t{trial_index:03d}")),
            }
            for metric in PAIRWISE_METRICS:
                row[f"delta_{metric}"] = _round(_numeric(left, metric) - _numeric(right, metric))
            trial_diff_rows.append(row)

    target_groups: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    for row in trial_diff_rows:
        target_groups[(str(row["contrast"]), str(row["target_id"]))].append(row)

    target_mean_rows: list[dict[str, Any]] = []
    for (contrast, target_id), group in sorted(target_groups.items()):
        row: dict[str, Any] = {
            "contrast": contrast,
            "target_id": target_id,
            "paired_trial_count": len(group),
        }
        for metric in PAIRWISE_METRICS:
            row[f"mean_delta_{metric}"] = _round(mean(float(item[f"delta_{metric}"]) for item in group))
        target_mean_rows.append(row)

    contrasts: dict[str, dict[str, Any]] = {}
    for contrast_name in CONTRASTS:
        contrast_targets = [row for row in target_mean_rows if row["contrast"] == contrast_name]
        complete_trial_pairs = sum(1 for row in trial_diff_rows if row["contrast"] == contrast_name)
        metric_summary: dict[str, Any] = {}
        for metric in PAIRWISE_METRICS:
            values = [float(row[f"mean_delta_{metric}"]) for row in contrast_targets]
            wins = sum(value > 1e-12 for value in values)
            losses = sum(value < -1e-12 for value in values)
            ties = len(values) - wins - losses
            metric_summary[metric] = {
                "n_targets": len(values),
                "n_complete_trial_pairs": complete_trial_pairs,
                "mean_delta": _round(mean(values)) if values else 0.0,
                "median_delta": _round(median(values)) if values else 0.0,
                "bootstrap_ci95": _bootstrap_ci(
                    values,
                    _stable_seed(manifest.analysis_seed, contrast_name, metric),
                ),
                "wins": wins,
                "ties": ties,
                "losses": losses,
            }
        contrasts[contrast_name] = metric_summary

    trial_fields = ["contrast", "target_id", "trial_index", "trial_id"] + [f"delta_{m}" for m in PAIRWISE_METRICS]
    with (output_dir / "paired_trial_differences.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=trial_fields, lineterminator="\n")
        writer.writeheader()
        writer.writerows(trial_diff_rows)

    target_fields = ["contrast", "target_id", "paired_trial_count"] + [f"mean_delta_{m}" for m in PAIRWISE_METRICS]
    with (output_dir / "paired_target_means.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=target_fields, lineterminator="\n")
        writer.writeheader()
        writer.writerows(target_mean_rows)

    target_condition_means = _condition_target_means(rows)
    overall_condition_means = _overall_condition_means(target_condition_means)
    analysis = {
        "manifest_sha256": manifest.manifest_sha256,
        "analysis_seed": manifest.analysis_seed,
        "bootstrap_draws": 2000,
        "unit_of_inference": "target_level_mean_across_repeated_trials",
        "contrasts": contrasts,
        "overall_condition_target_means": overall_condition_means,
    }
    (output_dir / "paired_analysis.json").write_text(
        json.dumps(analysis, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )

    gate = _gate1_evaluation(overall_condition_means, manifest)
    (output_dir / "gate1_evaluation.json").write_text(
        json.dumps(gate, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    return analysis

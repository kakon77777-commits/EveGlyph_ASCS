from __future__ import annotations

import csv
import json
from pathlib import Path
from statistics import mean
from typing import Iterable

from .builders import build_address, build_definition, build_keywords
from .datasets import load_dataset
from .models import FrozenRepresentation, MetricVector, ObservationBundle, RecoveryResult
from .recovery import recover
from .scoring import score

_CONDITION_BUILDERS = (
    ("definition_first", build_definition),
    ("keyword_first", build_keywords),
    ("address_first", build_address),
)


def _write_jsonl(path: Path, rows: Iterable[dict]) -> None:
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n")


def _read_frozen_jsonl(path: Path) -> list[FrozenRepresentation]:
    return [
        FrozenRepresentation.from_dict(json.loads(line))
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]


def _round(value: float) -> float:
    return round(value, 12)


def _aggregate(metrics: list[MetricVector], condition: str) -> dict[str, float | int]:
    rows = [m for m in metrics if m.condition == condition]
    return {
        "count": len(rows),
        "mean_hda": _round(mean(m.hda for m in rows)),
        "mean_ana": _round(mean(m.ana for m in rows)),
        "mean_relation_f1": _round(mean(m.relation_f1 for m in rows)),
        "mean_constraint_f1": _round(mean(m.constraint_f1 for m in rows)),
        "mean_ups": _round(mean(m.ups for m in rows)),
        "mean_composite": _round(mean(m.composite for m in rows)),
        "mean_efficiency": _round(mean(m.efficiency for m in rows)),
        "mean_representation_bytes": _round(mean(m.representation_bytes for m in rows)),
    }


def _report(summary: dict) -> str:
    if summary.get("dataset_version") == "v0.2":
        lines = [
            "# PSSA-BSAR Dataset v0.2 Deterministic Mock Report",
            "",
            "**Evidence status:** `MOCK_AUDITED_DATASET_NOT_SCIENTIFIC`",
            "",
            "> The dataset is leakage-audited, but these deterministic mock scores validate plumbing only and are not scientific evidence for PSSA.",
            "",
            f"- Seed: `{summary['seed']}`",
            f"- Targets: `{summary['target_count']}`",
            f"- Dataset SHA-256: `{summary['dataset_sha256']}`",
            f"- Dataset audit: `{summary['dataset_audit_pass_count']}` pass / `{summary['dataset_audit_fail_count']}` fail",
            f"- Representation byte cap: `{summary['budget_bytes']}`",
            "",
            "## Condition means",
            "",
            "| Condition | HDA | ANA | Relation F1 | Constraint F1 | UPS | Composite | Mean bytes |",
            "|---|---:|---:|---:|---:|---:|---:|---:|",
        ]
        for condition in summary["conditions"]:
            row = summary["aggregates"][condition]
            lines.append(
                f"| {condition} | {row['mean_hda']:.3f} | {row['mean_ana']:.3f} | "
                f"{row['mean_relation_f1']:.3f} | {row['mean_constraint_f1']:.3f} | "
                f"{row['mean_ups']:.3f} | {row['mean_composite']:.3f} | "
                f"{row['mean_representation_bytes']:.1f} |"
            )
        lines.extend([
            "",
            "## Interpretation boundary",
            "",
            "Dataset v0.2 removes preregistered lexical leakage shortcuts, but the built-in mock builders are not scientific model subjects.",
            "",
        ])
        return "\n".join(lines)

    lines = [
        "# PSSA-BSAR v0.1 Deterministic Mock Report",
        "",
        "**Evidence status:** `MOCK_PLUMBING_ONLY`",
        "",
        "> These results validate deterministic experiment plumbing only. They are not empirical evidence for PSSA, pre-symbolic cognition, or model-internal semantic addressing.",
        "",
        f"- Seed: `{summary['seed']}`",
        f"- Targets: `{summary['target_count']}`",
        f"- Representation byte cap: `{summary['budget_bytes']}`",
        "",
        "## Condition means",
        "",
        "| Condition | HDA | ANA | Relation F1 | Constraint F1 | UPS | Composite | Mean bytes |",
        "|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for condition in summary["conditions"]:
        row = summary["aggregates"][condition]
        lines.append(
            f"| {condition} | {row['mean_hda']:.3f} | {row['mean_ana']:.3f} | "
            f"{row['mean_relation_f1']:.3f} | {row['mean_constraint_f1']:.3f} | "
            f"{row['mean_ups']:.3f} | {row['mean_composite']:.3f} | "
            f"{row['mean_representation_bytes']:.1f} |"
        )
    lines.extend(
        [
            "",
            "## Interpretation boundary",
            "",
            "The synthetic descriptions are intentionally machine-readable. Any apparent condition advantage is a harness sanity check, not a scientific result. The live experiment must replace these templates with leakage-audited targets and independent model sessions.",
            "",
        ]
    )
    return "\n".join(lines)


def run_mock_experiment(
    output_dir: Path,
    seed: int = 20260821,
    budget_bytes: int = 900,
    dataset_version: str = "v0.1",
) -> dict:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    targets, observations, dataset_manifest = load_dataset(dataset_version, seed=seed, count=30)
    target_by_id = {target.target_id: target for target in targets}

    _write_jsonl(output_dir / "targets.jsonl", (target.to_dict() for target in targets))
    _write_jsonl(output_dir / "observations.jsonl", (obs.to_dict() for obs in observations))
    if dataset_manifest is not None:
        (output_dir / "dataset_manifest.json").write_text(
            json.dumps(dataset_manifest, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
            encoding="utf-8",
            newline="\n",
        )

    reps: list[FrozenRepresentation] = []
    for obs in observations:
        for _, builder in _CONDITION_BUILDERS:
            reps.append(builder(obs, budget_bytes=budget_bytes))
    _write_jsonl(output_dir / "frozen_representations.jsonl", (rep.to_dict() for rep in reps))

    # Recovery intentionally reloads the frozen artifact instead of consuming builder objects directly.
    frozen = _read_frozen_jsonl(output_dir / "frozen_representations.jsonl")
    recoveries: list[RecoveryResult] = []
    metrics: list[MetricVector] = []
    for rep in frozen:
        target = target_by_id[rep.target_id]
        public_cases = [case.public_view() for case in (*target.holdout_cases, *target.adversarial_cases)]
        result = recover(rep, public_cases)
        recoveries.append(result)
        metrics.append(score(target, result, rep.utf8_bytes))

    _write_jsonl(output_dir / "recoveries.jsonl", (result.to_dict() for result in recoveries))

    metric_fields = [
        "target_id", "condition", "hda", "ana", "relation_f1", "constraint_f1",
        "ups", "representation_bytes", "composite", "efficiency",
    ]
    with (output_dir / "metrics.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=metric_fields, lineterminator="\n")
        writer.writeheader()
        for metric in metrics:
            writer.writerow(metric.to_dict())

    conditions = [name for name, _ in _CONDITION_BUILDERS]
    summary = {
        "experiment": "PSSA-BSAR",
        "version": "0.1-milestone1",
        "run_mode": "deterministic_mock",
        "evidence_status": "MOCK_PLUMBING_ONLY",
        "seed": seed,
        "budget_bytes": budget_bytes,
        "target_count": len(targets),
        "conditions": conditions,
        "aggregates": {condition: _aggregate(metrics, condition) for condition in conditions},
    }
    if dataset_manifest is not None:
        summary.update({
            "version": "0.1-milestone3",
            "dataset_version": dataset_version,
            "dataset_sha256": dataset_manifest["dataset_sha256"],
            "dataset_audit_pass_count": dataset_manifest["pass_count"],
            "dataset_audit_fail_count": dataset_manifest["fail_count"],
            "evidence_status": "MOCK_AUDITED_DATASET_NOT_SCIENTIFIC",
        })
    (output_dir / "summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    (output_dir / "REPORT.md").write_text(_report(summary), encoding="utf-8", newline="\n")
    return summary

from __future__ import annotations

from .dataset import generate_targets, make_observation
from .dataset_audit import audit_dataset_v2
from .dataset_v2 import generate_targets_v2, make_observation_v2
from .models import GroundTruthTarget, ObservationBundle

SUPPORTED_DATASET_VERSIONS = ("v0.1", "v0.2")


def load_dataset(
    version: str,
    seed: int,
    count: int = 30,
) -> tuple[list[GroundTruthTarget], list[ObservationBundle], dict | None]:
    if version == "v0.1":
        targets = generate_targets(seed=seed, count=count)
        observations = [make_observation(target) for target in targets]
        return targets, observations, None
    if version == "v0.2":
        targets = generate_targets_v2(seed=seed, count=count)
        observations = [make_observation_v2(target) for target in targets]
        manifest = audit_dataset_v2(targets, observations, seed=seed)
        if manifest["fail_count"]:
            raise ValueError(
                f"dataset v0.2 failed leakage audit: {manifest['fail_count']} target(s) failed"
            )
        return targets, observations, manifest
    raise ValueError(f"unsupported dataset version: {version}")

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any


@dataclass(frozen=True)
class Relation:
    source: str
    relation_type: str
    target: str
    polarity: int
    confidence: float

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Relation":
        return cls(**data)


@dataclass(frozen=True)
class Case:
    case_id: str
    description: str
    label: bool | None
    kind: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Case":
        return cls(**data)

    def public_view(self) -> "Case":
        return Case(self.case_id, self.description, None, self.kind)


@dataclass(frozen=True)
class GroundTruthTarget:
    target_id: str
    family: str
    positive_anchors: tuple[str, ...]
    negative_anchors: tuple[str, ...]
    relations: tuple[Relation, ...]
    constraints: tuple[str, ...]
    open_variables: tuple[str, ...]
    candidate_categories: tuple[str, ...]
    development_cases: tuple[Case, ...]
    holdout_cases: tuple[Case, ...]
    adversarial_cases: tuple[Case, ...]

    def to_dict(self) -> dict[str, Any]:
        return {
            "target_id": self.target_id,
            "family": self.family,
            "positive_anchors": list(self.positive_anchors),
            "negative_anchors": list(self.negative_anchors),
            "relations": [x.to_dict() for x in self.relations],
            "constraints": list(self.constraints),
            "open_variables": list(self.open_variables),
            "candidate_categories": list(self.candidate_categories),
            "development_cases": [x.to_dict() for x in self.development_cases],
            "holdout_cases": [x.to_dict() for x in self.holdout_cases],
            "adversarial_cases": [x.to_dict() for x in self.adversarial_cases],
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "GroundTruthTarget":
        return cls(
            target_id=data["target_id"],
            family=data["family"],
            positive_anchors=tuple(data["positive_anchors"]),
            negative_anchors=tuple(data["negative_anchors"]),
            relations=tuple(Relation.from_dict(x) for x in data["relations"]),
            constraints=tuple(data["constraints"]),
            open_variables=tuple(data["open_variables"]),
            candidate_categories=tuple(data["candidate_categories"]),
            development_cases=tuple(Case.from_dict(x) for x in data["development_cases"]),
            holdout_cases=tuple(Case.from_dict(x) for x in data["holdout_cases"]),
            adversarial_cases=tuple(Case.from_dict(x) for x in data["adversarial_cases"]),
        )


@dataclass(frozen=True)
class ObservationBundle:
    target_id: str
    family: str
    positive_examples: tuple[str, ...]
    negative_examples: tuple[str, ...]
    minimal_contrasts: tuple[tuple[str, str], ...]
    unresolved_ambiguity: str
    misleading_neighbor: str
    relation_probe: str
    candidate_categories: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        return {
            "target_id": self.target_id,
            "family": self.family,
            "positive_examples": list(self.positive_examples),
            "negative_examples": list(self.negative_examples),
            "minimal_contrasts": [list(x) for x in self.minimal_contrasts],
            "unresolved_ambiguity": self.unresolved_ambiguity,
            "misleading_neighbor": self.misleading_neighbor,
            "relation_probe": self.relation_probe,
            "candidate_categories": list(self.candidate_categories),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ObservationBundle":
        return cls(
            target_id=data["target_id"],
            family=data["family"],
            positive_examples=tuple(data["positive_examples"]),
            negative_examples=tuple(data["negative_examples"]),
            minimal_contrasts=tuple(tuple(x) for x in data["minimal_contrasts"]),
            unresolved_ambiguity=data["unresolved_ambiguity"],
            misleading_neighbor=data["misleading_neighbor"],
            relation_probe=data["relation_probe"],
            candidate_categories=tuple(data["candidate_categories"]),
        )


@dataclass(frozen=True)
class FrozenRepresentation:
    target_id: str
    condition: str
    payload: Any
    utf8_bytes: int
    token_count: int

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "FrozenRepresentation":
        return cls(**data)


@dataclass(frozen=True)
class RecoveryResult:
    target_id: str
    condition: str
    recovered_positive_anchors: tuple[str, ...]
    recovered_negative_anchors: tuple[str, ...]
    relations: tuple[Relation, ...]
    constraints: tuple[str, ...]
    open_variables: tuple[str, ...]
    holdout_predictions: dict[str, bool]
    adversarial_predictions: dict[str, bool]
    rendering: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "target_id": self.target_id,
            "condition": self.condition,
            "recovered_positive_anchors": list(self.recovered_positive_anchors),
            "recovered_negative_anchors": list(self.recovered_negative_anchors),
            "relations": [x.to_dict() for x in self.relations],
            "constraints": list(self.constraints),
            "open_variables": list(self.open_variables),
            "holdout_predictions": dict(self.holdout_predictions),
            "adversarial_predictions": dict(self.adversarial_predictions),
            "rendering": self.rendering,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "RecoveryResult":
        return cls(
            target_id=data["target_id"],
            condition=data["condition"],
            recovered_positive_anchors=tuple(data["recovered_positive_anchors"]),
            recovered_negative_anchors=tuple(data["recovered_negative_anchors"]),
            relations=tuple(Relation.from_dict(x) for x in data["relations"]),
            constraints=tuple(data["constraints"]),
            open_variables=tuple(data["open_variables"]),
            holdout_predictions=dict(data["holdout_predictions"]),
            adversarial_predictions=dict(data["adversarial_predictions"]),
            rendering=data["rendering"],
        )


@dataclass(frozen=True)
class MetricVector:
    target_id: str
    condition: str
    hda: float
    ana: float
    relation_f1: float
    constraint_f1: float
    ups: float
    representation_bytes: int
    composite: float
    efficiency: float

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "MetricVector":
        return cls(**data)

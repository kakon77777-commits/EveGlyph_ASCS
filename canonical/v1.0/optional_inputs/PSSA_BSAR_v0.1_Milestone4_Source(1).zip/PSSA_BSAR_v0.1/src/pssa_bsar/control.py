from __future__ import annotations

import hashlib
import itertools
import json
import random
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from .models import GroundTruthTarget

CONDITIONS = ("definition_first", "keyword_first", "address_first")


def _canonical_bytes(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def _sha256(value: Any) -> str:
    return hashlib.sha256(_canonical_bytes(value)).hexdigest()


def _trial_seed(dataset_seed: int, schedule_seed: int, target_id: str, trial_index: int) -> int:
    raw = f"{dataset_seed}|{schedule_seed}|{target_id}|{trial_index}".encode("utf-8")
    return int.from_bytes(hashlib.sha256(raw).digest()[:4], "big", signed=False)


@dataclass(frozen=True)
class TrialScheduleItem:
    sequence: int
    target_id: str
    trial_index: int
    trial_seed: int
    conditions: tuple[str, str, str]

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["conditions"] = list(self.conditions)
        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "TrialScheduleItem":
        conditions = tuple(data["conditions"])
        if len(conditions) != 3 or set(conditions) != set(CONDITIONS):
            raise ValueError("schedule item must contain each condition exactly once")
        return cls(
            sequence=int(data["sequence"]),
            target_id=str(data["target_id"]),
            trial_index=int(data["trial_index"]),
            trial_seed=int(data["trial_seed"]),
            conditions=conditions,  # type: ignore[arg-type]
        )


@dataclass(frozen=True)
class ControlManifest:
    experiment: str
    version: str
    dataset_version: str
    dataset_seed: int
    dataset_sha256: str
    target_count: int
    trials_per_target: int
    budget_bytes: int
    schedule_seed: int
    analysis_seed: int
    expected_provider: str
    expected_model: str
    sampling_policy: dict[str, Any]
    success_thresholds: dict[str, float]
    conditions: tuple[str, str, str]
    schedule: tuple[TrialScheduleItem, ...]
    schedule_sha256: str
    manifest_sha256: str

    def _payload_without_manifest_hash(self) -> dict[str, Any]:
        return {
            "experiment": self.experiment,
            "version": self.version,
            "dataset_version": self.dataset_version,
            "dataset_seed": self.dataset_seed,
            "dataset_sha256": self.dataset_sha256,
            "target_count": self.target_count,
            "trials_per_target": self.trials_per_target,
            "budget_bytes": self.budget_bytes,
            "schedule_seed": self.schedule_seed,
            "analysis_seed": self.analysis_seed,
            "expected_provider": self.expected_provider,
            "expected_model": self.expected_model,
            "sampling_policy": self.sampling_policy,
            "success_thresholds": self.success_thresholds,
            "conditions": list(self.conditions),
            "schedule": [item.to_dict() for item in self.schedule],
            "schedule_sha256": self.schedule_sha256,
        }

    def to_dict(self) -> dict[str, Any]:
        data = self._payload_without_manifest_hash()
        data["manifest_sha256"] = self.manifest_sha256
        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ControlManifest":
        schedule = tuple(TrialScheduleItem.from_dict(x) for x in data["schedule"])
        manifest = cls(
            experiment=str(data["experiment"]),
            version=str(data["version"]),
            dataset_version=str(data["dataset_version"]),
            dataset_seed=int(data["dataset_seed"]),
            dataset_sha256=str(data["dataset_sha256"]),
            target_count=int(data["target_count"]),
            trials_per_target=int(data["trials_per_target"]),
            budget_bytes=int(data["budget_bytes"]),
            schedule_seed=int(data["schedule_seed"]),
            analysis_seed=int(data["analysis_seed"]),
            expected_provider=str(data["expected_provider"]),
            expected_model=str(data["expected_model"]),
            sampling_policy=dict(data["sampling_policy"]),
            success_thresholds={str(k): float(v) for k, v in dict(data["success_thresholds"]).items()},
            conditions=tuple(data["conditions"]),  # type: ignore[arg-type]
            schedule=schedule,
            schedule_sha256=str(data["schedule_sha256"]),
            manifest_sha256=str(data["manifest_sha256"]),
        )
        manifest.validate_hashes()
        return manifest

    def validate_hashes(self) -> None:
        actual_schedule_hash = _sha256([item.to_dict() for item in self.schedule])
        if actual_schedule_hash != self.schedule_sha256:
            raise ValueError("schedule hash mismatch")
        actual_manifest_hash = _sha256(self._payload_without_manifest_hash())
        if actual_manifest_hash != self.manifest_sha256:
            raise ValueError("manifest hash mismatch")


def _balanced_schedule(
    *,
    target_ids: list[str],
    trials_per_target: int,
    dataset_seed: int,
    schedule_seed: int,
) -> tuple[TrialScheduleItem, ...]:
    blocks = [(target_id, trial_index) for target_id in target_ids for trial_index in range(trials_per_target)]
    rng = random.Random(schedule_seed)
    rng.shuffle(blocks)

    permutations = list(itertools.permutations(CONDITIONS))
    rng.shuffle(permutations)

    schedule: list[TrialScheduleItem] = []
    for sequence, (target_id, trial_index) in enumerate(blocks):
        conditions = permutations[sequence % len(permutations)]
        schedule.append(
            TrialScheduleItem(
                sequence=sequence,
                target_id=target_id,
                trial_index=trial_index,
                trial_seed=_trial_seed(dataset_seed, schedule_seed, target_id, trial_index),
                conditions=conditions,  # type: ignore[arg-type]
            )
        )
    return tuple(schedule)


def build_control_manifest(
    *,
    targets: list[GroundTruthTarget],
    dataset_manifest: dict[str, Any],
    dataset_seed: int,
    schedule_seed: int,
    trials_per_target: int,
    budget_bytes: int,
    expected_provider: str,
    expected_model: str,
    sampling_policy: dict[str, Any],
    analysis_seed: int,
    success_thresholds: dict[str, float],
) -> ControlManifest:
    if dataset_manifest.get("dataset_version") != "v0.2":
        raise ValueError("controlled Gate 1 requires audited dataset v0.2")
    if int(dataset_manifest.get("fail_count", -1)) != 0:
        raise ValueError("controlled Gate 1 requires dataset v0.2 with zero audit failures")
    if not expected_provider:
        raise ValueError("expected_provider must not be empty")
    if not expected_model:
        raise ValueError("expected_model must not be empty")
    if trials_per_target <= 0:
        raise ValueError("trials_per_target must be positive")
    if budget_bytes <= 0:
        raise ValueError("budget_bytes must be positive")
    if len(targets) != int(dataset_manifest.get("target_count", -1)):
        raise ValueError("target count does not match dataset manifest")

    dataset_sha256 = str(dataset_manifest.get("dataset_sha256", ""))
    if len(dataset_sha256) != 64:
        raise ValueError("dataset_sha256 must be a 64-character SHA-256 hex digest")

    target_ids = [target.target_id for target in targets]
    if len(set(target_ids)) != len(target_ids):
        raise ValueError("target IDs must be unique")

    schedule = _balanced_schedule(
        target_ids=target_ids,
        trials_per_target=trials_per_target,
        dataset_seed=dataset_seed,
        schedule_seed=schedule_seed,
    )
    schedule_sha256 = _sha256([item.to_dict() for item in schedule])

    provisional = ControlManifest(
        experiment="PSSA-BSAR-Gate1",
        version="0.1-milestone4",
        dataset_version="v0.2",
        dataset_seed=dataset_seed,
        dataset_sha256=dataset_sha256,
        target_count=len(targets),
        trials_per_target=trials_per_target,
        budget_bytes=budget_bytes,
        schedule_seed=schedule_seed,
        analysis_seed=analysis_seed,
        expected_provider=expected_provider,
        expected_model=expected_model,
        sampling_policy=dict(sampling_policy),
        success_thresholds={str(k): float(v) for k, v in success_thresholds.items()},
        conditions=CONDITIONS,
        schedule=schedule,
        schedule_sha256=schedule_sha256,
        manifest_sha256="",
    )
    manifest_sha256 = _sha256(provisional._payload_without_manifest_hash())
    return ControlManifest(**{**provisional.__dict__, "manifest_sha256": manifest_sha256})


def write_control_manifest(path: Path, manifest: ControlManifest) -> None:
    manifest.validate_hashes()
    Path(path).write_text(
        json.dumps(manifest.to_dict(), ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )


def load_control_manifest(path: Path) -> ControlManifest:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    return ControlManifest.from_dict(data)

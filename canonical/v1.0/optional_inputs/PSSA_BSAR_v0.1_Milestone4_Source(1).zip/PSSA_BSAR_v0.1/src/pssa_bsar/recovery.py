from __future__ import annotations

import re
from typing import Any

from .models import Case, FrozenRepresentation, RecoveryResult, Relation


def _split_csv(text: str) -> tuple[str, ...]:
    text = text.strip()
    if not text or text == "none":
        return ()
    return tuple(part.strip() for part in text.split(",") if part.strip())


def _parse_definition(text: str) -> tuple[tuple[str, ...], tuple[str, ...], tuple[Relation, ...], tuple[str, ...], tuple[str, ...]]:
    pattern = re.compile(
        r"^A .+? target centered on (?P<pos>.+?)\. It excludes (?P<neg>.+?)\. "
        r"It is constrained by (?P<constraints>.*?)\. A salient relation is "
        r"(?P<src>[a-z0-9_]+) (?P<rel>[a-z0-9_]+) (?P<dst>[a-z0-9_]+)\. "
        r"Unresolved variable: (?P<open>.*?)\.$"
    )
    match = pattern.match(text)
    if not match:
        tokens = tuple(re.findall(r"[a-z0-9_]+", text.lower()))
        return tokens, (), (), (), ()
    relation = Relation(match["src"], match["rel"], match["dst"], 1, 0.8)
    return (
        _split_csv(match["pos"]),
        _split_csv(match["neg"]),
        (relation,),
        _split_csv(match["constraints"]),
        _split_csv(match["open"]),
    )


def _parse_representation(rep: FrozenRepresentation) -> tuple[tuple[str, ...], tuple[str, ...], tuple[Relation, ...], tuple[str, ...], tuple[str, ...]]:
    if rep.condition == "address_first":
        payload = rep.payload
        if not isinstance(payload, dict):
            raise TypeError("address_first payload must be a dict")
        relations = tuple(Relation.from_dict(x) for x in payload.get("relations", []))
        return (
            tuple(payload.get("positive_anchors", [])),
            tuple(payload.get("negative_anchors", [])),
            relations,
            tuple(payload.get("constraints", [])),
            tuple(payload.get("open_variables", [])),
        )
    if rep.condition == "definition_first":
        if not isinstance(rep.payload, str):
            raise TypeError("definition_first payload must be text")
        return _parse_definition(rep.payload)
    if rep.condition == "keyword_first":
        if not isinstance(rep.payload, list):
            raise TypeError("keyword_first payload must be a list")
        return tuple(str(x) for x in rep.payload), (), (), (), ()
    raise ValueError(f"unknown representation condition: {rep.condition}")


def _tokens(text: str) -> set[str]:
    return set(re.findall(r"[a-z0-9_]+", text.lower()))


def _predict(case: Case, positive: tuple[str, ...], negative: tuple[str, ...], constraints: tuple[str, ...]) -> bool:
    tokens = _tokens(case.description)
    if any(anchor in tokens for anchor in negative):
        return False
    if any(anchor in tokens for anchor in positive):
        return True
    if any(constraint in tokens for constraint in constraints):
        return True
    return False


def recover(rep: FrozenRepresentation, eval_cases: list[Case]) -> RecoveryResult:
    positive, negative, relations, constraints, open_variables = _parse_representation(rep)
    holdout_predictions: dict[str, bool] = {}
    adversarial_predictions: dict[str, bool] = {}
    for case in eval_cases:
        prediction = _predict(case, positive, negative, constraints)
        if case.kind == "holdout":
            holdout_predictions[case.case_id] = prediction
        elif case.kind == "adversarial":
            adversarial_predictions[case.case_id] = prediction
    rendering = (
        f"Recovered {len(positive)} positive anchors, {len(negative)} exclusions, "
        f"{len(relations)} relations, {len(constraints)} constraints, and "
        f"{len(open_variables)} unresolved variables."
    )
    return RecoveryResult(
        target_id=rep.target_id,
        condition=rep.condition,
        recovered_positive_anchors=positive,
        recovered_negative_anchors=negative,
        relations=relations,
        constraints=constraints,
        open_variables=open_variables,
        holdout_predictions=holdout_predictions,
        adversarial_predictions=adversarial_predictions,
        rendering=rendering,
    )

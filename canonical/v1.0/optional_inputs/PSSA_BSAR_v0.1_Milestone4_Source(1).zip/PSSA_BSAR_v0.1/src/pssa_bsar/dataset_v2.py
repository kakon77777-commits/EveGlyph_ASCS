from __future__ import annotations

import random
from dataclasses import dataclass

from .models import Case, GroundTruthTarget, ObservationBundle, Relation


@dataclass(frozen=True)
class _V2FamilySpec:
    family: str
    category: str
    positive_anchors: tuple[str, ...]
    negative_anchors: tuple[str, ...]
    relations: tuple[tuple[str, str, str, int], ...]
    constraints: tuple[str, ...]
    open_variable: str
    positive_frames: tuple[str, ...]
    negative_frames: tuple[str, ...]
    holdout_positive_frames: tuple[str, ...]
    holdout_negative_frames: tuple[str, ...]
    adversarial_frames: tuple[tuple[str, bool], ...]
    variants: tuple[tuple[str, str], ...]
    unresolved_surface: str
    relation_probe_surface: str


_SPECS = (
    _V2FamilySpec(
        family="identity_continuity",
        category="identity",
        positive_anchors=("historical_continuity", "traceable_provenance", "responsibility_chain"),
        negative_anchors=("appearance_only_match", "snapshot_copy", "unlinked_replica"),
        relations=(
            ("historical_continuity", "supports", "responsibility_chain", 1),
            ("traceable_provenance", "constrains", "identity_claim", 1),
            ("snapshot_copy", "insufficient_for", "historical_continuity", -1),
        ),
        constraints=("lineage_evidence_required", "silent_replacement_invalid"),
        open_variable="continuity_cutoff",
        positive_frames=(
            "Each revision keeps an auditable chain back to earlier states, and obligations follow that chain {p}.",
            "The current bearer can show how every handoff arose from the previous one, including who inherited duties {p}.",
            "Changes accumulate through recorded transitions rather than an isolated replacement {p}.",
            "A dispute can be resolved by replaying the sequence of transfers and checking who remained answerable {p}.",
        ),
        negative_frames=(
            "A perfect visual duplicate appears from one frozen moment, but nothing links it to what came before {n}.",
            "The replacement has the same label and shape, yet no record explains how it inherited any prior obligations {n}.",
            "Only one saved image survives; the path between earlier and current states is missing {n}.",
            "A copy is declared equivalent solely because it looks the same, despite an absent transition record {n}.",
        ),
        holdout_positive_frames=(
            "An auditor can reconstruct successive handovers and show why the present holder remains answerable {p}.",
            "The object changed repeatedly, but every change is linked to a prior state by recorded transfers {p}.",
        ),
        holdout_negative_frames=(
            "Two instances are indistinguishable in a photograph, while one has no chain connecting it to earlier events {n}.",
            "A saved snapshot is restored under the old name, with no evidence that duties survived the break {n}.",
        ),
        adversarial_frames=(
            ("The duplicate is byte-for-byte identical and carries the old badge, but there is no recorded path from the former bearer {n}.", False),
            ("The exterior is different after repairs, yet the recorded handoff chain and assigned duties remain inspectable {p}.", True),
        ),
        variants=(
            ("through a signed handoff log", "after an unlabeled clone"),
            ("across staged migrations", "after a one-shot restore"),
            ("through a custody trail", "after a detached copy"),
            ("across maintained versions", "after a disconnected fork"),
            ("through recorded succession", "after an anonymous swap"),
            ("across verified transfers", "after a stand-alone replica"),
        ),
        unresolved_surface="The exact amount of breakage that should count as too much remains intentionally unspecified.",
        relation_probe_surface="Describe how a recorded transition history should affect later responsibility without naming the hidden concept.",
    ),
    _V2FamilySpec(
        family="causality_intervention",
        category="causality",
        positive_anchors=("controlled_intervention", "counterfactual_dependence", "mechanism_path"),
        negative_anchors=("correlation_only", "shared_trend", "posthoc_narrative"),
        relations=(
            ("controlled_intervention", "changes", "outcome_state", 1),
            ("mechanism_path", "mediates", "outcome_state", 1),
            ("correlation_only", "insufficient_for", "causal_claim", -1),
        ),
        constraints=("alternative_explanations_tracked", "manipulation_link_required"),
        open_variable="intervention_strength_threshold",
        positive_frames=(
            "When one factor is deliberately changed while alternatives are held in check, the downstream result shifts {p}.",
            "Changing the candidate driver produces a repeatable downstream difference and the intermediate steps are observable {p}.",
            "The result follows the manipulated pathway rather than merely moving at the same time {p}.",
            "A controlled alteration changes the later state, while rival explanations are explicitly monitored {p}.",
        ),
        negative_frames=(
            "Two measurements rise together, but neither is deliberately altered and a third influence is left uncontrolled {n}.",
            "The sequence happens in the expected order, yet no manipulation separates the proposed driver from a common background cause {n}.",
            "A story is written after the outcome using only co-movement, without an independent change to the proposed driver {n}.",
            "The variables share a trend across time, but the system never tests what happens when one is changed on purpose {n}.",
        ),
        holdout_positive_frames=(
            "A planned change to one component produces a repeatable downstream shift while competing pathways stay monitored {p}.",
            "The proposed driver is varied across trials and the later response follows the predicted intermediate route {p}.",
        ),
        holdout_negative_frames=(
            "The two series track one another closely, but both could be responding to the same external event {n}.",
            "The explanation fits the observed order only after the fact and no deliberate perturbation was performed {n}.",
        ),
        adversarial_frames=(
            ("The graphs align almost perfectly and the timing looks persuasive, but the proposed driver was never independently changed {n}.", False),
            ("The raw correlation is modest, yet a targeted perturbation repeatedly moves the predicted downstream state through the same intermediate route {p}.", True),
        ),
        variants=(
            ("under randomized switches", "during a synchronized trend"),
            ("under isolated perturbations", "during a seasonal rise"),
            ("under controlled toggles", "during a common shock"),
            ("under staged manipulations", "during shared drift"),
            ("under repeatable interventions", "during parallel movement"),
            ("under alternate-setting trials", "during coincident timing"),
        ),
        unresolved_surface="How large a deliberately induced change must be before the evidence is persuasive remains open.",
        relation_probe_surface="Describe how a deliberate change and an observed intermediate route should alter confidence in a directional explanation.",
    ),
    _V2FamilySpec(
        family="boundary_access",
        category="boundary",
        positive_anchors=("selective_access_control", "direction_sensitive_passage", "contextual_threshold"),
        negative_anchors=("mere_difference", "free_passage", "symmetric_default"),
        relations=(
            ("contextual_threshold", "conditions", "selective_access_control", 1),
            ("direction_sensitive_passage", "modulates", "crossing_result", 1),
            ("mere_difference", "insufficient_for", "boundary_effect", -1),
        ),
        constraints=("effect_channel_specified", "crossing_context_required"),
        open_variable="effective_strength_cutoff",
        positive_frames=(
            "Crossing is allowed for one kind of traveler but blocked for another, and the result depends on approach direction {p}.",
            "The same location permits one transfer channel while stopping a different channel under stated conditions {p}.",
            "A crossing rule changes what can pass once a context-dependent level is exceeded {p}.",
            "Movement through the interface is selective rather than uniformly open, with different results from opposite sides {p}.",
        ),
        negative_frames=(
            "Two regions have different labels, but movement between them is unrestricted and nothing changes on crossing {n}.",
            "A visible line separates colors on a map, yet every relevant transfer behaves exactly the same on both sides {n}.",
            "The coordinates differ, but there is no rule, cost, trigger, or selective passage associated with the change {n}.",
            "The marker is purely decorative and crossing it has no effect on any tested channel {n}.",
        ),
        holdout_positive_frames=(
            "A packet may enter from one side only when a stated condition is met; the reverse path follows a different rule {p}.",
            "One substance crosses the interface while another is stopped, and the outcome changes with the operating context {p}.",
        ),
        holdout_negative_frames=(
            "The map changes color at a coordinate, but all tested movements continue without cost or restriction {n}.",
            "A named line separates two administrative labels while every relevant passage remains identical in both directions {n}.",
        ),
        adversarial_frames=(
            ("The line is thick, official, and visually obvious, but every tested traveler crosses it freely in both directions {n}.", False),
            ("The interface is almost invisible, yet one direction blocks the transfer once a specified operating condition is reached {p}.", True),
        ),
        variants=(
            ("for authenticated traffic", "across a decorative marker"),
            ("for one-way flow", "across a color change"),
            ("under a permission rule", "across a coordinate label"),
            ("for selected material", "across a painted stripe"),
            ("under an operating threshold", "across a named region"),
            ("for gated movement", "across a visual divider"),
        ),
        unresolved_surface="The exact strength at which the selective effect should count as practically important is left open.",
        relation_probe_surface="Describe how direction and operating conditions should change the interpretation of a crossing without naming the hidden concept.",
    ),
    _V2FamilySpec(
        family="reconstruction_recoverability",
        category="reconstruction",
        positive_anchors=("recoverable_state", "independent_redundancy", "source_trace"),
        negative_anchors=("surface_lookalike", "irreversible_overwrite", "unsupported_guess"),
        relations=(
            ("independent_redundancy", "supports", "recoverable_state", 1),
            ("source_trace", "constrains", "repair_candidate", 1),
            ("unsupported_guess", "insufficient_for", "recovery_claim", -1),
        ),
        constraints=("repair_path_auditable", "uncertainty_marked"),
        open_variable="minimum_recovery_evidence",
        positive_frames=(
            "After damage, multiple independent traces can be compared to rebuild the missing state and every repair step can be inspected {p}.",
            "A lost segment can be reconstructed from separate retained records while uncertainty about doubtful pieces stays explicit {p}.",
            "The system detects corruption, traces earlier sources, and proposes a repair that can be checked against independent evidence {p}.",
            "Rollback points and separate evidence streams make it possible to restore an earlier state without pretending uncertain gaps are known {p}.",
        ),
        negative_frames=(
            "A plausible-looking replacement is invented after loss, but there is no independent record showing it matches the missing state {n}.",
            "The damaged content is overwritten permanently and the later fill is chosen only because it resembles neighboring material {n}.",
            "Only one evidence-free proposal remains, with no retained source trail or way to verify the repair {n}.",
            "The output looks convincing, yet the evidence needed to distinguish restoration from fabrication has disappeared {n}.",
        ),
        holdout_positive_frames=(
            "Several separately preserved traces agree on the missing segment, and the restoration can be replayed step by step {p}.",
            "A prior checkpoint plus independent evidence allows a damaged state to be rebuilt while uncertain fragments remain flagged {p}.",
        ),
        holdout_negative_frames=(
            "The replacement resembles the surrounding content, but every original trace was erased before the guess was inserted {n}.",
            "A repair candidate is selected from intuition alone and there is no retained evidence with which to challenge it {n}.",
        ),
        adversarial_frames=(
            ("The reconstructed output is visually convincing and internally smooth, but no independent trace survived to test whether it is authentic {n}.", False),
            ("The rebuilt result looks different from a naive guess, yet several independent records and a replayable repair path agree on it {p}.", True),
        ),
        variants=(
            ("using separate checkpoints", "after every prior copy is erased"),
            ("using independently kept traces", "after destructive overwrite"),
            ("using a replayable repair log", "after evidence-free filling"),
            ("using several source fragments", "after a one-source guess"),
            ("using a retained rollback point", "after silent corruption"),
            ("using cross-checked archives", "after unverifiable replacement"),
        ),
        unresolved_surface="How much independent evidence is enough to call the rebuilt state acceptable is deliberately not fixed.",
        relation_probe_surface="Describe how independent traces and an inspectable repair path should constrain a proposed restored state.",
    ),
    _V2FamilySpec(
        family="intention_specification",
        category="intention",
        positive_anchors=("explicit_goal", "bounded_method", "verification_contract"),
        negative_anchors=("wish_only", "unbounded_instruction", "unstated_failure_handling"),
        relations=(
            ("bounded_method", "constrains", "explicit_goal", 1),
            ("verification_contract", "checks", "explicit_goal", 1),
            ("wish_only", "insufficient_for", "executable_specification", -1),
        ),
        constraints=("forbidden_paths_recorded", "failure_response_explicit"),
        open_variable="acceptable_goal_tolerance",
        positive_frames=(
            "The request states the desired outcome, allowed methods, forbidden moves, and a test that decides whether the result is acceptable {p}.",
            "The task includes resource limits, a success check, and instructions for what to do if execution cannot meet the requirement {p}.",
            "The operator knows both the target state and which routes are disallowed, with an explicit check before committing the result {p}.",
            "The request is actionable because it includes a measurable outcome, bounded methods, and a rollback rule {p}.",
        ),
        negative_frames=(
            "The instruction only says to make things better, with no success test, resource limit, or rule for handling failure {n}.",
            "A desirable outcome is mentioned, but any method is implicitly permitted and no forbidden path is recorded {n}.",
            "The request expresses a preference but never states how completion will be checked or what should happen if execution fails {n}.",
            "The command names an aspiration without measurable acceptance conditions or operational limits {n}.",
        ),
        holdout_positive_frames=(
            "The assignment includes a measurable end state, a restricted set of methods, and a check that must pass before acceptance {p}.",
            "The operator receives a resource ceiling, prohibited actions, a success test, and a fallback procedure {p}.",
        ),
        holdout_negative_frames=(
            "The request asks for the best possible outcome but gives no criterion for success and no limits on how to pursue it {n}.",
            "The message expresses what would be nice to have, yet leaves failure response and forbidden actions completely unstated {n}.",
        ),
        adversarial_frames=(
            ("The instruction sounds ambitious and precise in tone, but it still lacks an acceptance test and permits any route to the result {n}.", False),
            ("The request is brief and plain, yet it specifies a measurable end state, restricted methods, and a concrete fallback if the check fails {p}.", True),
        ),
        variants=(
            ("under a fixed compute budget", "with unlimited discretion"),
            ("under a bounded tool set", "with no fallback rule"),
            ("with a predeclared acceptance check", "with only a vague preference"),
            ("with explicit prohibited actions", "with any method allowed"),
            ("with a rollback condition", "with fire-and-forget execution"),
            ("with measurable completion criteria", "with no test for completion"),
        ),
        unresolved_surface="The exact tolerance around the desired outcome is intentionally left for later calibration.",
        relation_probe_surface="Describe how allowed methods and a success check should constrain execution of a request without naming the hidden concept.",
    ),
)


def _instantiate_cases(
    spec: _V2FamilySpec,
    target_id: str,
    positive_variant: str,
    negative_variant: str,
) -> tuple[tuple[Case, ...], tuple[Case, ...], tuple[Case, ...]]:
    development: list[Case] = []
    for idx, frame in enumerate(spec.positive_frames):
        development.append(Case(f"{target_id}-d{idx}", frame.format(p=positive_variant, n=negative_variant), True, "development"))
    offset = len(development)
    for idx, frame in enumerate(spec.negative_frames):
        development.append(Case(f"{target_id}-d{offset + idx}", frame.format(p=positive_variant, n=negative_variant), False, "development"))

    holdout = (
        Case(f"{target_id}-h0", spec.holdout_positive_frames[0].format(p=positive_variant, n=negative_variant), True, "holdout"),
        Case(f"{target_id}-h1", spec.holdout_negative_frames[0].format(p=positive_variant, n=negative_variant), False, "holdout"),
        Case(f"{target_id}-h2", spec.holdout_positive_frames[1].format(p=positive_variant, n=negative_variant), True, "holdout"),
        Case(f"{target_id}-h3", spec.holdout_negative_frames[1].format(p=positive_variant, n=negative_variant), False, "holdout"),
    )
    adversarial = tuple(
        Case(f"{target_id}-a{idx}", frame.format(p=positive_variant, n=negative_variant), label, "adversarial")
        for idx, (frame, label) in enumerate(spec.adversarial_frames)
    )
    return tuple(development), holdout, adversarial


def generate_targets_v2(seed: int = 20260821, count: int = 30) -> list[GroundTruthTarget]:
    if count <= 0 or count % len(_SPECS) != 0:
        raise ValueError("count must be a positive multiple of five")
    per_family = count // len(_SPECS)
    if per_family > 6:
        raise ValueError("v0.2 provides at most six deterministic variants per family")

    candidates: list[tuple[_V2FamilySpec, str, str]] = []
    for spec in _SPECS:
        for positive_variant, negative_variant in spec.variants[:per_family]:
            candidates.append((spec, positive_variant, negative_variant))

    rng = random.Random(seed)
    rng.shuffle(candidates)

    targets: list[GroundTruthTarget] = []
    for index, (spec, positive_variant, negative_variant) in enumerate(candidates):
        target_id = f"bsar2-{index:03d}"
        development, holdout, adversarial = _instantiate_cases(spec, target_id, positive_variant, negative_variant)
        relations = tuple(Relation(src, rel, dst, polarity, 0.95) for src, rel, dst, polarity in spec.relations)
        targets.append(
            GroundTruthTarget(
                target_id=target_id,
                family=spec.family,
                positive_anchors=spec.positive_anchors,
                negative_anchors=spec.negative_anchors,
                relations=relations,
                constraints=spec.constraints,
                open_variables=(spec.open_variable,),
                candidate_categories=(spec.category,),
                development_cases=development,
                holdout_cases=holdout,
                adversarial_cases=adversarial,
            )
        )
    return targets


def _spec_for_family(family: str) -> _V2FamilySpec:
    for spec in _SPECS:
        if spec.family == family:
            return spec
    raise KeyError(family)


def make_observation_v2(target: GroundTruthTarget) -> ObservationBundle:
    spec = _spec_for_family(target.family)
    positive = tuple(case.description for case in target.development_cases if case.label)[:3]
    negative = tuple(case.description for case in target.development_cases if case.label is False)[:3]
    return ObservationBundle(
        target_id=target.target_id,
        family="undisclosed",
        positive_examples=positive,
        negative_examples=negative,
        minimal_contrasts=((positive[0], negative[0]), (positive[1], negative[1])),
        unresolved_ambiguity=spec.unresolved_surface,
        misleading_neighbor=negative[-1],
        relation_probe=spec.relation_probe_surface,
        candidate_categories=(),
    )

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Any

from .models import GroundTruthTarget, ObservationBundle

_STOPWORDS = {
    "a", "an", "and", "are", "as", "at", "be", "but", "by", "for", "from", "if", "in", "is",
    "it", "its", "no", "not", "of", "on", "one", "or", "that", "the", "their", "this", "to",
    "under", "when", "while", "with", "without", "every", "any", "same", "only",
}


def _tokens(text: str) -> list[str]:
    return re.findall(r"[a-z0-9]+", text.replace("_", " ").lower())


def _contains_phrase(text_tokens: list[str], phrase: str) -> bool:
    needle = _tokens(phrase)
    if not needle:
        return False
    width = len(needle)
    return any(text_tokens[i : i + width] == needle for i in range(len(text_tokens) - width + 1))


def _bigrams(text: str) -> set[tuple[str, str]]:
    tokens = _tokens(text)
    return set(zip(tokens, tokens[1:]))


def _jaccard(a: set[object], b: set[object]) -> float:
    if not a and not b:
        return 0.0
    return len(a & b) / len(a | b)


def _content_tokens(text: str) -> set[str]:
    return {token for token in _tokens(text) if len(token) > 2 and token not in _STOPWORDS}


def _observation_text(observation: ObservationBundle) -> str:
    contrast_text = tuple(" ".join(pair) for pair in observation.minimal_contrasts)
    return " ".join(
        observation.positive_examples
        + observation.negative_examples
        + contrast_text
        + (
            observation.unresolved_ambiguity,
            observation.misleading_neighbor,
            observation.relation_probe,
        )
    )


def _sensitive_identifiers(target: GroundTruthTarget) -> list[str]:
    values = {
        target.family,
        *target.candidate_categories,
        *target.positive_anchors,
        *target.negative_anchors,
        *target.constraints,
        *target.open_variables,
    }
    for relation in target.relations:
        values.add(relation.source)
        values.add(relation.target)
    return sorted(values)


def _canonical_bytes(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def audit_target_v2(target: GroundTruthTarget, observation: ObservationBundle) -> dict[str, Any]:
    failure_tags: list[str] = []
    obs_tokens = _tokens(_observation_text(observation))
    sensitive_leaks = [
        identifier
        for identifier in _sensitive_identifiers(target)
        if _contains_phrase(obs_tokens, identifier)
    ]
    if sensitive_leaks:
        failure_tags.append("canonical_identifier_leakage")

    opaque_id_ok = bool(re.fullmatch(r"bsar2-\d{3}", target.target_id)) and target.family not in target.target_id
    if not opaque_id_ok:
        failure_tags.append("non_opaque_target_id")

    hidden_metadata_ok = observation.family == "undisclosed" and not observation.candidate_categories
    if not hidden_metadata_ok:
        failure_tags.append("builder_visible_family_or_category")

    dev_text = {case.description for case in target.development_cases}
    hold_text = {case.description for case in target.holdout_cases}
    adv_text = {case.description for case in target.adversarial_cases}
    exact_reuse = bool(dev_text & hold_text or dev_text & adv_text or hold_text & adv_text)
    if exact_reuse:
        failure_tags.append("cross_split_exact_reuse")

    max_overlap = 0.0
    for dev in target.development_cases:
        dev_bigrams = _bigrams(dev.description)
        for other in (*target.holdout_cases, *target.adversarial_cases):
            max_overlap = max(max_overlap, _jaccard(dev_bigrams, _bigrams(other.description)))
    max_overlap = round(max_overlap, 12)
    if max_overlap > 0.30:
        failure_tags.append("cross_split_bigram_overlap")

    positive_surface_tokens: set[str] = set()
    for case in target.development_cases:
        if case.label is True:
            positive_surface_tokens.update(_content_tokens(case.description))

    adversarial_negative_cues: dict[str, list[str]] = {}
    for case in target.adversarial_cases:
        if case.label is False:
            shared = sorted(positive_surface_tokens & _content_tokens(case.description))
            adversarial_negative_cues[case.case_id] = shared
            if not shared:
                failure_tags.append("adversarial_without_positive_surface_cue")

    return {
        "target_id": target.target_id,
        "family": target.family,
        "passed": not failure_tags,
        "failure_tags": sorted(set(failure_tags)),
        "sensitive_leaks": sensitive_leaks,
        "opaque_id_ok": opaque_id_ok,
        "hidden_metadata_ok": hidden_metadata_ok,
        "cross_split_exact_reuse": exact_reuse,
        "max_cross_split_bigram_jaccard": max_overlap,
        "adversarial_negative_shared_cues": adversarial_negative_cues,
    }


def audit_dataset_v2(
    targets: list[GroundTruthTarget],
    observations: list[ObservationBundle],
    seed: int,
) -> dict[str, Any]:
    if len(targets) != len(observations):
        raise ValueError("targets and observations must have equal length")
    observations_by_id = {obs.target_id: obs for obs in observations}
    if len(observations_by_id) != len(observations):
        raise ValueError("observation target IDs must be unique")

    rows = [audit_target_v2(target, observations_by_id[target.target_id]) for target in targets]
    payload = {
        "targets": [target.to_dict() for target in targets],
        "observations": [observations_by_id[target.target_id].to_dict() for target in targets],
    }
    dataset_sha256 = hashlib.sha256(_canonical_bytes(payload)).hexdigest()
    pass_count = sum(row["passed"] for row in rows)
    return {
        "dataset_version": "v0.2",
        "seed": seed,
        "target_count": len(targets),
        "pass_count": pass_count,
        "fail_count": len(rows) - pass_count,
        "audit_policy": {
            "max_cross_split_bigram_jaccard": 0.30,
            "opaque_target_ids": True,
            "hide_family_and_category": True,
            "canonical_identifier_leakage_forbidden": True,
            "adversarial_negative_requires_positive_surface_cue": True,
        },
        "dataset_sha256": dataset_sha256,
        "targets": rows,
    }


def write_dataset_manifest(path: Path, report: dict[str, Any]) -> None:
    Path(path).write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )

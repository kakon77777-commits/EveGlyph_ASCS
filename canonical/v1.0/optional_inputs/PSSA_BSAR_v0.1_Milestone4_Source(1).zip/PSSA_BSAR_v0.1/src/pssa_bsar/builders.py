from __future__ import annotations

import json
import re
from collections import Counter
from typing import Any

from .models import FrozenRepresentation, ObservationBundle

_STOP = {
    "evidence", "pattern", "state", "relation", "neighbor", "holdout", "adversarial",
    "safe_context", "without", "decoy",
}
_RELATION_WORDS = {
    "supports", "changes", "mediates", "insufficient_for", "conditions", "modulates",
    "constrains", "bounds", "checks",
}
_CONSTRAINT_MARKERS = (
    "must_be", "required", "insufficient", "tracked", "specified", "explicit", "recorded",
    "auditable", "marked",
)


def _tokenize(text: str) -> list[str]:
    return re.findall(r"[a-z0-9_]+", text.lower())


def _is_constraint(token: str) -> bool:
    return any(marker in token for marker in _CONSTRAINT_MARKERS)


def _ranked_terms(examples: tuple[str, ...], *, negative: bool = False) -> list[str]:
    counts: Counter[str] = Counter()
    order: list[str] = []
    for example in examples:
        for token in _tokenize(example):
            if token in _STOP or token in _RELATION_WORDS or _is_constraint(token):
                continue
            if token.startswith("decoy_") or token.startswith("without_"):
                continue
            if token not in counts:
                order.append(token)
            counts[token] += 1
    positions = {token: i for i, token in enumerate(order)}
    order.sort(key=lambda x: (-counts[x], positions[x]))
    return order


def _constraints(obs: ObservationBundle) -> list[str]:
    found: list[str] = []
    for example in obs.positive_examples:
        for token in _tokenize(example):
            if _is_constraint(token) and token not in found:
                found.append(token)
    return found


def _relation(obs: ObservationBundle) -> dict[str, Any]:
    parts = _tokenize(obs.relation_probe)
    if len(parts) < 3:
        return {"source": "unknown", "relation_type": "related_to", "target": "unknown", "polarity": 1, "confidence": 0.5}
    return {"source": parts[0], "relation_type": parts[1], "target": parts[2], "polarity": 1, "confidence": 0.8}


def _payload_bytes(payload: Any) -> int:
    if isinstance(payload, str):
        text = payload
    else:
        text = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return len(text.encode("utf-8"))


def _token_count(payload: Any) -> int:
    if isinstance(payload, str):
        text = payload
    else:
        text = json.dumps(payload, ensure_ascii=False, sort_keys=True)
    return len(re.findall(r"\w+", text, flags=re.UNICODE))


def _truncate_text(text: str, budget_bytes: int) -> str:
    if budget_bytes <= 0:
        raise ValueError("budget_bytes must be positive")
    encoded = text.encode("utf-8")
    if len(encoded) <= budget_bytes:
        return text
    suffix = "..."
    room = max(0, budget_bytes - len(suffix.encode("utf-8")))
    clipped = encoded[:room]
    while clipped:
        try:
            return clipped.decode("utf-8") + suffix
        except UnicodeDecodeError:
            clipped = clipped[:-1]
    return suffix[:budget_bytes]


def _freeze(target_id: str, condition: str, payload: Any, budget_bytes: int) -> FrozenRepresentation:
    size = _payload_bytes(payload)
    if size > budget_bytes:
        raise ValueError(f"representation exceeds budget: {size} > {budget_bytes}")
    return FrozenRepresentation(target_id, condition, payload, size, _token_count(payload))


def _address_payload(obs: ObservationBundle) -> dict[str, Any]:
    positives = _ranked_terms(obs.positive_examples)
    negatives = _ranked_terms(obs.negative_examples, negative=True)
    if obs.misleading_neighbor not in negatives:
        negatives.append(obs.misleading_neighbor)
    return {
        "positive_anchors": positives[:6],
        "negative_anchors": negatives[:5],
        "relations": [_relation(obs)],
        "constraints": _constraints(obs)[:6],
        "open_variables": [obs.unresolved_ambiguity] if obs.unresolved_ambiguity else [],
        "candidate_categories": list(obs.candidate_categories[:3]),
        "confidence": {"anchors": 0.8, "relations": 0.8, "constraints": 0.75, "open_variables": 1.0},
    }


def build_address(obs: ObservationBundle, budget_bytes: int = 900) -> FrozenRepresentation:
    payload = _address_payload(obs)
    trim_order = ["candidate_categories", "positive_anchors", "negative_anchors", "constraints", "open_variables", "relations"]
    while _payload_bytes(payload) > budget_bytes:
        changed = False
        for key in trim_order:
            value = payload[key]
            minimum = 1 if key in {"positive_anchors", "negative_anchors", "relations"} else 0
            if isinstance(value, list) and len(value) > minimum:
                value.pop()
                changed = True
                break
        if not changed:
            raise ValueError("budget too small for minimum address schema")
    return _freeze(obs.target_id, "address_first", payload, budget_bytes)


def build_definition(obs: ObservationBundle, budget_bytes: int = 900) -> FrozenRepresentation:
    address = _address_payload(obs)
    positives = ", ".join(address["positive_anchors"])
    negatives = ", ".join(address["negative_anchors"])
    constraints = ", ".join(address["constraints"])
    category = ", ".join(address["candidate_categories"]) or "uncategorized"
    relation = address["relations"][0]
    open_var = ", ".join(address["open_variables"]) or "none"
    text = (
        f"A {category} target centered on {positives}. It excludes {negatives}. "
        f"It is constrained by {constraints}. A salient relation is {relation['source']} "
        f"{relation['relation_type']} {relation['target']}. Unresolved variable: {open_var}."
    )
    text = _truncate_text(text, budget_bytes)
    return _freeze(obs.target_id, "definition_first", text, budget_bytes)


def build_keywords(obs: ObservationBundle, budget_bytes: int = 900) -> FrozenRepresentation:
    address = _address_payload(obs)
    # Deliberately untyped: negative anchors lose their polarity in this baseline.
    payload = list(dict.fromkeys(address["positive_anchors"] + address["negative_anchors"] + address["candidate_categories"]))
    while payload and _payload_bytes(payload) > budget_bytes:
        payload.pop()
    if not payload:
        raise ValueError("budget too small for keyword representation")
    return _freeze(obs.target_id, "keyword_first", payload, budget_bytes)

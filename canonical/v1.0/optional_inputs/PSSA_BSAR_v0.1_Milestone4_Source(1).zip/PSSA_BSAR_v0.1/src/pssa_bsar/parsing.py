from __future__ import annotations

import json
import re
from typing import Any

from .models import FrozenRepresentation, RecoveryResult, Relation


class ParseError(ValueError):
    def __init__(self, kind: str, message: str):
        super().__init__(f"{kind}: {message}")
        self.kind = kind


def _loads_object(text: str) -> Any:
    try:
        return json.loads(text)
    except json.JSONDecodeError as exc:
        raise ParseError("invalid_json", str(exc)) from exc


def _payload_bytes(payload: Any) -> int:
    if isinstance(payload, str):
        encoded = payload
    else:
        encoded = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return len(encoded.encode("utf-8"))


def _token_count(payload: Any) -> int:
    text = payload if isinstance(payload, str) else json.dumps(payload, ensure_ascii=False, sort_keys=True)
    return len(re.findall(r"\w+", text, flags=re.UNICODE))


def _require_str_list(value: Any, field: str) -> list[str]:
    if not isinstance(value, list) or any(not isinstance(item, str) for item in value):
        raise ParseError("schema", f"{field} must be a list of strings")
    return list(value)


def _validate_relation_dict(value: Any) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ParseError("schema", "relation must be an object")
    required = {"source", "relation_type", "target", "polarity", "confidence"}
    if set(value) != required:
        raise ParseError("schema", "relation keys mismatch")
    if not all(isinstance(value[k], str) for k in ("source", "relation_type", "target")):
        raise ParseError("schema", "relation text fields must be strings")
    if value["polarity"] not in (-1, 1):
        raise ParseError("schema", "relation polarity must be -1 or 1")
    if not isinstance(value["confidence"], (int, float)):
        raise ParseError("schema", "relation confidence must be numeric")
    return dict(value)


def parse_builder_response(condition: str, target_id: str, text: str, budget_bytes: int) -> FrozenRepresentation:
    if budget_bytes <= 0:
        raise ValueError("budget_bytes must be positive")
    data = _loads_object(text)
    if not isinstance(data, dict):
        raise ParseError("schema", "builder response must be a JSON object")
    if condition == "definition_first":
        if set(data) != {"definition"} or not isinstance(data["definition"], str):
            raise ParseError("schema", "definition_first requires exactly one string definition")
        payload: Any = data["definition"]
    elif condition == "keyword_first":
        if set(data) != {"keywords"}:
            raise ParseError("schema", "keyword_first requires exactly keywords")
        payload = _require_str_list(data["keywords"], "keywords")
    elif condition == "address_first":
        required = {
            "positive_anchors", "negative_anchors", "relations", "constraints",
            "open_variables", "candidate_categories", "confidence",
        }
        if set(data) != required:
            raise ParseError("schema", "address_first keys mismatch")
        payload = {
            "positive_anchors": _require_str_list(data["positive_anchors"], "positive_anchors"),
            "negative_anchors": _require_str_list(data["negative_anchors"], "negative_anchors"),
            "relations": [_validate_relation_dict(x) for x in data["relations"]] if isinstance(data["relations"], list) else None,
            "constraints": _require_str_list(data["constraints"], "constraints"),
            "open_variables": _require_str_list(data["open_variables"], "open_variables"),
            "candidate_categories": _require_str_list(data["candidate_categories"], "candidate_categories"),
            "confidence": data["confidence"],
        }
        if payload["relations"] is None:
            raise ParseError("schema", "relations must be a list")
        if not isinstance(payload["confidence"], dict):
            raise ParseError("schema", "confidence must be an object")
        if any(not isinstance(v, (int, float)) for v in payload["confidence"].values()):
            raise ParseError("schema", "confidence values must be numeric")
    else:
        raise ValueError(f"unknown condition: {condition}")
    size = _payload_bytes(payload)
    if size > budget_bytes:
        raise ParseError("over_budget", f"representation exceeds budget: {size} > {budget_bytes}")
    return FrozenRepresentation(target_id, condition, payload, size, _token_count(payload))


def parse_recovery_response(target_id: str, condition: str, text: str) -> RecoveryResult:
    data = _loads_object(text)
    if not isinstance(data, dict):
        raise ParseError("schema", "recovery response must be an object")
    required = {
        "recovered_positive_anchors", "recovered_negative_anchors", "relations",
        "constraints", "open_variables", "holdout_predictions",
        "adversarial_predictions", "rendering",
    }
    if set(data) != required:
        raise ParseError("schema", "recovery keys mismatch")
    if not isinstance(data["relations"], list):
        raise ParseError("schema", "relations must be a list")
    if not isinstance(data["holdout_predictions"], dict) or not all(
        isinstance(k, str) and isinstance(v, bool) for k, v in data["holdout_predictions"].items()
    ):
        raise ParseError("schema", "holdout_predictions must map strings to booleans")
    if not isinstance(data["adversarial_predictions"], dict) or not all(
        isinstance(k, str) and isinstance(v, bool) for k, v in data["adversarial_predictions"].items()
    ):
        raise ParseError("schema", "adversarial_predictions must map strings to booleans")
    if not isinstance(data["rendering"], str):
        raise ParseError("schema", "rendering must be a string")
    relations = tuple(Relation.from_dict(_validate_relation_dict(x)) for x in data["relations"])
    return RecoveryResult(
        target_id=target_id,
        condition=condition,
        recovered_positive_anchors=tuple(_require_str_list(data["recovered_positive_anchors"], "recovered_positive_anchors")),
        recovered_negative_anchors=tuple(_require_str_list(data["recovered_negative_anchors"], "recovered_negative_anchors")),
        relations=relations,
        constraints=tuple(_require_str_list(data["constraints"], "constraints")),
        open_variables=tuple(_require_str_list(data["open_variables"], "open_variables")),
        holdout_predictions=dict(data["holdout_predictions"]),
        adversarial_predictions=dict(data["adversarial_predictions"]),
        rendering=data["rendering"],
    )

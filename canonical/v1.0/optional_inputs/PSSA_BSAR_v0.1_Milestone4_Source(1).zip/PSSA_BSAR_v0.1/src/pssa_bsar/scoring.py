from __future__ import annotations

import math
from collections.abc import Iterable

from .models import GroundTruthTarget, MetricVector, RecoveryResult, Relation


def _f1(gold: set[object], predicted: set[object]) -> float:
    if not gold and not predicted:
        return 1.0
    if not predicted:
        return 0.0
    true_positive = len(gold & predicted)
    precision = true_positive / len(predicted)
    recall = true_positive / len(gold) if gold else 1.0
    if precision + recall == 0:
        return 0.0
    return 2 * precision * recall / (precision + recall)


def _relation_key(relation: Relation) -> tuple[str, str, str, int]:
    return (relation.source, relation.relation_type, relation.target, relation.polarity)


def _accuracy(cases, predictions: dict[str, bool]) -> float:
    if not cases:
        return 1.0
    correct = 0
    for case in cases:
        if case.label is None:
            raise ValueError("scoring requires gold case labels")
        if predictions.get(case.case_id) is bool(case.label):
            correct += 1
    return correct / len(cases)


def score(target: GroundTruthTarget, result: RecoveryResult, representation_bytes: int) -> MetricVector:
    hda = _accuracy(target.holdout_cases, result.holdout_predictions)
    ana = _accuracy(target.adversarial_cases, result.adversarial_predictions)
    relation_f1 = _f1(
        {_relation_key(x) for x in target.relations},
        {_relation_key(x) for x in result.relations},
    )
    constraint_f1 = _f1(set(target.constraints), set(result.constraints))
    gold_unknowns = set(target.open_variables)
    recovered_unknowns = set(result.open_variables)
    ups = 1.0 if not gold_unknowns else len(gold_unknowns & recovered_unknowns) / len(gold_unknowns)
    composite = 0.30 * hda + 0.20 * ana + 0.20 * relation_f1 + 0.15 * constraint_f1 + 0.15 * ups
    efficiency = composite / (1.0 + math.log1p(representation_bytes))
    return MetricVector(
        target_id=target.target_id,
        condition=result.condition,
        hda=hda,
        ana=ana,
        relation_f1=relation_f1,
        constraint_f1=constraint_f1,
        ups=ups,
        representation_bytes=representation_bytes,
        composite=composite,
        efficiency=efficiency,
    )

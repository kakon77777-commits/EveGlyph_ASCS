from __future__ import annotations

import csv
import json
from pathlib import Path
from statistics import mean
from typing import Any, Iterable

from .adapters import ModelAdapter, ModelRequest, ModelResponse
from .analysis import analyze_trial_metrics
from .control import ControlManifest, write_control_manifest
from .datasets import load_dataset
from .ledger import RunLedger
from .live_pipeline import _interaction, _invoke
from .models import MetricVector
from .parsing import ParseError, parse_builder_response, parse_recovery_response
from .prompts import builder_prompt, recovery_prompt
from .scoring import score


def _write_jsonl(path: Path, rows: Iterable[dict[str, Any]]) -> None:
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n")


def _aggregate(metrics: list[MetricVector], condition: str) -> dict[str, float | int]:
    rows = [m for m in metrics if m.condition == condition]
    if not rows:
        return {
            "count": 0,
            "mean_hda": 0.0,
            "mean_ana": 0.0,
            "mean_relation_f1": 0.0,
            "mean_constraint_f1": 0.0,
            "mean_ups": 0.0,
            "mean_composite": 0.0,
            "mean_efficiency": 0.0,
            "mean_representation_bytes": 0.0,
        }
    return {
        "count": len(rows),
        "mean_hda": round(mean(m.hda for m in rows), 12),
        "mean_ana": round(mean(m.ana for m in rows), 12),
        "mean_relation_f1": round(mean(m.relation_f1 for m in rows), 12),
        "mean_constraint_f1": round(mean(m.constraint_f1 for m in rows), 12),
        "mean_ups": round(mean(m.ups for m in rows), 12),
        "mean_composite": round(mean(m.composite for m in rows), 12),
        "mean_efficiency": round(mean(m.efficiency for m in rows), 12),
        "mean_representation_bytes": round(mean(m.representation_bytes for m in rows), 12),
    }


def _identity_ok(manifest: ControlManifest, response: ModelResponse) -> bool:
    return response.provider == manifest.expected_provider and response.model == manifest.expected_model


def _report(summary: dict[str, Any]) -> str:
    lines = [
        "# PSSA-BSAR Milestone 4 Controlled Gate 1 Report",
        "",
        "**Evidence status:** `CONTROLLED_RUN_REQUIRES_MODEL_VALIDATION`",
        "",
        "> This artifact proves that a preregistered controlled schedule was executed. Scientific interpretation still requires validating the external model wrapper, model identity, sampling behavior, and run environment.",
        "",
        f"- Manifest SHA-256: `{summary['manifest_sha256']}`",
        f"- Dataset SHA-256: `{summary['dataset_sha256']}`",
        f"- Model: `{summary['expected_provider']}/{summary['expected_model']}`",
        f"- Targets: `{summary['target_count']}`",
        f"- Trials per target: `{summary['trials_per_target']}`",
        f"- Trial blocks: `{summary['trial_block_count']}`",
        f"- Builder successes/failures: `{summary['builder_success_count']}` / `{summary['builder_failure_count']}`",
        f"- Recovery successes/failures: `{summary['recovery_success_count']}` / `{summary['recovery_failure_count']}`",
        "",
        "## Raw successful recovery means",
        "",
        "| Condition | N | HDA | ANA | Relation F1 | Constraint F1 | UPS | Composite | Mean bytes |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for condition in summary["conditions"]:
        row = summary["aggregates"][condition]
        lines.append(
            f"| {condition} | {row['count']} | {row['mean_hda']:.3f} | {row['mean_ana']:.3f} | "
            f"{row['mean_relation_f1']:.3f} | {row['mean_constraint_f1']:.3f} | {row['mean_ups']:.3f} | "
            f"{row['mean_composite']:.3f} | {row['mean_representation_bytes']:.1f} |"
        )
    lines.extend([
        "",
        "Repeated trials are not interpreted here as independent samples. Target-level paired analysis is produced by the Milestone 4 analysis layer.",
        "",
    ])
    return "\n".join(lines)


def run_controlled_protocol(
    output_dir: Path,
    manifest: ControlManifest,
    adapter: ModelAdapter,
) -> dict[str, Any]:
    manifest.validate_hashes()
    if manifest.dataset_version != "v0.2":
        raise ValueError("controlled protocol requires dataset v0.2")

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    targets, observations, dataset_manifest = load_dataset(
        "v0.2", seed=manifest.dataset_seed, count=manifest.target_count
    )
    if dataset_manifest is None:
        raise ValueError("controlled protocol requires audited dataset manifest")
    if dataset_manifest["dataset_sha256"] != manifest.dataset_sha256:
        raise ValueError("dataset hash mismatch against control manifest")

    target_by_id = {target.target_id: target for target in targets}
    obs_by_id = {obs.target_id: obs for obs in observations}
    scheduled_ids = {item.target_id for item in manifest.schedule}
    if scheduled_ids != set(target_by_id):
        raise ValueError("control schedule target IDs do not match audited dataset")

    # Freeze control artifacts before any adapter invocation.
    write_control_manifest(output_dir / "control_manifest.json", manifest)
    _write_jsonl(output_dir / "trial_schedule.jsonl", (item.to_dict() for item in manifest.schedule))
    (output_dir / "dataset_manifest.json").write_text(
        json.dumps(dataset_manifest, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    _write_jsonl(output_dir / "targets.jsonl", (target.to_dict() for target in targets))
    _write_jsonl(output_dir / "observations.jsonl", (obs.to_dict() for obs in observations))

    ledger = RunLedger()
    frozen_rows: list[dict[str, Any]] = []
    recovery_rows: list[dict[str, Any]] = []
    metric_rows: list[dict[str, Any]] = []
    metrics: list[MetricVector] = []

    for block in manifest.schedule:
        target = target_by_id[block.target_id]
        obs = obs_by_id[block.target_id]
        trial_id = f"{block.target_id}:t{block.trial_index:03d}"
        for condition_position, condition in enumerate(block.conditions):
            common_meta = {
                "control_manifest_sha256": manifest.manifest_sha256,
                "schedule_sha256": manifest.schedule_sha256,
                "schedule_sequence": block.sequence,
                "condition_position": condition_position,
                "trial_id": trial_id,
                "trial_index": block.trial_index,
                "trial_seed": block.trial_seed,
                "sampling_policy": manifest.sampling_policy,
                "expected_provider": manifest.expected_provider,
                "expected_model": manifest.expected_model,
            }
            builder_request = ModelRequest(
                request_id=f"b:{block.target_id}:t{block.trial_index:03d}:{condition}",
                stage="builder",
                target_id=block.target_id,
                condition=condition,
                prompt=builder_prompt(obs, condition, manifest.budget_bytes),
                metadata={**common_meta, "budget_bytes": manifest.budget_bytes},
            )
            builder_response = _invoke(adapter, builder_request, ledger)
            if builder_response is None:
                continue
            if not _identity_ok(manifest, builder_response):
                ledger.append(_interaction(
                    sequence=len(ledger.records), request=builder_request, response=builder_response,
                    status="failed", error_type="model_identity_mismatch",
                    error_message=(
                        f"expected {manifest.expected_provider}/{manifest.expected_model}, got "
                        f"{builder_response.provider}/{builder_response.model}"
                    ),
                ))
                continue
            try:
                rep = parse_builder_response(condition, block.target_id, builder_response.text, manifest.budget_bytes)
            except ParseError as exc:
                ledger.append(_interaction(
                    sequence=len(ledger.records), request=builder_request, response=builder_response,
                    status="failed", error_type=exc.kind, error_message=str(exc),
                ))
                continue
            ledger.append(_interaction(
                sequence=len(ledger.records), request=builder_request, response=builder_response, status="ok",
            ))
            frozen_rows.append({
                "trial_id": trial_id,
                "trial_index": block.trial_index,
                "trial_seed": block.trial_seed,
                "schedule_sequence": block.sequence,
                "condition_position": condition_position,
                "target_id": block.target_id,
                "condition": condition,
                "representation": rep.to_dict(),
            })

            public_cases = [case.public_view() for case in (*target.holdout_cases, *target.adversarial_cases)]
            recovery_request = ModelRequest(
                request_id=f"r:{block.target_id}:t{block.trial_index:03d}:{condition}",
                stage="recovery",
                target_id=block.target_id,
                condition=condition,
                prompt=recovery_prompt(rep, public_cases),
                metadata={**common_meta, "representation_bytes": rep.utf8_bytes},
            )
            recovery_response = _invoke(adapter, recovery_request, ledger)
            if recovery_response is None:
                continue
            if not _identity_ok(manifest, recovery_response):
                ledger.append(_interaction(
                    sequence=len(ledger.records), request=recovery_request, response=recovery_response,
                    status="failed", error_type="model_identity_mismatch",
                    error_message=(
                        f"expected {manifest.expected_provider}/{manifest.expected_model}, got "
                        f"{recovery_response.provider}/{recovery_response.model}"
                    ),
                ))
                continue
            try:
                result = parse_recovery_response(block.target_id, condition, recovery_response.text)
            except ParseError as exc:
                ledger.append(_interaction(
                    sequence=len(ledger.records), request=recovery_request, response=recovery_response,
                    status="failed", error_type=exc.kind, error_message=str(exc),
                ))
                continue
            ledger.append(_interaction(
                sequence=len(ledger.records), request=recovery_request, response=recovery_response, status="ok",
            ))
            recovery_rows.append({
                "trial_id": trial_id,
                "trial_index": block.trial_index,
                "trial_seed": block.trial_seed,
                "schedule_sequence": block.sequence,
                "condition_position": condition_position,
                "target_id": block.target_id,
                "condition": condition,
                "recovery": result.to_dict(),
            })
            metric = score(target, result, rep.utf8_bytes)
            metrics.append(metric)
            metric_rows.append({
                "trial_id": trial_id,
                "target_id": block.target_id,
                "trial_index": block.trial_index,
                "trial_seed": block.trial_seed,
                "condition": condition,
                **metric.to_dict(),
            })

    ledger.write_jsonl(output_dir / "requests.jsonl")
    _write_jsonl(output_dir / "frozen_representations.jsonl", frozen_rows)
    _write_jsonl(output_dir / "recoveries.jsonl", recovery_rows)
    _write_jsonl(output_dir / "failures.jsonl", (r.to_dict() for r in ledger.records if r.status != "ok"))

    metric_fields = [
        "trial_id", "target_id", "trial_index", "trial_seed", "condition",
        "hda", "ana", "relation_f1", "constraint_f1", "ups",
        "representation_bytes", "composite", "efficiency",
    ]
    with (output_dir / "trial_metrics.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=metric_fields, lineterminator="\n")
        writer.writeheader()
        for row in metric_rows:
            writer.writerow({key: row[key] for key in metric_fields})

    analysis = analyze_trial_metrics(metric_rows, manifest, output_dir)
    gate1 = json.loads((output_dir / "gate1_evaluation.json").read_text(encoding="utf-8"))

    builder_records = [r for r in ledger.records if r.stage == "builder"]
    recovery_records = [r for r in ledger.records if r.stage == "recovery"]
    summary: dict[str, Any] = {
        "experiment": "PSSA-BSAR-Gate1",
        "version": "0.1-milestone4",
        "run_mode": "controlled_live_protocol",
        "evidence_status": "CONTROLLED_RUN_REQUIRES_MODEL_VALIDATION",
        "manifest_sha256": manifest.manifest_sha256,
        "schedule_sha256": manifest.schedule_sha256,
        "dataset_version": manifest.dataset_version,
        "dataset_seed": manifest.dataset_seed,
        "dataset_sha256": manifest.dataset_sha256,
        "target_count": manifest.target_count,
        "trials_per_target": manifest.trials_per_target,
        "trial_block_count": len(manifest.schedule),
        "budget_bytes": manifest.budget_bytes,
        "expected_provider": manifest.expected_provider,
        "expected_model": manifest.expected_model,
        "sampling_policy": manifest.sampling_policy,
        "conditions": list(manifest.conditions),
        "paired_analysis_unit": analysis["unit_of_inference"],
        "gate1_overall_status": gate1["overall_status"],
        "builder_success_count": sum(r.status == "ok" for r in builder_records),
        "builder_failure_count": sum(r.status != "ok" for r in builder_records),
        "recovery_success_count": sum(r.status == "ok" for r in recovery_records),
        "recovery_failure_count": sum(r.status != "ok" for r in recovery_records),
        "aggregates": {condition: _aggregate(metrics, condition) for condition in manifest.conditions},
    }
    (output_dir / "summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    (output_dir / "REPORT.md").write_text(_report(summary), encoding="utf-8", newline="\n")
    return summary

from __future__ import annotations

import csv
import json
from pathlib import Path
from statistics import mean
from typing import Any, Iterable

from .adapters import AdapterError, ModelAdapter, ModelRequest, ModelResponse, prompt_sha256
from .datasets import load_dataset
from .ledger import InteractionRecord, RunLedger
from .models import FrozenRepresentation, MetricVector, RecoveryResult
from .parsing import ParseError, parse_builder_response, parse_recovery_response
from .prompts import builder_prompt, recovery_prompt
from .scoring import score

_CONDITIONS = ("definition_first", "keyword_first", "address_first")


def _write_jsonl(path: Path, rows: Iterable[dict[str, Any]]) -> None:
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n")


def _aggregate(metrics: list[MetricVector], condition: str) -> dict[str, float | int]:
    rows = [m for m in metrics if m.condition == condition]
    if not rows:
        return {
            "count": 0,
            "mean_hda": 0.0,
            "mean_ana": 0.0,
            "mean_relation_f1": 0.0,
            "mean_constraint_f1": 0.0,
            "mean_ups": 0.0,
            "mean_composite": 0.0,
            "mean_efficiency": 0.0,
            "mean_representation_bytes": 0.0,
        }
    return {
        "count": len(rows),
        "mean_hda": round(mean(m.hda for m in rows), 12),
        "mean_ana": round(mean(m.ana for m in rows), 12),
        "mean_relation_f1": round(mean(m.relation_f1 for m in rows), 12),
        "mean_constraint_f1": round(mean(m.constraint_f1 for m in rows), 12),
        "mean_ups": round(mean(m.ups for m in rows), 12),
        "mean_composite": round(mean(m.composite for m in rows), 12),
        "mean_efficiency": round(mean(m.efficiency for m in rows), 12),
        "mean_representation_bytes": round(mean(m.representation_bytes for m in rows), 12),
    }


def _interaction(
    *,
    sequence: int,
    request: ModelRequest,
    response: ModelResponse | None,
    status: str,
    error_type: str = "",
    error_message: str = "",
) -> InteractionRecord:
    raw_response = response.text if response else ""
    return InteractionRecord(
        sequence=sequence,
        request_id=request.request_id,
        stage=request.stage,
        target_id=request.target_id,
        condition=request.condition,
        prompt_sha256=prompt_sha256(request.prompt),
        prompt_bytes=len(request.prompt.encode("utf-8")),
        raw_response=raw_response,
        response_bytes=len(raw_response.encode("utf-8")),
        status=status,
        error_type=error_type,
        error_message=error_message,
        provider=response.provider if response else "",
        model=response.model if response else "",
        timestamp_utc=None,
        request=request.to_dict(),
        response=response.to_dict() if response else None,
    )


def _invoke(adapter: ModelAdapter, request: ModelRequest, ledger: RunLedger) -> ModelResponse | None:
    try:
        response = adapter.generate(request)
    except AdapterError as exc:
        ledger.append(_interaction(
            sequence=len(ledger.records), request=request, response=None, status="failed",
            error_type=exc.kind, error_message=str(exc),
        ))
        return None
    except Exception as exc:  # explicit capture so a single target cannot destroy the run
        ledger.append(_interaction(
            sequence=len(ledger.records), request=request, response=None, status="failed",
            error_type=type(exc).__name__, error_message=str(exc),
        ))
        return None
    return response


def _report(summary: dict[str, Any]) -> str:
    if summary.get("dataset_version") == "v0.2":
        lines = [
            "# PSSA-BSAR Dataset v0.2 Live-Protocol Report",
            "",
            "**Evidence status:** `LIVE_PROTOCOL_ONLY_NOT_SCIENTIFIC`",
            "",
            "> This run uses the leakage-audited v0.2 dataset. The protocol is ready for controlled model experiments, but this label alone does not make a run empirical evidence.",
            "",
            f"- Seed: `{summary['seed']}`",
            f"- Targets: `{summary['target_count']}`",
            f"- Dataset SHA-256: `{summary['dataset_sha256']}`",
            f"- Dataset audit: `{summary['dataset_audit_pass_count']}` pass / `{summary['dataset_audit_fail_count']}` fail",
            f"- Builder successes/failures: `{summary['builder_success_count']}` / `{summary['builder_failure_count']}`",
            f"- Recovery successes/failures: `{summary['recovery_success_count']}` / `{summary['recovery_failure_count']}`",
            "",
            "## Successful recovery means",
            "",
            "| Condition | N | HDA | ANA | Relation F1 | Constraint F1 | UPS | Composite | Mean bytes |",
            "|---|---:|---:|---:|---:|---:|---:|---:|---:|",
        ]
        for condition in summary["conditions"]:
            row = summary["aggregates"][condition]
            lines.append(
                f"| {condition} | {row['count']} | {row['mean_hda']:.3f} | {row['mean_ana']:.3f} | "
                f"{row['mean_relation_f1']:.3f} | {row['mean_constraint_f1']:.3f} | {row['mean_ups']:.3f} | "
                f"{row['mean_composite']:.3f} | {row['mean_representation_bytes']:.1f} |"
            )
        lines.extend([
            "",
            "Failures are first-class artifacts in `failures.jsonl`; invalid model output is never silently truncated or repaired.",
            "",
        ])
        return "\n".join(lines)

    lines = [
        "# PSSA-BSAR v0.1 Live-Protocol Report",
        "",
        "**Evidence status:** `LIVE_PROTOCOL_ONLY_NOT_SCIENTIFIC`",
        "",
        "> This run validates live adapter isolation, strict parsing, ledgers, and scoring plumbing. The Milestone 1 synthetic dataset remains machine-readable and is not leakage-audited scientific evidence for PSSA.",
        "",
        f"- Seed: `{summary['seed']}`",
        f"- Targets: `{summary['target_count']}`",
        f"- Builder successes/failures: `{summary['builder_success_count']}` / `{summary['builder_failure_count']}`",
        f"- Recovery successes/failures: `{summary['recovery_success_count']}` / `{summary['recovery_failure_count']}`",
        "",
        "## Successful recovery means",
        "",
        "| Condition | N | HDA | ANA | Relation F1 | Constraint F1 | UPS | Composite | Mean bytes |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for condition in summary["conditions"]:
        row = summary["aggregates"][condition]
        lines.append(
            f"| {condition} | {row['count']} | {row['mean_hda']:.3f} | {row['mean_ana']:.3f} | "
            f"{row['mean_relation_f1']:.3f} | {row['mean_constraint_f1']:.3f} | {row['mean_ups']:.3f} | "
            f"{row['mean_composite']:.3f} | {row['mean_representation_bytes']:.1f} |"
        )
    lines.extend([
        "",
        "Failures are first-class artifacts in `failures.jsonl`; invalid model output is never silently truncated or repaired.",
        "",
    ])
    return "\n".join(lines)


def run_live_protocol(
    output_dir: Path,
    adapter: ModelAdapter,
    seed: int = 20260821,
    budget_bytes: int = 900,
    dataset_version: str = "v0.1",
) -> dict[str, Any]:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    targets, observations, dataset_manifest = load_dataset(dataset_version, seed=seed, count=30)
    target_by_id = {target.target_id: target for target in targets}
    if dataset_manifest is not None:
        _write_jsonl(output_dir / "targets.jsonl", (target.to_dict() for target in targets))
        _write_jsonl(output_dir / "observations.jsonl", (obs.to_dict() for obs in observations))
        (output_dir / "dataset_manifest.json").write_text(
            json.dumps(dataset_manifest, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
            encoding="utf-8",
            newline="\n",
        )
    ledger = RunLedger()
    frozen: list[FrozenRepresentation] = []
    recoveries: list[RecoveryResult] = []
    metrics: list[MetricVector] = []

    for obs in observations:
        for condition in _CONDITIONS:
            request = ModelRequest(
                request_id=f"b:{obs.target_id}:{condition}",
                stage="builder",
                target_id=obs.target_id,
                condition=condition,
                prompt=builder_prompt(obs, condition, budget_bytes),
                metadata={"budget_bytes": budget_bytes},
            )
            response = _invoke(adapter, request, ledger)
            if response is None:
                continue
            try:
                rep = parse_builder_response(condition, obs.target_id, response.text, budget_bytes)
            except ParseError as exc:
                ledger.append(_interaction(
                    sequence=len(ledger.records), request=request, response=response, status="failed",
                    error_type=exc.kind, error_message=str(exc),
                ))
                continue
            ledger.append(_interaction(
                sequence=len(ledger.records), request=request, response=response, status="ok",
            ))
            frozen.append(rep)

    for rep in frozen:
        target = target_by_id[rep.target_id]
        public_cases = [case.public_view() for case in (*target.holdout_cases, *target.adversarial_cases)]
        request = ModelRequest(
            request_id=f"r:{rep.target_id}:{rep.condition}",
            stage="recovery",
            target_id=rep.target_id,
            condition=rep.condition,
            prompt=recovery_prompt(rep, public_cases),
            metadata={"representation_bytes": rep.utf8_bytes},
        )
        response = _invoke(adapter, request, ledger)
        if response is None:
            continue
        try:
            result = parse_recovery_response(rep.target_id, rep.condition, response.text)
        except ParseError as exc:
            ledger.append(_interaction(
                sequence=len(ledger.records), request=request, response=response, status="failed",
                error_type=exc.kind, error_message=str(exc),
            ))
            continue
        ledger.append(_interaction(
            sequence=len(ledger.records), request=request, response=response, status="ok",
        ))
        recoveries.append(result)
        metrics.append(score(target, result, rep.utf8_bytes))

    ledger.write_jsonl(output_dir / "requests.jsonl")
    _write_jsonl(output_dir / "frozen_representations.jsonl", (rep.to_dict() for rep in frozen))
    _write_jsonl(output_dir / "recoveries.jsonl", (result.to_dict() for result in recoveries))
    failures = [record.to_dict() for record in ledger.records if record.status != "ok"]
    _write_jsonl(output_dir / "failures.jsonl", failures)

    metric_fields = [
        "target_id", "condition", "hda", "ana", "relation_f1", "constraint_f1",
        "ups", "representation_bytes", "composite", "efficiency",
    ]
    with (output_dir / "metrics.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=metric_fields, lineterminator="\n")
        writer.writeheader()
        for metric in metrics:
            writer.writerow(metric.to_dict())

    builder_records = [r for r in ledger.records if r.stage == "builder"]
    recovery_records = [r for r in ledger.records if r.stage == "recovery"]
    summary: dict[str, Any] = {
        "experiment": "PSSA-BSAR",
        "version": "0.1-milestone2",
        "run_mode": "live_protocol",
        "evidence_status": "LIVE_PROTOCOL_ONLY_NOT_SCIENTIFIC",
        "seed": seed,
        "budget_bytes": budget_bytes,
        "target_count": len(targets),
        "conditions": list(_CONDITIONS),
        "builder_success_count": sum(r.status == "ok" for r in builder_records),
        "builder_failure_count": sum(r.status != "ok" for r in builder_records),
        "recovery_success_count": sum(r.status == "ok" for r in recovery_records),
        "recovery_failure_count": sum(r.status != "ok" for r in recovery_records),
        "aggregates": {condition: _aggregate(metrics, condition) for condition in _CONDITIONS},
    }
    if dataset_manifest is not None:
        summary.update({
            "version": "0.1-milestone3",
            "dataset_version": dataset_version,
            "dataset_sha256": dataset_manifest["dataset_sha256"],
            "dataset_audit_pass_count": dataset_manifest["pass_count"],
            "dataset_audit_fail_count": dataset_manifest["fail_count"],
        })
    (output_dir / "summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    (output_dir / "REPORT.md").write_text(_report(summary), encoding="utf-8", newline="\n")
    return summary

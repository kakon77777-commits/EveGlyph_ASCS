# EveGlyph Computational Canvas MVP v0.1 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [x]`) syntax for tracking.

**Goal:** Build a runnable local-first EveGlyph Computational Canvas MVP that loads/saves EGIR through EGStore, preserves ASCS identity/version invariants, supports canvas move/edit/clone/conflict semantics, executes a native derivative, binds a custom glyph to that operator, and promotes AI-style candidates only through an explicit commit boundary.

**Architecture:** A dependency-light Python runtime owns canonical EGIR state and transactions. A small HTTP server exposes typed commands and serves a vanilla browser canvas; the browser holds only session/visual state. Storage uses the TW-02 directory-store model with decoded chunk hashes, optional Brotli physical representation, and deterministic rehydration into EGIR.

**Tech Stack:** Python 3 standard library, optional `brotli` Python package, `unittest`, Vanilla HTML/CSS/JavaScript.

**Spec:** `/mnt/data/EveGlyph_Addressable_Symbolic_Computational_Space_Series_v0.1/TW-01_EveGlyph_Symbol_IR_Specification_v0.1.md`, `/mnt/data/EveGlyph_Addressable_Symbolic_Computational_Space_Series_v0.1/TW-02_UTF-8_UTF-8X_Compatibility_and_Storage_Architecture_v0.1.md`, `/mnt/data/EveGlyph_Addressable_Symbolic_Computational_Space_Series_v0.1/TW-03_EveGlyph_Computational_Canvas_Runtime_Architecture_v0.1.md`

## Global Constraints

- Canonical state, session overlay, derived cache, and external effects MUST remain distinct.
- Persistent identity MUST survive move/edit/storage repack; clone MUST create a new persistent identity.
- Canonical writes MUST carry `base_workspace_revision`; stale writes MUST return conflict without mutation.
- AI/heuristic outputs MUST remain candidate-only until explicit promotion.
- Native math execution MUST operate on NCM objects directly; LaTeX is projection only.
- Imported or visual glyph data MUST NOT grant execution permission by itself.
- EGStore physical representation changes MUST NOT alter TW-01 object/revision identities.
- UTF-8 source files use LF line endings. No silent Unicode normalization.
- Runtime core MUST work without network access.
- Production code is written only after a failing test demonstrates the behavior.

---

### Task 1: Canonical hashing and fixture loader

**Files:**
- Create: `src/eveglyph_mvp/canonical.py`
- Create: `src/eveglyph_mvp/fixtures.py`
- Test: `tests/test_canonical.py`

**Interfaces:**
- Produces: `canonical_bytes(value) -> bytes`, `sha256_hex(data) -> str`, `content_address(kind, intrinsic) -> str`, `load_minimal_workspace() -> dict`.

- [x] Write failing tests that canonical object key order is deterministic and TW-01 minimal math content address recomputes exactly.
- [x] Run `python -m unittest tests.test_canonical -v` and verify failure because the module does not exist.
- [x] Implement the minimal canonicalizer and fixture loader by copying the TW-01 fixture into project examples at setup time.
- [x] Re-run the test and verify PASS.
- [x] Commit `feat: add EGIR canonical hashing core`.

### Task 2: In-memory canonical workspace runtime

**Files:**
- Create: `src/eveglyph_mvp/runtime.py`
- Test: `tests/test_runtime_transactions.py`

**Interfaces:**
- Consumes: canonical hashing helpers.
- Produces: `WorkspaceRuntime(bundle)`, `.snapshot()`, `.move_object(...)`, `.edit_math_power(...)`, `.clone_object(...)`, `.resolve_revision(...)`.

- [x] Write failing test: pure move changes workspace revision but not math object revision/content address.
- [x] Run targeted test and verify failure.
- [x] Implement move transaction and deterministic workspace revision calculation.
- [x] Verify PASS.
- [x] Write failing test: stale `base_workspace_revision` returns `Conflict` and state is unchanged.
- [x] Implement stale-write guard; verify PASS.
- [x] Write failing test: semantic edit preserves persistent ID but creates new content/revision IDs.
- [x] Implement edit; verify PASS.
- [x] Write failing test: clone has same initial content address but different persistent ID.
- [x] Implement clone; verify PASS.
- [x] Commit `feat: add canonical transaction runtime`.

### Task 3: Candidate and explicit relation authority boundary

**Files:**
- Modify: `src/eveglyph_mvp/runtime.py`
- Test: `tests/test_candidates.py`

**Interfaces:**
- Produces: `.propose_relation(...)`, `.promote_candidate(...)`, `.list_candidates()`.

- [x] Write failing test that proposed relation does not appear in committed relation heads.
- [x] Implement candidate storage only; verify PASS.
- [x] Write failing test that promotion creates a first-class relation object/revision/event and removes the candidate.
- [x] Implement promotion; verify PASS.
- [x] Commit `feat: enforce candidate promotion boundary`.

### Task 4: Native math derivative and custom glyph binding

**Files:**
- Create: `src/eveglyph_mvp/math_runtime.py`
- Modify: `src/eveglyph_mvp/runtime.py`
- Test: `tests/test_math_and_glyph.py`

**Interfaces:**
- Produces: `differentiate_ncm(intrinsic, variable) -> dict`, `.execute_derivative(...)`, `.create_glyph(...)`, `.bind_glyph_operator(...)`, `.execute_glyph(...)`.

- [x] Write failing test that NCM `$x^2$` differentiates to an NCM representation of `$2x$` without LaTeX parsing.
- [x] Implement minimal derivative rules for integer power of one symbol; verify PASS.
- [x] Write failing runtime test that derivative execution creates a new result identity and provenance event while leaving source identity unchanged.
- [x] Implement execution transaction; verify PASS.
- [x] Write failing test that a new custom glyph exists without Unicode code point and cannot execute before semantic binding.
- [x] Implement glyph object creation and explicit `represents` binding.
- [x] Write failing test that glyph execution resolves the bound derivative operator and produces the same math result.
- [x] Implement glyph execution; verify PASS.
- [x] Commit `feat: add native math and executable glyph binding`.

### Task 5: EGStore directory storage with identity and Brotli variants

**Files:**
- Create: `src/eveglyph_mvp/storage.py`
- Test: `tests/test_storage.py`

**Interfaces:**
- Produces: `pack_store(bundle, directory, codec='identity', chunk_size=4096) -> manifest`, `load_store(directory) -> dict`, `repack_store(directory, target_directory, codec) -> manifest`.

- [x] Write failing test that identity pack/load round-trips the exact EGIR bundle.
- [x] Implement fixed chunking, decoded chunk IDs, encoded hashes, manifest writing, and load verification; verify PASS.
- [x] Write failing test that Brotli repack produces different physical manifest/chunks but loads to the same canonical object/revision identities.
- [x] Implement Brotli codec path with identity fallback error if dependency absent; verify PASS.
- [x] Write failing corruption test for encoded hash mismatch.
- [x] Implement typed `StorageError('EncodedHashMismatch')`; verify PASS.
- [x] Commit `feat: add EGStore directory storage`.

### Task 6: HTTP API and deterministic command surface

**Files:**
- Create: `src/eveglyph_mvp/server.py`
- Create: `src/eveglyph_mvp/app.py`
- Test: `tests/test_api.py`

**Interfaces:**
- Produces JSON endpoints: `GET /api/state`, `POST /api/move`, `POST /api/edit-power`, `POST /api/clone`, `POST /api/candidate`, `POST /api/promote`, `POST /api/derivative`, `POST /api/glyph`, `POST /api/glyph-bind`, `POST /api/glyph-execute`, `POST /api/save`.

- [x] Write failing API test using an in-process HTTP server: `GET /api/state` returns workspace revision and object list.
- [x] Implement state endpoint; verify PASS.
- [x] Write failing stale-write API test returning HTTP 409 with typed conflict.
- [x] Implement command routing and typed errors; verify PASS.
- [x] Write failing derivative/glyph endpoint tests; implement minimal routes; verify PASS.
- [x] Commit `feat: expose runtime HTTP command API`.

### Task 7: Infinite canvas browser UI

**Files:**
- Create: `web/index.html`
- Create: `web/app.js`
- Create: `web/style.css`
- Test: `tests/test_web_assets.py`

**Interfaces:**
- Browser consumes the HTTP API; canonical mutation always includes current `base_workspace_revision`.

- [x] Write failing static asset test that index loads `app.js`/`style.css` and contains canvas, toolbar, diagnostics, candidate panel.
- [x] Create minimal UI shell; verify PASS.
- [x] Write failing test that `app.js` contains pan/zoom, draggable nodes, stale-conflict refresh, derivative, clone, candidate/promote, and glyph binding commands.
- [x] Implement browser logic with CSS transform-based logically unbounded canvas, draggable nodes, relation lines, and status panels; verify PASS.
- [x] Commit `feat: add computational infinite canvas UI`.

### Task 8: End-to-end demo, validators, docs, and package

**Files:**
- Create: `scripts/run_demo.py`
- Create: `scripts/validate_mvp.py`
- Create: `README.md`
- Create: `MVP-01_VALIDATION.md`
- Create: `examples/demo_store/` generated at validation time.
- Test: `tests/test_end_to_end.py`

**Interfaces:**
- Produces: one-command validation and one-command local server launch.

- [x] Write failing E2E test: load fixture → move → clone → candidate → promote → derivative → glyph bind/execute → save identity store → repack Brotli → rehydrate; final original source identities and result provenance remain valid.
- [x] Implement demo orchestration; verify PASS.
- [x] Run full `python -m unittest discover -s tests -v`.
- [x] Run TW-01/TW-02/TW-03 validators against their packaged fixtures plus MVP validator.
- [x] Run source UTF-8/LF/control-character scan and compile all Python modules.
- [x] Generate `MVP-01_VALIDATION.md`, SHA256 manifest, and final ZIP.
- [x] Commit `feat: complete EveGlyph Computational Canvas MVP v0.1`.

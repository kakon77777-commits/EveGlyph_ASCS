# MVP-01 Validation Report — EveGlyph Computational Canvas v0.1

**Date:** 2026-08-24  
**Status:** PASS — final release validation record  
**Scope:** Standalone MVP repository plus bundled TW-01/TW-02/TW-03 conformance support.

## Verification commands

The final release process executes the following checks from the repository root:

```bash
PYTHONPATH=src python -m unittest discover -s tests -v
python -m compileall -q src scripts tests run_mvp.py
node --check web/app.js
PYTHONPATH=src python scripts/run_demo.py --output examples/demo_output --json
PYTHONPATH=src python scripts/validate_mvp.py --demo-output examples/demo_output --json
python run_mvp.py --help
git diff --check
```

A source scan additionally verifies UTF-8 decoding, LF-only line endings, forbidden control characters, and absence of Python bytecode/cache directories from the release tree.

## Fresh final verification evidence

- `python -m unittest discover -s tests -v`: **26 tests, 0 failures**.
- `python -m compileall -q src scripts tests run_mvp.py`: **PASS**.
- `node --check web/app.js`: **PASS**.
- deterministic E2E demo: **PASS**, with every demo check `true`.
- self-contained `validate_mvp.py`: **PASS**; TW-01, TW-02, and TW-03 reference validators all PASS.
- launcher smoke check: **PASS**.
- UTF-8/LF/control scan: **56 MVP text files PASS**; **33 architecture text files PASS**.
- SHA-256 manifest verification: **67 MVP entries PASS**; **34 architecture entries PASS**.
- `git diff --check`: **PASS**.

## Functional conformance covered

- canonical EGIR hash recomputation;
- pure Canvas move preserves object revision/content address;
- stale base revision returns typed `Conflict`;
- semantic edit preserves persistent identity while creating a new revision/content address;
- clone creates a new persistent identity with the same initial content address;
- AI-style relation proposal remains candidate-only until promotion;
- promotion creates a first-class explicit relation plus provenance;
- Native Math differentiates the NCM representation of `$x^2$` directly to an NCM representation of `$2x$`, without canonical LaTeX parse-back;
- derivative execution creates a new result identity and `computed` provenance;
- a custom glyph requires no Unicode code point and cannot execute until explicitly bound to the derivative operator;
- identity EGStore and Brotli EGStore rehydrate to the same EGIR object/revision identities;
- corrupted encoded chunks are rejected with typed storage errors;
- browser API writes carry `base_workspace_revision` and return HTTP 409 for stale writes;
- browser pan/zoom/selection remain session state; drag-end performs the canonical move transaction;
- bundled TW-01, TW-02, and TW-03 reference validators run from `spec_support/` without a separate architecture checkout.

## Deterministic demo baseline

The deterministic reference demo produces these stable identifiers for the packaged fixture and operation sequence:

```text
final_workspace_revision = wrev:sha256:3a24aef436f6d5cf4f18f6f18dcd078ba47441491eff6a236ae71168c644119b
source_object             = urn:uuid:0190a001-1111-7abc-8def-111111111111
clone_object              = urn:uuid:78ddc5fb-1ab8-5a97-ac97-62f954222c7b
derivative_result         = urn:uuid:33bec699-0061-5be0-933d-1186a4515995
glyph_object              = urn:uuid:8f2d699d-7193-5c6a-8aac-64d1c44e0906
glyph_result              = urn:uuid:16523219-c517-59d0-8330-16700b058d58
identity_store_manifest   = store:sha256:c48970145f575430c367cfcecce0256c67340f7e2c66d8d2e9c03412045df9a1
brotli_store_manifest     = store:sha256:7ff824655031a1c41d550ddbbeefe5537629f6b250e263773da73ec40eb4212b
```

These IDs are reference/conformance values. MVP-01 intentionally uses a deterministic UUIDv5 sequence for repeatable tests; production writers should migrate new persistent identities to the TW-01 recommended RFC 9562 UUIDv7 policy.

## Evidence boundary

This report validates the MVP vertical slice, not a production-complete EveGlyph rewrite. It does not claim a complete CAS, general spatial grammar, distributed collaboration, external-agent sandbox, complete GSC integration, or full UTF-8X runtime integration. Those remain explicit post-MVP upgrade work.

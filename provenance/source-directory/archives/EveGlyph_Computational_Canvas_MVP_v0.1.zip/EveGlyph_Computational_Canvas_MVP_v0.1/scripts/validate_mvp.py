#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path
import subprocess
import sys

from jsonschema import Draft202012Validator, FormatChecker

from eveglyph_mvp.canonical import content_address, revision_address, workspace_revision_address
from eveglyph_mvp.storage import load_store


def validate_tw01_bundle(bundle: dict, schema_path: Path) -> None:
    schema = json.loads(schema_path.read_text(encoding="utf-8"))
    errors = sorted(
        Draft202012Validator(schema, format_checker=FormatChecker()).iter_errors(bundle),
        key=lambda error: list(error.path),
    )
    if errors:
        raise AssertionError("TW-01 schema: " + "; ".join(f"{list(e.path)} {e.message}" for e in errors[:8]))

    objects = {record["persistent_id"]: record for record in bundle["object_records"]}
    revisions = {record["revision_id"]: record for record in bundle["revision_records"]}
    if len(objects) != len(bundle["object_records"]):
        raise AssertionError("duplicate persistent object identity")
    if len(revisions) != len(bundle["revision_records"]):
        raise AssertionError("duplicate revision identity")

    for obj in bundle["object_records"]:
        for revision_id in obj.get("heads", {}).values():
            revision = revisions.get(revision_id)
            if revision is None or revision["persistent_id"] != obj["persistent_id"]:
                raise AssertionError(f"object head lineage mismatch: {obj['persistent_id']} {revision_id}")

    for revision in bundle["revision_records"]:
        if revision["persistent_id"] not in objects:
            raise AssertionError(f"revision missing persistent object: {revision['revision_id']}")
        for parent in revision["parents"]:
            if parent not in revisions:
                raise AssertionError(f"revision missing parent: {parent}")
        if content_address(revision["kind"], revision["intrinsic"]) != revision["content_address"]:
            raise AssertionError(f"content address mismatch: {revision['revision_id']}")
        if revision_address(revision) != revision["revision_id"]:
            raise AssertionError(f"revision hash mismatch: {revision['revision_id']}")

    for head in bundle["workspace"]["object_heads"] + bundle["workspace"]["relation_heads"]:
        if head["persistent_id"] not in objects or head["revision"] not in revisions:
            raise AssertionError(f"workspace head unresolved: {head}")
    for placement in bundle["workspace"]["placements"]:
        if placement["object_id"] not in objects:
            raise AssertionError(f"placement target unresolved: {placement['object_id']}")
    if workspace_revision_address(bundle["workspace"]) != bundle["workspace"]["workspace_revision"]:
        raise AssertionError("workspace revision hash mismatch")


def validate_store_schema(store_dir: Path, schema_path: Path) -> None:
    schema = json.loads(schema_path.read_text(encoding="utf-8"))
    manifest = json.loads((store_dir / "manifest.json").read_text(encoding="utf-8"))
    errors = list(Draft202012Validator(schema).iter_errors(manifest))
    if errors:
        raise AssertionError("TW-02 schema: " + "; ".join(f"{list(e.path)} {e.message}" for e in errors[:8]))


def run_reference_validator(path: Path) -> tuple[bool, str]:
    proc = subprocess.run(
        [sys.executable, str(path)],
        cwd=path.parent,
        text=True,
        capture_output=True,
        check=False,
    )
    output = (proc.stdout + "\n" + proc.stderr).strip()
    return proc.returncode == 0, output


def validate(demo_output: Path, spec_root: Path) -> dict:
    final_path = demo_output / "final.egir.json"
    final_bundle = json.loads(final_path.read_text(encoding="utf-8"))

    tw01_schema = spec_root / "TW-01_Support" / "schemas" / "eveglyph-ir.schema.json"
    tw02_schema = spec_root / "TW-02_Support" / "schemas" / "eveglyph-storage-manifest.schema.json"

    checks: dict[str, bool] = {}
    notes: dict[str, str] = {}

    validate_tw01_bundle(final_bundle, tw01_schema)
    checks["tw01_schema"] = True
    checks["tw01_hashes"] = True

    identity_store = demo_output / "identity_store"
    brotli_store = demo_output / "brotli_store"
    validate_store_schema(identity_store, tw02_schema)
    validate_store_schema(brotli_store, tw02_schema)
    identity_bundle = load_store(identity_store)
    brotli_bundle = load_store(brotli_store)
    checks["tw02_identity_store"] = identity_bundle == final_bundle
    checks["tw02_brotli_store"] = brotli_bundle == final_bundle
    if not checks["tw02_identity_store"] or not checks["tw02_brotli_store"]:
        raise AssertionError("store round-trip mismatch")

    validators = {
        "reference_tw01": spec_root / "TW-01_Support" / "tools" / "validate_tw01.py",
        "reference_tw02": spec_root / "TW-02_Support" / "tools" / "validate_tw02.py",
        "reference_tw03": spec_root / "TW-03_Support" / "tools" / "validate_tw03.py",
    }
    for name, path in validators.items():
        ok, output = run_reference_validator(path)
        checks[name] = ok
        notes[name] = output
        if not ok:
            raise AssertionError(f"{name} failed:\n{output}")

    checks["no_candidates_left"] = final_bundle.get("candidate_records", []) == []
    checks["computed_results_present"] = any(
        revision.get("metadata", {}).get("evidence_class") == "computed"
        for revision in final_bundle["revision_records"]
    )
    if not all(checks.values()):
        raise AssertionError("one or more validation checks are false")

    return {
        "status": "PASS",
        "workspace_revision": final_bundle["workspace"]["workspace_revision"],
        "checks": checks,
        "reference_outputs": notes,
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Validate EveGlyph Computational Canvas MVP v0.1")
    parser.add_argument("--demo-output", type=Path, required=True)
    default_spec_root = Path(__file__).resolve().parents[1] / "spec_support"
    parser.add_argument("--spec-root", type=Path, default=default_spec_root)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)
    try:
        report = validate(args.demo_output, args.spec_root)
    except Exception as exc:
        report = {"status": "FAIL", "error": f"{type(exc).__name__}: {exc}"}
        if args.json:
            print(json.dumps(report, ensure_ascii=False, separators=(",", ":")))
        else:
            print(json.dumps(report, ensure_ascii=False, indent=2))
        return 1
    if args.json:
        print(json.dumps(report, ensure_ascii=False, separators=(",", ":")))
    else:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

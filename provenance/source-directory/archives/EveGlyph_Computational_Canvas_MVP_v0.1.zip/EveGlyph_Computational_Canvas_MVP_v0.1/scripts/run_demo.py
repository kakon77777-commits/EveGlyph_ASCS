#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

from eveglyph_mvp.fixtures import load_minimal_workspace
from eveglyph_mvp.runtime import WorkspaceRuntime
from eveglyph_mvp.storage import load_store, pack_store, repack_store

MATH_ID = "urn:uuid:0190a001-1111-7abc-8def-111111111111"


def run_vertical_slice(output: Path) -> dict:
    output.mkdir(parents=True, exist_ok=True)
    runtime = WorkspaceRuntime(load_minimal_workspace())
    source_head = runtime.object_head(MATH_ID)
    source_content = runtime.revision(source_head)["content_address"]

    runtime.move_object(
        MATH_ID,
        x="260.0",
        y="160.0",
        base_workspace_revision=runtime.workspace_revision,
    )
    clone = runtime.clone_object(MATH_ID, base_workspace_revision=runtime.workspace_revision)

    candidate = runtime.propose_relation(
        source_id=MATH_ID,
        predicate="eg:dependsOn",
        target={
            "type": "semantic",
            "schema": "eg-sem/0.1",
            "ontology": "eg:demo",
            "anchors": ["source-expression"],
            "negative_anchors": [],
            "relations": [],
            "constraints": [],
            "open_variables": [],
            "confidence": "0.79",
            "authority": "candidate",
        },
        base_workspace_revision=runtime.workspace_revision,
        actor_type="ai",
        actor_id="mvp-demo-agent",
    )
    promoted = runtime.promote_candidate(
        candidate["candidate_id"],
        base_workspace_revision=runtime.workspace_revision,
    )

    derivative = runtime.execute_derivative(
        MATH_ID,
        variable="x",
        base_workspace_revision=runtime.workspace_revision,
    )

    glyph = runtime.create_glyph(
        name="∂ custom",
        geometry={"kind": "polyline", "points": [["0", "0"], ["10", "5"], ["0", "10"]]},
        base_workspace_revision=runtime.workspace_revision,
    )
    binding = runtime.bind_glyph_operator(
        glyph["persistent_id"],
        operator="derivative",
        base_workspace_revision=runtime.workspace_revision,
    )
    glyph_result = runtime.execute_glyph(
        glyph["persistent_id"],
        math_object_id=MATH_ID,
        variable="x",
        base_workspace_revision=runtime.workspace_revision,
    )

    final_bundle = runtime.snapshot()
    final_path = output / "final.egir.json"
    final_path.write_text(json.dumps(final_bundle, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")

    identity_dir = output / "identity_store"
    brotli_dir = output / "brotli_store"
    identity_manifest = pack_store(final_bundle, identity_dir, codec="identity", chunk_size=4096)
    identity_rebuilt = load_store(identity_dir)
    brotli_manifest = repack_store(identity_dir, brotli_dir, codec="brotli")
    brotli_rebuilt = load_store(brotli_dir)

    source_identity_preserved = (
        runtime.object_head(MATH_ID) == source_head
        and runtime.revision(source_head)["content_address"] == source_content
    )
    derivative_revision = runtime.revision(runtime.object_head(derivative["result_object_id"]))
    glyph_revision = runtime.revision(runtime.object_head(glyph_result["result_object_id"]))

    checks = {
        "source_identity_preserved": source_identity_preserved,
        "clone_new_identity_same_content": (
            clone["persistent_id"] != MATH_ID
            and runtime.revision(runtime.object_head(clone["persistent_id"]))["content_address"] == source_content
        ),
        "candidate_promoted": promoted["status"] == "Committed" and not runtime.list_candidates(),
        "native_derivative_result": (
            derivative_revision["metadata"].get("evidence_class") == "computed"
            and derivative_revision["metadata"].get("derived_from", {}).get("object") == MATH_ID
        ),
        "glyph_bound": binding["status"] == "Committed",
        "glyph_exec_result": (
            glyph_result["status"] == "Committed"
            and glyph_result.get("invoked_by_glyph") == glyph["persistent_id"]
            and glyph_revision["metadata"].get("evidence_class") == "computed"
        ),
        "identity_store_roundtrip": identity_rebuilt == final_bundle,
        "brotli_store_roundtrip": brotli_rebuilt == final_bundle,
        "physical_manifests_differ": identity_manifest["manifest_id"] != brotli_manifest["manifest_id"],
        "workspace_revision_preserved_across_store": (
            identity_rebuilt["workspace"]["workspace_revision"]
            == brotli_rebuilt["workspace"]["workspace_revision"]
            == final_bundle["workspace"]["workspace_revision"]
        ),
    }
    status = "PASS" if all(checks.values()) else "FAIL"
    return {
        "status": status,
        "workspace_revision": final_bundle["workspace"]["workspace_revision"],
        "source_object_id": MATH_ID,
        "clone_object_id": clone["persistent_id"],
        "derivative_result_id": derivative["result_object_id"],
        "glyph_id": glyph["persistent_id"],
        "glyph_result_id": glyph_result["result_object_id"],
        "identity_manifest_id": identity_manifest["manifest_id"],
        "brotli_manifest_id": brotli_manifest["manifest_id"],
        "checks": checks,
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Run the EveGlyph MVP-01 deterministic vertical slice")
    parser.add_argument("--output", type=Path, default=Path("examples/demo_output"))
    parser.add_argument("--json", action="store_true", help="Print compact JSON report")
    args = parser.parse_args(argv)
    report = run_vertical_slice(args.output)
    report_path = args.output / "report.json"
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    if args.json:
        print(json.dumps(report, ensure_ascii=False, separators=(",", ":")))
    else:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())

import pathlib
import shutil
import sys
import tempfile
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))

from eveglyph_mvp.fixtures import load_minimal_workspace
from eveglyph_mvp.storage import load_store, pack_store


class StorageTests(unittest.TestCase):
    def test_identity_store_round_trips_exact_egir_bundle(self):
        bundle = load_minimal_workspace()
        with tempfile.TemporaryDirectory() as tmp:
            store = pathlib.Path(tmp) / 'store'
            manifest = pack_store(bundle, store, codec='identity', chunk_size=4096)
            rebuilt = load_store(store)

        self.assertEqual(rebuilt, bundle)
        self.assertEqual(manifest['store_version'], 'egstore/0.1')
        self.assertTrue(manifest['manifest_id'].startswith('store:sha256:'))
        self.assertTrue(manifest['chunks'])
        self.assertTrue(all(chunk['codec'] == 'identity' for chunk in manifest['chunks']))

    def test_brotli_repack_changes_physical_store_but_preserves_egir_identities(self):
        bundle = load_minimal_workspace()
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            source = root / 'identity'
            target = root / 'brotli'
            identity_manifest = pack_store(bundle, source, codec='identity', chunk_size=4096)
            from eveglyph_mvp.storage import repack_store
            brotli_manifest = repack_store(source, target, codec='brotli')
            rebuilt = load_store(target)

        self.assertNotEqual(identity_manifest['manifest_id'], brotli_manifest['manifest_id'])
        self.assertTrue(all(chunk['codec'] == 'brotli' for chunk in brotli_manifest['chunks']))
        self.assertEqual(
            {o['persistent_id']: o['heads'] for o in rebuilt['object_records']},
            {o['persistent_id']: o['heads'] for o in bundle['object_records']},
        )
        self.assertEqual(
            {r['revision_id'] for r in rebuilt['revision_records']},
            {r['revision_id'] for r in bundle['revision_records']},
        )

    def test_corrupted_encoded_chunk_returns_typed_error(self):
        from eveglyph_mvp.storage import StorageError
        bundle = load_minimal_workspace()
        with tempfile.TemporaryDirectory() as tmp:
            store = pathlib.Path(tmp) / 'store'
            manifest = pack_store(bundle, store, codec='identity', chunk_size=4096)
            chunk_path = store / manifest['chunks'][0]['locator']
            data = bytearray(chunk_path.read_bytes())
            data[0] ^= 0x01
            chunk_path.write_bytes(bytes(data))
            with self.assertRaises(StorageError) as ctx:
                load_store(store)
        self.assertEqual(ctx.exception.code, 'EncodedHashMismatch')


if __name__ == '__main__':
    unittest.main()

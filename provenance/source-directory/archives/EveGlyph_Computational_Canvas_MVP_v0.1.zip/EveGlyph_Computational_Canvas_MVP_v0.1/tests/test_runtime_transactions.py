import pathlib
import sys
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))

from eveglyph_mvp.fixtures import load_minimal_workspace
from eveglyph_mvp.runtime import WorkspaceRuntime

MATH_ID = 'urn:uuid:0190a001-1111-7abc-8def-111111111111'


class RuntimeTransactionTests(unittest.TestCase):
    def test_pure_move_changes_workspace_revision_but_not_object_revision_or_content(self):
        runtime = WorkspaceRuntime(load_minimal_workspace())
        before = runtime.snapshot()
        old_workspace = before['workspace']['workspace_revision']
        old_head = runtime.object_head(MATH_ID)
        old_content = runtime.revision(old_head)['content_address']

        result = runtime.move_object(
            MATH_ID,
            x='420.0',
            y='260.0',
            base_workspace_revision=old_workspace,
        )

        self.assertEqual(result['status'], 'Committed')
        self.assertNotEqual(runtime.workspace_revision, old_workspace)
        self.assertEqual(runtime.object_head(MATH_ID), old_head)
        self.assertEqual(runtime.revision(old_head)['content_address'], old_content)
        placement = runtime.placement_for(MATH_ID)
        self.assertEqual(placement['transform']['x'], '420.0')
        self.assertEqual(placement['transform']['y'], '260.0')

    def test_stale_base_returns_conflict_without_mutation(self):
        runtime = WorkspaceRuntime(load_minimal_workspace())
        stale = runtime.workspace_revision
        runtime.move_object(MATH_ID, x='200.0', y='100.0', base_workspace_revision=stale)
        before = runtime.snapshot()

        result = runtime.try_move_object(MATH_ID, x='999.0', y='999.0', base_workspace_revision=stale)

        self.assertEqual(result['status'], 'Conflict')
        self.assertEqual(result['current_workspace_revision'], runtime.workspace_revision)
        self.assertEqual(runtime.snapshot(), before)

    def test_semantic_edit_preserves_identity_but_creates_new_revision_and_content(self):
        runtime = WorkspaceRuntime(load_minimal_workspace())
        base = runtime.workspace_revision
        old_head = runtime.object_head(MATH_ID)
        old_content = runtime.revision(old_head)['content_address']

        result = runtime.edit_math_power(MATH_ID, exponent='3', base_workspace_revision=base)

        self.assertEqual(result['status'], 'Committed')
        new_head = runtime.object_head(MATH_ID)
        self.assertNotEqual(new_head, old_head)
        self.assertNotEqual(runtime.revision(new_head)['content_address'], old_content)
        self.assertEqual(runtime.revision(new_head)['persistent_id'], MATH_ID)
        self.assertEqual(runtime.revision(new_head)['parents'], [old_head])

    def test_clone_keeps_content_but_gets_new_persistent_identity(self):
        runtime = WorkspaceRuntime(load_minimal_workspace())
        base = runtime.workspace_revision
        old_head = runtime.object_head(MATH_ID)
        old_content = runtime.revision(old_head)['content_address']

        result = runtime.clone_object(MATH_ID, base_workspace_revision=base)

        self.assertEqual(result['status'], 'Committed')
        clone_id = result['persistent_id']
        self.assertNotEqual(clone_id, MATH_ID)
        clone_head = runtime.object_head(clone_id)
        self.assertEqual(runtime.revision(clone_head)['content_address'], old_content)
        self.assertEqual(runtime.revision(clone_head)['persistent_id'], clone_id)


if __name__ == '__main__':
    unittest.main()

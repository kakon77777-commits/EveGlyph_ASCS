import pathlib
import sys
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))

from eveglyph_mvp.fixtures import load_minimal_workspace
from eveglyph_mvp.runtime import WorkspaceRuntime

MATH_ID = 'urn:uuid:0190a001-1111-7abc-8def-111111111111'


class CandidateTests(unittest.TestCase):
    def test_proposed_relation_stays_candidate_only(self):
        runtime = WorkspaceRuntime(load_minimal_workspace())
        base = runtime.workspace_revision
        committed_before = list(runtime.snapshot()['workspace']['relation_heads'])

        result = runtime.propose_relation(
            source_id=MATH_ID,
            predicate='eg:dependsOn',
            target={'type': 'semantic', 'schema': 'eg-sem/0.1', 'ontology': 'eg:math', 'anchors': ['x'], 'negative_anchors': [], 'relations': [], 'constraints': [], 'open_variables': [], 'confidence': '0.72', 'authority': 'candidate'},
            base_workspace_revision=base,
            actor_type='ai',
            actor_id='demo-agent',
        )

        self.assertEqual(result['status'], 'CandidateRecorded')
        self.assertEqual(runtime.workspace_revision, base)
        self.assertEqual(runtime.snapshot()['workspace']['relation_heads'], committed_before)
        candidate = runtime.list_candidates()[0]
        self.assertEqual(candidate['authority'], 'candidate')
        self.assertEqual(candidate['candidate_type'], 'relation')

    def test_promotion_creates_first_class_explicit_relation_and_removes_candidate(self):
        runtime = WorkspaceRuntime(load_minimal_workspace())
        base = runtime.workspace_revision
        proposal = runtime.propose_relation(
            source_id=MATH_ID,
            predicate='eg:dependsOn',
            target={'type': 'semantic', 'schema': 'eg-sem/0.1', 'ontology': 'eg:math', 'anchors': ['x'], 'negative_anchors': [], 'relations': [], 'constraints': [], 'open_variables': [], 'confidence': '0.72', 'authority': 'candidate'},
            base_workspace_revision=base,
            actor_type='ai',
            actor_id='demo-agent',
        )

        result = runtime.promote_candidate(
            proposal['candidate_id'],
            base_workspace_revision=runtime.workspace_revision,
        )

        self.assertEqual(result['status'], 'Committed')
        self.assertFalse(runtime.list_candidates())
        relation = runtime.object(result['relation_object_id'])
        self.assertEqual(relation['kind'], 'relation')
        revision = runtime.revision(relation['heads']['main'])
        self.assertEqual(revision['intrinsic']['authority']['class'], 'explicit')
        self.assertEqual(revision['intrinsic']['predicate'], 'eg:dependsOn')
        self.assertTrue(any(h['persistent_id'] == relation['persistent_id'] for h in runtime.snapshot()['workspace']['relation_heads']))


if __name__ == '__main__':
    unittest.main()

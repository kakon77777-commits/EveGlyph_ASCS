import json
import pathlib
import sys
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))

from eveglyph_mvp.canonical import canonical_bytes, content_address
from eveglyph_mvp.fixtures import load_minimal_workspace


class CanonicalTests(unittest.TestCase):
    def test_object_key_order_is_deterministic(self):
        left = {'z': 1, 'a': 'α', 'nested': {'b': True, 'a': None}}
        right = {'nested': {'a': None, 'b': True}, 'a': 'α', 'z': 1}
        self.assertEqual(canonical_bytes(left), canonical_bytes(right))
        self.assertEqual(canonical_bytes(left).decode('utf-8'), '{"a":"α","nested":{"a":null,"b":true},"z":1}')

    def test_minimal_math_content_address_recomputes(self):
        bundle = load_minimal_workspace()
        math_revision = next(r for r in bundle['revision_records'] if r['kind'] == 'math')
        self.assertEqual(
            content_address(math_revision['kind'], math_revision['intrinsic']),
            math_revision['content_address'],
        )


if __name__ == '__main__':
    unittest.main()

import pathlib
import sys
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))

from eveglyph_mvp.fixtures import load_minimal_workspace
from eveglyph_mvp.math_runtime import differentiate_ncm
from eveglyph_mvp.runtime import WorkspaceRuntime

MATH_ID = 'urn:uuid:0190a001-1111-7abc-8def-111111111111'


def node_map(intrinsic):
    return {node['id']: node for node in intrinsic['expression']['nodes']}


class MathAndGlyphTests(unittest.TestCase):
    def test_native_x_squared_derivative_is_two_x_without_latex_reparse(self):
        bundle = load_minimal_workspace()
        source = next(r for r in bundle['revision_records'] if r['kind'] == 'math')['intrinsic']

        result = differentiate_ncm(source, 'x')

        nodes = node_map(result)
        root = nodes[result['expression']['root']]
        self.assertEqual(root['type'], 'apply')
        self.assertEqual(root['operator']['builtin'], 'mul')
        left = nodes[root['args'][0]]
        right = nodes[root['args'][1]]
        self.assertEqual(left, {'id': left['id'], 'type': 'integer', 'value': '2'})
        self.assertEqual(right, {'id': right['id'], 'type': 'symbol', 'name': 'x'})
        self.assertNotIn('latex', result)

    def test_runtime_derivative_creates_new_result_identity_and_provenance(self):
        runtime = WorkspaceRuntime(load_minimal_workspace())
        base = runtime.workspace_revision
        source_head = runtime.object_head(MATH_ID)

        result = runtime.execute_derivative(MATH_ID, variable='x', base_workspace_revision=base)

        self.assertEqual(result['status'], 'Committed')
        result_id = result['result_object_id']
        self.assertNotEqual(result_id, MATH_ID)
        self.assertEqual(runtime.object_head(MATH_ID), source_head)
        result_head = runtime.object_head(result_id)
        result_rev = runtime.revision(result_head)
        self.assertEqual(result_rev['kind'], 'math')
        self.assertEqual(result_rev['metadata']['evidence_class'], 'computed')
        self.assertEqual(result_rev['metadata']['derived_from']['object'], MATH_ID)
        self.assertEqual(result_rev['metadata']['derived_from']['revision'], source_head)

    def test_custom_glyph_needs_explicit_operator_binding_before_execution(self):
        runtime = WorkspaceRuntime(load_minimal_workspace())
        base = runtime.workspace_revision

        created = runtime.create_glyph(
            name='∂-custom',
            geometry={'kind': 'polyline', 'points': [['0', '0'], ['8', '4'], ['0', '8']]},
            base_workspace_revision=base,
        )

        glyph_id = created['persistent_id']
        glyph_rev = runtime.revision(runtime.object_head(glyph_id))
        self.assertEqual(glyph_rev['kind'], 'glyph')
        self.assertNotIn('unicode', glyph_rev['intrinsic'])
        before_execute = runtime.workspace_revision
        result = runtime.execute_glyph(
            glyph_id,
            math_object_id=MATH_ID,
            variable='x',
            base_workspace_revision=before_execute,
        )
        self.assertEqual(result['status'], 'UnresolvedOperator')
        self.assertEqual(runtime.workspace_revision, before_execute)

    def test_explicit_glyph_binding_executes_the_same_derivative_operator(self):
        runtime = WorkspaceRuntime(load_minimal_workspace())
        created = runtime.create_glyph(
            name='∂-custom',
            geometry={'kind': 'polyline', 'points': [['0', '0'], ['8', '4'], ['0', '8']]},
            base_workspace_revision=runtime.workspace_revision,
        )
        glyph_id = created['persistent_id']

        binding = runtime.bind_glyph_operator(
            glyph_id,
            operator='derivative',
            base_workspace_revision=runtime.workspace_revision,
        )
        self.assertEqual(binding['status'], 'Committed')

        result = runtime.execute_glyph(
            glyph_id,
            math_object_id=MATH_ID,
            variable='x',
            base_workspace_revision=runtime.workspace_revision,
        )

        self.assertEqual(result['status'], 'Committed')
        result_rev = runtime.revision(runtime.object_head(result['result_object_id']))
        nodes = node_map(result_rev['intrinsic'])
        root = nodes[result_rev['intrinsic']['expression']['root']]
        self.assertEqual(root['operator']['builtin'], 'mul')


if __name__ == '__main__':
    unittest.main()

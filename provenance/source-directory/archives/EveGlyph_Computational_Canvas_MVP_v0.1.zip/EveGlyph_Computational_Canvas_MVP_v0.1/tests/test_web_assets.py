from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]


class WebAssetTests(unittest.TestCase):
    def test_ui_shell_contains_canvas_toolbar_diagnostics_and_candidate_panel(self):
        html = (ROOT / 'web' / 'index.html').read_text(encoding='utf-8')
        self.assertIn('id="canvas-viewport"', html)
        self.assertIn('id="world"', html)
        self.assertIn('id="toolbar"', html)
        self.assertIn('id="diagnostics"', html)
        self.assertIn('id="candidate-list"', html)
        self.assertIn('id="btn-save"', html)
        self.assertIn('src="/app.js"', html)
        self.assertIn('href="/style.css"', html)

    def test_browser_logic_has_pan_zoom_drag_conflict_and_core_commands(self):
        js = (ROOT / 'web' / 'app.js').read_text(encoding='utf-8')
        for marker in [
            'wheel', 'pointermove', 'base_workspace_revision', 'Conflict',
            '/api/move', '/api/clone', '/api/derivative', '/api/candidate',
            '/api/promote', '/api/glyph', '/api/glyph-bind', '/api/glyph-execute', '/api/save',
        ]:
            self.assertIn(marker, js)


if __name__ == '__main__':
    unittest.main()

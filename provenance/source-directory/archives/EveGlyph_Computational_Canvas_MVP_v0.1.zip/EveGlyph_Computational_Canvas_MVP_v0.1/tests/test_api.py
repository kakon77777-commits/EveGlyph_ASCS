import json
import pathlib
import sys
import threading
import unittest
import urllib.error
import urllib.request

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))

from eveglyph_mvp.fixtures import load_minimal_workspace
from eveglyph_mvp.runtime import WorkspaceRuntime
from eveglyph_mvp.server import create_http_server

MATH_ID = 'urn:uuid:0190a001-1111-7abc-8def-111111111111'


class APITests(unittest.TestCase):
    def setUp(self):
        self.runtime = WorkspaceRuntime(load_minimal_workspace())
        self.server = create_http_server(self.runtime, host='127.0.0.1', port=0, web_root=ROOT / 'web')
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        host, port = self.server.server_address
        self.base = f'http://{host}:{port}'

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=2)

    def _json(self, path, payload=None):
        if payload is None:
            req = urllib.request.Request(self.base + path)
        else:
            req = urllib.request.Request(
                self.base + path,
                data=json.dumps(payload).encode('utf-8'),
                headers={'Content-Type': 'application/json'},
                method='POST',
            )
        with urllib.request.urlopen(req, timeout=2) as resp:
            return resp.status, json.loads(resp.read().decode('utf-8'))

    def test_get_state_returns_workspace_revision_and_objects(self):
        status, data = self._json('/api/state')
        self.assertEqual(status, 200)
        self.assertEqual(data['workspace_revision'], self.runtime.workspace_revision)
        self.assertTrue(any(obj['persistent_id'] == MATH_ID for obj in data['objects']))

    def test_stale_move_returns_http_409_and_typed_conflict(self):
        stale = self.runtime.workspace_revision
        self.runtime.move_object(MATH_ID, x='180.0', y='110.0', base_workspace_revision=stale)
        current = self.runtime.workspace_revision
        payload = {
            'object_id': MATH_ID,
            'x': '999.0',
            'y': '999.0',
            'base_workspace_revision': stale,
        }
        req = urllib.request.Request(
            self.base + '/api/move',
            data=json.dumps(payload).encode('utf-8'),
            headers={'Content-Type': 'application/json'},
            method='POST',
        )
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            urllib.request.urlopen(req, timeout=2)
        self.assertEqual(ctx.exception.code, 409)
        data = json.loads(ctx.exception.read().decode('utf-8'))
        self.assertEqual(data['status'], 'Conflict')
        self.assertEqual(data['current_workspace_revision'], current)
        self.assertEqual(self.runtime.placement_for(MATH_ID)['transform']['x'], '180.0')

    def test_core_command_surface_derivative_candidate_and_glyph_routes(self):
        status, edited = self._json('/api/edit-power', {
            'object_id': MATH_ID, 'exponent': '3',
            'base_workspace_revision': self.runtime.workspace_revision,
        })
        self.assertEqual((status, edited['status']), (200, 'Committed'))

        status, derivative = self._json('/api/derivative', {
            'object_id': MATH_ID, 'variable': 'x',
            'base_workspace_revision': self.runtime.workspace_revision,
        })
        self.assertEqual((status, derivative['status']), (200, 'Committed'))

        status, clone = self._json('/api/clone', {
            'object_id': MATH_ID,
            'base_workspace_revision': self.runtime.workspace_revision,
        })
        self.assertEqual((status, clone['status']), (200, 'Committed'))

        status, candidate = self._json('/api/candidate', {
            'source_id': MATH_ID,
            'predicate': 'eg:dependsOn',
            'target': {'type': 'semantic', 'schema': 'eg-sem/0.1', 'ontology': 'eg:math', 'anchors': ['x'], 'negative_anchors': [], 'relations': [], 'constraints': [], 'open_variables': [], 'confidence': '0.8', 'authority': 'candidate'},
            'base_workspace_revision': self.runtime.workspace_revision,
        })
        self.assertEqual((status, candidate['status']), (200, 'CandidateRecorded'))

        status, promoted = self._json('/api/promote', {
            'candidate_id': candidate['candidate_id'],
            'base_workspace_revision': self.runtime.workspace_revision,
        })
        self.assertEqual((status, promoted['status']), (200, 'Committed'))

        status, glyph = self._json('/api/glyph', {
            'name': 'custom-d',
            'geometry': {'kind': 'polyline', 'points': [['0', '0'], ['8', '4'], ['0', '8']]},
            'base_workspace_revision': self.runtime.workspace_revision,
        })
        self.assertEqual((status, glyph['status']), (200, 'Committed'))

        status, bound = self._json('/api/glyph-bind', {
            'glyph_id': glyph['persistent_id'], 'operator': 'derivative',
            'base_workspace_revision': self.runtime.workspace_revision,
        })
        self.assertEqual((status, bound['status']), (200, 'Committed'))

        status, executed = self._json('/api/glyph-execute', {
            'glyph_id': glyph['persistent_id'], 'math_object_id': MATH_ID, 'variable': 'x',
            'base_workspace_revision': self.runtime.workspace_revision,
        })
        self.assertEqual((status, executed['status']), (200, 'Committed'))
        self.assertEqual(executed['invoked_by_glyph'], glyph['persistent_id'])

    def test_app_factory_builds_default_runtime_from_packaged_fixture(self):
        from eveglyph_mvp.app import build_default_runtime
        runtime = build_default_runtime()
        self.assertEqual(runtime.snapshot()['ir_version'], 'egir/0.1')
        self.assertTrue(runtime.workspace_revision.startswith('wrev:sha256:'))

    def test_server_serves_browser_canvas_assets(self):
        with urllib.request.urlopen(self.base + '/', timeout=2) as resp:
            html = resp.read().decode('utf-8')
            self.assertEqual(resp.status, 200)
            self.assertIn('EveGlyph Computational Canvas MVP v0.1', html)
        with urllib.request.urlopen(self.base + '/app.js', timeout=2) as resp:
            js = resp.read().decode('utf-8')
            self.assertEqual(resp.status, 200)
            self.assertIn('/api/move', js)

    def test_save_endpoint_writes_only_to_server_configured_store_root(self):
        import tempfile
        with tempfile.TemporaryDirectory() as tmp:
            server = create_http_server(
                self.runtime, host='127.0.0.1', port=0, web_root=ROOT / 'web', store_root=pathlib.Path(tmp) / 'saved'
            )
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            host, port = server.server_address
            req = urllib.request.Request(
                f'http://{host}:{port}/api/save',
                data=json.dumps({'codec': 'identity'}).encode('utf-8'),
                headers={'Content-Type': 'application/json'},
                method='POST',
            )
            try:
                with urllib.request.urlopen(req, timeout=2) as resp:
                    data = json.loads(resp.read().decode('utf-8'))
                self.assertEqual(data['status'], 'Saved')
                self.assertTrue((pathlib.Path(tmp) / 'saved' / 'manifest.json').exists())
                self.assertTrue(data['manifest_id'].startswith('store:sha256:'))
            finally:
                server.shutdown(); server.server_close(); thread.join(timeout=2)


if __name__ == '__main__':
    unittest.main()

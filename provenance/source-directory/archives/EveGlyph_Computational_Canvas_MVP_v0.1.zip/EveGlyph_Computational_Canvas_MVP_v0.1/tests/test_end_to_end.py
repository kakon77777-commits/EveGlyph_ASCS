import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


class EndToEndTests(unittest.TestCase):
    def test_demo_sequence_runs_full_vertical_slice_and_rehydrates_brotli_store(self):
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp) / 'demo'
            env = dict(os.environ)
            env['PYTHONPATH'] = str(ROOT / 'src')
            proc = subprocess.run(
                [sys.executable, str(ROOT / 'scripts' / 'run_demo.py'), '--output', str(output), '--json'],
                cwd=ROOT,
                env=env,
                text=True,
                capture_output=True,
                check=False,
            )
            self.assertEqual(proc.returncode, 0, proc.stdout + '\n' + proc.stderr)
            report = json.loads(proc.stdout)
            self.assertEqual(report['status'], 'PASS')
            self.assertTrue(report['checks']['source_identity_preserved'])
            self.assertTrue(report['checks']['candidate_promoted'])
            self.assertTrue(report['checks']['native_derivative_result'])
            self.assertTrue(report['checks']['glyph_exec_result'])
            self.assertTrue(report['checks']['identity_store_roundtrip'])
            self.assertTrue(report['checks']['brotli_store_roundtrip'])
            self.assertTrue((output / 'identity_store' / 'manifest.json').exists())
            self.assertTrue((output / 'brotli_store' / 'manifest.json').exists())
            self.assertTrue((output / 'final.egir.json').exists())

    def test_mvp_validator_accepts_demo_and_runs_spec_reference_validators(self):
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp) / 'demo'
            env = dict(os.environ)
            env['PYTHONPATH'] = str(ROOT / 'src')
            demo = subprocess.run(
                [sys.executable, str(ROOT / 'scripts' / 'run_demo.py'), '--output', str(output), '--json'],
                cwd=ROOT, env=env, text=True, capture_output=True, check=False,
            )
            self.assertEqual(demo.returncode, 0, demo.stdout + demo.stderr)
            validate = subprocess.run(
                [
                    sys.executable, str(ROOT / 'scripts' / 'validate_mvp.py'),
                    '--demo-output', str(output),
                    '--json',
                ],
                cwd=ROOT, env=env, text=True, capture_output=True, check=False,
            )
            self.assertEqual(validate.returncode, 0, validate.stdout + '\n' + validate.stderr)
            report = json.loads(validate.stdout)
            self.assertEqual(report['status'], 'PASS')
            self.assertTrue(report['checks']['tw01_schema'])
            self.assertTrue(report['checks']['tw01_hashes'])
            self.assertTrue(report['checks']['tw02_identity_store'])
            self.assertTrue(report['checks']['tw02_brotli_store'])
            self.assertTrue(report['checks']['reference_tw01'])
            self.assertTrue(report['checks']['reference_tw02'])
            self.assertTrue(report['checks']['reference_tw03'])


if __name__ == '__main__':
    unittest.main()

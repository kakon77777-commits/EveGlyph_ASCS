from pathlib import Path
import subprocess
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]


class LauncherTests(unittest.TestCase):
    def test_root_launcher_exposes_help_without_pythonpath_setup(self):
        proc = subprocess.run(
            [sys.executable, str(ROOT / 'run_mvp.py'), '--help'],
            cwd=ROOT,
            text=True,
            capture_output=True,
            check=False,
        )
        self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)
        self.assertIn('EveGlyph Computational Canvas MVP v0.1', proc.stdout)
        self.assertIn('--store-root', proc.stdout)


if __name__ == '__main__':
    unittest.main()

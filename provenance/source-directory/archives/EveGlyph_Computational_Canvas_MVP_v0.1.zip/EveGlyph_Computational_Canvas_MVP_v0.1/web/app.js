const $ = (id) => document.getElementById(id)
const viewport = $('canvas-viewport')
const world = $('world')
const nodeLayer = $('node-layer')
const edgeLayer = $('edge-layer')
const diagnostics = $('diagnostics')
const objectList = $('object-list')
const candidateList = $('candidate-list')
const inspector = $('inspector')
const zoomReadout = $('zoom-readout')

const view = {
  panX: 360,
  panY: 220,
  scale: 1,
  selectedId: null,
  state: null,
  panning: null,
  dragging: null,
}

function note(message) {
  diagnostics.textContent = String(message)
}

function applyWorldTransform() {
  world.style.transform = `translate(${view.panX}px, ${view.panY}px) scale(${view.scale})`
  zoomReadout.textContent = `${Math.round(view.scale * 100)}%`
}

async function api(path, payload = undefined) {
  const options = payload === undefined
    ? {}
    : {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      }
  const response = await fetch(path, options)
  const data = await response.json()
  if (!response.ok) {
    if (data.status === 'Conflict') {
      note(`Conflict: canonical state advanced to ${data.current_workspace_revision}`)
      await refresh()
    }
    const error = new Error(data.reason || data.status || `HTTP ${response.status}`)
    error.data = data
    throw error
  }
  return data
}

function revisionShort(value) {
  if (!value) return '—'
  return value.length > 22 ? `${value.slice(0, 13)}…${value.slice(-8)}` : value
}

function expressionText(intrinsic) {
  if (!intrinsic?.expression) return 'math'
  const nodes = new Map(intrinsic.expression.nodes.map((node) => [node.id, node]))
  const show = (id) => {
    const node = nodes.get(id)
    if (!node) return '?'
    if (node.type === 'symbol') return node.name
    if (node.type === 'integer' || node.type === 'decimal') return node.value
    if (node.type === 'apply') {
      const op = node.operator?.builtin
      if (op === 'pow') return `${show(node.args[0])}^${show(node.args[1])}`
      if (op === 'mul') return `${show(node.args[0])} · ${show(node.args[1])}`
      return `${op || 'apply'}(${node.args.map(show).join(', ')})`
    }
    return node.type
  }
  return show(intrinsic.expression.root)
}

function displayTitle(obj) {
  const alias = obj.aliases?.[0]?.name
  if (obj.kind === 'math') return expressionText(obj.intrinsic)
  if (obj.kind === 'glyph') return alias || 'Custom Glyph'
  if (obj.kind === 'operator') return alias || 'Operator'
  return alias || obj.kind
}

function placementMap() {
  return new Map((view.state?.workspace?.placements || []).map((p) => [p.object_id, p]))
}

function objectMap() {
  return new Map((view.state?.objects || []).map((obj) => [obj.persistent_id, obj]))
}

function renderEdges() {
  edgeLayer.replaceChildren()
  const placements = placementMap()
  const objects = objectMap()
  for (const rel of view.state?.objects || []) {
    if (rel.kind !== 'relation') continue
    const intrinsic = rel.intrinsic || {}
    if (intrinsic.authority?.class !== 'explicit') continue
    const sourceId = intrinsic.source?.type === 'identity' ? intrinsic.source.value : null
    const targetId = intrinsic.target?.type === 'identity' ? intrinsic.target.value : null
    if (!sourceId || !targetId || !objects.has(sourceId) || !objects.has(targetId)) continue
    const a = placements.get(sourceId)
    const b = placements.get(targetId)
    if (!a || !b) continue
    const line = document.createElementNS('http://www.w3.org/2000/svg', 'line')
    const ax = Number(a.transform.x) + 85
    const ay = Number(a.transform.y) + 40
    const bx = Number(b.transform.x) + 85
    const by = Number(b.transform.y) + 40
    line.setAttribute('x1', ax)
    line.setAttribute('y1', ay)
    line.setAttribute('x2', bx)
    line.setAttribute('y2', by)
    line.setAttribute('stroke', '#7187aa')
    line.setAttribute('stroke-width', '2')
    line.setAttribute('stroke-dasharray', intrinsic.predicate === 'eg:bindsOperator' ? '5 4' : 'none')
    edgeLayer.appendChild(line)
  }
}

function selectObject(id) {
  view.selectedId = id
  render()
}

function nodePointerDown(event, obj, placement, element) {
  event.stopPropagation()
  selectObject(obj.persistent_id)
  const startX = Number(placement.transform.x)
  const startY = Number(placement.transform.y)
  view.dragging = {
    pointerId: event.pointerId,
    id: obj.persistent_id,
    startClientX: event.clientX,
    startClientY: event.clientY,
    startX,
    startY,
    element,
    base_workspace_revision: view.state.workspace_revision,
  }
  element.setPointerCapture?.(event.pointerId)
}

function renderNodes() {
  nodeLayer.replaceChildren()
  const placements = placementMap()
  for (const obj of view.state?.objects || []) {
    if (obj.kind === 'relation') continue
    const placement = placements.get(obj.persistent_id)
    if (!placement) continue
    const node = document.createElement('article')
    node.className = `node${view.selectedId === obj.persistent_id ? ' selected' : ''}`
    node.dataset.objectId = obj.persistent_id
    node.style.left = `${Number(placement.transform.x)}px`
    node.style.top = `${Number(placement.transform.y)}px`

    const kind = document.createElement('div')
    kind.className = 'kind'
    kind.textContent = obj.kind
    const title = document.createElement('div')
    title.className = 'title'
    title.textContent = displayTitle(obj)
    const meta = document.createElement('div')
    meta.className = 'meta'
    meta.textContent = revisionShort(obj.head)
    node.append(kind, title, meta)
    node.addEventListener('pointerdown', (event) => nodePointerDown(event, obj, placement, node))
    node.addEventListener('dblclick', () => selectObject(obj.persistent_id))
    nodeLayer.appendChild(node)
  }
}

function renderObjectList() {
  objectList.replaceChildren()
  for (const obj of view.state?.objects || []) {
    if (obj.kind === 'relation') continue
    const row = document.createElement('div')
    row.className = `object-row${view.selectedId === obj.persistent_id ? ' active' : ''}`
    row.textContent = `${obj.kind} · ${displayTitle(obj)}`
    row.title = obj.persistent_id
    row.addEventListener('click', () => selectObject(obj.persistent_id))
    objectList.appendChild(row)
  }
}

function renderCandidates() {
  candidateList.replaceChildren()
  const candidates = view.state?.candidates || []
  if (!candidates.length) {
    candidateList.textContent = 'No candidates.'
    return
  }
  for (const candidate of candidates) {
    const row = document.createElement('div')
    row.className = 'candidate-row'
    row.textContent = `${candidate.candidate_type}: ${candidate.payload?.predicate || candidate.candidate_id}`
    row.dataset.candidateId = candidate.candidate_id
    candidateList.appendChild(row)
  }
}

function renderInspector() {
  const obj = (view.state?.objects || []).find((item) => item.persistent_id === view.selectedId)
  inspector.textContent = obj ? JSON.stringify(obj, null, 2) : '—'
}

function render() {
  if (!view.state) return
  if (view.selectedId && !(view.state.objects || []).some((o) => o.persistent_id === view.selectedId)) {
    view.selectedId = null
  }
  renderNodes()
  renderEdges()
  renderObjectList()
  renderCandidates()
  renderInspector()
  applyWorldTransform()
}

async function refresh() {
  view.state = await api('/api/state')
  if (!view.selectedId) {
    view.selectedId = view.state.objects.find((o) => o.kind === 'math')?.persistent_id || null
  }
  render()
  note(`Loaded ${view.state.objects.length} objects\n${view.state.workspace_revision}`)
}

viewport.addEventListener('pointerdown', (event) => {
  if (event.target.closest?.('.node')) return
  view.panning = {
    pointerId: event.pointerId,
    startClientX: event.clientX,
    startClientY: event.clientY,
    startPanX: view.panX,
    startPanY: view.panY,
  }
  viewport.classList.add('panning')
  viewport.setPointerCapture?.(event.pointerId)
})

window.addEventListener('pointermove', (event) => {
  if (view.dragging && event.pointerId === view.dragging.pointerId) {
    const dx = (event.clientX - view.dragging.startClientX) / view.scale
    const dy = (event.clientY - view.dragging.startClientY) / view.scale
    const x = view.dragging.startX + dx
    const y = view.dragging.startY + dy
    view.dragging.element.style.left = `${x}px`
    view.dragging.element.style.top = `${y}px`
    view.dragging.previewX = x
    view.dragging.previewY = y
    return
  }
  if (view.panning && event.pointerId === view.panning.pointerId) {
    view.panX = view.panning.startPanX + event.clientX - view.panning.startClientX
    view.panY = view.panning.startPanY + event.clientY - view.panning.startClientY
    applyWorldTransform()
  }
})

window.addEventListener('pointerup', async (event) => {
  if (view.dragging && event.pointerId === view.dragging.pointerId) {
    const drag = view.dragging
    view.dragging = null
    const x = drag.previewX ?? drag.startX
    const y = drag.previewY ?? drag.startY
    try {
      await api('/api/move', {
        object_id: drag.id,
        x: x.toFixed(3),
        y: y.toFixed(3),
        base_workspace_revision: drag.base_workspace_revision,
      })
      await refresh()
    } catch (error) {
      if (error.data?.status !== 'Conflict') note(error.message)
    }
  }
  if (view.panning && event.pointerId === view.panning.pointerId) {
    view.panning = null
    viewport.classList.remove('panning')
  }
})

viewport.addEventListener('wheel', (event) => {
  event.preventDefault()
  const rect = viewport.getBoundingClientRect()
  const cx = event.clientX - rect.left
  const cy = event.clientY - rect.top
  const worldX = (cx - view.panX) / view.scale
  const worldY = (cy - view.panY) / view.scale
  const factor = Math.exp(-event.deltaY * 0.001)
  const next = Math.min(4, Math.max(0.15, view.scale * factor))
  view.panX = cx - worldX * next
  view.panY = cy - worldY * next
  view.scale = next
  applyWorldTransform()
}, { passive: false })

function selectedObject(kind = undefined) {
  const current = view.state?.objects?.find((o) => o.persistent_id === view.selectedId)
  if (current && (!kind || current.kind === kind)) return current
  return view.state?.objects?.find((o) => !kind || o.kind === kind) || null
}

function originalMath() {
  return view.state?.objects?.find((o) => o.kind === 'math' && o.aliases?.some((a) => a.name === 'x²'))
    || view.state?.objects?.find((o) => o.kind === 'math')
}

async function command(path, payload) {
  try {
    const result = await api(path, {
      ...payload,
      base_workspace_revision: view.state.workspace_revision,
    })
    await refresh()
    note(`${path}: ${result.status}\n${result.workspace_revision || ''}`)
    return result
  } catch (error) {
    if (error.data?.status !== 'Conflict') note(`${path}: ${error.message}`)
    throw error
  }
}

$('btn-refresh').addEventListener('click', refresh)
$('btn-clone').addEventListener('click', async () => {
  const obj = selectedObject()
  if (obj) await command('/api/clone', { object_id: obj.persistent_id })
})
$('btn-derivative').addEventListener('click', async () => {
  const obj = selectedObject('math') || originalMath()
  if (obj) await command('/api/derivative', { object_id: obj.persistent_id, variable: 'x' })
})
$('btn-edit-power').addEventListener('click', async () => {
  const obj = selectedObject('math') || originalMath()
  if (!obj) return
  const nodes = obj.intrinsic?.expression?.nodes || []
  const root = nodes.find((n) => n.id === obj.intrinsic?.expression?.root)
  const exponent = nodes.find((n) => n.id === root?.args?.[1])
  const next = String(Number(exponent?.value || '1') + 1)
  await command('/api/edit-power', { object_id: obj.persistent_id, exponent: next })
})
$('btn-glyph').addEventListener('click', async () => {
  const result = await command('/api/glyph', {
    name: '∂ custom',
    geometry: { kind: 'polyline', points: [['0', '0'], ['10', '5'], ['0', '10']] },
  })
  view.selectedId = result.persistent_id
  render()
})
$('btn-bind').addEventListener('click', async () => {
  const glyph = selectedObject('glyph')
  if (!glyph) return note('Select a glyph first.')
  await command('/api/glyph-bind', { glyph_id: glyph.persistent_id, operator: 'derivative' })
})
$('btn-glyph-exec').addEventListener('click', async () => {
  const glyph = selectedObject('glyph')
  const math = originalMath()
  if (!glyph || !math) return note('Need a selected glyph and a math object.')
  await command('/api/glyph-execute', { glyph_id: glyph.persistent_id, math_object_id: math.persistent_id, variable: 'x' })
})
$('btn-candidate').addEventListener('click', async () => {
  const source = selectedObject() || originalMath()
  if (!source) return
  await command('/api/candidate', {
    source_id: source.persistent_id,
    predicate: 'eg:dependsOn',
    target: {
      type: 'semantic', schema: 'eg-sem/0.1', ontology: 'eg:demo',
      anchors: ['computed-result'], negative_anchors: [], relations: [], constraints: [], open_variables: [],
      confidence: '0.72', authority: 'candidate',
    },
    actor_type: 'ai', actor_id: 'browser-demo-agent',
  })
})
$('btn-promote').addEventListener('click', async () => {
  const candidate = view.state?.candidates?.[0]
  if (!candidate) return note('No candidate to promote.')
  await command('/api/promote', { candidate_id: candidate.candidate_id })
})
$('btn-save').addEventListener('click', async () => {
  try {
    const result = await api('/api/save', { codec: 'identity' })
    note(`Saved EGStore\n${result.manifest_id}`)
  } catch (error) {
    note(`Save failed: ${error.message}`)
  }
})

applyWorldTransform()
refresh().catch((error) => note(`Startup failed: ${error.message}`))

# EveGlyph Computational Canvas MVP v0.1

這是 ASCS v0.1（Addressable Symbolic Computational Space）系列的第一個可執行 MVP。它不是完整 EveGlyph 重寫，而是一條可驗證的 vertical slice，用最小程式證明 Paper 00–05 與 TW-01–03 的核心不變量可以同時落地。

## 這個 MVP 實作什麼

- **EGIR canonical state**：persistent object、immutable revision、workspace revision、relation、placement、event/provenance。
- **Transaction boundary**：canonical write 必須帶 `base_workspace_revision`；stale write 回 `Conflict`，不 silent overwrite。
- **Canvas move / semantic edit / clone**：move 不改 object revision；edit 同 identity 新 revision；clone 同初始 content 新 identity。
- **Candidate → explicit authority**：AI-style relation proposal 先停在 candidate layer，只有 promotion 才建立 first-class explicit relation。
- **Native Math**：直接在 NCM object 上執行 `$x^2 \mapsto 2x$`，canonical execution 不經 LaTeX parse-back。
- **Custom Glyph**：glyph 不需要 Unicode code point；未綁定 operator 前不能執行，explicit `eg:bindsOperator` 後可觸發同一 derivative runtime。
- **EGStore**：identity chunks 與 Brotli physical representation 可互換，rehydrate 後 EGIR object/revision identity 不漂移。
- **Infinite Canvas UI**：pan、zoom、drag、selection、clone、derivative、glyph、candidate/promotion、Save EGStore。
- **Self-contained validation**：MVP 內含 TW-01/02/03 reference support subset，可離線跑 reference validators。

## 快速啟動

需求：Python 3.11+。瀏覽器 UI 的 identity storage 不需要第三方框架。

完整 demo / validation 需要：

```bash
python -m pip install brotli jsonschema
```

啟動：

```bash
python run_mvp.py
```

預設：

- UI: `http://127.0.0.1:8765`
- Save EGStore: `./workspace_store/`

可改：

```bash
python run_mvp.py --host 127.0.0.1 --port 9000 --store-root ./my_store
```

## 一鍵 deterministic demo

```bash
PYTHONPATH=src python scripts/run_demo.py --output examples/demo_output --json
```

Demo 依序執行：

1. 載入 TW-01 minimal EGIR workspace；
2. move math node；
3. clone `$x^2$`；
4. 產生 AI-style candidate relation；
5. promote candidate；
6. native derivative；
7. 建立 custom glyph；
8. explicit bind `derivative`；
9. glyph execution；
10. identity EGStore pack；
11. Brotli repack；
12. 兩種 store rehydrate 回同一 EGIR state。

## 一鍵 validation

```bash
PYTHONPATH=src python scripts/validate_mvp.py \
  --demo-output examples/demo_output \
  --json
```

Validator 會檢查：

- TW-01 JSON Schema；
- content / revision / workspace hash recomputation；
- TW-02 identity store 與 Brotli store round-trip；
- bundled TW-01 reference validator；
- bundled TW-02 reference validator；
- bundled TW-03 reference runtime validator。

## 全測試

```bash
PYTHONPATH=src python -m unittest discover -s tests -v
```

## 專案結構

```text
EveGlyph_Computational_Canvas_MVP_v0.1/
├─ run_mvp.py
├─ README.md
├─ src/eveglyph_mvp/
│  ├─ app.py
│  ├─ canonical.py
│  ├─ fixtures.py
│  ├─ math_runtime.py
│  ├─ runtime.py
│  ├─ server.py
│  └─ storage.py
├─ web/
│  ├─ index.html
│  ├─ app.js
│  └─ style.css
├─ tests/
├─ scripts/
│  ├─ run_demo.py
│  └─ validate_mvp.py
├─ examples/
├─ spec_support/
│  ├─ TW-01_Support/
│  ├─ TW-02_Support/
│  └─ TW-03_Support/
└─ docs/superpowers/plans/
```

## Canonical / Session / Cache 邊界

MVP 的設計原則仍是：

$$
\text{Canonical State}
\neq
\text{Session Overlay}
\neq
\text{Derived Cache}
\neq
\text{External Effects}.
$$

瀏覽器的 pan / zoom / selection / drag preview 不直接改 EGIR。只有 drag end 或 toolbar command 才送 transaction。

## 已知限制（刻意保留到正式升級）

這是 MVP，不是 production runtime：

- Reference runtime 為了 deterministic conformance 使用可重現 UUIDv5 sequence；production writer 應切到 TW-01 建議的 UUIDv7 policy。
- Native Math 目前只實作單一 symbol 的正整數 power derivative；不是完整 CAS。
- Spatial parser / local grammar 尚未做一般化；目前 Canvas drag 是 explicit move，candidate relation 由 command/API 示範。
- 沒有 CRDT / distributed collaboration / remote federation。
- 沒有真正呼叫外部 AI model；「AI candidate」在 MVP 是 authority-boundary simulation，目的是驗證 proposal 不能直接變 canonical fact。
- Glyph geometry 只示範簡單 structured geometry；沒有整合完整 GSC v1.13 compiler pipeline。
- Execution sandbox 目前只跑內建 deterministic math backend；沒有 shell/network tool execution。
- EGStore 實作 identity + Brotli；Zstd / UTF-8X adapter 留給正式 storage upgrade。
- Browser UI 是工程驗證介面，不是商業版 UX/UI。

## 與既有 EveGlyph Editor 的關係

本 MVP 是 standalone reference implementation。未來正式升級 `eveglyph-editor` 時，建議採漸進遷移：

- 現有 mutable `S` state → UI Session Facade；
- 現有 filesystem / git-diff agent → Legacy File-Agent Adapter；
- canonical mutation → EGCR transaction；
- Markdown / LaTeX → adapter / projection，而不是唯一 ontology。

這樣可以保留現有編輯器價值，而不需要 big-bang rewrite。

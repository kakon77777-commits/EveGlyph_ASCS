from __future__ import annotations

import copy
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any

from .canonical import content_address, revision_address, workspace_revision_address
from .math_runtime import differentiate_ncm


class Conflict(RuntimeError):
    def __init__(self, base: str, current: str):
        super().__init__(f"stale base workspace revision: {base} != {current}")
        self.base = base
        self.current = current


class _DeterministicSequence:
    """Reproducible event IDs/timestamps for the reference MVP runtime."""

    def __init__(self, workspace_id: str):
        self.workspace_id = workspace_id
        self.counter = 0
        self.epoch = datetime(2026, 8, 24, 14, 30, 0, tzinfo=timezone.utc)

    def next(self, label: str) -> tuple[str, str]:
        self.counter += 1
        value = uuid.uuid5(uuid.NAMESPACE_URL, f"{self.workspace_id}:{self.counter}:{label}")
        timestamp = self.epoch + timedelta(seconds=self.counter)
        return f"urn:uuid:{value}", timestamp.isoformat(timespec="milliseconds").replace("+00:00", "Z")


class WorkspaceRuntime:
    def __init__(self, bundle: dict[str, Any]):
        self._bundle = copy.deepcopy(bundle)
        self._seq = _DeterministicSequence(self._bundle["workspace"]["workspace_id"])

    @property
    def workspace_revision(self) -> str:
        return self._bundle["workspace"]["workspace_revision"]

    def snapshot(self) -> dict[str, Any]:
        return copy.deepcopy(self._bundle)

    def object(self, persistent_id: str) -> dict[str, Any]:
        for record in self._bundle["object_records"]:
            if record["persistent_id"] == persistent_id:
                return record
        raise KeyError(persistent_id)

    def revision(self, revision_id: str) -> dict[str, Any]:
        for record in self._bundle["revision_records"]:
            if record["revision_id"] == revision_id:
                return record
        raise KeyError(revision_id)

    def object_head(self, persistent_id: str, branch: str = "main") -> str:
        return self.object(persistent_id)["heads"][branch]

    def placement_for(self, persistent_id: str) -> dict[str, Any]:
        for placement in self._bundle["workspace"]["placements"]:
            if placement["object_id"] == persistent_id:
                return placement
        raise KeyError(persistent_id)

    def _require_base(self, base_workspace_revision: str) -> None:
        if base_workspace_revision != self.workspace_revision:
            raise Conflict(base_workspace_revision, self.workspace_revision)

    def _append_event(self, op: str, base: str, *, actor_type: str = "human", actor_id: str = "local-user") -> tuple[str, str]:
        event_id, created_at = self._seq.next(op)
        self._bundle["event_records"].append(
            {
                "record_type": "event",
                "event_id": event_id,
                "actor": {"type": actor_type, "id": actor_id, "model": None},
                "op": op,
                "inputs": [],
                "outputs": [],
                "base_workspace_revision": base,
                "tool": {"name": "eveglyph-mvp", "version": "0.1"},
                "policy": {"mode": "explicit"},
                "created_at": created_at,
                "metadata": {},
            }
        )
        return event_id, created_at

    def _commit_workspace(self, previous_revision: str, event_id: str, created_at: str) -> str:
        workspace = self._bundle["workspace"]
        workspace["parents"] = [previous_revision]
        workspace["event_id"] = event_id
        workspace["created_at"] = created_at
        workspace["workspace_revision"] = workspace_revision_address(workspace)
        return workspace["workspace_revision"]


    def _set_workspace_head(self, persistent_id: str, revision_id: str, *, relation: bool = False) -> None:
        key = "relation_heads" if relation else "object_heads"
        heads = self._bundle["workspace"][key]
        for item in heads:
            if item["persistent_id"] == persistent_id:
                item["revision"] = revision_id
                return
        heads.append({"persistent_id": persistent_id, "revision": revision_id})

    def edit_math_power(
        self,
        persistent_id: str,
        *,
        exponent: str,
        base_workspace_revision: str,
    ) -> dict[str, Any]:
        self._require_base(base_workspace_revision)
        obj = self.object(persistent_id)
        if obj["kind"] != "math":
            raise TypeError("object is not math")
        old_head = obj["heads"]["main"]
        old_revision = self.revision(old_head)
        intrinsic = copy.deepcopy(old_revision["intrinsic"])
        nodes = intrinsic["expression"]["nodes"]
        root_id = intrinsic["expression"]["root"]
        root = next(node for node in nodes if node["id"] == root_id)
        if root.get("type") != "apply" or root.get("operator", {}).get("builtin") != "pow":
            raise ValueError("MVP edit_math_power requires pow root")
        exponent_id = root["args"][1]
        exponent_node = next(node for node in nodes if node["id"] == exponent_id)
        if exponent_node.get("type") != "integer":
            raise ValueError("MVP exponent must be integer")
        exponent_node["value"] = str(exponent)

        event_id, created_at = self._append_event("edit-math-power", base_workspace_revision)
        revision = {
            "record_type": "revision",
            "persistent_id": persistent_id,
            "revision_id": "",
            "kind": "math",
            "parents": [old_head],
            "content_address": content_address("math", intrinsic),
            "intrinsic": intrinsic,
            "event_id": event_id,
            "created_at": created_at,
            "metadata": {},
        }
        revision["revision_id"] = revision_address(revision)
        self._bundle["revision_records"].append(revision)
        obj["heads"]["main"] = revision["revision_id"]
        self._set_workspace_head(persistent_id, revision["revision_id"], relation=False)
        event = self._bundle["event_records"][-1]
        event["inputs"] = [{"type": "version", "object": persistent_id, "revision": old_head}]
        event["outputs"] = [{"type": "version", "object": persistent_id, "revision": revision["revision_id"]}]
        new_workspace = self._commit_workspace(base_workspace_revision, event_id, created_at)
        return {
            "status": "Committed",
            "workspace_revision": new_workspace,
            "persistent_id": persistent_id,
            "revision_id": revision["revision_id"],
        }


    def clone_object(
        self,
        persistent_id: str,
        *,
        base_workspace_revision: str,
    ) -> dict[str, Any]:
        self._require_base(base_workspace_revision)
        source_obj = self.object(persistent_id)
        source_head = source_obj["heads"]["main"]
        source_revision = self.revision(source_head)
        event_id, created_at = self._append_event("clone-object", base_workspace_revision)
        clone_uuid = uuid.uuid5(uuid.NAMESPACE_URL, event_id + ":clone-target")
        clone_id = f"urn:uuid:{clone_uuid}"
        clone_revision = {
            "record_type": "revision",
            "persistent_id": clone_id,
            "revision_id": "",
            "kind": source_revision["kind"],
            "parents": [],
            "content_address": source_revision["content_address"],
            "intrinsic": copy.deepcopy(source_revision["intrinsic"]),
            "event_id": event_id,
            "created_at": created_at,
            "metadata": {"cloned_from": persistent_id},
        }
        clone_revision["revision_id"] = revision_address(clone_revision)
        clone_obj = {
            "record_type": "object",
            "persistent_id": clone_id,
            "kind": source_obj["kind"],
            "status": "active",
            "created_event": event_id,
            "heads": {"main": clone_revision["revision_id"]},
            "aliases": [],
            "metadata": {"cloned_from": persistent_id},
        }
        self._bundle["object_records"].append(clone_obj)
        self._bundle["revision_records"].append(clone_revision)
        self._set_workspace_head(
            clone_id,
            clone_revision["revision_id"],
            relation=(source_obj["kind"] == "relation"),
        )
        try:
            source_place = self.placement_for(persistent_id)
        except KeyError:
            source_place = None
        if source_place is not None:
            new_place = copy.deepcopy(source_place)
            new_place["placement_id"] = "place:" + clone_uuid.hex[:16]
            new_place["object_id"] = clone_id
            try:
                new_place["transform"]["x"] = str(float(new_place["transform"]["x"]) + 80.0)
                new_place["transform"]["y"] = str(float(new_place["transform"]["y"]) + 80.0)
            except (KeyError, ValueError):
                pass
            self._bundle["workspace"]["placements"].append(new_place)
        event = self._bundle["event_records"][-1]
        event["inputs"] = [{"type": "version", "object": persistent_id, "revision": source_head}]
        event["outputs"] = [{"type": "version", "object": clone_id, "revision": clone_revision["revision_id"]}]
        new_workspace = self._commit_workspace(base_workspace_revision, event_id, created_at)
        return {
            "status": "Committed",
            "workspace_revision": new_workspace,
            "persistent_id": clone_id,
            "revision_id": clone_revision["revision_id"],
        }




    def create_glyph(
        self,
        *,
        name: str,
        geometry: dict[str, Any],
        base_workspace_revision: str,
    ) -> dict[str, Any]:
        self._require_base(base_workspace_revision)
        event_id, created_at = self._append_event("create-glyph", base_workspace_revision)
        glyph_uuid = uuid.uuid5(uuid.NAMESPACE_URL, event_id + ":glyph")
        glyph_id = f"urn:uuid:{glyph_uuid}"
        intrinsic = {
            "profile": "glyph/0.1",
            "geometry": copy.deepcopy(geometry),
            "topology": {},
            "parts": {},
            "semantics": [],
            "render_profiles": [{"id": "default", "kind": "canvas"}],
            "behavior": {"enabled": False},
        }
        revision = {
            "record_type": "revision",
            "persistent_id": glyph_id,
            "revision_id": "",
            "kind": "glyph",
            "parents": [],
            "content_address": content_address("glyph", intrinsic),
            "intrinsic": intrinsic,
            "event_id": event_id,
            "created_at": created_at,
            "metadata": {},
        }
        revision["revision_id"] = revision_address(revision)
        obj = {
            "record_type": "object",
            "persistent_id": glyph_id,
            "kind": "glyph",
            "status": "active",
            "created_event": event_id,
            "heads": {"main": revision["revision_id"]},
            "aliases": [{"scope": "workspace", "name": name, "mutable": True, "authority": "user"}],
            "metadata": {},
        }
        self._bundle["object_records"].append(obj)
        self._bundle["revision_records"].append(revision)
        self._set_workspace_head(glyph_id, revision["revision_id"], relation=False)
        self._bundle["workspace"]["placements"].append(
            {
                "placement_id": "place:" + glyph_uuid.hex[:16],
                "object_id": glyph_id,
                "region_id": None,
                "frame": "world",
                "transform": {"x": "120.0", "y": "260.0", "scale_x": "1.0", "scale_y": "1.0", "rotation_deg": "0.0"},
                "z": 0,
                "layer": "main",
            }
        )
        event = self._bundle["event_records"][-1]
        event["outputs"] = [{"type": "version", "object": glyph_id, "revision": revision["revision_id"]}]
        new_workspace = self._commit_workspace(base_workspace_revision, event_id, created_at)
        return {"status": "Committed", "workspace_revision": new_workspace, "persistent_id": glyph_id, "revision_id": revision["revision_id"]}


    def bind_glyph_operator(
        self,
        glyph_id: str,
        *,
        operator: str,
        base_workspace_revision: str,
    ) -> dict[str, Any]:
        self._require_base(base_workspace_revision)
        glyph = self.object(glyph_id)
        if glyph["kind"] != "glyph":
            raise TypeError("binding source is not glyph")
        event_id, created_at = self._append_event("bind-glyph-operator", base_workspace_revision)
        relation_uuid = uuid.uuid5(uuid.NAMESPACE_URL, event_id + ":glyph-binding")
        relation_id = f"urn:uuid:{relation_uuid}"
        target = {
            "type": "semantic",
            "schema": "eg-sem/0.1",
            "ontology": "eg:operator",
            "anchors": [operator],
            "negative_anchors": [],
            "relations": [],
            "constraints": [],
            "open_variables": [],
            "confidence": "1.0",
            "authority": "explicit",
        }
        intrinsic = {
            "profile": "relation/0.1",
            "source": {"type": "identity", "value": glyph_id},
            "predicate": "eg:bindsOperator",
            "target": target,
            "qualifiers": {},
            "authority": {
                "class": "explicit",
                "source": "user",
                "rule": "bind-glyph-operator",
                "confidence": "1.0",
            },
        }
        revision = {
            "record_type": "revision",
            "persistent_id": relation_id,
            "revision_id": "",
            "kind": "relation",
            "parents": [],
            "content_address": content_address("relation", intrinsic),
            "intrinsic": intrinsic,
            "event_id": event_id,
            "created_at": created_at,
            "metadata": {},
        }
        revision["revision_id"] = revision_address(revision)
        obj = {
            "record_type": "object",
            "persistent_id": relation_id,
            "kind": "relation",
            "status": "active",
            "created_event": event_id,
            "heads": {"main": revision["revision_id"]},
            "aliases": [],
            "metadata": {},
        }
        self._bundle["object_records"].append(obj)
        self._bundle["revision_records"].append(revision)
        self._set_workspace_head(relation_id, revision["revision_id"], relation=True)
        event = self._bundle["event_records"][-1]
        event["inputs"] = [{"type": "identity", "value": glyph_id}]
        event["outputs"] = [{"type": "version", "object": relation_id, "revision": revision["revision_id"]}]
        new_workspace = self._commit_workspace(base_workspace_revision, event_id, created_at)
        return {
            "status": "Committed",
            "workspace_revision": new_workspace,
            "relation_object_id": relation_id,
            "operator": operator,
        }

    def _glyph_operator(self, glyph_id: str) -> str | None:
        for head in self._bundle["workspace"]["relation_heads"]:
            rev = self.revision(head["revision"])
            intrinsic = rev.get("intrinsic", {})
            if intrinsic.get("profile") != "relation/0.1":
                continue
            if intrinsic.get("predicate") != "eg:bindsOperator":
                continue
            source = intrinsic.get("source", {})
            target = intrinsic.get("target", {})
            if source == {"type": "identity", "value": glyph_id} and target.get("type") == "semantic":
                anchors = target.get("anchors", [])
                if anchors:
                    return anchors[0]
        return None

    def execute_glyph(
        self,
        glyph_id: str,
        *,
        math_object_id: str,
        variable: str,
        base_workspace_revision: str,
    ) -> dict[str, Any]:
        self._require_base(base_workspace_revision)
        self.object(glyph_id)
        operator = self._glyph_operator(glyph_id)
        if operator is None:
            return {"status": "UnresolvedOperator", "glyph_id": glyph_id}
        if operator == "derivative":
            result = self.execute_derivative(
                math_object_id,
                variable=variable,
                base_workspace_revision=base_workspace_revision,
                actor_type="system",
                actor_id=f"glyph:{glyph_id}",
            )
            result["invoked_by_glyph"] = glyph_id
            return result
        return {"status": "UnsupportedOperator", "operator": operator}

    def execute_derivative(
        self,
        persistent_id: str,
        *,
        variable: str,
        base_workspace_revision: str,
        actor_type: str = "system",
        actor_id: str = "eg-math-core/0.1",
    ) -> dict[str, Any]:
        self._require_base(base_workspace_revision)
        source_obj = self.object(persistent_id)
        if source_obj["kind"] != "math":
            raise TypeError("derivative source is not math")
        source_head = source_obj["heads"]["main"]
        source_revision = self.revision(source_head)
        intrinsic = differentiate_ncm(source_revision["intrinsic"], variable)
        event_id, created_at = self._append_event(
            "execute-derivative",
            base_workspace_revision,
            actor_type=actor_type,
            actor_id=actor_id,
        )
        result_uuid = uuid.uuid5(uuid.NAMESPACE_URL, event_id + ":math-result")
        result_id = f"urn:uuid:{result_uuid}"
        metadata = {
            "evidence_class": "computed",
            "backend": {"name": "eg-math-core", "version": "0.1"},
            "derived_from": {"object": persistent_id, "revision": source_head},
            "operation": {"kind": "derivative", "variable": variable},
        }
        revision = {
            "record_type": "revision",
            "persistent_id": result_id,
            "revision_id": "",
            "kind": "math",
            "parents": [],
            "content_address": content_address("math", intrinsic),
            "intrinsic": intrinsic,
            "event_id": event_id,
            "created_at": created_at,
            "metadata": metadata,
        }
        revision["revision_id"] = revision_address(revision)
        obj = {
            "record_type": "object",
            "persistent_id": result_id,
            "kind": "math",
            "status": "active",
            "created_event": event_id,
            "heads": {"main": revision["revision_id"]},
            "aliases": [],
            "metadata": {"derived_from": persistent_id},
        }
        self._bundle["object_records"].append(obj)
        self._bundle["revision_records"].append(revision)
        self._set_workspace_head(result_id, revision["revision_id"], relation=False)
        try:
            source_place = self.placement_for(persistent_id)
            transform = copy.deepcopy(source_place["transform"])
            transform["x"] = str(float(transform["x"]) + 260.0)
            transform["y"] = str(float(transform["y"]) + 40.0)
        except KeyError:
            transform = {"x": "380.0", "y": "120.0", "scale_x": "1.0", "scale_y": "1.0", "rotation_deg": "0.0"}
        self._bundle["workspace"]["placements"].append(
            {
                "placement_id": "place:" + result_uuid.hex[:16],
                "object_id": result_id,
                "region_id": None,
                "frame": "world",
                "transform": transform,
                "z": 0,
                "layer": "main",
            }
        )
        event = self._bundle["event_records"][-1]
        event["inputs"] = [{"type": "version", "object": persistent_id, "revision": source_head}]
        event["outputs"] = [{"type": "version", "object": result_id, "revision": revision["revision_id"]}]
        event["metadata"] = {"evidence_class": "computed", "operation": "derivative", "variable": variable}
        new_workspace = self._commit_workspace(base_workspace_revision, event_id, created_at)
        return {
            "status": "Committed",
            "workspace_revision": new_workspace,
            "source_object_id": persistent_id,
            "source_revision": source_head,
            "result_object_id": result_id,
            "result_revision": revision["revision_id"],
            "evidence_class": "computed",
        }

    def list_candidates(self) -> list[dict[str, Any]]:
        return copy.deepcopy(self._bundle["candidate_records"])

    def propose_relation(
        self,
        *,
        source_id: str,
        predicate: str,
        target: dict[str, Any],
        base_workspace_revision: str,
        actor_type: str = "ai",
        actor_id: str = "agent",
    ) -> dict[str, Any]:
        self._require_base(base_workspace_revision)
        self.object(source_id)
        seed_id, created_at = self._seq.next("candidate-relation")
        candidate_uuid = uuid.uuid5(uuid.NAMESPACE_URL, seed_id + ":candidate")
        candidate_id = f"urn:uuid:{candidate_uuid}"
        candidate = {
            "candidate_id": candidate_id,
            "candidate_type": "relation",
            "payload": {
                "profile": "relation/0.1",
                "source": {"type": "identity", "value": source_id},
                "predicate": predicate,
                "target": copy.deepcopy(target),
                "qualifiers": {},
                "authority": {
                    "class": "derived",
                    "source": actor_type,
                    "rule": "proposal",
                    "confidence": target.get("confidence", "0.5"),
                },
            },
            "authority": "candidate",
            "created_at": created_at,
            "source": {
                "actor": {"type": actor_type, "id": actor_id, "model": None},
                "tool": "eveglyph-mvp",
            },
        }
        self._bundle["candidate_records"].append(candidate)
        return {
            "status": "CandidateRecorded",
            "candidate_id": candidate_id,
            "authoritative": False,
        }

    def promote_candidate(
        self,
        candidate_id: str,
        *,
        base_workspace_revision: str,
        actor_type: str = "human",
        actor_id: str = "local-user",
    ) -> dict[str, Any]:
        self._require_base(base_workspace_revision)
        candidate = next(
            (item for item in self._bundle["candidate_records"] if item["candidate_id"] == candidate_id),
            None,
        )
        if candidate is None or candidate.get("candidate_type") != "relation":
            return {"status": "Unresolved", "reason": "candidate not found"}
        event_id, created_at = self._append_event(
            "promote-candidate",
            base_workspace_revision,
            actor_type=actor_type,
            actor_id=actor_id,
        )
        relation_uuid = uuid.uuid5(uuid.NAMESPACE_URL, event_id + ":relation-target")
        relation_id = f"urn:uuid:{relation_uuid}"
        intrinsic = copy.deepcopy(candidate["payload"])
        intrinsic["authority"] = {
            "class": "explicit",
            "source": actor_type,
            "rule": "promote-candidate",
            "confidence": "1.0",
        }
        revision = {
            "record_type": "revision",
            "persistent_id": relation_id,
            "revision_id": "",
            "kind": "relation",
            "parents": [],
            "content_address": content_address("relation", intrinsic),
            "intrinsic": intrinsic,
            "event_id": event_id,
            "created_at": created_at,
            "metadata": {"promoted_from": candidate_id},
        }
        revision["revision_id"] = revision_address(revision)
        obj = {
            "record_type": "object",
            "persistent_id": relation_id,
            "kind": "relation",
            "status": "active",
            "created_event": event_id,
            "heads": {"main": revision["revision_id"]},
            "aliases": [],
            "metadata": {"promoted_from": candidate_id},
        }
        self._bundle["object_records"].append(obj)
        self._bundle["revision_records"].append(revision)
        self._set_workspace_head(relation_id, revision["revision_id"], relation=True)
        self._bundle["candidate_records"] = [
            item for item in self._bundle["candidate_records"] if item["candidate_id"] != candidate_id
        ]
        event = self._bundle["event_records"][-1]
        event["outputs"] = [{"type": "version", "object": relation_id, "revision": revision["revision_id"]}]
        event["metadata"] = {"candidate_id": candidate_id}
        new_workspace = self._commit_workspace(base_workspace_revision, event_id, created_at)
        return {
            "status": "Committed",
            "workspace_revision": new_workspace,
            "candidate_id": candidate_id,
            "relation_object_id": relation_id,
            "relation_revision": revision["revision_id"],
            "authoritative": True,
        }

    def try_move_object(
        self,
        persistent_id: str,
        *,
        x: str,
        y: str,
        base_workspace_revision: str,
    ) -> dict[str, Any]:
        try:
            return self.move_object(
                persistent_id,
                x=x,
                y=y,
                base_workspace_revision=base_workspace_revision,
            )
        except Conflict as exc:
            return {
                "status": "Conflict",
                "base_workspace_revision": exc.base,
                "current_workspace_revision": exc.current,
            }

    def move_object(
        self,
        persistent_id: str,
        *,
        x: str,
        y: str,
        base_workspace_revision: str,
    ) -> dict[str, Any]:
        self._require_base(base_workspace_revision)
        placement = self.placement_for(persistent_id)
        placement["transform"]["x"] = str(x)
        placement["transform"]["y"] = str(y)
        event_id, created_at = self._append_event("move-object", base_workspace_revision)
        new_revision = self._commit_workspace(base_workspace_revision, event_id, created_at)
        return {"status": "Committed", "workspace_revision": new_revision}

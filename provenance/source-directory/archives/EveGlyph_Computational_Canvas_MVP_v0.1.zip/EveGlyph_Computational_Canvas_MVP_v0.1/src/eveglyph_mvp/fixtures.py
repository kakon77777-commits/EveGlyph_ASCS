from __future__ import annotations

import json
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]
MINIMAL_WORKSPACE = PROJECT_ROOT / "examples" / "minimal_workspace.egir.json"


def load_minimal_workspace() -> dict:
    return json.loads(MINIMAL_WORKSPACE.read_text(encoding="utf-8"))

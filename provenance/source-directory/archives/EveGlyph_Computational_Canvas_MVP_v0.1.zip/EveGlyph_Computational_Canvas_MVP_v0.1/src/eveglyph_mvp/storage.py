from __future__ import annotations

import hashlib
import json
from pathlib import Path

try:
    import brotli
except Exception:
    brotli = None
from typing import Any


class StorageError(RuntimeError):
    def __init__(self, code: str, detail: str = ""):
        super().__init__(f"{code}: {detail}" if detail else code)
        self.code = code
        self.detail = detail


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _manifest_id(manifest: dict[str, Any]) -> str:
    clone = dict(manifest)
    clone["manifest_id"] = ""
    payload = json.dumps(clone, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return "store:sha256:" + _sha256(payload)


def _encode(codec: str, raw: bytes) -> bytes:
    if codec == "identity":
        return raw
    if codec == "brotli":
        if brotli is None:
            raise StorageError("UnsupportedCodec", "brotli dependency unavailable")
        return brotli.compress(raw)
    raise StorageError("UnsupportedCodec", codec)


def _decode(codec: str, encoded: bytes) -> bytes:
    if codec == "identity":
        return encoded
    if codec == "brotli":
        if brotli is None:
            raise StorageError("UnsupportedCodec", "brotli dependency unavailable")
        return brotli.decompress(encoded)
    raise StorageError("UnsupportedCodec", codec)


def _root_bytes(bundle: dict[str, Any]) -> bytes:
    return json.dumps(bundle, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


def pack_store(
    bundle: dict[str, Any],
    directory: str | Path,
    *,
    codec: str = "identity",
    chunk_size: int = 4096,
) -> dict[str, Any]:
    if chunk_size <= 0:
        raise ValueError("chunk_size must be positive")
    directory = Path(directory)
    chunks_dir = directory / "chunks"
    chunks_dir.mkdir(parents=True, exist_ok=True)
    root = _root_bytes(bundle)
    chunks: list[dict[str, Any]] = []
    chunk_ids: list[str] = []
    offset = 0
    for start in range(0, len(root), chunk_size):
        raw = root[start : start + chunk_size]
        decoded_sha = _sha256(raw)
        chunk_id = "chunk:sha256:" + decoded_sha
        encoded = _encode(codec, raw)
        encoded_sha = _sha256(encoded)
        suffix = "bin" if codec == "identity" else f"{codec}.bin"
        locator = f"chunks/{decoded_sha}.{suffix}" if codec != "identity" else f"chunks/{decoded_sha}.bin"
        (directory / locator).write_bytes(encoded)
        chunks.append(
            {
                "chunk_id": chunk_id,
                "logical_offset": offset,
                "decoded_length": len(raw),
                "decoded_sha256": decoded_sha,
                "codec": codec,
                "codec_parameters": {},
                "dictionary_ref": None,
                "encoded_length": len(encoded),
                "encoded_sha256": encoded_sha,
                "locator": locator,
                "crc32c": None,
            }
        )
        chunk_ids.append(chunk_id)
        offset += len(raw)
    manifest: dict[str, Any] = {
        "store_version": "egstore/0.1",
        "manifest_id": "",
        "egir_version": bundle.get("ir_version", ""),
        "root_payload": {
            "name": "workspace.egir.json",
            "media_type": "application/json",
            "decoded_length": len(root),
            "decoded_sha256": _sha256(root),
            "chunk_ids": chunk_ids,
        },
        "chunking": {"profile": "fixed-v1", "parameters": {"chunk_size": chunk_size}},
        "codecs": [
            {
                "id": codec,
                "name": "Identity / raw bytes" if codec == "identity" else codec,
                "required": True,
                "parameters": {},
            }
        ],
        "chunks": chunks,
        "dictionaries": [],
        "indexes": [
            {
                "type": "logical-offset-v1",
                "records": [
                    {
                        "chunk_id": item["chunk_id"],
                        "logical_offset": item["logical_offset"],
                        "decoded_length": item["decoded_length"],
                    }
                    for item in chunks
                ],
            }
        ],
        "limits": {
            "max_decoded_bytes": max(10_485_760, len(root) * 4),
            "max_chunk_count": 10000,
            "max_expansion_ratio": 64.0,
        },
        "generator": {"implementation": "eveglyph-mvp", "version": "0.1"},
        "extensions": {},
    }
    manifest["manifest_id"] = _manifest_id(manifest)
    (directory / "manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    return manifest


def load_store(directory: str | Path) -> dict[str, Any]:
    directory = Path(directory)
    manifest = json.loads((directory / "manifest.json").read_text(encoding="utf-8"))
    if _manifest_id(manifest) != manifest.get("manifest_id"):
        raise StorageError("ManifestHashMismatch")
    chunks_by_id = {item["chunk_id"]: item for item in manifest["chunks"]}
    output: list[bytes] = []
    for chunk_id in manifest["root_payload"]["chunk_ids"]:
        if chunk_id not in chunks_by_id:
            raise StorageError("MissingChunk", chunk_id)
        record = chunks_by_id[chunk_id]
        path = directory / record["locator"]
        if not path.exists():
            raise StorageError("MissingChunk", record["locator"])
        encoded = path.read_bytes()
        if len(encoded) != record["encoded_length"] or _sha256(encoded) != record["encoded_sha256"]:
            raise StorageError("EncodedHashMismatch", record["locator"])
        raw = _decode(record["codec"], encoded)
        if len(raw) != record["decoded_length"] or _sha256(raw) != record["decoded_sha256"]:
            raise StorageError("DecodedHashMismatch", record["locator"])
        if chunk_id != "chunk:sha256:" + _sha256(raw):
            raise StorageError("DecodedHashMismatch", chunk_id)
        output.append(raw)
    root = b"".join(output)
    if len(root) != manifest["root_payload"]["decoded_length"]:
        raise StorageError("RootPayloadHashMismatch", "length")
    if _sha256(root) != manifest["root_payload"]["decoded_sha256"]:
        raise StorageError("RootPayloadHashMismatch", "sha256")
    try:
        return json.loads(root.decode("utf-8"))
    except Exception as exc:
        raise StorageError("EGIRInvalid", str(exc)) from exc


def repack_store(
    source_directory: str | Path,
    target_directory: str | Path,
    *,
    codec: str,
) -> dict[str, Any]:
    source_directory = Path(source_directory)
    source_manifest = json.loads((source_directory / "manifest.json").read_text(encoding="utf-8"))
    chunk_size = int(source_manifest.get("chunking", {}).get("parameters", {}).get("chunk_size", 4096))
    bundle = load_store(source_directory)
    return pack_store(bundle, target_directory, codec=codec, chunk_size=chunk_size)

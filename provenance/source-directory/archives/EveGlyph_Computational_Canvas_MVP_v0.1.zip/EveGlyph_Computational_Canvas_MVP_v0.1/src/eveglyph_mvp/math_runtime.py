from __future__ import annotations

import copy


def differentiate_ncm(intrinsic: dict, variable: str) -> dict:
    """Differentiate the MVP-supported NCM form: one symbol raised to an integer power."""
    result = copy.deepcopy(intrinsic)
    expr = intrinsic["expression"]
    nodes = {node["id"]: node for node in expr["nodes"]}
    root = nodes[expr["root"]]
    if root.get("type") != "apply" or root.get("operator", {}).get("builtin") != "pow":
        raise ValueError("MVP derivative supports power expressions only")
    base = nodes[root["args"][0]]
    exponent = nodes[root["args"][1]]
    if base.get("type") != "symbol" or base.get("name") != variable:
        raise ValueError("MVP derivative variable must match power base")
    if exponent.get("type") != "integer":
        raise ValueError("MVP derivative exponent must be integer")
    n = int(exponent["value"])
    if n < 1:
        raise ValueError("MVP derivative supports positive integer powers only")

    out_nodes = [
        {"id": "d1", "type": "integer", "value": str(n)},
        {"id": "d2", "type": "symbol", "name": variable},
    ]
    if n == 1:
        out_nodes = [{"id": "d1", "type": "integer", "value": "1"}]
        root_id = "d1"
    elif n == 2:
        out_nodes.append(
            {
                "id": "d3",
                "type": "apply",
                "operator": {"builtin": "mul"},
                "args": ["d1", "d2"],
            }
        )
        root_id = "d3"
    else:
        out_nodes.extend(
            [
                {"id": "d3", "type": "integer", "value": str(n - 1)},
                {
                    "id": "d4",
                    "type": "apply",
                    "operator": {"builtin": "pow"},
                    "args": ["d2", "d3"],
                },
                {
                    "id": "d5",
                    "type": "apply",
                    "operator": {"builtin": "mul"},
                    "args": ["d1", "d4"],
                },
            ]
        )
        root_id = "d5"
    result["expression"] = {"root": root_id, "nodes": out_nodes}
    result.setdefault("execution", {})["derived_by"] = "eg-math-core/0.1:derivative"
    return result

from __future__ import annotations

import hashlib
import json
from typing import Any

SAFE_INTEGER = 9007199254740991
CANONICALIZATION = "egir-cj/0.1"


def _canonical_text(value: Any) -> str:
    if value is None:
        return "null"
    if value is True:
        return "true"
    if value is False:
        return "false"
    if isinstance(value, str):
        return json.dumps(value, ensure_ascii=False, separators=(",", ":"))
    if isinstance(value, int):
        if abs(value) > SAFE_INTEGER:
            raise ValueError("unsafe structural integer")
        return str(value)
    if isinstance(value, float):
        raise ValueError("floats forbidden in EGIR-CJ/0.1 hash preimages")
    if isinstance(value, list):
        return "[" + ",".join(_canonical_text(item) for item in value) + "]"
    if isinstance(value, dict):
        return "{" + ",".join(
            _canonical_text(key) + ":" + _canonical_text(value[key])
            for key in sorted(value)
        ) + "}"
    raise TypeError(type(value))


def canonical_bytes(value: Any) -> bytes:
    return _canonical_text(value).encode("utf-8")


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def content_address(kind: str, intrinsic: dict[str, Any]) -> str:
    preimage = {"canon": CANONICALIZATION, "kind": kind, "intrinsic": intrinsic}
    return "content:sha256:" + sha256_hex(canonical_bytes(preimage))


def revision_address(record: dict[str, Any]) -> str:
    preimage = {
        "canon": CANONICALIZATION,
        "persistent_id": record["persistent_id"],
        "kind": record["kind"],
        "parents": sorted(record["parents"]),
        "content_address": record["content_address"],
        "event_id": record["event_id"],
        "created_at": record["created_at"],
    }
    return "rev:sha256:" + sha256_hex(canonical_bytes(preimage))


def workspace_revision_address(workspace: dict[str, Any]) -> str:
    preimage = {
        "canon": CANONICALIZATION,
        "workspace_id": workspace["workspace_id"],
        "parents": sorted(workspace["parents"]),
        "object_heads": sorted(
            workspace["object_heads"],
            key=lambda item: (item["persistent_id"], item["revision"]),
        ),
        "relation_heads": sorted(
            workspace["relation_heads"],
            key=lambda item: (item["persistent_id"], item["revision"]),
        ),
        "placements": sorted(
            workspace["placements"],
            key=lambda item: (
                item["object_id"],
                item.get("region_id") or "",
                item["placement_id"],
            ),
        ),
        "event_id": workspace["event_id"],
        "created_at": workspace["created_at"],
    }
    return "wrev:sha256:" + sha256_hex(canonical_bytes(preimage))

from __future__ import annotations

import argparse
from pathlib import Path

from .fixtures import load_minimal_workspace
from .runtime import WorkspaceRuntime
from .server import create_http_server


def build_default_runtime() -> WorkspaceRuntime:
    return WorkspaceRuntime(load_minimal_workspace())


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Run EveGlyph Computational Canvas MVP v0.1")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8765)
    project_root = Path(__file__).resolve().parents[2]
    parser.add_argument("--web-root", default=str(project_root / "web"))
    parser.add_argument("--store-root", default=str(project_root / "workspace_store"))
    args = parser.parse_args(argv)
    runtime = build_default_runtime()
    server = create_http_server(
        runtime, host=args.host, port=args.port, web_root=args.web_root, store_root=args.store_root
    )
    host, port = server.server_address
    print(f"EveGlyph Computational Canvas MVP running at http://{host}:{port}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

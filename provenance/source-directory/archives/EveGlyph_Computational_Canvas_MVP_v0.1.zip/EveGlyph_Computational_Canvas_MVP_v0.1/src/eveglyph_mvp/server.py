from __future__ import annotations

import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

from .runtime import Conflict, WorkspaceRuntime
from .storage import StorageError, pack_store


def _state_view(runtime: WorkspaceRuntime) -> dict[str, Any]:
    snapshot = runtime.snapshot()
    objects = []
    for obj in snapshot["object_records"]:
        head = obj.get("heads", {}).get("main")
        current = None
        if head:
            try:
                current = runtime.revision(head)
            except KeyError:
                current = None
        objects.append(
            {
                "persistent_id": obj["persistent_id"],
                "kind": obj["kind"],
                "status": obj["status"],
                "head": head,
                "content_address": current.get("content_address") if current else None,
                "intrinsic": current.get("intrinsic") if current else None,
                "aliases": obj.get("aliases", []),
            }
        )
    return {
        "workspace_revision": runtime.workspace_revision,
        "workspace": snapshot["workspace"],
        "objects": objects,
        "candidates": snapshot.get("candidate_records", []),
    }


def _handler_factory(runtime: WorkspaceRuntime, web_root: Path, store_root: Path | None):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, format: str, *args: Any) -> None:
            return

        def _send_json(self, status: int, payload: dict[str, Any]) -> None:
            data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def _read_json(self) -> dict[str, Any]:
            try:
                length = int(self.headers.get("Content-Length", "0"))
            except ValueError:
                length = 0
            raw = self.rfile.read(length) if length else b"{}"
            try:
                data = json.loads(raw.decode("utf-8"))
            except Exception as exc:
                raise ValueError("invalid JSON body") from exc
            if not isinstance(data, dict):
                raise ValueError("JSON body must be an object")
            return data

        def _send_static(self, filename: str, content_type: str) -> None:
            path = web_root / filename
            if not path.exists() or not path.is_file():
                self._send_json(404, {"status": "NotFound"})
                return
            data = path.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(data)

        def do_GET(self) -> None:
            if self.path == "/api/state":
                self._send_json(200, _state_view(runtime))
                return
            static_map = {
                "/": ("index.html", "text/html; charset=utf-8"),
                "/index.html": ("index.html", "text/html; charset=utf-8"),
                "/app.js": ("app.js", "text/javascript; charset=utf-8"),
                "/style.css": ("style.css", "text/css; charset=utf-8"),
            }
            if self.path in static_map:
                filename, content_type = static_map[self.path]
                self._send_static(filename, content_type)
                return
            self._send_json(404, {"status": "NotFound"})

        def do_POST(self) -> None:
            try:
                payload = self._read_json()
                if self.path == "/api/move":
                    result = runtime.move_object(
                        payload["object_id"],
                        x=str(payload["x"]),
                        y=str(payload["y"]),
                        base_workspace_revision=payload["base_workspace_revision"],
                    )
                elif self.path == "/api/edit-power":
                    result = runtime.edit_math_power(
                        payload["object_id"],
                        exponent=str(payload["exponent"]),
                        base_workspace_revision=payload["base_workspace_revision"],
                    )
                elif self.path == "/api/clone":
                    result = runtime.clone_object(
                        payload["object_id"],
                        base_workspace_revision=payload["base_workspace_revision"],
                    )
                elif self.path == "/api/candidate":
                    result = runtime.propose_relation(
                        source_id=payload["source_id"],
                        predicate=payload["predicate"],
                        target=payload["target"],
                        base_workspace_revision=payload["base_workspace_revision"],
                        actor_type=payload.get("actor_type", "ai"),
                        actor_id=payload.get("actor_id", "api-agent"),
                    )
                elif self.path == "/api/promote":
                    result = runtime.promote_candidate(
                        payload["candidate_id"],
                        base_workspace_revision=payload["base_workspace_revision"],
                    )
                elif self.path == "/api/derivative":
                    result = runtime.execute_derivative(
                        payload["object_id"],
                        variable=payload.get("variable", "x"),
                        base_workspace_revision=payload["base_workspace_revision"],
                    )
                elif self.path == "/api/glyph":
                    result = runtime.create_glyph(
                        name=payload["name"],
                        geometry=payload["geometry"],
                        base_workspace_revision=payload["base_workspace_revision"],
                    )
                elif self.path == "/api/glyph-bind":
                    result = runtime.bind_glyph_operator(
                        payload["glyph_id"],
                        operator=payload["operator"],
                        base_workspace_revision=payload["base_workspace_revision"],
                    )
                elif self.path == "/api/glyph-execute":
                    result = runtime.execute_glyph(
                        payload["glyph_id"],
                        math_object_id=payload["math_object_id"],
                        variable=payload.get("variable", "x"),
                        base_workspace_revision=payload["base_workspace_revision"],
                    )
                elif self.path == "/api/save":
                    if store_root is None:
                        self._send_json(400, {"status": "Invalid", "reason": "store root not configured"})
                        return
                    codec = payload.get("codec", "identity")
                    manifest = pack_store(runtime.snapshot(), store_root, codec=codec, chunk_size=4096)
                    self._send_json(200, {
                        "status": "Saved",
                        "codec": codec,
                        "manifest_id": manifest["manifest_id"],
                        "workspace_revision": runtime.workspace_revision,
                    })
                    return
                else:
                    self._send_json(404, {"status": "NotFound"})
                    return
                self._send_json(200, result)
                return
            except Conflict as exc:
                self._send_json(
                    409,
                    {
                        "status": "Conflict",
                        "base_workspace_revision": exc.base,
                        "current_workspace_revision": exc.current,
                    },
                )
            except StorageError as exc:
                self._send_json(400, {"status": exc.code, "reason": exc.detail})
            except (KeyError, ValueError, TypeError) as exc:
                self._send_json(400, {"status": "Invalid", "reason": str(exc)})

    return Handler


def create_http_server(
    runtime: WorkspaceRuntime,
    *,
    host: str = "127.0.0.1",
    port: int = 8765,
    web_root: str | Path = ".",
    store_root: str | Path | None = None,
) -> ThreadingHTTPServer:
    root = Path(web_root)
    storage_root = Path(store_root) if store_root is not None else None
    return ThreadingHTTPServer((host, port), _handler_factory(runtime, root, storage_root))

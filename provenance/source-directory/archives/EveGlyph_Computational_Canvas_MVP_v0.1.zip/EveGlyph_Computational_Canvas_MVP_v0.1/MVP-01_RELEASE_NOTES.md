# MVP-01 Release Notes — EveGlyph Computational Canvas v0.1

## Scope

MVP-01 是 ASCS v0.1 architecture/specification phase 之後的第一個 implementation evidence package。

## Core vertical slice

$$
\text{EGStore}
\rightarrow
\text{EGIR}
\rightarrow
\text{Canvas}
\rightarrow
\text{Transaction}
\rightarrow
\text{Native Math}
\rightarrow
\text{Glyph Binding}
\rightarrow
\text{Candidate / Promotion}
\rightarrow
\text{Persist / Rehydrate}.
$$

## Design decision carried forward

MVP 不修改 UTF-8、不以 LaTeX 作 native math ontology、不以畫面座標作 identity、不以 content hash 作 persistent identity，也不允許 AI candidate 自動成為 canonical authority。

## Production handoff direction

下一次正式升級應以此 MVP 為可執行 contract，而不是重新從聊天重建概念；重點是將 reference runtime 逐步移入現有 `eveglyph-editor`，並替換 deterministic test-only ID policy、擴張 NCM、接入 GSC、加入正式 spatial grammar、sandbox、collaboration 與 richer EGStore profiles。

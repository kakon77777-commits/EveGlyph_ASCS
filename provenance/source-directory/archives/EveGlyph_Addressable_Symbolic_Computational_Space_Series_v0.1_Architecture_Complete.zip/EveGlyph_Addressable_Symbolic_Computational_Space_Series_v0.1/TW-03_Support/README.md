# TW-03 Support Artifacts

This directory contains a deliberately small deterministic runtime model for the TW-03 architecture specification. It is **not** the EveGlyph MVP and does not provide a user interface, network service, production sandbox, CAS, or distributed collaboration layer.

Files:

- `schemas/eveglyph-runtime-trace.schema.json` — trace schema for the reference runtime.
- `conformance/tw03_vectors.json` — deterministic command sequence and expected semantic properties.
- `examples/runtime_trace.json` — packaged trace generated from the reference run.
- `examples/runtime_final.egir.json` — final EGIR bundle after the reference transactions.
- `tools/reference_runtime.py` — pure transactional state-machine model over the TW-01 minimal workspace.
- `tools/validate_tw03.py` — conformance runner.

Run from anywhere:

```bash
python TW-03_Support/tools/validate_tw03.py
```

The validator checks, among other things, that session/view/cache state is non-canonical, movement preserves object revision and execution graph, stale writes conflict instead of silently overwriting, AI output remains candidate-level until explicit promotion, native math execution creates a new result identity with provenance, capabilities gate execution, old revisions remain resolvable, runtime rehydration is stable, and the final bundle still passes TW-01 object/revision/workspace hash semantics.

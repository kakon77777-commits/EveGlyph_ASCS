#!/usr/bin/env python3
"""Deterministic reference state machine for TW-03.

This is a conformance model, not the MVP/product runtime. It intentionally implements
only the small transaction slice needed to test the TW-03 authority and identity rules.
"""
from __future__ import annotations

from copy import deepcopy
from pathlib import Path
import hashlib
import importlib.util
import json
from typing import Any, Dict, List, Set

HERE = Path(__file__).resolve()
SERIES = HERE.parents[2]
TW01_VALIDATOR = SERIES / "TW-01_Support" / "tools" / "validate_tw01.py"
MINIMAL = SERIES / "TW-01_Support" / "examples" / "minimal_workspace.egir.json"

spec = importlib.util.spec_from_file_location("tw01v", TW01_VALIDATOR)
tw01v = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(tw01v)


def _sha(obj: Any) -> str:
    return hashlib.sha256(tw01v.canonicalize(obj).encode("utf-8")).hexdigest()


def _addr_identity(pid: str) -> Dict[str, Any]:
    return {"type": "identity", "value": pid}


def _addr_version(pid: str, rid: str) -> Dict[str, Any]:
    return {"type": "version", "object": pid, "revision": rid}


def _event(event_id: str, actor: Dict[str, Any], op: str, inputs: List[Dict[str, Any]], outputs: List[Dict[str, Any]],
           base: str | None, created_at: str, policy: Dict[str, Any] | None = None,
           metadata: Dict[str, Any] | None = None) -> Dict[str, Any]:
    return {
        "record_type": "event",
        "event_id": event_id,
        "actor": actor,
        "op": op,
        "inputs": inputs,
        "outputs": outputs,
        "base_workspace_revision": base,
        "tool": {"name": "tw03-reference-runtime", "version": "0.1"},
        "policy": policy or {},
        "created_at": created_at,
        "metadata": metadata or {},
    }


class RuntimeSession:
    """Minimal transactional runtime over one EGIR workspace bundle."""

    def __init__(self, bundle: Dict[str, Any], capabilities: Set[str] | None = None):
        self.bundle = deepcopy(bundle)
        self.capabilities: Set[str] = set(capabilities or {
            "resolve", "workspace.write", "object.write", "candidate.write",
            "relation.promote", "runtime.execute", "agent.propose"
        })
        self.trace: List[Dict[str, Any]] = []
        self.session_overlay: Dict[str, Any] = {
            "viewport": {"x": "0.0", "y": "0.0", "zoom": "1.0"},
            "selection": [],
            "transient_drag": None,
        }
        self.derived_cache: Dict[str, Any] = {}

    @classmethod
    def from_minimal(cls, capabilities: Set[str] | None = None) -> "RuntimeSession":
        return cls(json.loads(MINIMAL.read_text(encoding="utf-8")), capabilities)

    @property
    def workspace_revision(self) -> str:
        return self.bundle["workspace"]["workspace_revision"]

    def _objects(self) -> Dict[str, Dict[str, Any]]:
        return {o["persistent_id"]: o for o in self.bundle["object_records"]}

    def _revisions(self) -> Dict[str, Dict[str, Any]]:
        return {r["revision_id"]: r for r in self.bundle["revision_records"]}

    def _record(self, command: Dict[str, Any], result: Dict[str, Any], before: str, after: str) -> Dict[str, Any]:
        row = {
            "command_id": command["command_id"],
            "command_type": command["type"],
            "before_workspace_revision": before,
            "after_workspace_revision": after,
            "status": result["status"],
            "result": result,
        }
        self.trace.append(row)
        return result

    def _deny(self, command: Dict[str, Any], capability: str, before: str) -> Dict[str, Any]:
        return self._record(command, {
            "status": "Unauthorized",
            "required_capability": capability,
        }, before, before)

    def _conflict(self, command: Dict[str, Any], before: str) -> Dict[str, Any]:
        return self._record(command, {
            "status": "Conflict",
            "expected_base": before,
            "supplied_base": command.get("base_workspace_revision"),
        }, before, before)

    def _check_write(self, command: Dict[str, Any], capability: str, before: str) -> Dict[str, Any] | None:
        if capability not in self.capabilities:
            return self._deny(command, capability, before)
        if command.get("base_workspace_revision") != before:
            return self._conflict(command, before)
        return None

    def _replace_head(self, bucket: str, pid: str, rid: str) -> None:
        heads = self.bundle["workspace"][bucket]
        for h in heads:
            if h["persistent_id"] == pid:
                h["revision"] = rid
                return
        heads.append({"persistent_id": pid, "revision": rid})

    def _commit_workspace(self, previous: str, event_id: str, created_at: str) -> str:
        w = self.bundle["workspace"]
        w["parents"] = [previous]
        w["event_id"] = event_id
        w["created_at"] = created_at
        w["workspace_revision"] = tw01v.workspace_rev(w)
        return w["workspace_revision"]

    def execution_graph_hash(self) -> str:
        revs = self._revisions()
        executable = []
        for h in self.bundle["workspace"]["relation_heads"]:
            r = revs[h["revision"]]
            i = r.get("intrinsic", {})
            if i.get("profile") == "relation/0.1" and i.get("authority", {}).get("class") == "explicit":
                if i.get("predicate") in {"eg:dependsOn", "eg:dataflow", "eg:bindsOperator"}:
                    executable.append({
                        "persistent_id": h["persistent_id"],
                        "revision": h["revision"],
                        "predicate": i.get("predicate"),
                        "source": i.get("source"),
                        "target": i.get("target"),
                    })
        executable.sort(key=lambda x: (x["persistent_id"], x["revision"]))
        return "execgraph:sha256:" + _sha({"profile": "eg-execgraph/0.1", "edges": executable})

    def resolve(self, command: Dict[str, Any]) -> Dict[str, Any]:
        before = self.workspace_revision
        if "resolve" not in self.capabilities:
            return self._deny(command, "resolve", before)
        ref = command["payload"]["ref"]
        if ref["type"] == "identity":
            obj = self._objects().get(ref["value"])
            result = {"status": "Resolved", "target": _addr_identity(obj["persistent_id"])} if obj else {"status": "Unresolved"}
        elif ref["type"] == "version":
            r = self._revisions().get(ref["revision"])
            result = {"status": "Resolved", "target": ref} if r and r["persistent_id"] == ref["object"] else {"status": "Unresolved"}
        else:
            result = {"status": "Invalid", "reason": "reference type not implemented by conformance runtime"}
        return self._record(command, result, before, before)

    def move(self, command: Dict[str, Any]) -> Dict[str, Any]:
        before = self.workspace_revision
        blocked = self._check_write(command, "workspace.write", before)
        if blocked: return blocked
        pid = command["payload"]["object_id"]
        target = None
        for p in self.bundle["workspace"]["placements"]:
            if p["object_id"] == pid:
                target = p; break
        if target is None:
            return self._record(command, {"status": "Unresolved", "reason": "placement not found"}, before, before)
        rev_before = next(h["revision"] for h in self.bundle["workspace"]["object_heads"] if h["persistent_id"] == pid)
        exec_before = self.execution_graph_hash()
        target["transform"].update(command["payload"]["transform"])
        ev = _event(command["event_id"], command["actor"], "move-object", [_addr_identity(pid)], [], before, command["created_at"],
                    {"authority": "explicit"}, {"placement_only": True})
        self.bundle["event_records"].append(ev)
        after = self._commit_workspace(before, command["event_id"], command["created_at"])
        rev_after = next(h["revision"] for h in self.bundle["workspace"]["object_heads"] if h["persistent_id"] == pid)
        exec_after = self.execution_graph_hash()
        return self._record(command, {
            "status": "Committed",
            "object_revision_before": rev_before,
            "object_revision_after": rev_after,
            "execution_graph_before": exec_before,
            "execution_graph_after": exec_after,
            "placement_only": True,
        }, before, after)

    def edit_math_integer(self, command: Dict[str, Any]) -> Dict[str, Any]:
        before = self.workspace_revision
        blocked = self._check_write(command, "object.write", before)
        if blocked: return blocked
        pid = command["payload"]["object_id"]
        obj = self._objects().get(pid)
        if not obj or obj["kind"] != "math":
            return self._record(command, {"status": "Unresolved"}, before, before)
        old_rid = obj["heads"]["main"]
        old = self._revisions()[old_rid]
        intrinsic = deepcopy(old["intrinsic"])
        node_id = command["payload"]["node_id"]
        new_value = command["payload"]["value"]
        found = False
        for n in intrinsic["expression"]["nodes"]:
            if n["id"] == node_id and n["type"] == "integer":
                n["value"] = new_value; found = True; break
        if not found:
            return self._record(command, {"status": "Invalid", "reason": "integer node not found"}, before, before)
        ca = tw01v.content_addr("math", intrinsic)
        nr = {
            "record_type": "revision", "persistent_id": pid, "revision_id": "", "kind": "math",
            "parents": [old_rid], "content_address": ca, "intrinsic": intrinsic,
            "event_id": command["event_id"], "created_at": command["created_at"], "metadata": {}
        }
        nr["revision_id"] = tw01v.revision_id(nr)
        self.bundle["revision_records"].append(nr)
        obj["heads"]["main"] = nr["revision_id"]
        self._replace_head("object_heads", pid, nr["revision_id"])
        ev = _event(command["event_id"], command["actor"], "edit-object",
                    [_addr_version(pid, old_rid)], [_addr_version(pid, nr["revision_id"])], before, command["created_at"],
                    {"authority": "explicit"})
        self.bundle["event_records"].append(ev)
        after = self._commit_workspace(before, command["event_id"], command["created_at"])
        return self._record(command, {
            "status": "Committed", "persistent_id": pid,
            "old_revision": old_rid, "new_revision": nr["revision_id"],
            "old_content_address": old["content_address"], "new_content_address": ca,
        }, before, after)

    def agent_proposal(self, command: Dict[str, Any]) -> Dict[str, Any]:
        before = self.workspace_revision
        if "agent.propose" not in self.capabilities:
            return self._deny(command, "agent.propose", before)
        if "candidate.write" not in self.capabilities:
            return self._deny(command, "candidate.write", before)
        c = {
            "candidate_id": command["payload"]["candidate_id"],
            "candidate_type": command["payload"]["candidate_type"],
            "payload": deepcopy(command["payload"]["candidate_payload"]),
            "authority": "candidate",
            "created_at": command["created_at"],
            "source": {"actor": command["actor"], "tool": "tw03-reference-runtime"},
        }
        self.bundle["candidate_records"].append(c)
        return self._record(command, {
            "status": "CandidateRecorded", "candidate_id": c["candidate_id"],
            "authoritative": False,
        }, before, before)

    def promote_relation(self, command: Dict[str, Any]) -> Dict[str, Any]:
        before = self.workspace_revision
        blocked = self._check_write(command, "relation.promote", before)
        if blocked: return blocked
        cid = command["payload"]["candidate_id"]
        cand = next((c for c in self.bundle["candidate_records"] if c["candidate_id"] == cid), None)
        if not cand or cand["candidate_type"] != "relation":
            return self._record(command, {"status": "Unresolved", "reason": "candidate not found"}, before, before)
        pid = command["payload"]["relation_object_id"]
        intrinsic = deepcopy(cand["payload"])
        intrinsic.setdefault("profile", "relation/0.1")
        intrinsic["authority"] = {"class": "explicit", "source": command["actor"]["type"], "rule": "promote-candidate", "confidence": "1.0"}
        ca = tw01v.content_addr("relation", intrinsic)
        rr = {
            "record_type": "revision", "persistent_id": pid, "revision_id": "", "kind": "relation", "parents": [],
            "content_address": ca, "intrinsic": intrinsic, "event_id": command["event_id"],
            "created_at": command["created_at"], "metadata": {"promoted_from": cid}
        }
        rr["revision_id"] = tw01v.revision_id(rr)
        obj = {
            "record_type": "object", "persistent_id": pid, "kind": "relation", "status": "active",
            "created_event": command["event_id"], "heads": {"main": rr["revision_id"]}, "aliases": [], "metadata": {}
        }
        self.bundle["object_records"].append(obj)
        self.bundle["revision_records"].append(rr)
        self._replace_head("relation_heads", pid, rr["revision_id"])
        ev = _event(command["event_id"], command["actor"], "promote-candidate",
                    [], [_addr_version(pid, rr["revision_id"])], before, command["created_at"],
                    {"authority": "explicit"}, {"candidate_id": cid})
        self.bundle["event_records"].append(ev)
        after = self._commit_workspace(before, command["event_id"], command["created_at"])
        return self._record(command, {
            "status": "Committed", "candidate_id": cid,
            "relation_object_id": pid, "relation_revision": rr["revision_id"],
            "authoritative": True,
        }, before, after)

    def execute_derivative(self, command: Dict[str, Any]) -> Dict[str, Any]:
        before = self.workspace_revision
        blocked = self._check_write(command, "runtime.execute", before)
        if blocked: return blocked
        src_pid = command["payload"]["object_id"]
        src_obj = self._objects().get(src_pid)
        if not src_obj or src_obj["kind"] != "math":
            return self._record(command, {"status": "Unresolved"}, before, before)
        src_rid = src_obj["heads"]["main"]
        src = self._revisions()[src_rid]
        # Conformance core intentionally supports x^n only.
        nodes = {n["id"]: n for n in src["intrinsic"]["expression"]["nodes"]}
        root = nodes[src["intrinsic"]["expression"]["root"]]
        if root.get("type") != "apply" or root.get("operator", {}).get("builtin") != "pow" or len(root.get("args", [])) != 2:
            return self._record(command, {"status": "Unsupported", "reason": "reference core supports pow(symbol,integer) only"}, before, before)
        sym = nodes[root["args"][0]]; exp = nodes[root["args"][1]]
        if sym.get("type") != "symbol" or exp.get("type") != "integer":
            return self._record(command, {"status": "Unsupported"}, before, before)
        n = int(exp["value"])
        if n < 1:
            return self._record(command, {"status": "Unsupported"}, before, before)
        result_pid = command["payload"]["result_object_id"]
        if n == 1:
            out_nodes = [{"id": "r1", "type": "integer", "value": "1"}]; root_id = "r1"
        else:
            out_nodes = [
                {"id": "r1", "type": "integer", "value": str(n)},
                {"id": "r2", "type": "symbol", "name": sym["name"]},
                {"id": "r3", "type": "integer", "value": str(n-1)},
                {"id": "r4", "type": "apply", "operator": {"builtin": "pow"}, "args": ["r2", "r3"]},
                {"id": "r5", "type": "apply", "operator": {"builtin": "mul"}, "args": ["r1", "r4"]},
            ]; root_id = "r5"
        intrinsic = {
            "profile": "ncm/0.1",
            "expression": {"root": root_id, "nodes": out_nodes},
            "bindings": [], "type_info": deepcopy(src["intrinsic"].get("type_info", {})),
            "assumptions": deepcopy(src["intrinsic"].get("assumptions", [])),
            "constraints": deepcopy(src["intrinsic"].get("constraints", [])),
            "units": deepcopy(src["intrinsic"].get("units", {})),
            "numeric_policy": {"mode": "exact"},
            "presentation": {"preferred": "traditional"},
            "execution": {"operator_set": "eg-math-core/0.1"},
        }
        ca = tw01v.content_addr("math", intrinsic)
        rr = {
            "record_type": "revision", "persistent_id": result_pid, "revision_id": "", "kind": "math", "parents": [],
            "content_address": ca, "intrinsic": intrinsic, "event_id": command["event_id"],
            "created_at": command["created_at"],
            "metadata": {"evidence_class": "computed", "derived_from": _addr_version(src_pid, src_rid), "backend": "eg-math-core/0.1"}
        }
        rr["revision_id"] = tw01v.revision_id(rr)
        obj = {
            "record_type": "object", "persistent_id": result_pid, "kind": "math", "status": "active",
            "created_event": command["event_id"], "heads": {"main": rr["revision_id"]}, "aliases": [], "metadata": {}
        }
        self.bundle["object_records"].append(obj); self.bundle["revision_records"].append(rr)
        self._replace_head("object_heads", result_pid, rr["revision_id"])
        ev = _event(command["event_id"], command["actor"], "execute-native-math",
                    [_addr_version(src_pid, src_rid)], [_addr_version(result_pid, rr["revision_id"])], before, command["created_at"],
                    {"capability": "runtime.execute", "backend": "eg-math-core/0.1"},
                    {"evidence_class": "computed", "conditions": [], "deterministic": True})
        self.bundle["event_records"].append(ev)
        after = self._commit_workspace(before, command["event_id"], command["created_at"])
        return self._record(command, {
            "status": "Committed", "result_object_id": result_pid, "result_revision": rr["revision_id"],
            "source_revision": src_rid, "evidence_class": "computed", "backend": "eg-math-core/0.1"
        }, before, after)

    def apply(self, command: Dict[str, Any]) -> Dict[str, Any]:
        dispatch = {
            "resolve": self.resolve,
            "move": self.move,
            "edit-math-integer": self.edit_math_integer,
            "agent-proposal": self.agent_proposal,
            "promote-relation": self.promote_relation,
            "execute-derivative": self.execute_derivative,
        }
        fn = dispatch.get(command["type"])
        before = self.workspace_revision
        if fn is None:
            return self._record(command, {"status": "Invalid", "reason": "unknown command"}, before, before)
        return fn(command)

    def write_bundle(self, path: Path) -> None:
        path.write_text(json.dumps(self.bundle, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")

    def write_trace(self, path: Path) -> None:
        payload = {
            "runtime_profile": "eveglyph-runtime/0.1",
            "trace_profile": "tw03-trace/0.1",
            "entries": self.trace,
            "final_workspace_revision": self.workspace_revision,
            "final_execution_graph": self.execution_graph_hash(),
        }
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")


if __name__ == "__main__":
    print("TW-03 reference runtime is a library; run validate_tw03.py for conformance.")

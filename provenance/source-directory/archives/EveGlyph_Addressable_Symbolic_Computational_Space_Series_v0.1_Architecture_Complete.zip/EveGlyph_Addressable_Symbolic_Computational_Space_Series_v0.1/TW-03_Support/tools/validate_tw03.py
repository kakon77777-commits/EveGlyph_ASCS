#!/usr/bin/env python3
from pathlib import Path
import importlib.util
import json
from copy import deepcopy
from jsonschema import Draft202012Validator, FormatChecker

ROOT = Path(__file__).resolve().parents[1]
SERIES = ROOT.parent
VECTORS = ROOT / "conformance" / "tw03_vectors.json"
TRACE_SCHEMA = ROOT / "schemas" / "eveglyph-runtime-trace.schema.json"
TRACE_EXAMPLE = ROOT / "examples" / "runtime_trace.json"
FINAL_EXAMPLE = ROOT / "examples" / "runtime_final.egir.json"
TW01_SCHEMA = SERIES / "TW-01_Support" / "schemas" / "eveglyph-ir.schema.json"
TW01_VALIDATOR = SERIES / "TW-01_Support" / "tools" / "validate_tw01.py"
RUNTIME = ROOT / "tools" / "reference_runtime.py"


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(mod)
    return mod


tw01 = load_module("tw01v", TW01_VALIDATOR)
rt = load_module("tw03rt", RUNTIME)


def validate_tw01_bundle(data):
    schema = json.loads(TW01_SCHEMA.read_text(encoding="utf-8"))
    errors = sorted(Draft202012Validator(schema, format_checker=FormatChecker()).iter_errors(data), key=lambda e: list(e.path))
    if errors:
        raise AssertionError("TW-01 schema: " + "; ".join(f"{list(e.path)} {e.message}" for e in errors[:5]))
    objects = {o["persistent_id"]: o for o in data["object_records"]}
    revisions = {r["revision_id"]: r for r in data["revision_records"]}
    for o in data["object_records"]:
        for rid in o["heads"].values():
            assert rid in revisions and revisions[rid]["persistent_id"] == o["persistent_id"]
    for r in data["revision_records"]:
        assert r["persistent_id"] in objects
        for parent in r["parents"]:
            assert parent in revisions
        assert tw01.content_addr(r["kind"], r["intrinsic"]) == r["content_address"]
        assert tw01.revision_id(r) == r["revision_id"]
    for h in data["workspace"]["object_heads"] + data["workspace"]["relation_heads"]:
        assert h["persistent_id"] in objects and h["revision"] in revisions
    for p in data["workspace"]["placements"]:
        assert p["object_id"] in objects
    assert tw01.workspace_rev(data["workspace"]) == data["workspace"]["workspace_revision"]


def main():
    vectors = json.loads(VECTORS.read_text(encoding="utf-8"))
    session = rt.RuntimeSession.from_minimal()
    assert session.workspace_revision == vectors["initial_workspace_revision"]

    # Session overlay and derived cache are explicitly non-canonical.
    w0 = session.workspace_revision
    session.session_overlay["viewport"]["zoom"] = "2.0"
    session.derived_cache["semantic-index"] = {"status": "warm"}
    assert session.workspace_revision == w0
    print("PASS: session overlay/cache non-authority")

    for item in vectors["commands"]:
        command = item["command"]
        expect = item["expect"]
        before = session.workspace_revision
        exec_before = session.execution_graph_hash()
        result = session.apply(deepcopy(command))
        after = session.workspace_revision
        assert result["status"] == expect["status"], (command["type"], result, expect)
        if expect.get("workspace_unchanged"):
            assert after == before
        if expect.get("workspace_changed"):
            assert after != before
        if expect.get("object_revision_unchanged"):
            assert result["object_revision_before"] == result["object_revision_after"]
        if expect.get("execution_graph_unchanged"):
            assert result["execution_graph_before"] == result["execution_graph_after"] == exec_before
        if "authoritative" in expect:
            assert result["authoritative"] is expect["authoritative"]
        if expect.get("identity_unchanged"):
            assert result["persistent_id"] == command["payload"]["object_id"]
        if expect.get("content_changed"):
            assert result["old_content_address"] != result["new_content_address"]
        if expect.get("revision_changed"):
            assert result["old_revision"] != result["new_revision"]
        if "evidence_class" in expect:
            assert result["evidence_class"] == expect["evidence_class"]
        print("PASS:", command["type"], result["status"])

    assert session.workspace_revision == vectors["final_workspace_revision"]
    assert session.execution_graph_hash() == vectors["final_execution_graph"]

    # Candidate remains candidate in bundle even after promotion; promotion creates a new authoritative relation revision.
    assert any(c["authority"] == "candidate" for c in session.bundle["candidate_records"])
    promoted = [r for r in session.bundle["revision_records"] if r.get("metadata", {}).get("promoted_from")]
    assert promoted and promoted[-1]["intrinsic"]["authority"]["class"] == "explicit"
    print("PASS: candidate/promotion authority boundary")

    # Execution result is a new identity and carries computation provenance.
    result_objs = [o for o in session.bundle["object_records"] if o["persistent_id"].startswith("urn:uuid:0190b003-4006")]
    assert len(result_objs) == 1
    result_rev = session._revisions()[result_objs[0]["heads"]["main"]]
    assert result_rev["metadata"]["evidence_class"] == "computed"
    assert result_rev["metadata"]["backend"] == "eg-math-core/0.1"
    print("PASS: native execution result/provenance")

    # Restricted runtime: identity resolution succeeds, execution capability is denied with no mutation.
    r = vectors["restricted_execution"]
    restricted = rt.RuntimeSession.from_minimal(set(r["capabilities"]))
    before = restricted.workspace_revision
    denied = restricted.apply(deepcopy(r["command"]))
    assert denied["status"] == r["expect"]["status"]
    assert denied["required_capability"] == r["expect"]["required_capability"]
    assert restricted.workspace_revision == before
    print("PASS: capability denial non-mutation")

    # Full final bundle must remain a valid TW-01 bundle after runtime commits.
    validate_tw01_bundle(session.bundle)
    print("PASS: final bundle TW-01 conformance")

    # Serialize/rehydrate must preserve canonical identities and execution-graph derivation.
    roundtrip = json.loads(json.dumps(session.bundle, ensure_ascii=False))
    rehydrated = rt.RuntimeSession(roundtrip)
    assert rehydrated.workspace_revision == session.workspace_revision
    assert rehydrated.execution_graph_hash() == session.execution_graph_hash()
    validate_tw01_bundle(rehydrated.bundle)
    print("PASS: runtime rehydrate")

    # Packaged examples must exactly equal the reference run.
    packaged_final = json.loads(FINAL_EXAMPLE.read_text(encoding="utf-8"))
    assert packaged_final == session.bundle
    trace = json.loads(TRACE_EXAMPLE.read_text(encoding="utf-8"))
    trace_schema = json.loads(TRACE_SCHEMA.read_text(encoding="utf-8"))
    errors = list(Draft202012Validator(trace_schema).iter_errors(trace))
    assert not errors, errors
    assert trace["entries"] == session.trace
    assert trace["final_workspace_revision"] == session.workspace_revision
    assert trace["final_execution_graph"] == session.execution_graph_hash()
    print("PASS: packaged trace/schema")

    print("PASS: TW-03 deterministic runtime conformance")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

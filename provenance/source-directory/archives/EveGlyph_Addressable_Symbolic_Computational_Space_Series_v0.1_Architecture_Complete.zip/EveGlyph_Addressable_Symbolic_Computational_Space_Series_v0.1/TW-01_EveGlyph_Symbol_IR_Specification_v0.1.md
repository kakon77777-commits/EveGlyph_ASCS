# TW-01｜EveGlyph Symbol IR Specification v0.1

**English Title:** EveGlyph Symbol IR Specification v0.1: Canonical Object, Revision, Relation, Address, Spatial, Mathematical, Glyph, and Provenance Records

**作者：** Neo.K  
**機構：** EveMissLab / 一言諾科技有限公司  
**版本：** v0.1  
**日期：** 2026-08-24  
**文件類型：** 技術白皮書 / Normative Technical Specification  
**系列定位：** EveGlyph Addressable Symbolic Computational Space Series — TW-01  
**前置理論錨點：** Paper 00–05 ASCS v0.1 Core Theory Freeze

---

## Canonical Source Note

本文件以 UTF-8 Markdown 保存正式規格原稿，數學 source 僅使用 `$...$` 與 `$$...$$` 作為 canonical delimiter。

本白皮書第一次把 Paper 00–05 的形式化決策壓成可實作規格。與前六篇論文不同，本文件使用 **MUST / MUST NOT / SHOULD / SHOULD NOT / MAY** 表示規範強度。這些詞只在全大寫時具有規範性。

本文件定義 **EveGlyph Symbol IR，縮寫 EGIR**。v0.1 的 portable canonical carrier 是 UTF-8 JSON；JSON Schema Draft 2020-12 用於結構驗證；hash preimage 使用 `EGIR-CJ/0.1` deterministic canonicalization。未來 TW-02 可以新增 CBOR、UTF-8X region carrier 或其他 binary representation，但不得改變本文定義的 abstract IR semantics。

因此：

$$
\text{EGIR abstract model}
\neq
\text{JSON surface}
\neq
\text{storage carrier}.
$$

---

# 1. 規格目標

TW-01 的目標不是設計完整 EveGlyph UI，也不是把所有未來 object kind 一次凍死；它要提供一個最小但足夠穩定的 **canonical object contract**，使 Paper 00–05 的不變量可以被程式驗證。

v0.1 必須支援：

1. persistent object identity；
2. immutable revision records；
3. content addressing；
4. revision DAG；
5. first-class relations；
6. workspace placement 與 spatial state；
7. multi-layer address references；
8. event/provenance records；
9. native math profile；
10. glyph profile；
11. candidate/authority separation；
12. deterministic canonicalization；
13. import/export adapter metadata；
14. schema evolution 與 extension preservation。

EGIR v0.1 明確不處理完整網路 federation、distributed consensus、CRDT、GPU renderer、CAS backend、font engine 或 UTF-8X storage layout；這些留給 TW-02/TW-03。

---

# 2. Conformance Classes

實作者可宣告三種 conformance class。

## 2.1 Reader

Reader MUST：

- 解析 UTF-8 JSON EGIR bundle；
- 驗證 `ir_version`；
- 拒絕 duplicate JSON object keys；
- 驗證 core schema；
- 保留未知 extension fields/records；
- 不把未知 executable binding 自動執行；
- 能辨識 typed addresses 與 typed failure/candidate states。

## 2.2 Writer

Writer 除 Reader 要求外 MUST：

- 生成合法 persistent IDs；
- 生成 deterministic content/revision addresses；
- 生成 provenance event；
- 將 placement 與 intrinsic state 分離；
- 不把 candidate relations 寫成 explicit relations；
- 保留 parent revision DAG；
- 使用 canonical UTF-8 source output。

## 2.3 Runtime

Runtime 除 Writer 要求外 MUST：

- 驗證 execution binding；
- 在執行前做 policy/permission check；
- 產生 execution provenance；
- 不以 visual projection equality 判定 semantic identity；
- 不以 AI suggestion 直接完成 high-authority identity merge。

---

# 3. EGIR Bundle

v0.1 的交換單位稱為 **bundle**：

```json
{
  "ir_version": "egir/0.1",
  "bundle_kind": "workspace-snapshot",
  "workspace": {},
  "object_records": [],
  "revision_records": [],
  "event_records": [],
  "candidate_records": [],
  "extensions": {}
}
```

`bundle_kind` v0.1 定義：

- `workspace-snapshot`：完整 workspace state；
- `fragment`：部分 object/revision graph；
- `object-pack`：一組可匯入 objects 與 lineage。

bundle 是 carrier unit，不是 object identity。

$$
\text{Bundle identity}
\neq
\text{Object identity}.
$$

---

# 4. Persistent Identity

## 4.1 新 object 的預設格式

EGIR v0.1 新建 persistent identities SHOULD 使用 RFC 9562 UUIDv7，並以 lowercase UUID URN 表示：

```text
urn:uuid:0190a001-1111-7abc-8def-111111111111
```

新 writer SHOULD 使用 UUIDv7，因其時間排序特性有利於 local-first event/object store；reader MUST NOT 依時間順序推論 causality。

## 4.2 Legacy identity

Reader MAY 接受從舊系統導入的其他 identity schemes，但轉入 canonical EGIR 時 MUST 以明確 adapter record 保存來源，不得把 display name 當 persistent identity。

## 4.3 Identity invariants

對 persistent object $O_i$：

$$
A^{id}(O_i)=i.
$$

`i` MUST NOT 因 edit、move、rerender、storage migration、alias rename 改變。

Tombstoned identity MUST NOT 被重用。

---

# 5. Object Record

Object record 描述 persistent lineage，而不是某一版內容：

```json
{
  "record_type": "object",
  "persistent_id": "urn:uuid:...",
  "kind": "math",
  "status": "active",
  "created_event": "urn:uuid:...",
  "heads": {
    "main": "rev:sha256:..."
  },
  "aliases": [],
  "metadata": {}
}
```

## 5.1 `kind`

v0.1 保留以下 built-in kinds：

- `text`；
- `math`；
- `code`；
- `glyph`；
- `data`；
- `operator`；
- `region`；
- `relation`；
- `media-ref`；
- `external-ref`；
- `composite`。

Reader MUST preserve unknown kinds。Runtime MUST NOT execute unknown kinds without explicit extension support。

## 5.2 `heads`

`heads` 是 branch-name 到 immutable revision address 的 mapping。

同一 object MAY 同時存在：

```json
{
  "main": "rev:sha256:...",
  "agent-a": "rev:sha256:...",
  "agent-b": "rev:sha256:..."
}
```

因此 branch divergence 是合法 canonical state。

---

# 6. Revision Record

Revision record 描述 immutable object state：

```json
{
  "record_type": "revision",
  "persistent_id": "urn:uuid:...",
  "revision_id": "rev:sha256:...",
  "kind": "math",
  "parents": [],
  "content_address": "content:sha256:...",
  "intrinsic": {},
  "event_id": "urn:uuid:...",
  "created_at": "2026-08-24T10:30:00.000Z",
  "metadata": {}
}
```

## 6.1 Immutable contract

一旦 commit，revision record 的 hash-covered fields MUST NOT 被修改。

需要改動時 MUST 產生新 revision：

$$
v_1\rightarrow v_2.
$$

Merge revision MAY 有多個 parent：

$$
Parents(v_m)=\{v_a,v_b\}.
$$

## 6.2 Intrinsic boundary

`intrinsic` 只保存 object 本體 state。Canvas placement、viewport、selection、cache、UI-expanded state MUST NOT 進入一般 object intrinsic content。

不同 kind 的 intrinsic boundary 由 profile 規格定義。

---

# 7. Content Address 與 Revision Address

EGIR v0.1 使用 SHA-256 作為 mandatory digest algorithm。未來 TW-02 MAY 增加 algorithm agility，但 v0.1 writer MUST 同時支援 SHA-256。

## 7.1 Content preimage

對 kind $k$ 與 intrinsic $I$：

$$
P_c=
\{
canon=\text{egir-cj/0.1},
kind=k,
intrinsic=I
\}.
$$

$$
A^{content}=\text{content:sha256:}H(C(P_c)).
$$

Canvas placement、physical locator、human alias 不進 $P_c$。

## 7.2 Revision preimage

v0.1 revision address preimage：

$$
P_v=
\{
canon,
persistent\_id,
kind,
parents,
content\_address,
event\_id,
created\_at
\}.
$$

其中 `parents` MUST 在 hash preimage 中以 revision ID lexical order 排序。

$$
A^{ver}=\text{rev:sha256:}H(C(P_v)).
$$

因此同 intrinsic content 在不同 persistent object 中可以有相同 content address，但不同 revision address。

---

# 8. EGIR-CJ/0.1 Canonicalization

## 8.1 原則

EGIR-CJ/0.1 的目的不是定義新的數學簡化器，而是生成 deterministic hash bytes。

$$
\text{Canonicalization}
\neq
\text{semantic normalization}
\neq
\text{theorem simplification}.
$$

## 8.2 JSON lowering

所有 hash-covered state MUST 先 lowering 到 safe JSON domain。

v0.1 禁止在 hash preimage 中使用：

- NaN；
- Infinity；
- binary floating-point runtime values；
- 不可攜的 language-specific object；
- raw pointer/memory address。

## 8.3 數值規則

大整數、exact rational、arbitrary decimal、measurement、coordinate decimal SHOULD 使用 typed string representation，例如：

```json
{ "type": "integer", "value": "123456789012345678901234567890" }
```

```json
{ "type": "rational", "numerator": "1", "denominator": "3" }
```

Canvas transform v0.1 使用 decimal strings：

```json
{
  "x": "120.0",
  "y": "80.0",
  "scale_x": "1.0",
  "scale_y": "1.0",
  "rotation_deg": "0.0"
}
```

這避免不同語言把同一概念輸出成不同 IEEE-754 shortest-string representation。

## 8.4 Key order

JSON object keys 在 canonical output 中 MUST 按 Unicode code point lexical order 排序。

## 8.5 Arrays

Array order 預設具有語義，MUST 保留。

只有規格明確宣告為 set 的欄位才排序。例如：

- revision `parents`：lexical sort；
- workspace `object_heads`：以 `(persistent_id, revision)` 排序；
- workspace `relation_heads`：同上；
- canonical placement list：以 `(object_id, region_id, placement_id)` 排序。

## 8.6 Unicode

EGIR-CJ/0.1 MUST 保存 Unicode scalar sequence，不在 canonicalization 階段自動執行 NFC/NFKC normalization。

搜尋／比較層 MAY 建立 normalized secondary index，但不得回寫 source string。

## 8.7 Whitespace

Canonical JSON output MUST 不包含 token 之間的非必要 whitespace，並以 UTF-8 bytes hash。

---

# 9. 為什麼不是「直接 JCS 就好」

RFC 8785 JSON Canonicalization Scheme 是 EGIR-CJ/0.1 的重要基礎：deterministic key ordering、JSON primitive serialization 與 hash-friendly bytes 都直接採納其精神。

但 JCS 將 input 約束在 I-JSON，且 JSON number 需可由 IEEE-754 double precision 表示。Native Computational Mathematics 必須支援 arbitrary integer、rational 與 exact decimal，因此 EGIR 必須先把這些值 lowering 成 typed strings/objects，再在 safe JSON layer 做 deterministic serialization。

所以：

$$
\text{NCM exact number}
\xrightarrow{lower}
\text{safe EGIR JSON value}
\xrightarrow{canonicalize}
\text{hash bytes}.
$$

---

# 10. Event / Provenance Record

任何 persistent state mutation MUST 有 event：

```json
{
  "record_type": "event",
  "event_id": "urn:uuid:...",
  "actor": {
    "type": "human",
    "id": "Neo.K",
    "model": null
  },
  "op": "create-object",
  "inputs": [],
  "outputs": [],
  "base_workspace_revision": null,
  "tool": {
    "name": "eveglyph-runtime",
    "version": "0.1"
  },
  "policy": {},
  "created_at": "2026-08-24T10:30:00.000Z",
  "metadata": {}
}
```

Actor type：

- `human`；
- `ai`；
- `system`；
- `importer`。

AI event SHOULD 記錄 model/runtime identifier，但 MUST NOT 把 API key、token 或 secrets 寫入 canonical provenance。

---

# 11. Relations as First-Class Objects

EGIR v0.1 將 authoritative relation 實作成普通 persistent object，`kind="relation"`。

Relation intrinsic：

```json
{
  "profile": "relation/0.1",
  "source": { "type": "identity", "value": "urn:uuid:..." },
  "predicate": "eg:dependsOn",
  "target": { "type": "identity", "value": "urn:uuid:..." },
  "qualifiers": {},
  "authority": {
    "class": "explicit",
    "source": "user",
    "rule": null,
    "confidence": "1.0"
  }
}
```

`authority.class` 只能是：

- `explicit`；
- `derived`。

AI、spatial parser、recognizer 尚未 commit 的輸出 MUST 先放在 `candidate_records`，不能直接出現在 workspace `relation_heads`。

---

# 12. Candidate Records

Candidate 是可保存但沒有 authoritative semantics 的結構：

```json
{
  "candidate_id": "urn:uuid:...",
  "candidate_type": "relation",
  "payload": {},
  "authority": "candidate",
  "created_at": "...",
  "source": {}
}
```

v0.1 candidate types：

- `relation`；
- `semantic`；
- `parse`；
- `identity-match`。

Promotion 必須產生 event：

$$
Candidate
\xrightarrow{Promote}
CommittedRevision.
$$

---

# 13. Multi-Layer AddressRef

EGIR v0.1 address reference 是 tagged union。

## 13.1 Identity

```json
{ "type": "identity", "value": "urn:uuid:..." }
```

## 13.2 Version

```json
{
  "type": "version",
  "object": "urn:uuid:...",
  "revision": "rev:sha256:..."
}
```

## 13.3 Content

```json
{
  "type": "content",
  "algorithm": "sha-256",
  "canonicalization": "egir-cj/0.1",
  "digest": "..."
}
```

## 13.4 Semantic

```json
{
  "type": "semantic",
  "schema": "eg-sem/0.1",
  "ontology": "eg:math",
  "anchors": ["derivative"],
  "negative_anchors": [],
  "relations": [],
  "constraints": [],
  "open_variables": [],
  "confidence": "0.93",
  "authority": "candidate"
}
```

## 13.5 Spatial

```json
{
  "type": "spatial",
  "workspace": "urn:uuid:...",
  "snapshot": "wrev:sha256:...",
  "region": null,
  "frame": "world",
  "selector": {}
}
```

## 13.6 Physical

```json
{
  "type": "physical",
  "carrier": "file",
  "locator": "workspace.egir.json",
  "authority": "local",
  "qualifiers": {}
}
```

Physical references MUST NOT be interpreted as persistent identity。

---

# 14. Workspace Revision

Workspace revision 是 object heads、relation heads 與 placements 的 immutable snapshot：

```json
{
  "workspace_id": "urn:uuid:...",
  "workspace_revision": "wrev:sha256:...",
  "parents": [],
  "title": "Example",
  "object_heads": [],
  "relation_heads": [],
  "placements": [],
  "event_id": "urn:uuid:...",
  "created_at": "...",
  "metadata": {}
}
```

Workspace revision preimage 包含：

$$
P_W=
\{
canon,
workspace\_id,
parents,
object\_heads,
relation\_heads,
placements,
event\_id,
created\_at
\}.
$$

$$
A^{workspaceVer}=
\text{wrev:sha256:}H(C(P_W)).
$$

UI viewport、selection、cursor、hover、temporary drag state MUST NOT 進 workspace revision preimage。

---

# 15. Placement Record

Placement 是 extrinsic workspace state：

```json
{
  "placement_id": "place:node-001",
  "object_id": "urn:uuid:...",
  "region_id": null,
  "frame": "world",
  "transform": {
    "x": "120.0",
    "y": "80.0",
    "scale_x": "1.0",
    "scale_y": "1.0",
    "rotation_deg": "0.0"
  },
  "z": 0,
  "layer": "main"
}
```

純 move 只建立新 workspace revision，不建立新 object revision：

$$
Move(o)
\Rightarrow
v_o'=v_o,
\quad
v_W'\neq v_W.
$$

---

# 16. Region / Local Formality

`region` 是 built-in object kind。其 intrinsic SHOULD 包含：

- boundary geometry；
- local frame；
- grammar profile；
- execution policy；
- namespace policy；
- snap/tolerance profile。

幾何進入 region 只能產生 candidate membership；semantic scope 必須 explicit commit。

$$
Inside_{geo}(o,r)
\not\Rightarrow
ScopedBy(o,r).
$$

---

# 17. Native Math Profile `ncm/0.1`

`math` revision intrinsic MUST 使用 profile：

```json
{
  "profile": "ncm/0.1",
  "expression": {
    "root": "n3",
    "nodes": []
  },
  "bindings": [],
  "type_info": {},
  "assumptions": [],
  "constraints": [],
  "units": {},
  "numeric_policy": {},
  "presentation": {},
  "execution": {}
}
```

## 17.1 Expression nodes

v0.1 core node types SHOULD 至少支援：

- `symbol`；
- `integer`；
- `rational`；
- `decimal`；
- `apply`；
- `binder`；
- `relation`；
- `matrix`；
- `piecewise`；
- `hole`。

## 17.2 Bound variables

Bound variables SHOULD 有 local node identity / binding record，而不是只靠 visible name。

## 17.3 Exactness

Exact numeric value MUST NOT 被 renderer 的 decimal approximation 回寫成 intrinsic mutation。

## 17.4 Execution

Runtime MUST 能直接在 NCM intrinsic 上執行，不得把 NCM 先輸出 LaTeX 再作 canonical parse-back。

---

# 18. Glyph Profile `glyph/0.1`

`glyph` revision intrinsic：

```json
{
  "profile": "glyph/0.1",
  "geometry": {},
  "topology": {},
  "parts": {},
  "semantics": [],
  "render_profiles": [],
  "behavior": {}
}
```

## 18.1 Geometry / placement separation

`geometry` 是 intrinsic local geometry；Canvas transform 放在 placement record。

## 18.2 Unicode

Unicode code point MAY 存成 adapter metadata，但 MUST NOT 成為 glyph persistent identity 的唯一來源。

## 18.3 Behavior

Imported glyph behavior MUST 預設 disabled / untrusted。Runtime 必須有 explicit permission transition 才能執行。

---

# 19. Alias Records

Alias：

```json
{
  "scope": "workspace",
  "name": "Derivative",
  "mutable": true,
  "authority": "user"
}
```

`mutable=true` 的 alias MUST NOT 被用作 immutable citation。

`latest`、`main`、display names 都屬 mutable resolution surface；真正 reproducible reference 應使用 version address。

---

# 20. Tombstone

Object deletion 不等於 identity 消失。

Object record：

```json
{
  "status": "tombstoned"
}
```

Tombstoned object MAY 移除 content bytes，但 reader/resolver SHOULD 保留：

- persistent ID；
- tombstone event；
- last known revision；
- minimal provenance。

Identity MUST NOT 被分配給新 lineage。

---

# 21. Extension Model

EGIR 必須可演化。

## 21.1 Unknown fields

Core records 使用封閉 schema，因此 core 欄位不能任意增加。Extension data MUST 放進：

```json
"extensions": {
  "org.example.feature/1": {}
}
```

或 object/revision `metadata` 中的 namespace-qualified field。

## 21.2 Unknown kinds

Reader MUST preserve unknown kind revision `intrinsic`，Writer SHOULD round-trip unchanged。

Runtime MUST NOT execute unknown kind。

## 21.3 Version negotiation

`ir_version` v0.1 僅接受 `egir/0.1`。

未來 `egir/0.2` 若破壞 core semantics，MUST 使用顯式 migration，而不是 silent reinterpretation。

---

# 22. Serialization Profiles

## 22.1 UTF-8 JSON — REQUIRED

所有 v0.1 implementations MUST 支援。

要求：

- valid UTF-8；
- no BOM SHOULD be emitted；
- duplicate object keys MUST be rejected；
- parsed strings MUST preserve scalar sequence；
- canonical hashing 使用 EGIR-CJ/0.1，不使用 pretty-printed bytes。

## 22.2 CBOR — RESERVED / OPTIONAL

RFC 8949 CBOR 是後續 compact/binary carrier 的候選。TW-01 不凍結 CBOR tag mapping。

若實作者提前提供 CBOR exporter，MUST 以 JSON canonical abstract state 作 cross-check，且不得因 CBOR map order、float encoding 或 tag choice 改變 EGIR semantic identity。

## 22.3 UTF-8X — DEFERRED TO TW-02

UTF-8X 可承擔 physical/region representation，但其 encode/decode 必須滿足：

$$
Decode(Encode(EGIR))=EGIR
$$

在本文件定義 equality 下成立。

---

# 23. JSON Schema 2020-12

本封裝包含：

```text
TW-01_Support/schemas/eveglyph-ir.schema.json
```

v0.1 使用 JSON Schema Draft 2020-12 作 structural validation。

Schema validation 不是全部 conformance：hash、cross-record reference、DAG parent existence、content/revision recomputation、authority boundary 仍需要 semantic validator。

因此：

$$
SchemaValid(x)
\not\Rightarrow
EGIRConformant(x).
$$

---

# 24. Cross-Record Semantic Validation

Writer/validator MUST 額外檢查：

1. 每個 object head revision 存在；
2. revision `persistent_id` 與 object lineage 相符；
3. revision parents 存在或明確 external；
4. content address recompute 相符；
5. revision address recompute 相符；
6. workspace revision recompute 相符；
7. relation source/target references 型別合法；
8. explicit relation 不引用 candidate-only target 作 authoritative identity，除非 target reference type 本身允許 unresolved semantics；
9. placement target object 存在；
10. tombstoned ID 不被新 lineage 重用。

---

# 25. Import / Export Adapter Contract

Adapter 必須回：

$$
AdapterResult=(objects,candidates,diagnostics,fidelity,provenance).
$$

`fidelity` 至少可為：

- `lossless`；
- `structural`；
- `semantic-subset`；
- `visual-only`；
- `unknown`。

LaTeX importer 不得宣稱所有 macro 都已取得 NCM semantics；SVG importer 不得把所有 group/geometry 都當 semantic relation；PDF/image importer 更不得假裝 recovered structure 是原 canonical source。

---

# 26. AI Authority Boundary

AI 可以建立：

- candidate semantic address；
- candidate relation；
- candidate identity match；
- candidate parse；
- suggested rewrite。

AI output SHOULD 進 `candidate_records`。

High-authority commit 必須經：

$$
Proposal
\rightarrow
Validation
\rightarrow
Policy
\rightarrow
CommitEvent.
$$

任何生成式模型 output 都不能取代 content/revision hash recomputation。

---

# 27. Security Requirements

## 27.1 Parsing

Reader MUST：

- reject duplicate keys；
- impose maximum nesting / record count / byte size appropriate to deployment；
- reject malformed UTF-8；
- reject invalid ID/hash syntax；
- avoid code execution during parse。

## 27.2 Physical locators

Physical addresses MAY 包含敏感本機路徑。Exporter SHOULD 提供 redaction profile，public bundle SHOULD NOT 預設洩露 private absolute paths。

## 27.3 Executable bindings

`behavior`、`execution`、operator/tool binding MUST NOT 在 import 時自動取得執行權。

## 27.4 Provenance secrets

API keys、tokens、passwords、private credentials MUST NOT 寫入 event metadata。

---

# 28. Deterministic Validation Order

推薦 validator pipeline：

$$
Bytes
\rightarrow
UTF8Decode
\rightarrow
JSONParse
\rightarrow
SchemaValidate
\rightarrow
ReferenceValidate
\rightarrow
Canonicalize
\rightarrow
HashVerify
\rightarrow
AuthorityValidate
\rightarrow
RuntimePolicy.
$$

任何前置 stage 失敗，後續 MUST NOT 以 AI 猜測方式「修好後當作原資料」。Repair 可以是新的 explicit transformation event，但不能竄改 input provenance。

---

# 29. Conformance Vectors

本封裝包含：

```text
TW-01_Support/conformance/tw01_vectors.json
```

並提供 reference validator：

```text
TW-01_Support/tools/validate_tw01.py
```

必測向量包括：

1. canonical key ordering；
2. UTF-8 canonical bytes hash；
3. math content address；
4. relation content address；
5. revision IDs；
6. workspace revision；
7. edit preserves identity；
8. move preserves intrinsic object revision；
9. clone separates identity；
10. candidate non-authority。

---

# 30. Minimal Example

本封裝的：

```text
TW-01_Support/examples/minimal_workspace.egir.json
```

建立一個 `math` object：

$$
x^2
$$

一個 explicit semantic relation，以及一個 Canvas placement。

這個 example 實際證明：

- math intrinsic content 有獨立 content address；
- revision 有獨立 revision address；
- relation 是 persistent/versioned object；
- placement 不進 math content hash；
- workspace snapshot 自己具有 workspace revision；
- provenance event 與 revision 互相可追蹤。

---

# 31. v0.1 Reference Package Layout

```text
EveGlyph_Addressable_Symbolic_Computational_Space_Series_v0.1/
├─ 00_...md
├─ 01_...md
├─ 02_...md
├─ 03_...md
├─ 04_...md
├─ 05_...md
├─ TW-01_EveGlyph_Symbol_IR_Specification_v0.1.md
├─ TW-01_Support/
│  ├─ schemas/
│  │  └─ eveglyph-ir.schema.json
│  ├─ examples/
│  │  └─ minimal_workspace.egir.json
│  ├─ conformance/
│  │  └─ tw01_vectors.json
│  └─ tools/
│     └─ validate_tw01.py
├─ SERIES_INDEX_v0.1.md
├─ VALIDATION.md
└─ SHA256SUMS.txt
```

---

# 32. TW-01 Design Freeze

完成本文件後，TW-02、TW-03 與 MVP-01 不得在未顯式升版的情況下破壞以下決策：

1. EGIR abstract model 與 carrier 分離；
2. UTF-8 JSON 是 v0.1 mandatory portable carrier；
3. JSON Schema 2020-12 是 v0.1 structural schema dialect；
4. new persistent object IDs SHOULD 使用 UUIDv7 URN；
5. persistent object 與 immutable revision 分離；
6. content address 與 revision address 分離；
7. SHA-256 是 v0.1 mandatory digest；
8. hash 使用 EGIR-CJ/0.1 canonicalization；
9. arbitrary/exact numerics 不直接依賴 binary float JSON serialization；
10. canonicalization 不做 theorem simplification；
11. Unicode scalar sequence 在 canonicalization 中不做 automatic normalization；
12. relation 是 first-class persistent/versioned object；
13. candidate records 不具有 explicit authority；
14. placement 是 workspace extrinsic state；
15. pure move 不建立 object intrinsic revision；
16. workspace snapshot 有自己的 immutable revision；
17. identity/content/semantic/spatial/physical/version refs 是 tagged typed union；
18. mutable alias 不得冒充 immutable citation；
19. Native Math 使用 `ncm/0.1` profile 且可直接執行；
20. Glyph 使用 `glyph/0.1` profile，geometry 與 placement 分離；
21. import adapter 必須回 fidelity 與 provenance；
22. executable binding 匯入後預設不取得權限；
23. schema validation 與 full semantic conformance 分離；
24. unknown extension kinds 必須可保存，但不得自動執行；
25. state mutation 必須有 event/provenance；
26. content/revision/workspace hash 必須可由不同合規 implementation 重算一致；
27. secrets 不進 canonical provenance；
28. repair 是新 transformation event，不可 silent 改寫 input；
29. TW-02 可替換 physical carrier，但不能改 EGIR identity semantics；
30. TW-03 可替換 runtime/index/renderer，但不能改 authority / revision / addressing semantics。

---

# 33. MVP-01 直接實作要求

MVP-01 不需要一次實作整個 schema registry，只需完成一個垂直切片：

1. create `math` object；
2. write object/revision/event records；
3. compute content/revision address；
4. place object on canvas；
5. move without changing math revision；
6. create relation object；
7. create one custom glyph object；
8. bind glyph semantic candidate → explicit operator relation；
9. execute math operator；
10. create result object + provenance；
11. export bundle；
12. validate with schema + hash recomputation；
13. import bundle and reproduce identities/revisions；
14. export LaTeX only as adapter projection。

成功條件：

$$
Decode(Encode(W))\equiv_{EGIR}W.
$$

並且：

$$
Move(o)
\Rightarrow
A^{content}(o)\text{ unchanged}.
$$

以及：

$$
Execute(M)
\not\Rightarrow
\text{canonical LaTeX reparse}.
$$

---

# 34. 與 TW-02 的明確接口

TW-02 接手：

- EGIR bundle 的 file/chunk/object-store layout；
- UTF-8 text carrier；
- CBOR/UTF-8X optional carrier；
- block manifests；
- physical address；
- deduplication；
- random access；
- corruption recovery；
- replication；
- migration；
- storage benchmark。

TW-02 不得重新定義 persistent identity、revision identity 或 content canonical preimage。

---

# 35. 與 TW-03 的明確接口

TW-03 接手：

- in-memory object graph；
- Canvas scene graph；
- spatial index；
- resolver service；
- agent bridge；
- candidate promotion；
- execution scheduler；
- sandbox / permission；
- semantic zoom；
- adapter pipeline；
- collaboration/branch/merge；
- diagnostics / ExplainResolution / ExplainExecution。

TW-03 不得把 runtime cache 或 screen coordinates 重新升格為 canonical identity。

---

# 36. 結論

Paper 00–05 解決了「未來 EveGlyph 應該是什麼」；TW-01 第一次回答：

> **那它到底要怎麼存成一份可以由兩個不同程式重算、驗證、交換與再次執行的資料？**

答案不是把所有東西塞進一個巨大 JSON blob，而是把 object lineage、immutable revision、intrinsic content、relations、workspace placement、typed addresses、events、math profile 與 glyph profile 分層，再由 deterministic canonicalization 將需要驗證的 state 轉成 stable bytes。

因此 EGIR v0.1 的核心可以縮成：

$$
\boxed{
\text{Object Identity}
+
\text{Immutable Revision}
+
\text{Intrinsic Content}
+
\text{Typed Relations}
+
\text{Workspace State}
+
\text{Provenance}
}
$$

配上：

$$
\boxed{
\text{Deterministic Canonicalization}
+
\text{Typed Addressing}
+
\text{Schema Validation}
}
$$

這時 Markdown、LaTeX、SVG、PDF、PNG、UTF-8X、CBOR 甚至未來新的 representation 都可以重新回到各自適合的位置：它們是 carrier、adapter 或 projection，而不是唯一 ontology。

TW-01 至此把六篇理論真正壓成第一份機器可驗證的工程契約。

下一步 TW-02 不再重新設計 object model，而只回答：

$$
\boxed{
\text{How should EGIR be stored, transported, indexed, deduplicated, and recovered?}
}
$$

---

# References

[1] EveMissLab. *Paper 00 — From Linear Documents to Addressable Symbolic Computational Spaces*. v0.1, 2026.

[2] EveMissLab. *Paper 01 — Addressable Symbolic Object Model*. v0.1, 2026.

[3] EveMissLab. *Paper 02 — Spatial Syntax and Infinite Canvas Computation*. v0.1, 2026.

[4] EveMissLab. *Paper 03 — Native Computational Mathematics Beyond LaTeX*. v0.1, 2026.

[5] EveMissLab. *Paper 04 — Generative Glyph and Symbol Compilation*. v0.1, 2026.

[6] EveMissLab. *Paper 05 — Multi-Layer Addressing for Computational Documents*. v0.1, 2026.

[7] A. Rundgren, B. Jordan, and S. Erdtman. *RFC 8785 — JSON Canonicalization Scheme (JCS)*. 2020.

[8] C. Bormann and P. Hoffman. *RFC 8949 — Concise Binary Object Representation (CBOR)*. Internet Standard, 2020.

[9] K. Davis, B. Peabody, and P. Leach. *RFC 9562 — Universally Unique IDentifiers (UUIDs)*. 2024.

[10] JSON Schema Project. *JSON Schema Draft 2020-12 Core and Validation*. Published 2022.

[11] T. Bray. *RFC 8259 — The JavaScript Object Notation (JSON) Data Interchange Format*. 2017.

[12] EveMissLab. *UTF-8X — 區域動態表示架構*. research engineering baseline, 2026.

---

# Appendix A — Core Hash Formulas

$$
P_c=
\{
canon,
kind,
intrinsic
\}.
$$

$$
A^{content}=
\text{content:sha256:}H(C(P_c)).
$$

$$
P_v=
\{
canon,
persistent\_id,
kind,
parents,
content\_address,
event\_id,
created\_at
\}.
$$

$$
A^{ver}=
\text{rev:sha256:}H(C(P_v)).
$$

$$
P_W=
\{
canon,
workspace\_id,
parents,
object\_heads,
relation\_heads,
placements,
event\_id,
created\_at
\}.
$$

$$
A^{workspaceVer}=
\text{wrev:sha256:}H(C(P_W)).
$$

---

# Appendix B — Reference Files

本白皮書的 normative-support artifacts 為：

- `TW-01_Support/schemas/eveglyph-ir.schema.json`
- `TW-01_Support/examples/minimal_workspace.egir.json`
- `TW-01_Support/conformance/tw01_vectors.json`
- `TW-01_Support/tools/validate_tw01.py`

`validate_tw01.py` 是 v0.1 的 reference validator，不代表唯一允許的 implementation。任何獨立 implementation 只要能通過相同 schema、canonicalization 與 conformance vectors，即可作為 TW-01 compatible implementation。

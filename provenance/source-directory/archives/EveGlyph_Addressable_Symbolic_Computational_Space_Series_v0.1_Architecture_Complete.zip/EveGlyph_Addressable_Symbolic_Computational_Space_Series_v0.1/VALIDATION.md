# VALIDATION

## Canonical source files

- Paper 00: `00_從線性文件到可定址符號計算空間_統合論文_v0.1.md`
- Paper 01: `01_可定址符號物件模型_身份內容語義關係版本與相等性_v0.1.md`
- Paper 02: `02_空間語法與無限畫布計算_從幾何配置到可驗證執行結構_v0.1.md`
- Paper 03: `03_原生可計算數學_超越LaTeX字串的語義物件執行與投影模型_v0.1.md`
- Paper 04: `04_生成式字形與符號編譯_從像素來源到可定址幾何拓撲部件語法與語義符號_v0.1.md`
- Paper 05: `05_多層定址的可計算文件_身份內容語義空間物理版本解析與跨工作區參照_v0.1.md`

## Source encoding

All six formal papers:

- UTF-8 decode: PASS
- UTF-8 re-encode identity: PASS
- LF source output: PASS
- disallowed control-character scan: PASS

## Canonical math delimiter policy

All six formal paper sources:

- use `$...$` and `$$...$$` as the canonical Markdown math delimiters;
- contain no legacy alternative TeX math-delimiter forms;
- pass delimiter-balance validation outside fenced code blocks and inline code spans.

## Paper 00 referenced implementation verification

- GSC v1.13 strict symbolic: 105/105 Node tests PASS; JS syntax checks PASS.
- PSSA-BSAR v0.1 Milestone 4 source: 73/73 pytest tests PASS.

These test results validate the supplied code baselines and protocol plumbing. They do not independently validate all scientific hypotheses in Paper 00.

## Paper 01 literature / standards verification

Checked against public sources during drafting:

- RFC 6920 — hash-based names for digital objects;
- W3C PROV-O Recommendation — interoperable provenance representation;
- Software Hash IDentifier (SWHID) — intrinsic identifiers / Merkle object structure;
- Open Provenance Model and FAIR literature used only as supporting prior work.

## Paper 01 formal consistency checks

- persistent identity and content identity are explicitly non-equated;
- object revision history and workspace history are explicitly separated;
- intrinsic geometry and extrinsic placement are explicitly separated;
- explicit and derived relations are authority-distinct;
- revision model permits DAG branch/merge;
- 12 design-freeze invariants and 12 conformance vectors are included;
- no concrete JSON/wire schema is prematurely frozen; that boundary is deferred to TW-01.

## Paper 02 literature verification

Checked against public literature during drafting:

- Marshall & Shipman — implicit structure in spatial hypertext;
- VIKI — spatial hypertext supporting emergent structure;
- Shipman, Marshall & Moran — recognition/use of human-organized spatial layouts;
- Golin & Reiss — picture layout grammar for two-dimensional visual-language syntax;
- Golin — parsing visual languages with picture layout grammars.

The paper uses these works as prior evidence that spatial arrangement can carry implicit or formally parseable structure; it does not treat prior spatial-layout recognition as automatic semantic authority.

## Paper 02 formal consistency checks

- “infinite canvas” is operationally defined as logically unbounded and finitely materialized;
- world/region/local/view coordinate frames are explicitly separated;
- intrinsic geometry and extrinsic placement remain distinct;
- transient spatial state, derived candidates, and explicit committed relations are authority-distinct;
- ambiguous spatial parses are allowed to remain unresolved;
- local region grammars allow freeform and formal areas to coexist;
- layout graph and execution graph are explicitly non-equated;
- executable spatial compilation requires parse → validate → commit → compile boundaries;
- threshold relations include a stability requirement such as hysteresis/transaction boundaries;
- spatial indexes are defined only as acceleration structures;
- 18 design-freeze decisions and 15 conformance tests are included;
- concrete renderer/index/database choices remain deferred to TW-03.

## Paper 03 standards / literature verification

Checked against current public sources on 2026-08-24:

- W3C MathML Core — Candidate Recommendation Snapshot, 24 June 2025;
- W3C MathML 4.0 — Working Draft, 04 June 2026;
- OpenMath Standard — Version 2.0 Revision 2 remains the normative OpenMath standard;
- OMDoc — semantic mathematical documents / theories / proofs as prior art;
- historical CAS / semantic-math literature used only as background support.

These sources support the paper's claim that mathematical presentation and mathematical content are already distinct concerns in established standards. Paper 03 does not claim to invent semantic mathematics; its contribution is the integration with ASOM identity/versioning, spatial syntax, native execution, provenance, ambiguity, and workspace-level addressing.

## Paper 03 formal consistency checks

- mathematical object and notation/serialization are explicitly non-equated;
- LaTeX is retained as an adapter/projection and not declared obsolete;
- expression graph, binding, type/domain, assumptions, constraints, units, numeric exactness, presentation, execution, and provenance are explicitly separated;
- free/bound variable identity and alpha-equivalence are formalized;
- exact versus approximate numerical semantics are separated;
- assumptions and side conditions are required to survive transformations;
- undefined, conditional, unresolved, and unevaluated states remain distinct;
- canonicalization and theorem/simplification rewrites are explicitly non-equated;
- multiple equality classes are defined and non-interchangeable;
- spatial math notation is treated as an editing/parse surface rather than final ontology;
- evaluation returns result + derived state + provenance + conditions/status;
- computation evidence and proof evidence remain distinguishable;
- 20 design-freeze invariants and 18 conformance tests are included;
- the MVP requires direct computation on NCM objects without a canonical LaTeX reparse path.

## Paper 04 engineering / literature verification

Fresh GSC v1.13 verification during Paper 04 drafting:

- `node --test tests/core.test.js tests/strict-symbolic.test.js`: 105/105 tests PASS;
- `node --check src/core.js`: PASS;
- `node --check strict-symbolic-app.js`: PASS;
- `node --check app.js`: PASS.

The GSC baseline explicitly keeps `AssetSymbol v0.7` as the canonical strict-symbolic representation; the exact strict renderer is source-blind, the enhanced renderer remains source-blind, native import packages are consumer-layer artifacts, and Gate 11 project-binding plans remain non-mutating previews.

Supporting public literature checked during drafting includes shape-feature surveys, skeletonization/thinning literature, visual-language grammars, and visual-symbol/lexicon research. These sources are used only to support the existence of established geometry/topology/grammar techniques; Paper 04 does not claim that skeletonization, shape grammar, or visual recognition alone establishes semantic identity.

## Paper 04 formal consistency checks

- source artifact, normalized target, symbolic carry, structural lift, part grammar, and semantic symbol are explicitly separated;
- exact visual reconstruction and semantic understanding are explicitly non-equated;
- source and compiled glyph use separate persistent identities with derivation provenance by default;
- intrinsic geometry, topology, part graph, semantic binding, renderer profile, and behavior binding remain separable;
- character, glyph, and semantic symbol identities are distinguished;
- Unicode assignment is optional rather than a prerequisite for glyph existence;
- AI/recognizer semantic labels remain candidates until promotion/commit;
- visual import and executable behavior permission are separated;
- pixel, geometric, topological, part-structural, and semantic equality remain distinct;
- composite glyphs may preserve referenced child structure instead of being permanently raster-flattened;
- compiler/normalizer/profile provenance is versioned;
- 20 design-freeze invariants and 18 conformance tests are included;
- the MVP requires at least one custom glyph to participate in native semantic computation through an explicit binding.


## Paper 05 standards / literature verification

Checked against current public standards and official documentation during drafting on 2026-08-24:

- RFC 3986 — URI generic syntax and separation of identification from interaction;
- RFC 8141 — URNs as persistent, location-independent resource identifiers;
- RFC 6920 — hash-derived names for digital objects;
- ISO/IEC 18670:2025 — SWHID V1.2, intrinsic content-derived identifiers built over Merkle DAGs, with resolution explicitly outside the standard scope;
- DOI Foundation DOI Handbook — persistent identifier, metadata, and Handle-based resolution separation;
- W3C DID Core v1.0 Recommendation and DID v1.1 Candidate Recommendation Snapshot (05 March 2026) — identifier, subject/controller, document, service, and resolution separation.

These standards are used as architectural precedents. Paper 05 does not claim that ASCS must adopt URI, URN, SWHID, DOI, or DID as its universal native identifier scheme.

## Paper 05 formal consistency checks

- persistent/content/semantic/spatial/physical/version addresses are explicitly typed and non-interchangeable;
- resolver semantics are explicitly separated from dereference/retrieval;
- semantic resolution permits zero/one/many results and does not imply persistent identity;
- immutable revision addresses are separated from mutable aliases such as `latest`;
- aliases, locators, references, and persistent identities are distinguished;
- spatial addresses are workspace/snapshot/frame aware;
- physical addresses may migrate or replicate without identity mutation;
- subobject addresses are revision-aware unless child persistent identities are used;
- cross-workspace link/import/federation are distinct operations;
- tombstone, unavailable, unauthorized, invalid, stale, and unresolved states remain distinguishable;
- resolution success does not grant read/write/execute capability;
- AI identity reconciliation is candidate-level until authoritative commit;
- 24 design-freeze invariants and 20 conformance tests are included;
- MVP requirements explicitly demonstrate both identity continuity across edits/moves/storage migration and distinct identities sharing content/semantics.

## Core theory-set status

Paper 00–05 are complete for the ASCS v0.1 theory freeze. The next phase is technical specification/whitepaper work (TW-01, TW-02, TW-03), followed by MVP-01.

## TW-01 standards verification

Checked against current official/public specifications during drafting on 2026-08-24:

- RFC 8785 — JSON Canonicalization Scheme (JCS), used as the deterministic JSON canonicalization precedent;
- RFC 8949 — CBOR Internet Standard, reserved as a future compact/binary carrier rather than the v0.1 identity ontology;
- RFC 9562 — current UUID specification, used for the recommendation that newly created persistent identities use UUIDv7 URNs;
- JSON Schema Draft 2020-12 — current JSON Schema specification/dialect, used for structural validation.

TW-01 deliberately does not apply JCS directly to arbitrary-precision mathematical numbers. Exact/big numerics are lowered to typed string/object representations first, because JCS operates over the I-JSON / IEEE-754-compatible number domain.

## TW-01 machine-readable artifact verification

Included support artifacts:

- `TW-01_Support/schemas/eveglyph-ir.schema.json`;
- `TW-01_Support/examples/minimal_workspace.egir.json`;
- `TW-01_Support/conformance/tw01_vectors.json`;
- `TW-01_Support/tools/validate_tw01.py`.

Fresh reference validation result:

- JSON Schema Draft 2020-12 meta-schema check: PASS;
- minimal workspace schema validation: PASS;
- cross-record object/head/parent/placement references: PASS;
- content-address recomputation: PASS;
- revision-ID recomputation: PASS;
- workspace-revision recomputation: PASS;
- EGIR-CJ/0.1 canonicalization vector: PASS;
- executable edit/move/clone semantic vectors: PASS.

## TW-01 formal consistency checks

- persistent ID, content address, revision address, workspace revision and physical/spatial locators remain distinct;
- relation records are versioned persistent objects;
- candidate records are separated from committed relation heads;
- placement state is outside object intrinsic content;
- Native Math and Glyph profiles are included as built-in specialization contracts;
- exact/big numeric values do not depend on implementation-specific floating-point JSON serialization;
- canonicalization preserves Unicode scalar sequences and does not perform theorem simplification;
- import/export fidelity and execution-permission boundaries are explicit;
- the whitepaper includes 30 design-freeze decisions and a concrete MVP vertical-slice requirement.

## TW-02 standards / architecture verification

Checked against current public standards and the existing UTF-8X engineering baseline during drafting on 2026-08-24:

- Unicode Standard 17.0 / UTF-8 remains the standards-compatible text/byte anchor; TW-02 does not define a new Unicode encoding form;
- RFC 8949 — CBOR deterministic-encoding guidance, used only as a future/optional physical carrier reference;
- RFC 8878 — Zstandard framing/compression, reused as an external codec rather than redefined by EveGlyph;
- RFC 9841 — Shared Brotli compressed-data format, reused as an optional shared-dictionary codec profile;
- FastCDC / content-defined chunking literature, used as an experimental dedup/chunk-boundary profile rather than a mandatory ontology;
- existing `kakon77777-commits/utf-8x` v0.22 baseline and v0.1 whitepaper, including its deterministic-decode principle, Windows portability findings, block-size sensitivity, Brotli comparison, and previously missing random-access-amplification measurement.

The historical UTF-8X CJK corpus entry was located in the repository at 56,960 bytes. Because the historical repository intentionally preserves the old filename-encoding damage in that corpus directory, this ASCS package does not silently rename/reconstruct that historical source. Historical CJK compression numbers are treated as prior baseline evidence, while the fresh TW-02 benchmark below uses only sources bundled in this ASCS package.

## TW-02 machine-readable artifact verification

Included support artifacts:

- `TW-02_Support/schemas/eveglyph-storage-manifest.schema.json`;
- `TW-02_Support/examples/example_store/manifest.json`;
- `TW-02_Support/examples/example_store/chunks/*.bin`;
- `TW-02_Support/conformance/tw02_vectors.json`;
- `TW-02_Support/tools/validate_tw02.py`;
- `TW-02_Support/tools/benchmark_tw02.py`;
- `TW-02_Support/benchmark_baseline.json`;
- `TW-02_Support/BENCHMARK_BASELINE.md`.

Fresh reference validation result:

- storage-manifest JSON Schema validation: PASS;
- manifest-ID recomputation: PASS;
- chunk decoded/encoded hash verification: PASS;
- root reconstruction: PASS;
- reconstructed root UTF-8/EGIR payload check: PASS;
- TW-02 conformance vectors: PASS.

## TW-02 benchmark baseline

Fresh reproducible benchmark corpus: concatenated Paper 00–05 + TW-01 canonical UTF-8 Markdown source, 300,714 decoded bytes. Read trace: 1,000 pseudo-random reads, 512 decoded bytes per request, seed 20260824.

Selected results:

| Chunk bytes | Codec | Compression ratio | Mean decoded read amplification | P95 decoded read amplification |
|---:|---|---:|---:|---:|
| 4,096 | identity | 1.000000 | 8.8807 | 16.0000 |
| 4,096 | gzip | 0.547982 | 8.9595 | 16.0000 |
| 4,096 | brotli | 0.438796 | 9.0201 | 16.0000 |
| 65,536 | gzip | 0.392951 | 123.8732 | 128.0000 |
| 65,536 | brotli | 0.332339 | 124.0972 | 128.0000 |
| 262,144 | gzip | 0.375131 | 460.0926 | 512.0000 |
| 262,144 | brotli | 0.295264 | 457.3946 | 512.0000 |

This benchmark is illustrative rather than universal: larger independent chunks improve compression on this corpus while sharply worsening small-read amplification. Python `zstandard` was unavailable in the validation environment, so no Zstd number was fabricated.

## TW-02 formal consistency checks

- UTF-8 is retained as the standard-compatible anchor; UTF-8X is not redefined as a Unicode encoding form;
- EGIR identity/content/revision semantics remain above and independent of physical chunking/compression;
- decoded chunk identity and encoded blob integrity are separated;
- `identity` is a mandatory safe fallback;
- codec dependencies are manifest/version/hash bounded and deterministic at decode time;
- chunking strategies are storage profiles rather than object ontology;
- random-access claims require read-amplification metrics;
- compression ratio, read amplification, metadata overhead, write amplification, deduplication, decode/encode cost, and memory are defined as distinct optimization axes;
- checksum, cryptographic encoded hash, decoded chunk hash, and EGIR semantic validation are layered;
- missing/corrupt dependencies produce typed failures rather than generative repair;
- durability is platform/profile explicit, avoiding the old UTF-8X assumption that POSIX filesystem behavior applies unchanged on Windows;
- encryption and physical relocation do not change TW-01 identities;
- CBOR/UTF-8X/new carriers must round-trip to the same EGIR abstract state;
- 28 design-freeze decisions and 22 conformance tests are included;
- MVP-01 must demonstrate identity-stable migration across at least two physical representations.

## Technical-whitepaper phase status

- TW-01: COMPLETE.
- TW-02: COMPLETE.
- TW-03: next.
- MVP-01: pending after TW-03.

## TW-02 final source / package pre-commit validation

Fresh final pre-commit validation after TW-02 integration:

- TW-01 reference validator: PASS;
- TW-02 reference validator: PASS;
- TW-02 deterministic benchmark vectors (excluding wall-clock timing): exact MATCH against packaged baseline;
- all Markdown/JSON/Python/text support sources: strict UTF-8 round-trip PASS;
- all text sources: LF-only PASS;
- control-character scan: PASS;
- canonical math delimiter policy using only `$...$` and `$$...$$`: PASS;
- block/inline math delimiter balance: PASS;
- TW-02 LaTeX escape-regression checks for inequality/arrow commands: PASS;
- all JSON artifacts parse successfully;
- TW-01/TW-02 Python support tools compile successfully.


## TW-03 runtime / standards verification

Checked against current implementation and public protocol/security references during drafting on 2026-08-24:

- current `kakon77777-commits/eveglyph-editor` source: `src/state.js` still exposes a mutable frontend `S` singleton used as UI/workspace session state; TW-03 therefore treats it as a migration-compatible UI Session Facade rather than future canonical object truth;
- current `src/agent.js`: local-agent execution resolves one workspace directory, snapshots the filesystem through the git bridge, runs a CLI agent under permission tiers, and later surfaces a reviewable diff; TW-03 preserves this investment as a `LegacyFileAgentAdapter` rather than requiring an immediate rewrite;
- Model Context Protocol specification release `2026-07-28`: stateless core, self-describing requests, extensions/tasks framework, authorization hardening, cacheable list results, and formal deprecations; TW-03 accordingly treats MCP as an edge transport/adapter and does not bind canonical EveGlyph workspace identity to an MCP session lifecycle;
- WebAssembly current public specification/security documentation: Wasm modules execute within an embedding-controlled sandbox, while access to files/network/clocks remains governed by the embedding/WASI policy; TW-03 therefore treats Wasm/WASI as an optional sandbox backend rather than an automatic security guarantee.

## TW-03 machine-readable artifact verification

Included support artifacts:

- `TW-03_Support/schemas/eveglyph-runtime-trace.schema.json`;
- `TW-03_Support/conformance/tw03_vectors.json`;
- `TW-03_Support/examples/runtime_trace.json`;
- `TW-03_Support/examples/runtime_final.egir.json`;
- `TW-03_Support/tools/reference_runtime.py`;
- `TW-03_Support/tools/validate_tw03.py`.

Fresh deterministic reference validation result:

- session overlay / derived cache non-authority: PASS;
- identity resolution: PASS;
- pure Canvas move: PASS;
- move preserves object revision: PASS;
- move preserves execution-graph hash: PASS;
- stale-base write returns `Conflict`: PASS;
- stale conflict leaves canonical workspace unchanged: PASS;
- AI proposal remains candidate-level: PASS;
- candidate proposal leaves workspace revision unchanged: PASS;
- candidate promotion creates explicit relation revision + provenance: PASS;
- Native Math derivative execution on the TW-01 `x^2` object: PASS;
- computation creates a new result identity: PASS;
- computation evidence class/backend provenance: PASS;
- semantic edit preserves persistent identity while changing content/revision addresses: PASS;
- historical old revision remains resolvable after head changes: PASS;
- restricted session with only `resolve` capability cannot execute: PASS;
- denied execution leaves canonical workspace unchanged: PASS;
- final runtime bundle still satisfies TW-01 JSON Schema and content/revision/workspace hash semantics: PASS;
- serialize / rehydrate preserves final workspace revision and derived execution-graph hash: PASS;
- packaged trace passes the TW-03 trace JSON Schema: PASS;
- packaged baseline trace/final bundle exactly reproduce the fresh reference run: PASS.

Reference final workspace revision:

`wrev:sha256:cca15bd097f0278fddcfebc2883a04aa01acd1f6163d10f9ef0ecbd1efbffe0c`

Reference final execution-graph hash:

`execgraph:sha256:c6402c8e8e2173f88377dad93a8ef1a4a1667721c73f7d7243f0bc46c78e4445`

The reference runtime is deliberately not the MVP. It is a deterministic conformance state machine used to prove the transaction/authority model before the interactive implementation phase.

## TW-03 formal consistency checks

- Canonical State, Session Overlay, Derived Cache, and External Effects are explicitly separated;
- viewport/selection/hover/cache state cannot mutate canonical identity without a runtime transaction;
- every canonical write is version-pinned with a base workspace revision;
- stale writes conflict rather than silently overwrite;
- candidate and authoritative relation layers remain distinct;
- layout/spatial placement and execution graph remain separate;
- Native Math execution operates directly on NCM objects;
- execution results create new addressable result objects with provenance;
- computed evidence remains distinct from formal proof evidence;
- address resolution and execution capability are separately enforced;
- agent `suggest`/`patch`/`direct` concepts are reinterpreted as policy levels rather than validator bypasses;
- legacy filesystem/git-diff agent flow is retained only as a compatibility adapter;
- MCP/CLI/HTTP/UI transports all converge on the same runtime-command authority model;
- external side effects are not falsely modeled as reversible canonical mutations;
- crash recovery may rebuild derived state but cannot silently repair canonical hashes with generative guesses;
- the whitepaper freezes 32 runtime invariants and 28 conformance tests;
- MVP-01 is required to pass TW-01, TW-02, and TW-03 validation layers.

## ASCS v0.1 architecture/specification-set status

Paper 00–05 and TW-01–TW-03 are complete. No additional core paper or technical-whitepaper layer is planned before MVP-01. The next phase is implementation: `MVP-01 — EveGlyph Computational Canvas v0.1`.

## Final TW-03 source / package validation

Fresh full validation after TW-03 completion:

- Paper 00–05 + TW-01 + TW-02 + TW-03 strict UTF-8 decode/re-encode round-trip: PASS;
- LF-only source for all nine formal Markdown artifacts: PASS;
- forbidden alternate math delimiters `\\(`, `\\)`, `\\[`, `\\]`: none detected in formal sources;
- canonical `$...$` / `$$...$$` delimiter balance outside fenced code: PASS;
- unexpected ASCII control-character scan: PASS;
- all `TW-0*_Support/**/*.json` parse successfully: PASS;
- Python compile for TW-01/TW-02/TW-03 reference tools: PASS;
- TW-01 reference validator: PASS;
- TW-02 reference validator: PASS;
- TW-03 deterministic runtime validator: PASS.

TW-03 canonical source size at freeze: 52,304 UTF-8 bytes / 2,375 lines.

The architecture/specification phase is now frozen as nine formal artifacts: six papers and three technical whitepapers. MVP-01 is the next phase; it is intentionally not claimed as implemented by the TW-03 reference state-machine harness.

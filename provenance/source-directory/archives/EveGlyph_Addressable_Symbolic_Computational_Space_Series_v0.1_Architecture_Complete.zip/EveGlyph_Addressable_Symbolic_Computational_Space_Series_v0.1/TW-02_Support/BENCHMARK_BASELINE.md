# TW-02 Reproducible Storage Baseline

Corpus: `benchmark_corpus_00-05_TW01.md` (300,714 bytes), concatenating current Paper 00–05 and TW-01 canonical Markdown sources.
Random-read simulation: 1000 reads, 512 decoded bytes/read, seed 20260824.

| Chunk | Codec | Encoded bytes | CR | Mean decoded RA | P95 decoded RA | Encode s |
|---:|---|---:|---:|---:|---:|---:|
| 4,096 | identity | 300,714 | 1.000000 | 8.8807 | 16.0000 | 0.000005 |
| 4,096 | gzip | 164,786 | 0.547982 | 8.9595 | 16.0000 | 0.006485 |
| 4,096 | brotli | 131,952 | 0.438796 | 9.0201 | 16.0000 | 0.337030 |
| 65,536 | identity | 300,714 | 1.000000 | 124.7576 | 128.0000 | 0.000001 |
| 65,536 | gzip | 118,166 | 0.392951 | 123.8732 | 128.0000 | 0.018838 |
| 65,536 | brotli | 99,939 | 0.332339 | 124.0972 | 128.0000 | 0.363498 |
| 262,144 | identity | 300,714 | 1.000000 | 447.5238 | 512.0000 | 0.000001 |
| 262,144 | gzip | 112,807 | 0.375131 | 460.0926 | 512.0000 | 0.011771 |
| 262,144 | brotli | 88,790 | 0.295264 | 457.3946 | 512.0000 | 0.421557 |

## Interpretation

- This is an illustrative reference run, not a universal performance claim. The corpus is the current ASCS source set, not the historical UTF-8X CJK corpus.
- Larger independently compressed chunks improved compression ratio on this corpus, but greatly increased decoded read amplification for 512-byte random reads.
- Brotli quality 11 was available in this environment; Python `zstandard` was not installed, so Zstandard is intentionally not reported rather than estimated.
- Any future UTF-8X or adaptive-storage advantage claim MUST be evaluated against ordinary codecs on the same corpus and MUST include read amplification, metadata/index overhead, encode/decode cost, and deduplication effects.

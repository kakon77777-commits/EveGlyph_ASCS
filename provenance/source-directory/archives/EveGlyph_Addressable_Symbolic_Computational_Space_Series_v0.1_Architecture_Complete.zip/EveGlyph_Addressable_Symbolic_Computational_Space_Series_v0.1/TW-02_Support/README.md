# TW-02 Support Artifacts

This directory contains the machine-readable reference artifacts for `TW-02 — UTF-8 / UTF-8X Compatibility & Storage Architecture v0.1`.

- `schemas/eveglyph-storage-manifest.schema.json` — EGStore manifest structural schema.
- `examples/example_store/manifest.json` — fixed-chunk identity-codec store wrapping the TW-01 minimal EGIR workspace.
- `examples/example_store/chunks/*.bin` — raw independently verifiable chunks.
- `conformance/tw02_vectors.json` — manifest/chunk/root reconstruction vectors and semantic invariants.
- `tools/validate_tw02.py` — reference validator.
- `tools/benchmark_tw02.py` — baseline compression/read-amplification benchmark harness; Brotli/Zstandard are optional if installed.
- `BENCHMARK_BASELINE.md` — reproducible baseline run over the current ASCS source corpus.

The example deliberately uses the mandatory `identity` codec. Optional codecs must not change TW-01 object/content/revision identity semantics.

#!/usr/bin/env python3
from pathlib import Path
import json, hashlib, sys
try:
    import jsonschema
except Exception:
    jsonschema=None

HERE=Path(__file__).resolve().parent
SUP=HERE.parent
STORE=SUP/'examples'/'example_store'
SCHEMA=SUP/'schemas'/'eveglyph-storage-manifest.schema.json'
VECTORS=SUP/'conformance'/'tw02_vectors.json'

def sha(b): return hashlib.sha256(b).hexdigest()
def manifest_id(m):
    x=dict(m); x['manifest_id']=''
    b=json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8')
    return 'store:sha256:'+sha(b)

def main():
    m=json.loads((STORE/'manifest.json').read_text(encoding='utf-8'))
    if jsonschema:
        schema=json.loads(SCHEMA.read_text(encoding='utf-8'))
        jsonschema.Draft202012Validator.check_schema(schema)
        jsonschema.validate(m,schema)
        print('PASS: schema')
    else:
        print('SKIP: schema (jsonschema unavailable)')
    assert manifest_id(m)==m['manifest_id']
    print('PASS: manifest id')
    byid={c['chunk_id']:c for c in m['chunks']}
    out=[]
    last=-1
    for cid in m['root_payload']['chunk_ids']:
        c=byid[cid]
        raw=(STORE/c['locator']).read_bytes()
        assert c['codec']=='identity'
        assert len(raw)==c['encoded_length']==c['decoded_length']
        assert sha(raw)==c['encoded_sha256']==c['decoded_sha256']
        assert cid=='chunk:sha256:'+sha(raw)
        assert c['logical_offset']>last
        last=c['logical_offset']
        out.append(raw)
    rebuilt=b''.join(out)
    assert len(rebuilt)==m['root_payload']['decoded_length']
    assert sha(rebuilt)==m['root_payload']['decoded_sha256']
    print('PASS: chunk hashes and root reconstruction')
    root=json.loads(rebuilt.decode('utf-8'))
    assert root.get('ir_version')=='egir/0.1'
    print('PASS: UTF-8 EGIR root payload')
    v=json.loads(VECTORS.read_text(encoding='utf-8'))
    assert v['expected_manifest_id']==m['manifest_id']
    assert v['root_payload_sha256']==m['root_payload']['decoded_sha256']
    assert v['semantic_vectors']['ai_strategy_may_select_codec_but_decoder_must_not_invoke_ai'] is True
    print('PASS: conformance vectors')
    print('TW-02 reference validation: PASS')
if __name__=='__main__': main()

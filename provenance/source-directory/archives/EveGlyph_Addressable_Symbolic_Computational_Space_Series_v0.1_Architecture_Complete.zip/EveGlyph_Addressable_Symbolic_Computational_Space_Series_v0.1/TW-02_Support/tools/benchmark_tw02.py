#!/usr/bin/env python3
from pathlib import Path
import argparse, gzip, hashlib, json, random, statistics, time
try:
    import brotli
except Exception:
    brotli=None
try:
    import zstandard as zstd
except Exception:
    zstd=None

def codec_bytes(name, raw):
    if name=='identity': return raw
    if name=='gzip': return gzip.compress(raw, compresslevel=9)
    if name=='brotli':
        if brotli is None: return None
        return brotli.compress(raw, quality=11)
    if name=='zstd':
        if zstd is None: return None
        return zstd.ZstdCompressor(level=19).compress(raw)
    raise ValueError(name)

def run(path, chunk_sizes, read_size, reads, seed):
    data=Path(path).read_bytes(); rng=random.Random(seed)
    results=[]
    for cs in chunk_sizes:
        raw_chunks=[data[i:i+cs] for i in range(0,len(data),cs)] or [b'']
        for codec in ['identity','gzip','brotli','zstd']:
            t=time.perf_counter(); enc=[]; ok=True
            for c in raw_chunks:
                x=codec_bytes(codec,c)
                if x is None: ok=False; break
                enc.append(x)
            elapsed=time.perf_counter()-t
            if not ok: continue
            encoded=sum(map(len,enc)); cr=encoded/max(1,len(data))
            amps=[]
            if data:
                for _ in range(reads):
                    start=rng.randrange(0,len(data))
                    end=min(len(data),start+read_size)
                    first=start//cs; last=(end-1)//cs
                    decoded=sum(len(raw_chunks[i]) for i in range(first,last+1))
                    amps.append(decoded/max(1,end-start))
            results.append({'chunk_size':cs,'codec':codec,'encoded_bytes':encoded,'compression_ratio':round(cr,6),'encode_seconds':round(elapsed,6),'mean_read_amplification':round(statistics.mean(amps) if amps else 0,4),'p95_read_amplification':round(sorted(amps)[int(.95*(len(amps)-1))] if amps else 0,4)})
    return {'file':str(path),'decoded_bytes':len(data),'read_size':read_size,'reads':reads,'seed':seed,'results':results}

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('path'); ap.add_argument('--chunk-sizes',default='4096,65536,262144'); ap.add_argument('--read-size',type=int,default=512); ap.add_argument('--reads',type=int,default=1000); ap.add_argument('--seed',type=int,default=20260824); ap.add_argument('--json',action='store_true')
    a=ap.parse_args(); out=run(a.path,[int(x) for x in a.chunk_sizes.split(',')],a.read_size,a.reads,a.seed)
    if a.json: print(json.dumps(out,ensure_ascii=False,indent=2)); return
    print('file:',out['file'],'decoded_bytes:',out['decoded_bytes'])
    print('chunk_size codec encoded_bytes CR mean_RA p95_RA encode_s')
    for r in out['results']:
        print(r['chunk_size'],r['codec'],r['encoded_bytes'],r['compression_ratio'],r['mean_read_amplification'],r['p95_read_amplification'],r['encode_seconds'])
if __name__=='__main__': main()

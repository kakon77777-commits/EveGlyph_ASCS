

<!-- SOURCE: 00_從線性文件到可定址符號計算空間_統合論文_v0.1.md -->

# 00｜從線性文件到可定址符號計算空間：EveGlyph、UTF-8X、Generative Symbol Compiler 與 PSSA 的統一架構命題

**English Title:** From Linear Documents to Addressable Symbolic Computational Spaces: A Unified Architecture Proposition for EveGlyph, UTF-8X, Generative Symbol Compilation, and Semantic Addressing

**作者：** Neo.K  
**機構：** EveMissLab / 一言諾科技有限公司  
**版本：** v0.1  
**日期：** 2026-08-24  
**文件類型：** 統合論文 / Architecture Proposition Paper  
**系列定位：** EveGlyph Addressable Symbolic Computational Space Series — Paper 00  

---

## Canonical Source Note

本文件目前以 UTF-8 Markdown 作為可攜式正式原稿，且數學原始碼統一使用 `$...$` 與 `$$...$$` 作為唯一 delimiter。這是**當前文件交換層的相容性選擇**，不是本文主張的終局數學本體表示。

本文的核心命題恰恰是：未來 EveGlyph 不應把 LaTeX 字串、Markdown 字串、HTML 樹或 PDF 排版結果視為數學與文件物件的最終 canonical ontology；這些格式應逐步降為 projection、serialization、import/export 或 legacy compatibility layer。

---

## 摘要

當代數位文件仍大多建立於一個歷史性假設：知識首先被編碼成一維字元序列，再藉由 Markdown、HTML、LaTeX、XML 或其他標記語法描述其結構與外觀。即使現代工具已能嵌入公式、程式、圖表、互動元件與計算結果，文件的 canonical source 往往仍是線性文字，數學則經常以專門排版語法間接描述二維結構。這種設計在文字終端、印刷排版與早期網頁時代具有高度合理性，但在無限畫布、原生多模態物件、AI 協作、符號編譯、可執行文件與持續版本化的計算環境中，其限制開始顯現。

本文提出 **Addressable Symbolic Computational Space, ASCS（可定址符號計算空間）** 作為 EveGlyph 未來架構的統一命題。其核心不在於「為 Markdown 增加更多語法」，而在於把文件從字串容器提升為由可定址物件、顯式語義、幾何／拓撲結構、空間關係、執行綁定與版本歷史構成的計算空間。文字、數學、程式、圖像符號、流程、資料、模擬節點與 AI 狀態不再被視為彼此附屬的嵌入格式，而被統一建模為 first-class addressable objects。

本文統合四條既有研究與工程線：第一，EveGlyph Editor 已具備 local-first workspace、AI agent、diff review、World IR 與 MCP 等文件工作區骨架；第二，UTF-8X 已將 UTF-8 視為語義錨點，研究不同計算區域中的可逆任務特化物理表示；第三，Generative Symbol Compiler 的 strict symbolic branch 已實作 source-blind symbolic reconstruction，建立從 raster 到 palette、RUN token、region、adjacency、topology、skeleton 與 part grammar 的逐層提升；第四，PSSA-BSAR 以受控實驗檢驗「address-first」結構是否能在尚未提供穩定名稱或完整自然語言定義時，支援後續語義恢復與辨識。

本文主張：UTF-8 應保留為高度相容的文字／位元組基底，而不是被破壞性修改；真正需要擴張的是其上方的 symbolic object layer。LaTeX、MathML、OpenMath、Markdown、HTML、SVG、PDF 等格式各自保留其價值，但不必再壟斷 canonical source。未來的原生數學物件應同時支援語義、渲染、運算、證明／來源追蹤與多種投影；無限畫布中的位置、包含、鄰接、方向與群組可以成為可機器判讀的 spatial syntax，但必須區分顯式關係與由幾何推斷的弱關係。本文並提出多層地址模型、抽象 Symbol IR、projection/serialization 分離原則、可證偽的 MVP 驗收條件，以及後續五篇專題論文與三篇技術白皮書的研究邊界。

本文不是 Unicode、UTF-8、LaTeX、MathML 或 Markdown 的替代標準提案，而是一個更上層的文件／計算本體架構命題：**讓既有格式從「世界本身」回到「世界的投影」。**

**關鍵詞：** EveGlyph、Addressable Symbolic Computational Space、Symbol IR、Infinite Canvas、UTF-8X、Generative Symbol Compiler、PSSA、Native Computational Mathematics、Spatial Syntax、Semantic Addressing、Post-Linear Document

---

## Abstract

Most digital document systems still inherit a historical assumption: knowledge is first serialized as a one-dimensional character stream, while structure, mathematics, visual layout, and executable behavior are subsequently expressed through markup or embedded sublanguages. This model remains highly effective for interoperability, publishing, and textual exchange, but it becomes increasingly restrictive in environments centered on infinite canvases, multimodal objects, AI-assisted editing, executable documents, symbolic graphics, semantic addressing, and persistent computational state.

This paper proposes the **Addressable Symbolic Computational Space (ASCS)** as a unifying architectural proposition for the future evolution of EveGlyph. Instead of treating Markdown, LaTeX, HTML, XML, or any other surface syntax as the ontology of the document, ASCS models a workspace as a graph of addressable objects equipped with semantics, geometry, relations, execution bindings, storage representations, and version history. Text, mathematics, code, symbolic graphics, data, simulations, and AI-related states become first-class objects rather than attachments embedded in a primarily textual document.

The proposal integrates four existing research and engineering lines: EveGlyph Editor as an AI-native local-first workspace; UTF-8X as an experimental reversible regional representation architecture anchored to UTF-8; Generative Symbol Compiler as a source-blind symbolic visual reconstruction pipeline; and PSSA-BSAR as a controlled test of whether address-first semantic representations provide measurable recovery value before stable naming or full prose definition. The paper argues that UTF-8 should remain a compatibility substrate, while symbolic semantics and executable object structure should be layered above it. It further distinguishes canonical object identity from rendering, serialization, spatial position, physical storage, and semantic addressing.

The goal is not to replace existing standards, but to reposition them as projections, interchange formats, and compatibility adapters over a richer computational object space. The paper concludes with formal definitions, falsifiable invariants, interoperability constraints, and an MVP boundary for an EveGlyph Computational Canvas.

---

# 1. 問題：文件仍把「表示」誤當成「對象」

## 1.1 線性字串的歷史成功與當代限制

傳統文件可以抽象為一個字元序列：

$$
D_{text}=(c_1,c_2,\ldots,c_n).
$$

Markdown、LaTeX、HTML 與 XML 的巨大成功，部分原因正是它們可被放進上述序列，使用一般檔案系統、版本控制、網路協議與文字工具處理。這個模式不應被簡單否定；相反地，本文主張必須**保留它作為交換層的優勢，同時解除它作為上層本體的壟斷**。

問題在於，當一個真正的知識物件具有二維或高維結構時，我們仍經常先把它壓回線性字串。例如一個分數、矩陣、交換圖、程式資料流、空間包含關係或手繪符號，常透過額外語法重建其原本不是一維的結構。於是出現三個不同層次被混在一起的情況：

1. **object**：我們真正想表達或計算的對象；
2. **serialization**：對象如何被編碼成可儲存／交換的資料；
3. **projection**：對象如何被人類或機器看見、操作與輸出。

本文將這三層嚴格分離。

## 1.2 LaTeX 的問題不是「不好」，而是角色被過度延伸

LaTeX 對高品質數學排版仍然極具價值。但若一個數學物件的唯一 canonical state 是：

```text
\frac{\partial f}{\partial x}
```

則系統必須先解析排版導向語法，才能重新得到其運算結構。更合理的原生計算模型，是先保存數學物件本身，再依需要產生 LaTeX。

例如偏導物件可抽象為：

$$
m=(\operatorname{Derivative},f,x,1).
$$

LaTeX 僅是某個 renderer 或 serializer：

$$
R_{\mathrm{TeX}}(m)=\text{a TeX-compatible projection}.
$$

同一個 $m$ 還可被投影成 MathML、OpenMath、語音、節點圖、無限畫布 glyph，或直接送入 symbolic computation engine。

因此本文的命題不是：

> LaTeX 已無價值。

而是：

> **LaTeX 不必再等於數學物件本身。**

---

# 2. 既有標準與系統已經指出方向，但尚未形成一般化計算畫布

## 2.1 Unicode 與 UTF-8：穩固的文字基底，而非一般語義物件系統

Unicode 17.0 將文字字元映射到穩定 code point 空間，UTF-8 則以可變寬 8-bit code unit sequence 提供高度相容的 byte-oriented encoding form [1]。Unicode 的成功核心是跨系統文字交換與穩定性，而不是承擔任意 domain object、幾何拓撲、執行語義與版本地址。

因此，未來 EveGlyph 不應嘗試以「破壞 UTF-8 相容性」換取 Symbol IR。本文採取：

$$
\text{UTF-8 substrate}\subset\text{ASCS transport ecosystem},
$$

而非：

$$
\text{ASCS}=\text{modified UTF-8}.
$$

換言之，自訂 glyph 不必先取得新的 Unicode code point 才能成為可運算的一級物件；但當它需要文字交換、名稱、描述、標籤或相容 fallback 時，仍可充分使用 Unicode/UTF-8。

## 2.2 MathML 與 OpenMath：已經證明「數學結構不等於排版字串」

W3C MathML Core 的 2025 Candidate Recommendation 聚焦瀏覽器中的數學呈現；MathML 4 在 2026-06-04 仍為 Working Draft，並同時處理 mathematical notation 與 content markup [2][3]。MathML 自身已明確區分表示結構與 underlying mathematical structure。

OpenMath 2.0 Revision 2 更直接把數學物件視為具有語義的 abstract object，並允許多種 concrete encoding；其標準明確區分 application-private representation、OpenMath abstract layer 與 byte communication layer [4]。這與本文的 projection/serialization 分離高度一致。

本文並不聲稱「語義數學物件」是新的概念；真正的新命題在於把這種分層原則**一般化到數學之外**，並與空間、圖形符號、可執行節點、多層地址與 AI-native workspace 統一。

## 2.3 OMDoc：從公式語義走向數學文件語義

OMDoc 1.2 已將 OpenMath/MathML 的語義表示提升到 statements、theories、proofs、development graphs 與 document-level mathematical knowledge [5][6]。它證明「文件中的知識片段本身可以成為物件」。

ASCS 與 OMDoc 的差異不在於否定 semantic document model，而在於再跨出三步：

1. 不限定於數學文件；
2. 不以 XML/線性文件結構作為主要互動本體；
3. 讓位置、幾何、執行與多模態 symbol 成為同等的一級結構。

## 2.4 Jupyter：可執行文件已經成為主流證據

Jupyter Notebook 將 code、result 與 explanation 放在同一可讀、可執行文件中，並被明確提出為 reproducible computational workflow 的 publishing format [7]。這說明「文件可執行」不是純理論命題。

但 notebook 的核心編排仍以 cell sequence 為主：

$$
C_1\rightarrow C_2\rightarrow\cdots\rightarrow C_n.
$$

ASCS 希望把這個模式提升為一般圖與空間：

$$
\mathcal{W}=(V,E,P,X),
$$

其中執行依賴不必等於畫面上的線性順序。

## 2.5 Spatial Hypertext：空間本身可以攜帶結構

1990 年代的 spatial hypertext 研究已指出，使用者會透過位置、視覺群組、鄰近、重複符號與空間配置形成 emergent structure；VIKI 等系統亦研究從 human-organized spatial layout 中取得 implicit structure [8][9]。

ASCS 延續這個方向，但加入一個更強的工程條件：

> 空間關係若要進入計算與資料交換，必須被版本化、可驗證，並區分「顯式語義」與「從幾何推斷的候選語義」。

因此，畫面靠近不必自動等於邏輯相依；系統必須知道哪些關係是 authoritative，哪些只是 inference。

---

# 3. 四條既有 EveMissLab 資產如何收斂成同一架構

## 3.1 EveGlyph Editor：已具備 workspace / agent / runtime 骨架

目前 EveGlyph Editor 的公開基線已包含 Markdown editor、live preview、local workspace、encoding-aware file handling、AI provider 與 local CLI agent、git diff review、EveGlyph-MD metadata、World Studio、World IR validation、workspace memory 與 MCP server。它已經比「文字編輯器」更接近一個 agentic document workspace。

但目前主介面與 canonical editing path 仍以 Markdown 為中心。ASCS 對 EveGlyph 的未來升級不是丟掉現有功能，而是把它們重新分層：

$$
\text{EveGlyph Editor}_{current}
\rightarrow
\text{EveGlyph Workspace Runtime}_{future}.
$$

Markdown editor 之後可以保留為一個 view，而不必再是唯一中心。

## 3.2 UTF-8X：從固定表示走向區域任務特化的可逆表示

UTF-8X 目前自我定位為「以 UTF-8 為語義錨點，在不同計算區域生成可逆、任務特化的物理表示」，並要求 deterministic、versioned、hash-verifiable 的 decode；AI 可負責策略產生，但不參與最終解碼。

其核心可抽象為：

$$
E_r:U\rightarrow P_r,
$$

$$
D_r:P_r\rightarrow U,
$$

並要求：

$$
D_r(E_r(U))=U.
$$

這條線對 ASCS 的意義不是「讓 UTF-8X 取代 Unicode」，而是提供 storage/transport layer 的研究資產：同一 canonical semantic object 可以在不同計算區域具有不同 physical representation，只要可逆性、版本、雜湊與 provenance 被保存。

## 3.3 Generative Symbol Compiler：圖像可以被編譯為 source-independent symbolic asset

Generative Symbol Compiler v1.13 strict symbolic branch 的核心命題為：

$$
I\xrightarrow{C}S,\qquad \cancel{I},\qquad S\xrightarrow{R}\hat I.
$$

其 Gate 1 canonical representation 使用 canvas、palette、RUN tokens、regions 與 adjacency；後續 gate 已加入 topology、ordered contour anchors、skeleton/medial hints、skeleton graph、part grammar、enhanced re-render、autotile/runtime adapter、native import packaging 與 preview-only project binding。v1.13 封裝的 `AssetSymbol v0.7` 明確要求 strict renderer 僅依 symbolic asset 重建，而不接觸 source raster。

本輪重新驗證結果為：

$$
105/105
$$

項 Node automated tests 通過，且 `core.js`、`strict-symbolic-app.js`、`app.js` 均通過 syntax check。

這提供一個重要的工程證據：至少在目前限定的 finite-palette pixel-art / pixel-like domain，**visual object 不必永久等同於 source pixel buffer**。因此自訂 glyph 未來可以擁有：

$$
g=(G,T,S,B),
$$

其中：

- $G$：geometry；
- $T$：topology；
- $S$：semantics；
- $B$：behavior / execution binding。

同一符號可被多種 renderer 重新實體化，而不必只是一個 Unicode character 或 PNG blob。

## 3.4 PSSA-BSAR：語義地址可以先作為工程表示假說被測試

PSSA-BSAR 的 weakest useful claim 為：一個尚未具有穩定名稱或完整自然語言定義的 partial semantic target，能否先被表示成 versionable address-like structure，並在 matched representation budget 下支援 later recovery/discrimination。

其 address-first ledger 包含 positive anchors、negative anchors、typed relations、constraints、open variables、candidate categories 與 confidence。PSSA 的設計特別禁止把此工程結果直接解讀成「已觀測到生物或模型內部的前語言心智地址」。

本輪重新執行 PSSA-BSAR 原始碼測試結果為：

$$
73/73
$$

項 pytest 通過。這證明的是 harness 與 protocol implementation 的目前工程完整性，而不是 address-first hypothesis 已取得 scientific confirmation。其真正受控 real-model Gate 1 仍需依 preregistered manifest 執行與解讀。

PSSA 對 ASCS 的價值在於提供 $A_s$，也就是 semantic address 的研究方向；但 ASCS 不把 $A_s$ 簡化成單一整數座標，而把它視為可版本化、可組合、可不完全、可保留 unresolved field 的 typed structure。

---

# 4. 統一命題：Addressable Symbolic Computational Space

本文定義一個 workspace：

$$
\mathcal{W}=(O,R,P,A,X,H).
$$

其中：

- $O$：addressable objects；
- $R$：typed explicit relations；
- $P$：spatial / geometric / topological placement；
- $A$：multi-layer addresses；
- $X$：execution bindings and computational transitions；
- $H$：version, provenance, and history graph。

一個一般物件可寫為：

$$
o_i=
(
\iota_i,
\tau_i,
c_i,
s_i,
g_i,
a_i,
x_i,
v_i
).
$$

其中：

- $\iota_i$：persistent identity；
- $\tau_i$：object type；
- $c_i$：content / payload；
- $s_i$：semantic structure；
- $g_i$：geometry / visual structure；
- $a_i$：address bundle；
- $x_i$：execution binding；
- $v_i$：version / provenance state。

這是一個**抽象模型**，不是本文直接凍結的 JSON schema。真正的欄位、binary/text encoding、schema evolution 與 interoperability contract 將交由 TW-01 `EveGlyph Symbol IR Specification` 定義。

---

# 5. Canonical Object、Serialization 與 Projection 必須分離

## 5.1 Projection

令某個 viewer / renderer 為：

$$
\Pi_k:\mathcal{W}\rightarrow V_k.
$$

則 $V_k$ 可以是：

- EveGlyph Canvas；
- Markdown view；
- LaTeX；
- MathML；
- HTML；
- SVG；
- PDF；
- raster image；
- audio / accessibility view；
- graph/debug view。

關鍵是：

$$
\Pi_i(\mathcal{W})\neq \mathcal{W}.
$$

PDF 不是 workspace 本身；LaTeX 也不是數學本身；一張 PNG 更不是 glyph 的全部結構。

## 5.2 Serialization

令 serializer 為：

$$
\Sigma_j:\mathcal{W}\rightarrow B_j,
$$

其中 $B_j$ 是某種 bytes / text representation。

MVP 階段可優先使用 UTF-8 JSON/JSONL 或其他容易 diff、驗證與除錯的 representation；正式 runtime 未來可加入 binary carrier。此選擇不改變 abstract object model。

## 5.3 Import 並不保證完全可逆

對 legacy format $L$，importer 可表示為 partial map：

$$
I_L:L\rightharpoonup\mathcal{W}.
$$

例如從 LaTeX 只可能可靠恢復某些 supported subset 的 mathematics；從 PDF 或 PNG 更可能遺失原始語義。故系統必須記錄：

$$
\operatorname{Loss}(I_L),
$$

而不是假裝所有 import 都是 lossless。

---

# 6. 原生數學：公式應該是可計算物件，而不是只有排版語法

定義數學物件：

$$
m=(op,args,type,scope,constraints,assumptions,bindings).
$$

例如偏導：

$$
m_d=(\operatorname{partialDerivative},[f,x],\operatorname{Expression},\Gamma,C,A,B).
$$

渲染與運算是不同操作：

$$
R_k(m_d)\rightarrow \text{view},
$$

$$
E(m_d,\Gamma)\rightarrow(r,\Delta,\rho).
$$

其中：

- $r$：computation result；
- $\Delta$：state change 或 derived objects；
- $\rho$：provenance / execution record。

因此同一物件可以：

1. 顯示成傳統排版；
2. 顯示成 Unicode-friendly linear form；
3. 顯示成 canvas operator node；
4. 匯出成 MathML/OpenMath；
5. 執行 symbolic computation；
6. 連結證明、假設、資料與程式結果。

這就是「原生支援數學計算」與「Markdown 裡可顯示 LaTeX」的本質差別。

---

# 7. Infinite Canvas：空間可以成為 syntax，但不能把幾何關係偷換成語義真理

令物件的 spatial state 為：

$$
p_i=(x_i,y_i,z_i,b_i,\ell_i,r_i),
$$

其中可包含座標、bounding geometry、layer 與 region membership。

系統可以由幾何導出候選關係：

$$
\hat R_{ij}=\Phi(p_i,p_j,g_i,g_j).
$$

例如：

- containment candidate；
- adjacency candidate；
- alignment candidate；
- directional candidate；
- grouping candidate；
- proximity candidate。

但真正 authoritative relation 應區分為：

$$
R=R_{explicit}\cup R_{derived}.
$$

並且：

$$
R_{explicit}\neq R_{derived}.
$$

$R_{explicit}$ 是使用者、程式、importer 或已驗證轉換明確建立的 typed edge；$R_{derived}$ 則帶有 derivation rule、confidence、time/version 與可重新計算性。

這個區分避免一個重要錯誤：使用者只是把兩個物件暫時拖近，不應必然改寫其因果關係。

空間因此可以成為 syntax，但它是**可定義、可驗證、可撤銷的 syntax**。

---

# 8. 多層地址：不要讓一個 UUID 同時扮演所有身份

本文提出最小 address bundle：

$$
A(o)=
(
a^{id},
a^{content},
a^{sem},
a^{space},
a^{phys},
a^{ver}
).
$$

其中：

### 8.1 Identity Address

$$
a^{id}
$$

回答「這是不是同一個持續存在的 workspace object？」

### 8.2 Content Address

$$
a^{content}=H(\operatorname{canonicalContent}(o))
$$

回答「內容是否 byte/structure-equivalent？」

### 8.3 Semantic Address

$$
a^{sem}
$$

回答「它在概念／關係／約束空間中指向什麼？」。PSSA 研究的主要就是這一層，但其表示可為 typed ledger，而非強迫為固定向量或單一 URI。

### 8.4 Spatial Address

$$
a^{space}
$$

描述 object 在某 canvas、region、scope 或 transform tree 中的位置。

### 8.5 Physical Address

$$
a^{phys}
$$

描述檔案、chunk、database page、object store、remote endpoint 或 UTF-8X regional representation 的實際承載位置。

### 8.6 Version Address

$$
a^{ver}
$$

描述 object history 中的特定 revision/state。

於是物件移動時可有：

$$
a^{space}_{t_1}\neq a^{space}_{t_2},
$$

同時：

$$
a^{id}_{t_1}=a^{id}_{t_2}.
$$

物件內容改寫時可能：

$$
a^{content}_{t_1}\neq a^{content}_{t_2},
$$

但仍被人類與系統視為同一 persistent object。

這種分離是無限畫布、collaboration、versioning、AI editing 與 content-addressed storage 共同需要的基礎。

---

# 9. Glyph 不再必須等於 Unicode Code Point

在傳統文字模型中，一個可輸入符號通常期待存在 code point、字型 glyph 或字串組合。但在 ASCS 中，一個 local / domain-specific symbol 可以先被建立為 object：

$$
g_i=(G_i,T_i,S_i,A_i,X_i).
$$

其中它可以有：

- geometry；
- topology；
- semantic address；
- renderer；
- execution binding；
- fallback textual name；
- optional Unicode/PUA mapping；
- version history。

因此：

$$
\operatorname{Existence}(g_i)\not\Rightarrow\operatorname{UnicodeAssigned}(g_i).
$$

這不表示應繞過 Unicode 標準來交換一般文字；而是表示**domain object 的存在權不必由 character encoding standard 決定**。

Generative Symbol Compiler 已提供一條可利用的技術路徑：從 visual source 取得 symbolic geometry/topology，再由 EveGlyph 為其賦予 identity、semantics、address 與 behavior。

---

# 10. 建議的五層架構

本文提出以下概念分層：

## Layer 0 — Transport / Encoding Substrate

主要責任：

- UTF-8 / Unicode text compatibility；
- binary containers；
- hashes；
- compression；
- optional UTF-8X regional representation。

此層回答：**資料如何可靠存在與交換？**

## Layer 1 — Canonical Symbol/Object IR

主要責任：

- object identity；
- typed content；
- semantics；
- geometry；
- relations；
- addresses；
- schema/version。

此層回答：**這個東西是什麼？**

## Layer 2 — Canvas / Spatial Graph

主要責任：

- placement；
- region；
- layer；
- explicit/derived spatial relations；
- infinite canvas navigation。

此層回答：**它在哪裡，與其他物件如何配置？**

## Layer 3 — Computation / Runtime

主要責任：

- operator bindings；
- dependency graph；
- deterministic or declared stochastic execution；
- result objects；
- provenance；
- sandbox / permission / agent invocation。

此層回答：**它能做什麼，以及做過什麼？**

## Layer 4 — Projection / Interaction

主要責任：

- text editor；
- infinite canvas；
- mathematical layout；
- graph view；
- source view；
- Markdown/LaTeX/MathML/HTML/SVG/PDF export；
- accessibility renderers。

此層回答：**使用者與外部系統如何看見與操作它？**

這五層的關鍵原則是：

$$
\text{projection}\neq\text{canonical object}\neq\text{physical encoding}.
$$

---

# 11. AI 在 ASCS 中的角色：生成策略，而非取代可驗證語義

EveGlyph 是 AI-native workspace，但 ASCS 不應把 canonical correctness 建立在「AI 大概理解了」上。

本文採用以下原則：

$$
\text{AI proposal}\rightarrow\text{typed candidate}\rightarrow\text{validator}\rightarrow\text{commit}.
$$

AI 可以：

- 建議 relation；
- 推測 semantic address；
- 產生 glyph grammar；
- 將 legacy LaTeX/Markdown 轉成 candidate IR；
- 重構 canvas；
- 建議 execution graph；
- 搜尋與補充 metadata。

但 deterministic decode、schema validation、hash verification、version transition 與 critical execution contract 應盡可能由非生成式機制負責。

這與 UTF-8X「AI 不參與解碼」的原則相容，也與 EveGlyph 現有 diff-review / validation 路徑一致。

---

# 12. 可證偽性：這不是只靠概念漂亮就成立的架構

ASCS 至少必須通過下列可測試條件。

## 12.1 Object Identity Invariance

若只移動畫布位置：

$$
Move(o,p_1\rightarrow p_2),
$$

則應滿足：

$$
a^{id}_{before}=a^{id}_{after},
$$

且若 content 未改變：

$$
a^{content}_{before}=a^{content}_{after}.
$$

## 12.2 Projection Independence

同一 canonical math object 必須能輸出至少兩種異質 projection，而不以其中任一投影反過來作為 canonical truth：

$$
\Pi_1(m),\Pi_2(m),\Pi_3(m).
$$

## 12.3 Deterministic Serialization Round Trip

對 canonical serialization：

$$
Decode(Encode(o))=o
$$

必須在定義好的 equality rule 下成立。

## 12.4 Executable Semantics

至少一類 native math/code object 必須能由 object semantics 直接執行，而不是先把它轉成畫面文字再重新 parse。

## 12.5 Legacy Import Loss Accounting

對 LaTeX/Markdown/MathML 等 importer，系統必須報告 supported subset、unresolved nodes 與可能遺失的資訊。

## 12.6 Spatial Relation Reproducibility

若某 relation 是由 geometry derivation rule 產生，應能由同版本 rule 與相同 placement 重現：

$$
\Phi_v(P)=R_{derived}.
$$

## 12.7 Source-Independent Symbol Rendering

對支援的 symbolic visual domain，renderer 不得秘密依賴原始 raster source。GSC strict branch 已是此條件的現成基線。

---

# 13. EveGlyph Computational Canvas MVP v0.1 的最小邊界

第一版 MVP 不應試圖完成通用知識宇宙。只需證明以下六件事可以在同一 runtime 中成立。

## MVP-1：Infinite Canvas

可建立、移動、縮放與組織 addressable objects。

## MVP-2：Native Symbol IR

每個 object 有 persistent ID、type、content、version 與 relation record；canvas state 不是唯一資料來源。

## MVP-3：Native Math Object

至少支援：

- variable；
- literal；
- function application；
- arithmetic operators；
- derivative；
- simple equation。

其內部 representation 不以 LaTeX source 為 canonical。

## MVP-4：Executable Computation Node

例如由：

$$
f(x)=x^2
$$

建立 derivative operator，再得到：

$$
\frac{df}{dx}=2x.
$$

執行結果、input object IDs、operator version 與 timestamp/provenance 必須可追蹤。

## MVP-5：Legacy Adapter

至少完成：

- Markdown text import/export；
- LaTeX math import/export；
- MathML export 或 import 其中一個方向；
- JSON canonical/debug serialization。

## MVP-6：Custom Glyph / Symbol Object

使用一個簡化 glyph 或 GSC AssetSymbol 子集證明：非 Unicode-assigned visual symbol 也可以擁有 identity、geometry、semantic binding 與 renderer。

MVP 的成功標準不是畫面炫麗，而是：

$$
\boxed{
\text{One canonical object space}
+
\text{multiple views}
+
\text{native execution}
+
\text{stable addressing}
}
$$

真正成立。

---

# 14. 與現有格式的關係：不是消滅，而是重新定位

| 格式／系統 | ASCS 中的主要定位 |
|---|---|
| UTF-8 / Unicode | 文字與交換基底 |
| UTF-8X | 實驗性的 region-specific reversible storage/physical representation layer |
| Markdown | 人類友善 textual view / interchange adapter |
| LaTeX | 高品質數學排版與 legacy math serialization adapter |
| MathML | Web math interchange / presentation-content adapter |
| OpenMath | semantic mathematical object interoperability adapter |
| OMDoc | mathematical knowledge/document interoperability reference |
| HTML | Web projection |
| SVG | vector projection / geometry interchange |
| PDF | static publication projection |
| PNG/JPEG/WebP | raster projection / imported media |
| Jupyter | executable-document interoperability inspiration / possible adapter |
| EveGlyph Symbol IR | 未來 canonical object contract |
| EveGlyph Canvas | primary spatial interaction view之一，而非唯一 ontology |

這個表達可濃縮成：

$$
\text{Legacy formats}
\xleftrightarrow{Adapters}
\text{Symbol IR}
\xleftrightarrow{Runtime}
\text{Canvas / Computation / Projection}.
$$

---

# 15. 重要非主張與風險邊界

## 15.1 本文不主張修改 Unicode/UTF-8 標準

UTF-8X 與 EveGlyph Symbol IR 都應被視為 UTF-8 之上的實驗架構，而不是宣稱與 UTF-8 相容但實際改變其 decoding semantics 的私有變種。

## 15.2 本文不主張 LaTeX 應被淘汰

LaTeX 仍可長期作為出版與交換工具。本文只否定「LaTeX source 必須等於所有數學系統的 canonical ontology」。

## 15.3 本文不主張位置天然具有唯一語義

位置可提供候選 spatial syntax，但語義必須受規則、類型、版本與使用者／系統確認約束。

## 15.4 本文不主張 PSSA 已證明前語言認知地址存在

目前 PSSA-BSAR 是工程表示假說的受控實驗 harness。任何認知、本體或模型內部機制的更強結論都需要額外證據。

## 15.5 本文不主張 GSC 已解決一般視覺語義壓縮

GSC strict branch 的目前強證據來自限定 domain 下的 source-blind symbolic reconstruction；高階 semantic compression、任意照片、3D scene 或通用生成式視覺仍是不同問題。

## 15.6 本文不主張所有資料都應 object-graph 化

純文字流、log、source code、large tensor、video stream 等資料可能仍需要最適合自身的 representation。ASCS 的目標是提供可掛接與可定址的統一 workspace contract，而不是把每種資料強迫展開成低效率的節點海洋。

---

# 16. 研究貢獻

本文的主要貢獻不是發明每一個構件，而是提出它們的統一架構位置：

1. **提出 ASCS 作為 EveGlyph 的 post-linear document architecture。**
2. **把 canonical object、serialization、projection、execution 與 physical storage 分層。**
3. **把 native computational mathematics 從特殊文字語法提升為 first-class object。**
4. **把 infinite canvas 的 spatial syntax 納入正式模型，同時區分 explicit 與 derived relations。**
5. **提出 identity/content/semantic/spatial/physical/version 六層 address bundle。**
6. **把 GSC 的 source-independent symbolic visual asset 納入一般 glyph/object model。**
7. **把 PSSA 的 address-first 假說限制在可驗證的 semantic-address engineering layer。**
8. **將 UTF-8X 放回正確位置：可逆 storage/physical representation research，而非破壞 UTF-8 的新字元標準。**
9. **為 EveGlyph Computational Canvas MVP 提供可證偽驗收條件。**

---

# 17. 後續系列邊界

本統合論文只定義總體架構，不在此一次解決所有細節。後續正式拆分如下：

## Paper 01 — Addressable Symbolic Object Model

聚焦 object ontology、identity、type、relation、version 與 equality/invariance。

## Paper 02 — Spatial Syntax and Infinite Canvas Computation

聚焦 geometry、topology、region、scope、explicit/derived relation、spatial execution。

## Paper 03 — Native Computational Mathematics Beyond LaTeX

聚焦 native math object、semantic operator、renderer、computation、proof/provenance 與 legacy math adapters。

## Paper 04 — Generative Glyph and Symbol Compilation

聚焦 drawing-to-symbol compilation、geometry/topology、part grammar、symbol identity 與 non-Unicode glyph lifecycle。

## Paper 05 — Multi-Layer Addressing for Computational Documents

聚焦 identity/content/semantic/spatial/physical/version addressing，並與 PSSA、content hash、workspace history 統一。

## TW-01 — EveGlyph Symbol IR Specification

凍結 schema、object types、canonical serialization、validation、version migration 與 interoperability contract。

## TW-02 — UTF-8 / UTF-8X Compatibility & Storage Architecture

凍結 Unicode/UTF-8 compatibility boundary、regional representation、storage、hash、chunk、index 與 reversible transform contract。

## TW-03 — EveGlyph Computational Canvas Runtime Architecture

凍結 canvas engine、execution kernel、renderer/adapter interface、agent boundary、security、diff/commit、MVP deployment。

## MVP-01 — EveGlyph Computational Canvas v0.1

用最小 implementation 證明本文核心 invariants，而不是追求一次完成完整產品。

---

# 18. 結論

數位文件的下一步不必是再發明一套更複雜的標記語言。更根本的方向，是承認：文字語法、數學排版、圖形、空間配置、程式執行與物件身份原本就是不同層次的問題。

UTF-8 解決跨系統文字編碼；LaTeX 解決高品質排版；MathML/OpenMath 解決數學結構與語義交換；OMDoc 將語義提升到數學文件；Jupyter 證明文件可以可執行；Spatial Hypertext 證明位置與視覺組織可以承載 emergent structure。這些都不是應該被丟棄的舊物，而是新的上層架構應該吸收的成熟成果。

EveGlyph 的真正升級因此不應只是：

$$
\text{Markdown}+\text{more plugins}.
$$

而應是：

$$
\boxed{
\text{EveGlyph}
=
\text{Addressable Symbolic Computational Space}
}
$$

其中 Markdown、LaTeX、MathML、HTML、PDF 與圖像都只是不同 projection 或 adapter；canonical state 則由可定址、可版本化、可計算、可空間組織的 symbolic objects 構成。

最終目標不是讓使用者學會另一套更長的語法，而是讓系統直接承認使用者真正想操作的對象：公式就是公式，關係就是關係，符號就是符號，圖形就是圖形，程式就是程式，而它們都能被同一個 workspace 定址、組合、運算、驗證與投影。

換句話說，本文提出的不是「LaTeX 之後要用哪套字串」。

真正的問題是：

> **當符號本身已可被定址、計算、繪製與驗證時，我們是否還需要把字串語法當成世界本身？**

ASCS 的回答是：不需要。字串仍然重要，但它可以回到自己最擅長的位置——成為可靠、可攜、可交換的表示之一，而不是所有數位知識必須服從的唯一存在形式。

---

# References

## External standards and literature

[1] The Unicode Consortium. *The Unicode Standard, Version 17.0.0*. 2025. https://www.unicode.org/versions/Unicode17.0.0/

[2] W3C Math Working Group. *MathML Core*. Candidate Recommendation Snapshot, 24 June 2025. https://www.w3.org/TR/mathml-core/

[3] W3C Math Working Group. *Mathematical Markup Language (MathML) Version 4.0*. Working Draft, 04 June 2026. https://www.w3.org/TR/mathml4/

[4] The OpenMath Society. *The OpenMath Standard, Version 2.0 Revision 2*. July 2019. https://openmath.org/standard/om20-2019-07-01/

[5] Kohlhase, M. *OMDoc — An Open Markup Format for Mathematical Documents [Version 1.2]*. Lecture Notes in Computer Science 4180. Springer, 2006. DOI: 10.1007/11826095.

[6] OMDoc.org. *The OMDoc Format*. https://www.omdoc.org/format/

[7] Kluyver, T., Ragan-Kelley, B., Pérez, F., et al. “Jupyter Notebooks — a publishing format for reproducible computational workflows.” *Positioning and Power in Academic Publishing: Players, Agents and Agendas*, 2016, pp. 87–90. DOI: 10.3233/978-1-61499-649-1-87.

[8] Marshall, C. C., and Shipman, F. M. “Spatial Hypertext: Designing for Change.” *Communications of the ACM*, 38(8), 1995, pp. 88–97.

[9] Shipman, F. M., Marshall, C. C., and Moran, T. P. “Finding and Using Implicit Structure in Human-Organized Spatial Layouts of Information.” *Proceedings of CHI ’95*, 1995, pp. 346–353.

## EveMissLab / project artifacts

[10] EveMissLab. *EveGlyph Editor README*, repository `kakon77777-commits/eveglyph-editor`, current public baseline inspected 2026-08-24.

[11] EveMissLab. *UTF-8X README — 區域動態表示架構*, repository `kakon77777-commits/utf-8x`, v0.22 research engineering baseline inspected 2026-08-24.

[12] EveMissLab. *Generative Symbol Compiler Lab v1.13.0-strict-symbolic — Formal Technical Design v0.1*, including Gate 1–11 design addenda and `AssetSymbol v0.7`, inspected from supplied source archive 2026-08-24.

[13] EveMissLab. *Generative Symbol Compiler Lab v1.13.0-strict-symbolic — VALIDATION*, supplied source archive. Independent rerun in this research session: 105/105 Node tests passed; syntax checks passed for `src/core.js`, `strict-symbolic-app.js`, and `app.js`.

[14] EveMissLab. *PSSA Experiment 01 — Blind Semantic Address Recovery v0.1: Design Specification*, Design Freeze 2026-08-21.

[15] EveMissLab. *PSSA-BSAR v0.1 Milestone 4 Source*, supplied archive. Independent rerun in this research session: 73/73 pytest tests passed. This is engineering/protocol verification only and is not scientific confirmation of the PSSA hypothesis.

---

# Appendix A — 核心形式化摘要

Workspace：

$$
\mathcal{W}=(O,R,P,A,X,H).
$$

Object：

$$
o_i=(\iota_i,\tau_i,c_i,s_i,g_i,a_i,x_i,v_i).
$$

Projection：

$$
\Pi_k:\mathcal{W}\rightarrow V_k.
$$

Serialization：

$$
\Sigma_j:\mathcal{W}\rightarrow B_j.
$$

Legacy import：

$$
I_L:L\rightharpoonup\mathcal{W}.
$$

Math object：

$$
m=(op,args,type,scope,constraints,assumptions,bindings).
$$

Execution：

$$
E(m,\Gamma)\rightarrow(r,\Delta,\rho).
$$

Spatial derived relation：

$$
\hat R_{ij}=\Phi(p_i,p_j,g_i,g_j).
$$

Relation partition：

$$
R=R_{explicit}\cup R_{derived}.
$$

Address bundle：

$$
A(o)=(a^{id},a^{content},a^{sem},a^{space},a^{phys},a^{ver}).
$$

UTF-8X-style reversible regional transform：

$$
D_r(E_r(U))=U.
$$

GSC strict symbolic proposition：

$$
I\xrightarrow{C}S,\qquad \cancel{I},\qquad S\xrightarrow{R}\hat I.
$$

PSSA address-first recovery abstraction：

$$
a=(A_a^+,A_a^-,R_a,C_a,U_a),
$$

$$
\hat G=\operatorname{Materialize}(a).
$$

---

# Appendix B — v0.1 Design Freeze Decisions

1. **UTF-8 保留為底層相容基礎，不建立破壞性私有 UTF-8 解碼規則。**
2. **EveGlyph Symbol IR 才是未來 canonical object contract；Markdown 與 LaTeX 降為 views/adapters。**
3. **數學 object 的 semantics、rendering、execution、provenance 分離。**
4. **Spatial syntax 必須區分 explicit relations 與 derived relations。**
5. **Address 至少分 identity/content/semantic/spatial/physical/version 六層。**
6. **非 Unicode glyph 可以是一級 workspace object，但交換時必須提供 fallback 或 adapter 策略。**
7. **AI 可以生成 candidate structure，但 deterministic decode/validation/version contract 不依賴生成式猜測。**
8. **MVP 先證明 invariants，不追求一次完成通用 IDE、CAS、畫布、知識圖譜與多模態 OS。**
9. **Paper 00 作為後續 01–05、TW-01–03、MVP-01 的 canonical architecture anchor。**


<!-- SOURCE: 01_可定址符號物件模型_身份內容語義關係版本與相等性_v0.1.md -->

# 01｜可定址符號物件模型：身份、內容、語義、關係、版本與相等性

**English Title:** Addressable Symbolic Object Model: Identity, Content, Semantics, Relations, Versioning, and Equality in Computational Documents

**作者：** Neo.K  
**機構：** EveMissLab / 一言諾科技有限公司  
**版本：** v0.1  
**日期：** 2026-08-24  
**文件類型：** 專題論文 / Formal Architecture Paper  
**系列定位：** EveGlyph Addressable Symbolic Computational Space Series — Paper 01  
**前置錨點：** Paper 00 — From Linear Documents to Addressable Symbolic Computational Spaces

---

## Canonical Source Note

本文件以 UTF-8 Markdown 保存正式原稿。數學 source 僅使用 `$...$` 與 `$$...$$` 作為 canonical delimiter。

本文描述的是 **Addressable Symbolic Object Model, ASOM（可定址符號物件模型）** 的抽象語義與不變量，不直接凍結最終 JSON、CBOR、binary container 或資料庫 schema。具體欄位名稱、wire format、schema evolution、canonical byte serialization 與 interoperability contract 將由後續 `TW-01 — EveGlyph Symbol IR Specification` 凍結。

因此本文必須區分：

$$
\text{formal object model}
\neq
\text{wire schema}
\neq
\text{UI representation}.
$$

---

## 摘要

Paper 00 將 EveGlyph 的未來核心從線性文件重新定義為 **Addressable Symbolic Computational Space, ASCS**：文字、數學、程式、圖形、資料、關係與執行節點不再只是 Markdown 或其他文件中的嵌入片段，而是可定址、可版本化、可計算與可投影的一級物件。本文進一步回答其中最基礎的問題：**究竟什麼叫做「同一個物件」？**

傳統檔案與文件系統經常把位置、檔名、內容 hash、URI、記憶體位址、視覺外觀、語義名稱與版本號混合使用。這在簡單文字工作流中通常足夠，但在無限畫布、AI 多代理協作、原生數學物件、視覺符號編譯、內容定址與持續版本歷史中會導致嚴重歧義。例如：一個公式被移動到畫布另一處，它是否成為新物件？一個物件內容改變後，原 identity 是否應消失？兩個 byte-identical 複製物是否就是同一物件？兩個視覺完全相同但語義不同的 glyph 是否相等？一個 AI 將既有物件重構後，如何表示 derivation、fork、merge 與 provenance？

本文提出 ASOM，將 persistent identity、revision identity、content identity、semantic address、spatial placement、physical location 與 projection 分離。本文的核心形式化對象不是單一靜態 tuple，而是 **persistent object + revision graph + relation graph + workspace placement** 的組合。一個持續物件擁有不可重用的 persistent identity；每次其 intrinsic state 改變，可生成新的 revision；內容 hash 用於描述特定 canonical intrinsic state，而不替代 persistent identity；畫布位置則屬於 workspace placement state，移動物件不必改變其內容或 persistent identity。

本文進一步定義多種相等關係：identity equality、revision equality、content equality、formal semantic equivalence、geometric equivalence 與 projection equivalence。這些相等關係彼此不能偷換。例如兩個物件可以 content-equivalent 卻 identity-distinct；也可以 identity-identical 但位於不同 revision。本文亦將 authoritative relation 建模為具有自身 identity、類型、端點、版本與 provenance 的 first-class relation record，並嚴格區分 explicit relations 與 derived relations。

在版本模型上，本文採用 DAG 而非強迫線性歷史，使 branch、merge、AI agent concurrency 與回溯成為一級結構。對 hash address，本文吸收 RFC 6920、Software Hash Identifier（SWHID / ISO/IEC 18670）等 intrinsic identifier 的成熟思想，但拒絕把 content hash 與 persistent object identity 合併。對 provenance，本文採用與 Open Provenance Model / W3C PROV 可映射的 event/derivation 結構。本文最後給出十二項 ASOM 不變量、物件生命週期操作、canonicalization 原則與可直接轉入 MVP / TW-01 的 conformance tests。

**關鍵詞：** Addressable Symbolic Object Model、Persistent Identity、Content Addressing、Revision DAG、Semantic Address、Object Equality、Provenance、EveGlyph、Symbol IR、Versioned Object Graph

---

## Abstract

Paper 00 introduced the Addressable Symbolic Computational Space as a future architectural foundation for EveGlyph. This paper develops the object model required by that proposal and focuses on a deceptively simple question: **what makes a computational document object remain the same object across edits, movement, rendering, derivation, duplication, and version history?**

The Addressable Symbolic Object Model (ASOM) separates persistent identity from revision identity, intrinsic content identity, semantic addressing, spatial placement, physical location, and projection. A persistent object is modeled as an entity with an immutable identity and a version DAG of revisions. Content hashes identify canonical intrinsic states but do not replace persistent identity. Spatial movement is represented as workspace placement state and therefore need not mutate the intrinsic object revision. Relations are modeled as first-class typed records with their own identity, provenance, and version state. Explicit relations are kept distinct from geometry-derived or AI-inferred relations.

The paper defines multiple non-interchangeable equivalence relations, including identity equality, revision equality, content equality, formal semantic equivalence, geometric equivalence, and projection equivalence. It also specifies lifecycle operations such as creation, mutation, movement, clone, fork, merge, aliasing, derivation, tombstoning, and projection. The model is designed to interoperate with content-addressed naming systems, provenance standards, and future distributed or AI-native editing workflows without collapsing all notions of identity into a single hash or URI.

ASOM is not a concrete serialization specification. Instead, it establishes the semantic invariants that a future EveGlyph Symbol IR must preserve regardless of whether the physical representation is UTF-8 JSON, CBOR, a binary object store, a database, or a region-specific UTF-8X carrier.

---

# 1. 問題：在可計算文件裡，「同一個東西」不是單一問題

## 1.1 傳統文件中的隱性 identity

在傳統工作流裡，人類常把下列東西當作物件 identity：

- 檔名；
- 路徑；
- URL；
- 記憶體位址；
- 資料庫 primary key；
- byte hash；
- 畫布座標；
- 顯示文字；
- 視覺外觀；
- 語義名稱。

它們在特定情境中都可以作為有效 locator 或 identifier，但並不是同一概念。

例如一個 EveGlyph 數學物件 $o$ 被從左側移到右側：

$$
Move(o,p_1\rightarrow p_2).
$$

若位置就是 identity，則移動等於刪除舊物件並創建新物件。這與一般使用者直覺不符。

反過來，若 byte hash 就是 identity，則任何內容微小修改都造成：

$$
a^{content}_{t_1}\neq a^{content}_{t_2},
$$

進而被迫推論：

$$
o_{t_1}\neq o_{t_2}.
$$

這同樣不符合「同一份文件物件經過編輯」的常見認知。

因此 ASOM 的第一原則是：

> **identity、content、version、location、semantics 與 appearance 必須分離。**

## 1.2 「相等」本身需要型別

在 ASOM 中，以下問題不能只用一個 `==` 回答：

1. 是否是同一個持續物件？
2. 是否是同一個 revision？
3. 內容是否完全相同？
4. 語義是否等價？
5. 幾何是否等價？
6. 畫面是否看起來相同？
7. 是否來自相同來源？
8. 是否可以被同一運算器替換而不改變結果？

因此本文不定義單一 universal equality，而是定義一族 contextual equivalence relations。

---

# 2. ASOM 的設計目標

ASOM 必須同時滿足下列需求。

## 2.1 持續 identity

物件可在內容、位置、樣式與版本變化後繼續保持同一 persistent identity。

## 2.2 內容可驗證

特定 revision 的 intrinsic content 必須能被 deterministic canonicalization 與 cryptographic digest 驗證。

## 2.3 多模態中立

模型不能假定所有 object 都是文字。至少應能容納：

- text object；
- math object；
- code object；
- glyph / visual symbol；
- data object；
- media reference；
- operator / executable node；
- region / scope；
- relation；
- external reference。

## 2.4 空間與本體分離

物件在畫布中的 placement 不應默認成為其 intrinsic content。

## 2.5 關係可追蹤

authoritative relation 必須能被定址、版本化與追蹤 provenance。

## 2.6 版本不是只有 undo stack

歷史必須允許 branch 與 merge，而非只允許：

$$
v_0\rightarrow v_1\rightarrow v_2\rightarrow\cdots.
$$

## 2.7 AI proposal 與 committed fact 分離

AI 推論出的 semantic link 或 spatial relation 不能在沒有明確 commit 語義時自動變成 authoritative state。

## 2.8 不綁死 physical encoding

相同 ASOM semantics 應能被 UTF-8 JSON、binary container、database、content-addressed store 或 UTF-8X regional carrier 表示。

---

# 3. 基礎集合與 persistent object

令：

$$
\mathbb I
$$

為 persistent identity space，

$$
\mathbb K
$$

為 object kind space，

$$
\mathbb V
$$

為 revision identity space。

一個 persistent object 定義為：

$$
O_i=(i,k,H_i),
$$

其中：

- $i\in\mathbb I$ 為不可變 persistent identity；
- $k\in\mathbb K$ 為 object kind；
- $H_i$ 為此物件的 revision history graph。

核心思想是：

$$
O_i\neq \rho_{i,v}.
$$

$O_i$ 表示「這個持續存在的物件」，而 $\rho_{i,v}$ 表示「這個物件在某一 revision 下的狀態」。

這個區分使：

$$
O_i(t_1)=O_i(t_2)
$$

可以與：

$$
\rho_{i,v_1}\neq\rho_{i,v_2}
$$

同時成立。

---

# 4. Revision：物件狀態而不是物件本體

## 4.1 Revision tuple

一個 revision 可抽象為：

$$
\rho_{i,v}=
(i,v,k,c,s,g,b,m),
$$

其中：

- $i$：persistent identity；
- $v$：revision identity；
- $k$：object kind；
- $c$：intrinsic content payload；
- $s$：semantic structure / semantic annotations；
- $g$：intrinsic geometry / symbolic geometry；
- $b$：behavior or execution bindings；
- $m$：versioned metadata and provenance anchors。

此 tuple 是形式模型，不等於最終 schema。

## 4.2 Intrinsic 與 extrinsic state

ASOM 將狀態分為：

$$
State(o)=State_{intrinsic}(o)\cup State_{extrinsic}(o).
$$

intrinsic state 描述物件本身，例如：

- 文字內容；
- 數學 AST / semantic object；
- glyph geometry；
- operator signature；
- schema-relevant semantics。

extrinsic state 描述物件如何被放入某 workspace，例如：

- canvas position；
- local transform；
- z-order；
- workspace-specific group membership；
- temporary selection；
- viewport visibility。

因此「移動畫布物件」原則上可以只改 extrinsic placement，而不改 intrinsic revision。

---

# 5. Workspace state 與 placement

在時間或 commit state $t$ 下，workspace 定義為：

$$
\mathcal W_t=(Q_t,E_t,P_t,X_t,L_t),
$$

其中：

- $Q_t$：active object revision mapping；
- $E_t$：authoritative relation set；
- $P_t$：placement / spatial state；
- $X_t$：execution/runtime bindings and state references；
- $L_t$：workspace-level provenance / event ledger。

令：

$$
Q_t(i)=v
$$

表示在 workspace state $t$ 中，persistent object $i$ 指向 revision $v$。

令 placement 為：

$$
p_{i,t}=(canvas,region,T,z,\lambda),
$$

其中 $T$ 可為 affine / projective / higher-order transform descriptor，$z$ 為 ordering，$\lambda$ 為 layer/scope information。

於是移動操作：

$$
Move(i,p_{i,t_1}\rightarrow p_{i,t_2})
$$

可滿足：

$$
Q_{t_1}(i)=Q_{t_2}(i),
$$

即 object revision 不變，但 workspace state 改變。

---

# 6. 六類地址：每一類回答不同問題

Paper 00 已提出六層地址。本文將其正式接入 ASOM：

$$
A(O_i,\rho_{i,v},\mathcal W_t)
=
(a^{id},a^{content},a^{sem},a^{space},a^{phys},a^{ver}).
$$

## 6.1 Persistent Identity Address

$$
a^{id}(O_i)=i.
$$

回答：

> 這是不是同一個持續物件？

此 identity 不應因下列操作自動改變：

- edit；
- move；
- rerender；
- serialize；
- export；
- semantic annotation refinement。

persistent identity 一旦退役亦不得被重用。

## 6.2 Content Address

Content address 使用 deterministic canonical intrinsic representation：

$$
a^{content}_{i,v}=H(D_c\Vert C_{\sigma}(I_k(\rho_{i,v}))).
$$

其中：

- $I_k$ 是 object-kind-specific intrinsic boundary function；
- $C_{\sigma}$ 是版本化 canonicalization function；
- $D_c$ 是 domain separator；
- $H$ 是宣告的 cryptographic hash function。

這裡故意不定義為「整個 revision tuple 的 hash」，因為不同 object kind 對「intrinsic content」的界線不同。

例如：

- text object 的 intrinsic content 可能主要是文本與結構；
- math object 的 operator / operands / assumptions 本身就是 intrinsic semantics；
- glyph object 的 symbolic geometry/topology 可屬 intrinsic content；
- canvas position 通常不是 intrinsic content。

## 6.3 Semantic Address

semantic address 不應被誤認為必然是一個 scalar hash。

本文允許：

$$
a^{sem}=(\Omega,A^+,A^-,R,C,U,q,\nu),
$$

其中：

- $\Omega$：schema / ontology / semantic frame；
- $A^+$：positive anchors；
- $A^-$：negative anchors；
- $R$：typed semantic relations；
- $C$：constraints；
- $U$：open variables；
- $q$：confidence / qualification；
- $\nu$：semantic-address version。

這種設計與 PSSA 的 address-first ledger 相容，但 ASOM 不要求所有 semantic address 都使用 PSSA 表示。

formal domain 中 semantic address 可以是 URI/IRI、symbol table path、typed AST address 或 theorem object reference；開放域中則可以是 partial structured address。

## 6.4 Spatial Address

$$
a^{space}_{i,t}=Address(P_t(i)).
$$

它回答物件在特定 workspace/canvas 的位置，而不是回答物件是誰。

因此：

$$
a^{space}_{i,t_1}\neq a^{space}_{i,t_2}
$$

不推出：

$$
a^{id}_{i,t_1}\neq a^{id}_{i,t_2}.
$$

## 6.5 Physical Address

physical address 描述 bytes 或 object records 實際位於何處，例如：

- file path；
- object store key；
- database row/page；
- remote endpoint；
- content-addressed block；
- UTF-8X region/chunk。

physical relocation：

$$
a^{phys}_{t_1}\neq a^{phys}_{t_2}
$$

亦不應改變 persistent identity。

## 6.6 Revision Address

revision address 指向特定 immutable revision state：

$$
a^{ver}(\rho_{i,v})=v.
$$

其 hash 可定義為：

$$
v=H(D_v\Vert C_{\sigma}(R(\rho_{i,v}))),
$$

其中 $R$ 表示被納入 revision commitment 的 canonical revision state。

content address 與 revision address 可以相同算法，但必須使用不同 domain separation 與 canonical input definition。

---

# 7. 為什麼 persistent identity 不能等於 content hash

content-addressed naming 已有成熟先例。RFC 6920 定義以 hash output 命名 digital object 的標準方式；SWHID 進一步以 intrinsic identifiers 與 Merkle structure 對 software artifacts、revision、directory、snapshot 等物件提供可驗證 persistent reference，並已於 2025 年成為 ISO/IEC 18670。

ASOM 吸收其中的優點：

$$
\text{canonical bytes}\rightarrow\text{intrinsic digest}\rightarrow\text{verifiable reference}.
$$

但 ASOM 額外處理「可編輯持續物件」的 identity 問題。

假設：

$$
content(o_{t_1})\neq content(o_{t_2}).
$$

若 identity 等於 content hash，則：

$$
id(o_{t_1})\neq id(o_{t_2}).
$$

這對 immutable archival object 完全合理，卻不適合所有 editor-level entity。

因此 ASOM 採用雙重模型：

$$
\text{persistent identity}
+
\text{immutable revision/content identities}.
$$

persistent object 像一條持續的歷史線；revision/content hash 則像這條歷史上的不可變錨點。

---

# 8. 相等關係族

## 8.1 Identity equality

$$
O_i\equiv_{id}O_j
\iff
i=j.
$$

這表示它們是同一 persistent object。

## 8.2 Revision equality

$$
\rho_{i,v_1}\equiv_{rev}\rho_{j,v_2}
\iff
v_1=v_2
$$

在相同 revision identifier namespace / algorithm contract 下成立。

revision equality 比 identity equality 更強地指定「同一狀態」。

## 8.3 Content equality

$$
\rho_1\equiv_{content}\rho_2
\iff
a^{content}(\rho_1)=a^{content}(\rho_2).
$$

在 collision resistance 與相同 canonicalization contract 假設下，可作為 practical content equivalence。

重要的是：

$$
\rho_1\equiv_{content}\rho_2
\not\Rightarrow
O_1\equiv_{id}O_2.
$$

例如使用者複製一個節點：兩者一開始可以內容完全相同，但仍是兩個物件。

## 8.4 Formal semantic equivalence

當 domain 有明確 theory $\Theta$ 時，可定義：

$$
s_1\equiv_{sem,\Theta}s_2
\iff
\Theta\models(s_1\leftrightarrow s_2).
$$

對數學 expression，也可使用 domain-specific normal form 或 proof certificate 判定。

但在開放語義或自然語言域，semantic equivalence 往往不是二值可判定。因此 ASOM 不把 embedding distance 或 LLM judgement 當作 canonical equality。

可另外定義近似關係：

$$
s_1\approx_{sem,\Gamma,\epsilon}s_2,
$$

其中 $\Gamma$ 是 evaluation context，$\epsilon$ 是 tolerance / policy。`approx` 不得冒充 `equiv`。

## 8.5 Geometric equivalence

對 glyph 或圖形，可依允許的 transform group $G$ 定義：

$$
g_1\equiv_{geo,G}g_2
\iff
\exists T\in G:T(g_1)=g_2.
$$

例如是否允許 translation、rotation、uniform scale、reflection，必須由 domain contract 指定。

## 8.6 Projection equivalence

令 projection $\Pi$ 將 object 投影到某 viewer：

$$
\Pi(o_1)=\Pi(o_2).
$$

只能推出兩者在該 projection 下 observationally equivalent，不能推出 content 或 semantics 相同。

例如兩個 glyph 可以 pixel-identical，但一個表示「加法」，另一個在不同 domain 表示「crossing」。

所以：

$$
o_1\equiv_{proj,\Pi}o_2
\not\Rightarrow
o_1\equiv_{sem}o_2.
$$

---

# 9. Relation 也是一級可定址結構

## 9.1 Relation record

authoritative relation 定義為：

$$
e=
(i_e,src,pred,dst,q,prov,v_e),
$$

其中：

- $i_e$：relation persistent identity；
- $src$：source object reference；
- $pred$：typed predicate；
- $dst$：target object/reference/value；
- $q$：qualifiers / constraints；
- $prov$：provenance；
- $v_e$：relation revision state。

因此 relation 不只是「畫一條線」。

同一視覺箭頭可依 predicate 表示：

- causes；
- dependsOn；
- transformsTo；
- proves；
- references；
- contains；
- derivedFrom；
- flowsTo。

畫面 geometry 只是 projection；predicate 才是 authoritative relation semantics。

## 9.2 Explicit 與 derived relation

定義：

$$
E_t=E^{explicit}_t\cup E^{derived}_t.
$$

explicit relation 由使用者、程式、importer 或 validated transformation 明確 commit。

derived relation 則記錄：

$$
\hat e=(rule,input,output,confidence,version).
$$

例如 proximity inference：

$$
\Phi(P_t(i),P_t(j))\rightarrow\hat e_{near}.
$$

此 $\hat e$ 不自動等於 committed semantic edge。

## 9.3 Promote 操作

AI 或 geometry engine 產生的 relation candidate 可以透過：

$$
Promote(\hat e)\rightarrow e
$$

成為 explicit relation，但 promotion 本身必須產生 event/provenance record。

這使系統能清楚回答：

> 這條關係是使用者明確畫的、AI 推測的、幾何演算法導出的，還是 importer 轉換得到的？

---

# 10. Revision history 應是 DAG

## 10.1 Revision graph

對 persistent object $O_i$，其歷史定義為：

$$
H_i=(V_i,E_i^{parent}),
$$

其中每個 revision $v\in V_i$ 可以有零個、一個或多個 parent revisions。

初始 revision：

$$
Parents(v_0)=\varnothing.
$$

一般 edit：

$$
Parents(v_{n+1})=\{v_n\}.
$$

merge revision：

$$
Parents(v_m)=\{v_a,v_b\}.
$$

因此 ASOM 不把版本歷史限制成單一鏈。

## 10.2 Branch 與 merge

若兩個 agent 從同一 base revision $v_0$ 修改：

$$
v_0\rightarrow v_a,
$$

$$
v_0\rightarrow v_b,
$$

系統應保留兩個 revision，而不是默默覆蓋。

後續可生成：

$$
Merge(v_a,v_b)\rightarrow v_m.
$$

ASOM 本身不指定 merge algorithm。對純文字、AST、canvas graph、CRDT 或 domain-specific semantic object，可以有不同 merge policy。

但 ASOM 強制保留 parentage 與 provenance。

## 10.3 Object history 與 workspace history 分離

單一 object revision history：

$$
H_i
$$

與 workspace commit history：

$$
H_{\mathcal W}
$$

不是同一東西。

一次 workspace commit 可以同時：

- 修改 object A；
- 移動 object B；
- 新增 relation C；
- 產生 execution result D。

因此 workspace event 必須能指向多個 object/relation revisions。

---

# 11. Provenance：狀態之外還要知道「怎麼來的」

## 11.1 Event record

ASOM 定義抽象 event：

$$
e_t=
(i_{evt},actor,op,inputs,outputs,base,tool,policy,time,meta).
$$

其中：

- $actor$ 可為 human、AI agent、system service 或 importer；
- $op$ 為 operation type；
- $inputs$ 為輸入 revisions / relations；
- $outputs$ 為新 revisions / objects / relations；
- $base$ 為執行基準 state；
- $tool$ 為工具及版本；
- $policy$ 為 permission / execution policy；
- $time$ 為時間記錄；
- $meta$ 為可選附加資訊。

此模型可與 Open Provenance Model / W3C PROV 的 entity、activity、agent 觀念映射，但 ASOM 不要求 wire representation 必須直接採用 PROV-O。

## 11.2 Derivation 不等於 identity continuation

若新物件 $O_j$ 從 $O_i$ 衍生：

$$
O_j\xleftarrow{derivedFrom}O_i,
$$

通常：

$$
i\neq j.
$$

也就是「來源相同」不代表「是同一個物件」。

這對 AI transformation 特別重要。

例如 AI 將一張 raster source 編譯成 symbolic glyph asset，合理表示可能是：

$$
O_{symbol}\xleftarrow{generatedBy}C(O_{raster}),
$$

而不是強迫把兩者視為相同 identity。

---

# 12. Lifecycle operations

ASOM 至少定義下列抽象生命週期操作。

## 12.1 Create

$$
Create(k,state)\rightarrow(O_i,\rho_{i,v_0},e).
$$

建立新的 persistent identity 與 root revision。

## 12.2 Mutate

$$
Mutate(O_i,v,\Delta)\rightarrow\rho_{i,v'}.
$$

persistent identity 不變：

$$
a^{id}(v)=a^{id}(v').
$$

若 intrinsic content 改變，則通常：

$$
a^{content}(v)\neq a^{content}(v').
$$

## 12.3 Move

$$
Move(O_i,p_1,p_2)\rightarrow\mathcal W'.
$$

預設只更新 placement，不產生 intrinsic content mutation。

## 12.4 Clone

$$
Clone(O_i,v)\rightarrow(O_j,\rho_{j,v_0}).
$$

其中：

$$
i\neq j,
$$

但初始時可有：

$$
a^{content}(\rho_{i,v})=a^{content}(\rho_{j,v_0}).
$$

因此 clone 是「同內容、新 identity」。

## 12.5 Fork

Fork 與 clone 類似，但必須保留 explicit derivation / lineage：

$$
Fork(O_i,v)\rightarrow O_j,
$$

並建立：

$$
O_j\xleftarrow{forkedFrom}\rho_{i,v}.
$$

## 12.6 Merge

對同 persistent object 的 branch revisions：

$$
Merge(v_a,v_b,\mu)\rightarrow v_m,
$$

其中 $\mu$ 是 declared merge policy。

跨 persistent identities 的「合併」則不能默認為同一 operation；可以建立 composite object、新 identity 或 explicit equivalence/alias，依 domain 決定。

## 12.7 Alias

$$
Alias(name,O_i,scope)\rightarrow a_{alias}.
$$

alias 不建立 identity equality：

$$
Alias(O_i,O_j)\not\Rightarrow i=j.
$$

## 12.8 Derive

$$
Derive(F,inputs)\rightarrow outputs.
$$

新 output 預設取得新 persistent identities，並以 provenance graph 連回 inputs。

## 12.9 Tombstone

刪除採用：

$$
Tombstone(O_i)\rightarrow state_{retired}
$$

而不是 identity reuse。

實體 bytes 可依 retention policy 回收，但 persistent identity 不應被重新分配給其他物件。

## 12.10 Project

$$
Project_{\Pi}(O_i,v)\rightarrow view.
$$

projection 不創建新 object，除非使用者明確把 projection materialize 成新的 addressable artifact。

---

# 13. Canonicalization：hash 之前最重要的是「到底 hash 什麼」

## 13.1 Canonicalization contract

content addressing 若沒有 deterministic canonicalization，hash 只會穩定識別 bytes，而不能穩定識別 abstract content。

因此 ASOM 要求 canonicalization 必須帶版本：

$$
C_{\sigma}:S\rightarrow B,
$$

其中 $\sigma$ 是 schema/canonicalization version。

要求：

$$
x=y\Rightarrow C_{\sigma}(x)=C_{\sigma}(y)
$$

對 canonical semantic equality domain 成立。

並且：

$$
C_{\sigma}(x)
$$

在相同規格、平台與合法輸入上必須 deterministic。

## 13.2 Domain separation

避免不同類型的資料意外共享同一 digest namespace：

$$
Digest_x=H(D_x\Vert bytes).
$$

例如：

$$
D_c=\text{``ASOM:content:v1''},
$$

$$
D_v=\text{``ASOM:revision:v1''}.
$$

即使底層 bytes 相同，content digest 與 revision digest 仍不應被混淆。

## 13.3 Canonicalization 升級

若未來 canonicalization 從 $\sigma_1$ 升級到 $\sigma_2$：

$$
C_{\sigma_1}(x)\neq C_{\sigma_2}(x)
$$

是允許的。

因此 address 必須攜帶足夠資訊讓 validator 知道：

- hash algorithm；
- canonicalization/schema version；
- object kind / domain；
- digest value。

不能只保存一串裸 hash。

---

# 14. Semantic address 不是另一個 content hash

semantic address 的用途是協助定位「意義／關係／約束位置」，不是驗證 bytes。

對一個 partial semantic address $a^{sem}$，resolver 可以返回候選集合：

$$
Resolve_{sem}(a^{sem},\Gamma)
\rightarrow
\{(i_1,q_1),\ldots,(i_n,q_n)\}.
$$

其中 $q_j$ 是 match quality / confidence。

所以 semantic resolution 原生允許：

- 一對多；
- 多對一；
- context sensitivity；
- incomplete address；
- unresolved state。

這與 content address 的 deterministic verification 性質完全不同。

因此禁止以下偷換：

$$
semantic\ similarity\ score
\Rightarrow
persistent\ identity.
$$

也禁止：

$$
embedding\ hash
\Rightarrow
canonical\ meaning.
$$

embedding 可以是 search index；不能自動升格為 meaning identity。

---

# 15. Intrinsic geometry 與 placement geometry 必須分離

Generative Symbol Compiler 已顯示 symbolic visual object 可以具有自己的 geometry/topology。ASOM 因此進一步分成：

$$
g^{int}
$$

與：

$$
p^{ext}.
$$

$g^{int}$ 是 glyph/object 本身的 symbolic geometry，例如輪廓、region、skeleton、part grammar。

$p^{ext}$ 是此 object 在 canvas 上的 transform，例如：

$$
p^{ext}=(x,y,scale,rotation,z,layer).
$$

因此將 glyph 放大兩倍可能只是 placement/view transform：

$$
g^{int}_{before}=g^{int}_{after},
$$

而修改 glyph 本身的一條 stroke 則會改變 intrinsic geometry：

$$
g^{int}_{before}\neq g^{int}_{after}.
$$

這個區分對未來 visual symbol compiler、responsive rendering 與多裝置 projection 都非常重要。

---

# 16. Object kind 與 type discipline

ASOM 不在 Paper 01 凍結完整 taxonomy，但要求每個 object revision 至少存在：

$$
k\in\mathbb K.
$$

初步種類可以包含：

- `text`；
- `math`；
- `code`；
- `glyph`；
- `data`；
- `operator`；
- `region`；
- `relation`；
- `media-ref`；
- `external-ref`；
- `composite`。

kind 的作用不是 UI 分類而已，而是選擇：

- intrinsic boundary function $I_k$；
- canonicalization $C_{k,\sigma}$；
- validator；
- legal relations；
- execution contract；
- projection adapters。

因此：

$$
kind\rightarrow semantics\ of\ validation.
$$

---

# 17. Import / Export 與 identity

## 17.1 Import 不應偷偷假定外部 identity

對 legacy artifact $L$：

$$
Import(L)\rightarrow \mathcal O.
$$

如果 $L$ 不攜帶可驗證 persistent identifiers，importer 不應僅因為：

- 檔名相同；
- 顯示名稱相同；
- 內容近似；
- 位置相同；

就默認與既有 object identity 相同。

可採：

$$
ResolveIdentity(L,\Gamma)\rightarrow
\{new,matched,ambiguous\}.
$$

## 17.2 Export 不應反向綁死 canonical model

輸出 LaTeX、Markdown、MathML、SVG 或 PDF：

$$
Export_F(O_i,v)\rightarrow F
$$

不意味 ASOM object 必須改成 $F$ 的 ontology。

## 17.3 Round-trip fidelity 分級

adapter 應宣告：

$$
Fidelity\in\{lossless,structural,semantic\ subset,visual\ only,unknown\}.
$$

例如 PDF import 很可能只有 visual/textual recovery；OpenMath 對支援 subset 的數學 semantics 可能更高 fidelity。

---

# 18. AI 與多代理協作中的 identity discipline

AI-native editor 會帶來一個新的 identity 風險：模型可能「看起來合理地」重建物件，但誤認為它與既有 object 是同一個。

ASOM 要求 AI operation 至少區分：

$$
EditExisting(i)
$$

與：

$$
CreateDerived(i')
$$

兩種行為。

AI 不得僅因語義相似就自行 collapse identities。

一個 agent proposed patch 應包含 base revision：

$$
Proposal=(i,v_{base},\Delta,prov).
$$

commit 時若 active head 已變：

$$
Q_t(i)\neq v_{base},
$$

系統必須：

- reject；
- branch；
- rebase；
- merge；

四者之一，而不是 silent overwrite。

具體 concurrency policy 將留給 TW-03，但 Paper 01 先凍結這個 identity/version discipline。

---

# 19. 十二項核心不變量

以下構成 Paper 01 的 design freeze。

## I1 — Persistent Identity Immutability

對同一 persistent object：

$$
\forall v\in H_i:\ a^{id}(\rho_{i,v})=i.
$$

## I2 — No Identity Reuse

若 identity $i$ 被 tombstone，後續不得分配給不同 object lineage。

## I3 — Content Hash Does Not Define Persistent Identity

$$
a^{content}(x)=a^{content}(y)
\not\Rightarrow
x\equiv_{id}y.
$$

## I4 — Persistent Identity Does Not Define Revision Equality

$$
x\equiv_{id}y
\not\Rightarrow
x\equiv_{rev}y.
$$

## I5 — Placement Independence

純 `Move` 不得改變 persistent identity 與 intrinsic content address。

## I6 — Deterministic Canonicalization

對相同 abstract state、schema 與 canonicalization version，任兩個合規實作必須滿足：

$$
C^{(1)}_{\sigma}(x)=C^{(2)}_{\sigma}(x).
$$

也就是跨合法平台實作必須生成相同 canonical bytes。

## I7 — Revision Commitment Integrity

宣告的 revision digest 必須等於規格定義之 canonical revision state 的 digest。

## I8 — Relation Provenance

每個 authoritative non-trivial relation 必須可回答其 origin / commit provenance；derived relation 必須標記 derivation rule。

## I9 — Explicit/Derived Separation

$$
E^{explicit}\cap E^{derived}=\varnothing
$$

在 authority semantics 上成立，即 derived candidate 不可被默認當成 committed fact。

## I10 — Projection Non-Authority

視覺 projection 的 equality 不得單獨建立 semantic 或 identity equality。

## I11 — Version Graph Parentage

每個非-root revision 必須有可解析 parent 或明確 external parent reference。

## I12 — Physical Location Non-Identity

physical relocation 不得改變 persistent identity。

---

# 20. Conformance test vectors

以下不是最終測試格式，但可直接轉成 TW-01 / MVP test suite。

## T1 — Edit preserves identity

初始：

$$
O_i@v_1.
$$

修改內容後：

$$
O_i@v_2.
$$

要求：

$$
id(v_1)=id(v_2),
$$

$$
rev(v_1)\neq rev(v_2).
$$

若 intrinsic content 改變：

$$
contentHash(v_1)\neq contentHash(v_2).
$$

## T2 — Move preserves intrinsic state

移動 object 後：

$$
id_{before}=id_{after},
$$

$$
contentHash_{before}=contentHash_{after},
$$

$$
spaceAddress_{before}\neq spaceAddress_{after}.
$$

## T3 — Clone creates distinct identity

clone 後：

$$
id_A\neq id_B,
$$

$$
contentHash_A=contentHash_B.
$$

## T4 — Same rendering does not collapse semantics

兩個 object 在指定 renderer 下：

$$
\Pi(o_1)=\Pi(o_2),
$$

但若 semantic predicates 不同，identity/semantic equality 不得自動成立。

## T5 — Relation candidate remains non-authoritative

geometry engine 產生 $\hat e$ 後，直到 `Promote` / explicit commit 前：

$$
\hat e\notin E^{explicit}.
$$

## T6 — Branch preservation

兩個 agent 同時從 $v_0$ 編輯，系統必須能保留：

$$
v_0\rightarrow v_a,
$$

$$
v_0\rightarrow v_b.
$$

不得 silent overwrite。

## T7 — Merge parentage

merge revision：

$$
Parents(v_m)=\{v_a,v_b\}.
$$

## T8 — Tombstone does not permit reuse

刪除 $i$ 後建立新物件必須取得：

$$
j\neq i.
$$

## T9 — Canonical bytes are reproducible

兩個合規 implementation 對相同 abstract revision：

$$
C^{(1)}_{\sigma}(x)=C^{(2)}_{\sigma}(x).
$$

## T10 — Physical migration preserves identity

從 file storage 遷移到 object store 後：

$$
a^{phys}_1\neq a^{phys}_2,
$$

$$
a^{id}_1=a^{id}_2.
$$

## T11 — Derivation creates provenance edge

若 operator 產生新 object：

$$
O_j=F(O_i),
$$

則 provenance graph 必須記錄 derivation，而不能只留下 output bytes。

## T12 — Semantic address may remain unresolved

對 partial semantic address：

$$
Resolve_{sem}(a,\Gamma)=\varnothing
$$

是合法狀態。系統不得為了「一定要有答案」而強迫生成假 identity。

---

# 21. 與 UTF-8X、GSC、PSSA、EveGlyph 的對接

## 21.1 EveGlyph Editor

現有 EveGlyph 的 workspace、git diff review、MCP、World IR 與 AI agent plumbing 可以成為 ASOM 的 interaction/runtime 前身。未來最大改變是：編輯器不再只把「檔案文字」當最小 canonical unit，而是能操作 persistent object 與 revision graph。

## 21.2 UTF-8X

UTF-8X 適合承擔：

$$
a^{phys}
$$

與 storage/representation 層研究，而不應取代：

$$
a^{id}
$$

或：

$$
a^{sem}.
$$

即：物件可以換 physical representation，而 identity 不變。

## 21.3 Generative Symbol Compiler

GSC 的 strict symbolic output 可以成為 `glyph` / `visual-symbol` kind 的 intrinsic geometry $g^{int}$ 與 content state之一。

source raster 與 symbolic output 應保留 derivation relation，而非被硬判定為同一 persistent identity。

## 21.4 PSSA

PSSA 的 address-first ledger 可作為 $a^{sem}$ 的一種候選 representation，尤其適合 partial / unnamed semantic target。

但 Paper 01 明確限制：

$$
a^{sem}\neq a^{id}.
$$

semantic similarity 或 semantic recovery 成功不能直接證明 persistent identity equality。

---

# 22. 與既有標準的相容位置

## 22.1 RFC 6920

RFC 6920 的 `ni` naming 模型證明以 cryptographic hash 命名 digital object 是成熟、標準化的設計方向。ASOM 將其思想放在 content/revision address，而不是 persistent editable identity。

## 22.2 SWHID / ISO/IEC 18670

SWHID 對 content、directory、revision、release、snapshot 等 object type 使用 intrinsic identifiers 並形成 Merkle DAG，是 ASOM revision/content identity 的重要工程參照。

ASOM 的額外需求是：EveGlyph 中有些 object 是長期可編輯 entity，因此在 immutable revision identifiers 之外再需要 persistent identity。

## 22.3 W3C PROV

W3C PROV 將 provenance 建模為可交換的 entity/activity/agent 關係。ASOM 的 event/provenance ledger 應可建立對應，而不需要重新發明不可互通的 provenance vocabulary。

## 22.4 FAIR

FAIR 原則強調資料與 metadata 的 findability、accessibility、interoperability、reusability。ASOM 的 persistent identifiers、explicit provenance、typed semantics 與 versioned adapters 可視為支援這些目標的底層機制，但 ASOM 本身並不聲稱「採用 ASOM 即自動符合 FAIR」。

---

# 23. 非主張

本文不主張：

1. 所有 persistent identity 都必須使用 UUID；
2. 所有 content address 都必須使用某固定 hash algorithm；
3. 所有 semantic address 都可以被唯一解析；
4. 所有 semantic equality 都可計算判定；
5. 所有 revision graph 都必須採 Git；
6. 所有同步協作都必須採 CRDT；
7. 所有 object 都必須存在獨立 physical file；
8. 所有 relation 都必須顯示在 canvas；
9. hash collision 在數學上不可能；
10. AI 可以根據語義近似自行合併 persistent identities。

ASOM 提出的是 **semantic contract**，而不是特定 storage engine 的壟斷實作。

---

# 24. Paper 01 的 design freeze

完成本文後，後續文件不得在未顯式修訂的情況下破壞以下決策：

1. **Persistent object 與 revision 分離。**
2. **Persistent identity 與 content hash 分離。**
3. **Intrinsic object state 與 workspace placement 分離。**
4. **Content address 使用 versioned deterministic canonicalization。**
5. **Semantic address 不是 content hash，也不是必然唯一。**
6. **Relation 是可定址、可版本化、可追蹤 provenance 的一級結構。**
7. **Explicit relations 與 derived relations 分離。**
8. **Revision history 允許 DAG / branch / merge。**
9. **Clone 可同內容但不同 identity。**
10. **Fork / derive 必須保存 lineage。**
11. **Projection equality 不等於 semantic equality。**
12. **Tombstoned identity 不重用。**

---

# 25. 對後續論文與白皮書的接口

## Paper 02 — Spatial Syntax and Infinite Canvas Computation

直接使用本文的：

$$
P_t,
$$

$$
a^{space},
$$

$$
E^{explicit},E^{derived}
$$

研究空間如何成為可驗證 syntax。

## Paper 03 — Native Computational Mathematics Beyond LaTeX

使用本文的 persistent object、revision、content equality 與 formal semantic equivalence，定義 native math object lifecycle。

## Paper 04 — Generative Glyph and Symbol Compilation

使用 intrinsic geometry $g^{int}$、content addressing 與 derivation provenance，把 GSC output 提升為正式 EveGlyph object kind。

## Paper 05 — Multi-Layer Addressing for Computational Documents

深入展開本文六層 address bundle，尤其 semantic/spatial/physical/version addressing 的 resolution 與 cross-domain mapping。

## TW-01 — EveGlyph Symbol IR Specification

把本文抽象 tuple、relation record、event record、hash domain、canonicalization version 與 test vectors 轉成真正可實作 schema。

## MVP-01

至少實作：

$$
PersistentID
+
RevisionID
+
ContentHash
+
Placement
+
Relation
+
Provenance.
$$

只要這六者能在同一小型 canvas 中被清楚區分，Paper 01 的核心工程命題就可開始被驗證。

---

# 26. 結論

文件系統進入可計算、可定址、AI-native 的階段後，最大的基礎問題之一不是如何畫出更多 UI，而是如何避免把「看起來像同一個東西」與「在系統中確實是同一個東西」混為一談。

ASOM 的核心可以濃縮成：

$$
\boxed{
\text{Persistent Object}
\neq
\text{Revision}
\neq
\text{Content}
\neq
\text{Location}
\neq
\text{Projection}
}
$$

以及：

$$
\boxed{
\text{Identity}
+
\text{Revision DAG}
+
\text{Typed Relations}
+
\text{Provenance}
}
$$

共同構成物件的可追蹤生命史。

content-addressed systems 告訴我們如何穩定指認 immutable digital states；provenance systems 告訴我們如何描述來源、活動與衍生；版本控制系統告訴我們歷史可以是 DAG；semantic systems 告訴我們意義不能簡化成顯示字串。ASOM 的工作，是把這些原本分散的成熟思想重新組合到一個 **可編輯、可空間化、可執行、多模態、AI 協作的 document object model** 中。

因此，一個 EveGlyph object 未來不應只被問：

> 「它的文字是什麼？」

而應能回答：

> 它是誰？現在是哪個 revision？它的 intrinsic content 是什麼？它在什麼語義域？它目前在哪裡？它實際存在哪裡？它和誰有什麼關係？它從哪裡來？由誰或什麼工具修改？哪些關係是明確提交，哪些只是推斷？它可以如何被投影與執行？

當這些問題成為 canonical object contract 的一部分，EveGlyph 才真正從「文件編輯器」跨入 **Addressable Symbolic Computational Workspace**。

---

# References

[1] S. Farrell, D. Kutscher, C. Dannewitz, B. Ohlman, A. Keränen, and P. Hallam-Baker. *RFC 6920: Naming Things with Hashes*. IETF, 2013.

[2] Software Heritage. *SoftWare Hash IDentifier (SWHID) Specification*; standardized as ISO/IEC 18670 in 2025.

[3] R. Di Cosmo, M. Gruenpeter, and S. Zacchiroli. Work on intrinsic persistent identifiers for software source code and Software Heritage identifiers.

[4] L. Moreau, B. Clifford, J. Freire, J. Futrelle, Y. Gil, P. Groth, N. Kwasnikowska, S. Miles, P. Missier, J. Myers, B. Plale, Y. Simmhan, E. Stephan, and J. Van den Bussche. *The Open Provenance Model Core Specification (v1.1)*. 2010.

[5] T. Lebo, S. Sahoo, and D. McGuinness, eds. *PROV-O: The PROV Ontology*. W3C Recommendation, 30 April 2013.

[6] M. D. Wilkinson et al. “The FAIR Guiding Principles for scientific data management and stewardship.” *Scientific Data* 3, 160018, 2016.

[7] M. Kohlhase. *OMDoc — An Open Markup Format for Mathematical Documents [Version 1.2]*. Springer LNCS 4180, 2006.

[8] The OpenMath Society. *The OpenMath Standard, Version 2.0 Revision 2*. 2019.

[9] EveMissLab. *00 — From Linear Documents to Addressable Symbolic Computational Spaces*. v0.1, 2026.

[10] EveMissLab. *UTF-8X — 區域動態表示架構*. research engineering baseline.

[11] EveMissLab. *Generative Symbol Compiler Lab v1.13.0-strict-symbolic*. validated source baseline.

[12] EveMissLab. *PSSA-BSAR v0.1 Milestone 4 Source*. controlled address-first semantic recovery harness.

---

# Appendix A — 最小形式化摘要

Persistent object：

$$
O_i=(i,k,H_i).
$$

Revision：

$$
\rho_{i,v}=(i,v,k,c,s,g,b,m).
$$

Workspace：

$$
\mathcal W_t=(Q_t,E_t,P_t,X_t,L_t).
$$

Address bundle：

$$
A=(a^{id},a^{content},a^{sem},a^{space},a^{phys},a^{ver}).
$$

Content digest：

$$
a^{content}=H(D_c\Vert C_{\sigma}(I_k(\rho))).
$$

Revision digest：

$$
a^{ver}=H(D_v\Vert C_{\sigma}(R(\rho))).
$$

Relation：

$$
e=(i_e,src,pred,dst,q,prov,v_e).
$$

Revision DAG：

$$
H_i=(V_i,E_i^{parent}).
$$

Event：

$$
e_t=(i_{evt},actor,op,inputs,outputs,base,tool,policy,time,meta).
$$

Identity equality：

$$
O_i\equiv_{id}O_j\iff i=j.
$$

Content equality：

$$
\rho_1\equiv_{content}\rho_2
\iff
a^{content}(\rho_1)=a^{content}(\rho_2).
$$

Formal semantic equivalence：

$$
s_1\equiv_{sem,\Theta}s_2
\iff
\Theta\models(s_1\leftrightarrow s_2).
$$

Semantic resolution：

$$
Resolve_{sem}(a,\Gamma)
\rightarrow
\{(i_j,q_j)\}_{j=1}^{n}.
$$

---

# Appendix B — Implementation-facing checklist

在 TW-01 / MVP 實作開始前，至少必須回答：

1. persistent ID 使用何種 namespace / generation policy？
2. object kind registry 如何版本化？
3. 每個 kind 的 intrinsic boundary function 是什麼？
4. canonicalization version 如何寫入 address？
5. content digest 與 revision digest 使用哪些 domain separators？
6. relation 是否採獨立 persistent ID？
7. placement 是 workspace-local 還是可跨 workspace address？
8. tombstone / retention policy 如何處理？
9. import 時外部 identity 如何 map？
10. semantic address 如何標記 unresolved / approximate / authoritative？
11. AI-generated relation candidate 如何 promote？
12. revision DAG 如何存 parent references？
13. merge policy 是否按 object kind 分流？
14. provenance 如何映射 W3C PROV？
15. 哪些欄位進 content digest，哪些只進 revision digest？
16. round-trip equality 使用哪一種 equality relation 驗收？

Paper 01 不替 TW-01 預先猜答案；它只要求任何答案都不能破壞本文已凍結的不變量。


<!-- SOURCE: 02_空間語法與無限畫布計算_從幾何配置到可驗證執行結構_v0.1.md -->

# 02｜空間語法與無限畫布計算：從幾何配置到可驗證執行結構

**English Title:** Spatial Syntax and Infinite Canvas Computation: From Geometric Arrangement to Verifiable Executable Structure

**作者：** Neo.K  
**機構：** EveMissLab / 一言諾科技有限公司  
**版本：** v0.1  
**日期：** 2026-08-24  
**文件類型：** 專題論文 / Formal Architecture Paper  
**系列定位：** EveGlyph Addressable Symbolic Computational Space Series — Paper 02  
**前置錨點：** Paper 00 — From Linear Documents to Addressable Symbolic Computational Spaces；Paper 01 — Addressable Symbolic Object Model

---

## Canonical Source Note

本文件以 UTF-8 Markdown 保存正式原稿。數學 source 僅使用 `$...$` 與 `$$...$$` 作為 canonical delimiter。

本文中的「無限畫布」不是對實體記憶體或可計算資源真正無限的宣稱，而是指一個**邏輯上無預先固定頁面邊界、可持續擴張、可分區、可縮放與可巢狀化的座標／關係空間**。任一具體執行時刻仍只有有限物件、有限已實體化區域與有限計算資源。

本文凍結的是 spatial semantics、authority model、parse/commit boundary 與 execution invariants，不直接凍結最終 Canvas UI、GPU renderer、spatial index、CRDT、R-tree、quadtree 或資料庫實作。這些將由 TW-03 與 MVP-01 決定。

因此：

$$
\text{spatial semantics}
\neq
\text{rendering engine}
\neq
\text{spatial index}.
$$

---

## 摘要

線性文件將主要結構投射到字元順序：前後、段落、標題與巢狀標記共同形成可解析語法。但在白板、圖表、數學板書、流程圖、電路圖、知識圖譜與無限畫布中，人類同時使用位置、距離、包含、對齊、方向、群組、連線、區域與重複配置來表達結構。Spatial Hypertext 與 VIKI 等研究早已顯示，人類會以 proximity、visual grouping、recurrence 與 spatial context 建立可被辨識的 emergent structure；visual-language research 也以 picture layout grammar 等方法證明二維配置可以具有可形式化、可解析的 syntax。

然而，若把「任何空間配置」直接等同於「權威語義」，就會產生新的錯誤。使用者拖曳一個節點經過另一節點時，暫時的靠近不應自動建立因果關係；縮放、重新排版、responsive layout 或 AI 自動整理也不應任意改寫執行圖。相反地，如果系統完全忽略空間，只把畫布當成漂亮的視覺外殼，又會失去無限畫布相對線性文件最重要的表達能力。

本文提出 **Spatial Syntax Model for Addressable Symbolic Computational Space, SS-ASCS**。其核心主張是：空間可以成為 syntax，但必須經過型別化、版本化、可驗證與具有 authority boundary 的轉換。本文將空間關係分為三層：`transient spatial state`、`derived spatial candidates` 與 `explicit committed relations`。使用者拖曳、縮放與手勢首先只改變 transient/placement state；幾何解析器可依版本化規則推導 containment、adjacency、alignment、ordering、connection 等候選關係；只有被 grammar rule、explicit tool action、validated operator 或使用者／代理明確 commit 的關係，才可成為 authoritative relation，進一步影響計算與語義。

本文進一步提出多層座標模型、intrinsic geometry 與 extrinsic placement 的分離、region/scope semantics、spatial grammar、derived relation confidence、hysteresis、semantic zoom、nested canvas、canonical spatial normalization，以及 layout graph 與 execution graph 的分離。對真正的 spatial computation，本文定義一個受控的 compilation path：

$$
\text{Placement}
\rightarrow
\text{Spatial Parse}
\rightarrow
\text{Candidate Relations}
\rightarrow
\text{Validation / Commit}
\rightarrow
\text{Executable Graph}.
$$

其目的不是把所有圖像都宣稱為程式，而是允許某些被明確宣告的 canvas region、operator grammar 或 domain profile 將空間配置編譯為可執行結構，同時保留一般自由畫布的低形式性。本文最後提出十五項空間不變量與 MVP conformance tests，為後續 Native Computational Mathematics、Generative Glyph、Symbol IR 與 Computational Canvas Runtime 提供共同基礎。

**關鍵詞：** Spatial Syntax、Infinite Canvas、Spatial Hypertext、Visual Language、Spatial Parsing、Addressable Symbolic Computational Space、Canvas Computation、Explicit Relation、Derived Relation、Semantic Zoom、Nested Canvas、EveGlyph

---

## Abstract

Linear documents encode much of their structure through sequence. Infinite canvases, diagrams, whiteboards, mathematical notations, and visual programs instead rely on spatial relations such as proximity, containment, alignment, direction, connection, overlap, grouping, and region membership. Prior work in spatial hypertext has shown that users create meaningful emergent structures through spatial organization, while research on visual languages has demonstrated that two-dimensional arrangements can be specified and parsed through formal visual grammars.

A computational canvas, however, cannot safely equate every geometric arrangement with authoritative semantics. Temporary dragging, automatic layout, zooming, responsive rendering, or incidental proximity must not silently rewrite causal, logical, or executable relationships. This paper therefore introduces a spatial syntax model for the Addressable Symbolic Computational Space (SS-ASCS) in which spatial information is divided into transient placement state, derived spatial candidates, and explicitly committed relations.

The model separates intrinsic object geometry from extrinsic workspace placement, distinguishes world, region, local, and view coordinate systems, and represents spatial parsing as a versioned deterministic transformation from placement state into typed candidate relations. Candidate relations may be promoted to authoritative relations only through explicit or validated commit operations. Execution graphs remain distinct from layout graphs; spatial configuration affects execution only inside declared spatial-language domains or through committed spatial operators.

The paper defines region and scope semantics, nested canvases, semantic zoom, spatial normalization, tolerance and hysteresis policies, concurrency rules, and a compilation pathway from spatial arrangement to executable graph. It concludes with formal invariants and conformance tests intended to guide the future EveGlyph Symbol IR and Computational Canvas MVP.

---

# 1. 從線性 syntax 到空間 syntax

## 1.1 線性文件的主要結構來源

傳統文字文件可抽象為：

$$
D=(c_1,c_2,\ldots,c_n).
$$

其結構主要依賴：

$$
\operatorname{order}(c_i,c_j),
$$

以及 delimiter、markup、indentation、nesting 與 parser grammar。

即使最後被排版成二維頁面，canonical syntax 通常仍可回收到某個有序序列或樹。

## 1.2 畫布中的結構來源更多

對一個 spatial workspace，單純的 token order 不足以描述使用者表達的結構。至少還存在：

- containment；
- adjacency；
- proximity；
- alignment；
- overlap；
- directional ordering；
- connection；
- grouping；
- region membership；
- layer/scope；
- repeated pattern；
- local frame transformation。

因此空間狀態可粗略寫為：

$$
P_t=\{p_{i,t}\}_{i=1}^{n}.
$$

其中每個物件的 placement 不只是單一 $(x,y)$，而可以包含：

$$
p_{i,t}=(F,T,B,z,\lambda,r).
$$

$F$ 為 coordinate frame，$T$ 為 transform，$B$ 為 placement bounding geometry，$z$ 為 ordering，$\lambda$ 為 layer，$r$ 為 region/scope membership。

## 1.3 空間的兩難

如果系統採用：

$$
\text{geometry}=\text{semantics},
$$

則每一次拖曳、縮放與 layout optimization 都可能變成 semantic mutation。

如果採用：

$$
\text{geometry}\perp\text{semantics},
$$

則無限畫布又退化成純 UI，無法承載原生圖形語法。

本文選擇第三種模式：

$$
\boxed{
\text{geometry}
\rightarrow
\text{typed candidate structure}
\rightarrow
\text{committed semantics}
}
$$

也就是空間**可以**成為 syntax，但不因存在空間而**自動**成為 syntax。

---

# 2. 既有研究：空間能承載結構，但隱性結構與正式語法不同

## 2.1 Spatial Hypertext 與 VIKI

Marshall、Shipman 等人的 spatial hypertext 研究指出，使用者會透過位置、靠近、視覺群組與重複出現等方式形成 implicit structure。VIKI 更將 semi-structured objects、collections、composites 與 spatial parser 放入同一系統，允許 emergent structure 逐步提升為更正式的結構。

這一研究方向對 EveGlyph 有兩個直接啟示。

第一，使用者未必想在思考初期就寫出完整 schema。低形式性的空間配置本身具有認知與創作價值。

第二，系統可以辨識 implicit structure，但辨識結果不應與使用者明確宣告的 structure 混為一談。

因此 SS-ASCS 將 spatial parser 的輸出定義為 candidate relation，而不是直接寫入 canonical truth。

## 2.2 Visual Language 與 Picture Layout Grammar

Golin 與 Reiss 的 picture layout grammar 研究將二維 visual language 的邏輯結構與 layout 納入 grammar，並用 spatial parsing 從 picture 中恢復 syntactic structure。後續研究進一步提出 parsing algorithm，說明 visual program 可以經由 grammar specification 解析為 underlying tree/structure。

這證明一件重要事情：

$$
\text{2D arrangement}
$$

並不必然只能是視覺裝飾，它可以形成真正的 formal syntax。

但 EveGlyph 所需的模型比特定 visual programming language 更一般，因為同一 canvas 中可能同時存在：

- 完全自由的草圖區；
- 半形式的概念整理區；
- 強形式的數學區；
- 可執行 dataflow region；
- 只是排版用途的圖片與文字。

因此系統需要 **local formality**，而不是把整個 canvas 強制變成一種 grammar。

---

# 3. Infinite Canvas 的操作性定義

本文定義 infinite canvas 為邏輯空間：

$$
\mathcal C=(\mathbb F,\mathcal R,\mathcal O,\mathcal P),
$$

其中：

- $\mathbb F$ 為 coordinate frame set；
- $\mathcal R$ 為 region/scope set；
- $\mathcal O$ 為可被放置的 ASOM persistent objects；
- $\mathcal P$ 為 placement states。

「Infinite」在此只要求：

$$
\nexists B_{fixed}
$$

使所有合法 workspace object 永久被限制在預先固定的單頁矩形 $B_{fixed}$ 內。

它不要求：

$$
|\mathcal O|=\infty
$$

在任一實際時間成立，也不要求實體儲存無限。

因此更精確地說，EveGlyph 使用的是：

> logically unbounded, finitely materialized computational canvas。

---

# 4. 四層座標與 frame 模型

單一 global $(x,y)$ 無法支撐 nested canvas、component reuse、semantic zoom 與跨區域投影。本文至少區分四層 frame。

## 4.1 World frame

$$
F_W
$$

表示 workspace 的邏輯世界座標。

## 4.2 Region frame

每個 region $r$ 可有局部 frame：

$$
F_r.
$$

轉換為：

$$
T_{r\rightarrow W}:F_r\rightarrow F_W.
$$

## 4.3 Object-local frame

物件 intrinsic geometry 存在於：

$$
F_i^{local}.
$$

placement transform：

$$
T_{i\rightarrow r}:F_i^{local}\rightarrow F_r.
$$

## 4.4 View frame

螢幕、VR viewport、PDF projection 或其他 viewer 使用：

$$
F_V.
$$

其 transformation：

$$
T_{W\rightarrow V}:F_W\rightarrow F_V.
$$

最重要的不變量是：

$$
T_{W\rightarrow V}
$$

的改變不得自動改變 canonical spatial semantics。

也就是 zoom/pan 是 view change，不是 object move。

---

# 5. Intrinsic Geometry 與 Extrinsic Placement

Paper 01 已將 intrinsic geometry 與 placement 分離。本文正式使用：

$$
g_i^{int}
$$

表示物件自身 geometry/topology，並使用：

$$
p_{i,t}^{ext}
$$

表示在 workspace 中的放置。

對 glyph：stroke、contour、skeleton、part grammar 可以屬於 $g_i^{int}$。

對同一 glyph 的平移、縮放、旋轉通常屬於 $p_{i,t}^{ext}$。

因此：

$$
Move(i)
$$

可以滿足：

$$
g_{i,before}^{int}=g_{i,after}^{int}.
$$

而 `EditGlyphStroke` 則可以滿足：

$$
g_{i,before}^{int}\neq g_{i,after}^{int}.
$$

這個邊界是 spatial syntax 能否穩定的前提。

---

# 6. 三層空間權威模型

SS-ASCS 的核心由三層組成。

## 6.1 Transient Spatial State

拖曳、框選、gesture、磁吸預覽、動畫與 auto-layout 中間態先進入：

$$
P_t^{transient}.
$$

其特徵是：

- 高頻變化；
- 可撤銷；
- 不必寫入 persistent revision；
- 不直接改變 authoritative relations；
- 不直接觸發 semantic execution。

## 6.2 Derived Spatial Candidates

由 spatial parser 依版本化規則計算：

$$
\Phi_{\sigma}(P_t,G,K)\rightarrow \widehat E_t.
$$

其中：

- $\sigma$ 為 parser/grammar version；
- $P_t$ 為 committed 或 snapshot placement；
- $G$ 為 intrinsic geometries；
- $K$ 為 object kinds / region profile；
- $\widehat E_t$ 為 candidate relation set。

candidate 可以包含：

$$
\hat e=(src,pred,dst,q,rule,confidence,\sigma).
$$

## 6.3 Explicit Committed Relations

只有經過 commit path 的 relation：

$$
Promote(\hat e,authority)\rightarrow e
$$

或由 explicit tool action 直接建立的 relation，才進入：

$$
E_t^{explicit}.
$$

因此：

$$
\widehat E_t\cap E_t^{explicit}=\varnothing
$$

在 authority semantics 上成立。

這是 Paper 02 最重要的 design freeze。

---

# 7. Spatial Predicate Vocabulary

不同 domain 可以擴張 predicate，但核心空間層至少可定義以下類別。

## 7.1 Topological predicates

例如：

$$
Inside(A,B),
$$

$$
Contains(B,A),
$$

$$
Overlaps(A,B),
$$

$$
Touches(A,B),
$$

$$
Disjoint(A,B).
$$

## 7.2 Metric predicates

例如：

$$
Distance(A,B)=d.
$$

由 threshold 可導出：

$$
Near_{\epsilon}(A,B).
$$

但 `near` 必須攜帶 profile / threshold，不得假裝為 universal truth。

## 7.3 Directional predicates

例如：

$$
LeftOf(A,B),
$$

$$
Above(A,B),
$$

$$
BeforeAxis_x(A,B).
$$

其 coordinate frame 必須被明確指定。

## 7.4 Alignment predicates

例如：

$$
Aligned_x(A,B,\epsilon),
$$

$$
Aligned_y(A,B,\epsilon).
$$

## 7.5 Connection predicates

視覺 connector 可生成：

$$
Connected(A,B,port_a,port_b).
$$

但 connector geometry 與 semantic edge predicate 仍需分離；同一條線可以被 domain grammar 解讀為 dataflow、proof dependency、causality 或 annotation link。

## 7.6 Region predicates

例如：

$$
MemberOf(A,R),
$$

$$
ScopedBy(A,R).
$$

這些 predicate 若被 explicit commit，可直接影響 name resolution、execution environment 或 visibility policy。

---

# 8. Region：從畫框提升為可計算 scope

## 8.1 Region object

region 本身應是一級 object：

$$
R_j=(i_j,b_j,F_j,\pi_j,\gamma_j).
$$

其中：

- $i_j$：region persistent identity；
- $b_j$：region boundary；
- $F_j$：local coordinate frame；
- $\pi_j$：policy/profile；
- $\gamma_j$：optional grammar/runtime binding。

## 8.2 Visual containment 不必等於 scope containment

如果物件暫時被拖進 region，geometry parser 可以產生：

$$
\widehat{Inside}(O_i,R_j).
$$

但只有 commit 後才可能建立：

$$
ScopedBy(O_i,R_j).
$$

因此：

$$
Inside_{geometry}
\not\Rightarrow
ScopedBy_{semantic}.
$$

## 8.3 Region profile

region 可以宣告：

$$
\pi_j=(grammar,unitSystem,namespace,executionPolicy,snapPolicy,authorityPolicy).
$$

這使同一無限畫布可以局部存在不同語言。

例如：

- Region A：自由筆記，不解析 proximity；
- Region B：數學排版區，解析 baseline、fraction、superscript；
- Region C：dataflow 區，connector 代表 execution edge；
- Region D：GSC glyph 設計區，geometry/topology 有 intrinsic editing semantics。

這就是 **local formality**。

---

# 9. Spatial Grammar

## 9.1 Grammar 定義

本文定義一個 spatial grammar：

$$
\mathcal G_s=(\Sigma,N,\mathcal P,\Psi,\mathcal A,\nu).
$$

其中：

- $\Sigma$：terminal object kinds / primitive marks；
- $N$：non-terminal structural types；
- $\mathcal P$：production rules；
- $\Psi$：spatial predicates；
- $\mathcal A$：semantic actions / candidate relation constructors；
- $\nu$：grammar version。

## 9.2 Parse

對 region snapshot：

$$
S_r=(O_r,P_r,G_r),
$$

parser 執行：

$$
Parse_{\mathcal G_s}(S_r)
\rightarrow
(T,\widehat E,D).
$$

其中：

- $T$：parse structure；
- $\widehat E$：candidate relations；
- $D$：diagnostics / ambiguity / unresolved structure。

## 9.3 Ambiguity 是合法狀態

視覺／空間語法往往不是唯一解析。因此：

$$
Parse(S_r)
\rightarrow
\{(T_1,q_1),\ldots,(T_n,q_n)\}
$$

是合法輸出。

系統不得因為需要單一答案而強迫：

$$
q_{max}<\theta
$$

時仍 commit 某個 parse。

可以保留：

$$
Ambiguous(S_r).
$$

這與 PSSA 中 unresolved semantic address 的哲學一致：**不確定可以被正式保存。**

---

# 10. Tolerance、Hysteresis 與 Drag Stability

## 10.1 為什麼 threshold 不夠

若 `Near` 的條件只是：

$$
d(A,B)<\epsilon,
$$

使用者在 threshold 附近拖曳時可能造成 relation 不斷閃爍。

因此使用 hysteresis：

$$
\epsilon_{enter}<\epsilon_{leave}.
$$

建立候選關係條件：

$$
d<\epsilon_{enter}.
$$

維持候選關係直到：

$$
d>\epsilon_{leave}.
$$

## 10.2 Gesture transaction

一次拖曳應被視為 transaction：

$$
BeginGesture
\rightarrow
Update^{*}
\rightarrow
EndGesture.
$$

只有 `EndGesture` 或明確 checkpoint 後才進行 canonical spatial parse。

因此高頻 pointer move 不需要每一幀都生成 persistent relation revisions。

## 10.3 Preview 與 commit

UI 可以在拖曳時顯示：

- snapping hint；
- candidate group；
- candidate connector；
- candidate region membership。

但 preview state：

$$
Preview(\hat e)
$$

不等於：

$$
Commit(e).
$$

---

# 11. Layout Graph 與 Execution Graph 分離

這一節是「可計算畫布」最重要的安全與語義邊界之一。

## 11.1 Layout graph

由空間狀態與 explicit spatial relations 形成：

$$
G_L=(V,E_L).
$$

## 11.2 Execution graph

真正的 computation dependency graph：

$$
G_X=(V_X,E_X).
$$

一般情況下：

$$
G_L\neq G_X.
$$

也不要求：

$$
E_L\subseteq E_X.
$$

## 11.3 Spatially executable region

只有當 region 明確宣告：

$$
\gamma_r=ExecutableSpatialGrammar
$$

時，才允許 compiler：

$$
Compile_r(T,E^{explicit})\rightarrow G_X.
$$

例如 dataflow region 中，明確連接 operator port 的 edge 可以被編譯為 data dependency。

自由筆記區中的兩個靠近文字則不應進入 execution graph。

## 11.4 移動不應默認重寫計算

對一般 object move：

$$
Move(O_i,p_1,p_2)
$$

預設要求：

$$
G_X^{before}=G_X^{after}.
$$

除非此 move 在 active spatial grammar 中造成經 commit 的 structural change。

因此 EveGlyph 可以既允許「位置有語義」，又不讓「所有位置都有執行副作用」。

---

# 12. 從空間配置到可執行圖的 compilation path

本文凍結以下路徑：

$$
P
\xrightarrow{Snapshot}
S
\xrightarrow{Parse_{\nu}}
(T,\widehat E,D)
\xrightarrow{Validate}
(T',\widehat E')
\xrightarrow{Promote/Commit}
E^{explicit}
\xrightarrow{Compile_{\gamma}}
G_X.
$$

每一階段都必須可追蹤 provenance。

## 12.1 Snapshot

固定一個可重現的 placement state：

$$
S=Snapshot(P_t).
$$

## 12.2 Parse

使用已知 parser/grammar version：

$$
Parse_{\nu}(S).
$$

## 12.3 Validate

檢查：

- type compatibility；
- region policy；
- port validity；
- ambiguity；
- forbidden cycle；
- required cardinality；
- namespace constraints。

## 12.4 Commit

建立 ASOM relation revisions 與 event provenance。

## 12.5 Compile

只有 declarative spatial-language profile 才能把 committed structure 轉成 execution IR。

## 12.6 Execute

Runtime 執行：

$$
Exec(G_X,\Gamma)\rightarrow(result,trace,state').
$$

這樣 AI、UI、spatial parser 與 runtime 的權責就不會混在一起。

---

# 13. Canonical Spatial Representation

## 13.1 浮點座標不是理想 canonical truth

直接把 viewport float 當 canonical semantics 會帶來：

- platform rounding；
- renderer differences；
- transform accumulation；
- zoom-dependent error；
- nondeterministic threshold crossing。

因此 Paper 02 要求 spatial semantics 使用版本化 normalization：

$$
N_{\sigma}(P)\rightarrow P^{canon}.
$$

可能策略包括：

- fixed-point coordinates；
- rational coordinates；
- declared quantization grid；
- canonical transform decomposition；
- geometry predicates based on normalized bounds。

Paper 02 不決定哪一種，但要求 TW-01/TW-03 必須選定 deterministic contract。

## 13.2 View transform 不進 semantic hash

zoom/pan：

$$
T_{W\rightarrow V}
$$

不得進入 object intrinsic content hash，也預設不得進入 authoritative spatial relation hash。

## 13.3 Spatial state hash

對需要版本化的 committed placement，可定義：

$$
a^{spaceState}=H(D_s\Vert C_{\sigma}(P^{canon})).
$$

但它仍不同於 persistent object identity 與 intrinsic content hash。

---

# 14. Nested Canvas 與 Recursive Region

## 14.1 Canvas 可以是 object

一個 canvas/region 可以被當成 addressable object：

$$
C_j\in\mathcal O.
$$

其內部又包含：

$$
\mathcal W_j=(Q_j,E_j,P_j,X_j,L_j).
$$

因此可形成：

$$
\mathcal W_0
\supset
\mathcal W_1
\supset
\mathcal W_2
\supset\cdots
$$

但任一實際 workspace snapshot 仍是有限實體化。

## 14.2 Local frame composition

巢狀 object 的 world transform：

$$
T_{i\rightarrow W}
=
T_{r_0\rightarrow W}
\circ
T_{r_1\rightarrow r_0}
\circ\cdots\circ
T_{i\rightarrow r_n}.
$$

## 14.3 Scope inheritance

region policy 可以定義 inheritance：

$$
Policy_{eff}(i)=ResolvePolicy(R_0,R_1,\ldots,R_n).
$$

例如 unit system、namespace、execution permission 可以由外層繼承，再被內層合法覆寫。

---

# 15. Semantic Zoom：投影改變不等於物件改變

Infinite canvas 常使用 semantic zoom：距離遠時顯示摘要，放大後顯示細節。

定義 projection：

$$
\Pi(o,z,\Gamma)\rightarrow view_z.
$$

其中 $z$ 是 zoom/context parameter。

可以有：

$$
\Pi(o,z_1)\neq\Pi(o,z_2),
$$

但：

$$
a^{id}_{z_1}=a^{id}_{z_2}
$$

以及若未編輯 intrinsic state：

$$
a^{content}_{z_1}=a^{content}_{z_2}.
$$

例如遠距離看到一個 theorem node 名稱，近距離展開完整公式；兩者只是不同 projection。

因此 semantic zoom 不應以「切換到另一份內容檔」的假 identity model 實作。

---

# 16. Grouping、Container 與 Scope 不得混為一談

三個概念必須分開。

## 16.1 Visual group

表示共同移動／選取：

$$
Group_{visual}(A,B,C).
$$

## 16.2 Geometric container

表示幾何包含：

$$
Contains_{geo}(R,A).
$$

## 16.3 Semantic scope

表示名稱、規則或執行作用域：

$$
ScopedBy(A,R).
$$

三者可以同時成立，也可以彼此獨立。

例如使用者把三個物件框選成 visual group，不應自動讓它們進入新的 namespace。

因此：

$$
Group_{visual}
\not\Rightarrow
ScopedBy.
$$

---

# 17. Connection 與 Connector Geometry

## 17.1 Connector 本身是 object/relation projection

一條線可以有自己的 persistent identity：

$$
O_{conn}.
$$

或只是 relation $e$ 的 projection。

兩種實作都合法，但 TW-01 必須明確區分。

## 17.2 Endpoint semantics

真正的 authoritative connection 應至少知道：

$$
(src,srcPort,predicate,dst,dstPort).
$$

而不是只知道 line endpoints 的 pixel coordinates。

## 17.3 Re-route 不等於 relation mutation

connector path 改變：

$$
Path_1\neq Path_2
$$

若 endpoints/predicate 未變，則 semantic relation 可以保持不變。

這與 object move / identity 分離同構。

---

# 18. AI 在 Spatial Syntax 中的角色

AI 可以：

- 建議 grouping；
- 推測 relation type；
- 根據內容與位置產生 candidate edges；
- 建議 layout；
- 將草圖轉成 formal region；
- 建議 spatial grammar；
- 將 ambiguous parse 排序。

但 AI proposal 必須保持：

$$
AIProposal\subseteq CandidateLayer.
$$

除非 policy 明確授權，AI 不得直接把：

$$
\hat e
$$

寫成：

$$
e\in E^{explicit}.
$$

對可執行 region，更應採：

$$
AI\rightarrow Proposal
\rightarrow DeterministicValidator
\rightarrow Commit
\rightarrow Runtime.
$$

這延續 Paper 00 的 deterministic validation 原則。

---

# 19. Collaborative Editing 與 Spatial Conflict

Paper 01 已允許 revision DAG。Spatial state 也需要獨立 conflict semantics。

## 19.1 Content 與 placement 可分開 merge

Agent A 修改 object content：

$$
v_0\rightarrow v_a.
$$

Agent B 只移動 placement：

$$
p_0\rightarrow p_b.
$$

若兩者獨立，merge 可以同時保留：

$$
(v_a,p_b).
$$

不應因任何 placement change 都被塞進 intrinsic revision，而製造假 conflict。

## 19.2 Spatial conflict

兩個 actor 同時移動同一 object：

$$
p_0\rightarrow p_a,
$$

$$
p_0\rightarrow p_b.
$$

可由 runtime 使用：

- last-writer policy；
- explicit conflict；
- branch placement state；
- collaborative transform CRDT；
- user-selected merge。

Paper 02 不凍結演算法，但禁止 silent semantic collapse。

## 19.3 Relation conflict

若一方把 candidate edge promote 成 `dependsOn`，另一方 promote 成 `annotates`，這不是單純幾何 conflict，而是 predicate conflict，必須進 relation/version layer處理。

---

# 20. Spatial Index 只是 acceleration structure

為了無限畫布效能，系統可能使用：

- quadtree；
- R-tree；
- BVH；
- spatial hash；
- tile index；
- region shard。

但這些都是：

$$
Index(P)\rightarrow Accelerator.
$$

不得反過來定義 canonical semantics。

例如兩個不同 R-tree packing 結果仍應對同一 canonical placement 產生相同 spatial predicate 結果。

因此：

$$
\text{index structure}\neq\text{spatial truth}.
$$

---

# 21. Spatial Syntax 的安全邊界

可執行畫布會出現「拖曳即執行」的風險。因此至少需要以下層級。

## 21.1 Pure layout mode

空間只影響 projection：

$$
P\not\rightarrow G_X.
$$

## 21.2 Assisted structure mode

空間產生 candidates：

$$
P\rightarrow \widehat E,
$$

但不自動 commit。

## 21.3 Formal spatial-language mode

在已宣告 grammar 的 region：

$$
P\rightarrow \widehat E\rightarrow E^{explicit}.
$$

是否 auto-promote 由 policy 決定。

## 21.4 Executable spatial mode

只有已 commit 且 validation 通過的結構可：

$$
E^{explicit}\rightarrow G_X\rightarrow Exec.
$$

對高風險 operator，runtime 仍可要求額外 permission 或 sandbox。

這四層使 EveGlyph 可以同時服務自由創作與精確計算。

---

# 22. 十五項核心不變量

以下構成 Paper 02 的 design freeze。

## S1 — View Independence

zoom/pan/view transform 不得改變 canonical object identity 或 committed spatial relations。

## S2 — Move Identity Preservation

一般 move 不得改變 persistent identity。

## S3 — Intrinsic/Extrinsic Geometry Separation

物件 intrinsic geometry 與 workspace placement 必須可獨立版本化／比較。

## S4 — Transient Non-Authority

pointer/gesture transient state 不得直接成為 authoritative semantic relation。

## S5 — Candidate/Explicit Separation

$$
\widehat E\neq E^{explicit}.
$$

## S6 — Versioned Spatial Parsing

每個 derived candidate 必須可追溯至 parser/grammar version 與 input snapshot。

## S7 — Ambiguity Preservation

parser 不得在低 confidence 或多解情況下強迫生成唯一 authoritative parse。

## S8 — Region Local Formality

不同 region 可使用不同 spatial grammar/policy；自由區域不被全域 grammar 強迫解析。

## S9 — Layout/Execution Separation

$$
G_L\neq G_X
$$

是預設；只有明確 spatial compiler 才建立映射。

## S10 — Deterministic Canonical Spatial Normalization

相同 committed placement snapshot 與 normalization version，合規 implementation 必須生成相同 canonical spatial representation。

## S11 — Hysteresis for Threshold Relations

任何依 threshold 的持續候選關係若會被互動操作頻繁觸發，必須有穩定化策略，例如 hysteresis、transaction boundary 或 equivalent deterministic policy。

## S12 — Connector Route Non-Authority

純 connector visual path 改變不得自動改變 relation endpoints/predicate。

## S13 — Visual Group/Scope Separation

visual grouping 不得自動建立 namespace/execution scope。

## S14 — Spatial Index Non-Authority

quadtree/R-tree/BVH 等 index implementation 不得改變 spatial semantics。

## S15 — Executable Commit Boundary

未 committed / 未 validated 的 spatial candidate 不得直接進入 executable graph。

---

# 23. Conformance Tests

## T1 — Pan/Zoom invariance

改變 viewport：

$$
T_{W\rightarrow V}^{(1)}\neq T_{W\rightarrow V}^{(2)}.
$$

要求：

$$
E^{explicit}_{before}=E^{explicit}_{after}.
$$

## T2 — Drag-through does not create relation

將 A 從 B 附近拖過但未 commit，要求：

$$
Near(A,B)\in\widehat E
$$

可以短暫成立，但：

$$
Near(A,B)\notin E^{explicit}.
$$

## T3 — Region entry candidate

物件幾何進入 executable region，只產生 candidate membership；直到 commit 前，不取得 execution scope。

## T4 — Move preserves intrinsic content

純 move 後：

$$
a^{content}_{before}=a^{content}_{after}.
$$

## T5 — Glyph edit changes intrinsic geometry

修改 glyph stroke 後：

$$
g^{int}_{before}\neq g^{int}_{after}.
$$

但 persistent identity 可維持。

## T6 — Ambiguous parse remains ambiguous

若兩個合法 parse confidence 接近且 policy 無法消歧，系統必須保留 ambiguity，不得隨機 commit。

## T7 — Hysteresis stability

在 $\epsilon_{enter}$ 與 $\epsilon_{leave}$ 之間小幅往返，不應造成 candidate relation 每幀翻轉。

## T8 — Freeform region ignores grammar

自由筆記 region 中兩個相鄰 node，不得因 executable region 的 grammar 而生成 execution edge。

## T9 — Explicit connector compiles

在 declared dataflow region 中，合法 port connector 經 commit 與 validation 後：

$$
e_{data}\in E^{explicit}
$$

並可被 compiler 映射到：

$$
e_x\in E_X.
$$

## T10 — Re-route preserves semantics

改變 connector spline/path，但 endpoints/predicate 不變，要求 relation revision 可保持語義等價。

## T11 — Semantic zoom preserves identity

不同 zoom projection 下：

$$
a^{id}_{z_1}=a^{id}_{z_2}.
$$

## T12 — Nested transform composition

local object 經多層 region transform 後，兩個合規 implementation 必須得到相同 normalized world placement。

## T13 — Spatial parser reproducibility

相同 snapshot、grammar、normalization 與 tolerance profile：

$$
Parse^{(1)}(S)=Parse^{(2)}(S)
$$

在規格定義 equality 下成立。

## T14 — AI candidate cannot bypass commit

AI 推測 `causes(A,B)` 時，若未有 explicit authority：

$$
causes(A,B)\notin E^{explicit}.
$$

## T15 — Layout-only move does not rerun runtime

在 pure layout mode 中移動 node，runtime execution graph hash 不得改變。

---

# 24. EveGlyph MVP 的最小 Spatial Slice

Paper 02 不要求完整商業級 infinite canvas。MVP 只需實作下列最小垂直切片。

## 24.1 基本物件

至少：

- text node；
- math node；
- operator node；
- region；
- connector/relation。

## 24.2 Placement

支援：

$$
(x,y,scale,rotation,z).
$$

## 24.3 三層 relation UI

UI 能區分：

- gray/preview candidate；
- explicit committed relation；
- execution edge。

不限定顏色，只要求可辨識。

## 24.4 一個 executable region

例如最小 dataflow：

$$
Input\rightarrow Operator\rightarrow Output.
$$

只有 explicit committed connector 能編譯。

## 24.5 一個 non-executable freeform region

用來證明同一畫布中可存在低形式空間，而不會被全域 grammar 污染。

## 24.6 一個 semantic zoom projection

遠距離顯示 node title；近距離顯示完整內容，但 identity 不變。

若上述六項成立，即可初步驗證本文核心主張：

$$
\boxed{
\text{one canvas}
+
\text{multiple local grammars}
+
\text{authority boundary}
+
\text{controlled spatial execution}
}
$$

---

# 25. 與 Paper 03、04、05 的接口

## 25.1 對 Paper 03 — Native Computational Mathematics

Paper 03 可在 math region 定義特殊 spatial grammar：

- fraction numerator/denominator；
- superscript/subscript；
- matrix cell；
- radical scope；
- operator/operand adjacency；
- equation alignment。

但最終數學 semantics 仍應編譯成 native math object，而不是把座標本身永久當作唯一數學本體。

## 25.2 對 Paper 04 — Generative Glyph

GSC 的 intrinsic geometry/topology 對接 $g^{int}$；glyph 在 canvas 的 placement 對接 $p^{ext}$。兩者分離可避免「改位置」被誤認成「改符號」。

## 25.3 對 Paper 05 — Multi-Layer Addressing

$a^{space}$ 將在 Paper 05 深入展開，包括：

- local spatial address；
- region-relative address；
- world address；
- cross-canvas reference；
- symbolic/semantic location；
- versioned spatial snapshot address。

---

# 26. 與 TW-01 / TW-03 的工程接口

TW-01 必須凍結：

1. placement schema；
2. transform canonicalization；
3. region object schema；
4. candidate relation schema；
5. explicit relation authority fields；
6. grammar version reference；
7. spatial snapshot hash；
8. ambiguity/diagnostic representation。

TW-03 必須凍結：

1. spatial index strategy；
2. gesture transaction；
3. parse scheduling；
4. validation pipeline；
5. compilation/runtime boundary；
6. collaboration merge policy；
7. sandbox/permission model；
8. viewport/semantic zoom implementation。

Paper 02 不替兩份白皮書提前選定資料庫與 renderer，但所有工程選擇不得破壞本文的不變量。

---

# 27. 非主張

本文不主張：

1. 所有視覺靠近都代表語義關聯；
2. 所有圖表都應成為可執行程式；
3. 無限畫布具有無限實體資源；
4. 所有 spatial grammar 都可以無歧義解析；
5. AI 可以從畫面推測後直接寫入權威語義；
6. layout graph 與 execution graph 應該相同；
7. region 的幾何包含必然等於 lexical/semantic scope；
8. zoom level 是 canonical semantic state；
9. quadtree、R-tree 或任何特定 spatial index 是 ASCS ontology；
10. 一套 spatial grammar 應統治整個 workspace；
11. 每個空間 predicate 都具有跨 domain 的固定 threshold；
12. 二維畫布是 ASCS 最終最高維度上限。

本文只主張：

> **當空間被允許參與語法時，必須有可追蹤、可解析、可撤銷、可版本化與可執行前驗證的 authority boundary。**

---

# 28. Paper 02 Design Freeze

完成本文後，後續文件不得在未顯式修訂的情況下破壞以下決策：

1. infinite canvas 是 logically unbounded、finitely materialized 的空間，不宣稱實體無限；
2. intrinsic geometry 與 extrinsic placement 分離；
3. world/region/local/view frame 分離；
4. pan/zoom 不等於 canonical object move；
5. transient placement、derived candidate、explicit relation 三層 authority 分離；
6. spatial parser 必須版本化且可重現；
7. ambiguity/unresolved parse 是合法狀態；
8. region 可定義 local grammar 與 local formality；
9. visual containment、visual group、semantic scope 分離；
10. layout graph 與 execution graph 分離；
11. spatial execution 必須經 parse/validate/commit/compile path；
12. threshold-based relations 必須有 deterministic stability policy；
13. canonical spatial representation 不直接依賴 viewport float；
14. spatial index 是 acceleration structure，不是 ontology；
15. AI 推測預設停留在 candidate layer；
16. semantic zoom 改變 projection，不改 persistent identity；
17. nested canvas 使用可組合 local frames 與 policy resolution；
18. 未 committed / 未 validated 的空間候選不得直接執行。

---

# 29. 結論

無限畫布真正重要的地方，不是「可以一直往旁邊拖」；如果它只是更大的白板，那麼它仍然只是線性文件之外的一個 UI 替代品。

更深的可能性在於：人類原本就透過空間來思考。靠近、分群、上下、內外、連線、對齊、區域與重複配置，常常比額外寫一串語法更直接地表達關係。Spatial Hypertext 與 visual-language research 已經分別證明，人類會產生 emergent spatial structure，而二維配置也能被形式 grammar 解析。

EveGlyph 要做的下一步不是粗暴地宣稱：

$$
\text{Position}=\text{Meaning}.
$$

而是建立一個更精確的轉換：

$$
\boxed{
\text{Spatial Arrangement}
\rightarrow
\text{Parsed Candidate Structure}
\rightarrow
\text{Committed Typed Relations}
\rightarrow
\text{Optional Executable Structure}
}
$$

這個 authority boundary 讓兩個看似衝突的需求可以共存。

一方面，使用者可以像使用紙張、白板或創意牆一樣，自由擺放尚未形式化的思想；另一方面，當某個區域需要成為數學語法、dataflow、symbol grammar 或 simulation graph 時，系統又能逐步提升其形式性，使位置與關係真正成為 machine-readable structure。

因此，未來 EveGlyph 的 Infinite Canvas 不只是 viewport。它可以成為：

$$
\boxed{
\text{a locally formalizable spatial language surface}
}
$$

其中自由空間與形式空間可以共存，視覺配置與 canonical relation 可以互相轉換，但不互相偷換。

當這一層完成後，Paper 03 才能安全地回答下一個問題：**如果數學不再必須先寫成 LaTeX 字串，那麼一個真正原生、可定址、可運算、又能被空間排版的 mathematical object 應該是什麼？**

---

# References

[1] Catherine C. Marshall and Frank M. Shipman III. “Searching for the Missing Link: Discovering Implicit Structure in Spatial Hypertext.” Proceedings of Hypertext ’93, 1993, pp. 217–230.

[2] Catherine C. Marshall, Frank M. Shipman III, and James H. Coombs. “VIKI: Spatial Hypertext Supporting Emergent Structure.” ECHT ’94, 1994, pp. 13–23.

[3] Catherine C. Marshall and Frank M. Shipman III. “Spatial Hypertext: Designing for Change.” Communications of the ACM, 38(8), 1995, pp. 88–97.

[4] Frank M. Shipman III, Catherine C. Marshall, and Thomas P. Moran. “Finding and Using Implicit Structure in Human-Organized Spatial Layouts of Information.” CHI ’95, 1995, pp. 346–353.

[5] Eric J. Golin and Steven P. Reiss. “The Specification of Visual Language Syntax.” Journal of Visual Languages & Computing, 1(2), 1990, pp. 141–157. DOI: 10.1016/S1045-926X(05)80013-8.

[6] Eric J. Golin. “Parsing Visual Languages with Picture Layout Grammars.” Journal of Visual Languages & Computing, 2(4), 1991, pp. 371–393. DOI: 10.1016/S1045-926X(05)80005-9.

[7] EveMissLab. “00 — From Linear Documents to Addressable Symbolic Computational Spaces.” v0.1, 2026.

[8] EveMissLab. “01 — Addressable Symbolic Object Model: Identity, Content, Semantics, Relations, Versioning, and Equality in Computational Documents.” v0.1, 2026.

[9] EveMissLab. “Generative Symbol Compiler Lab v1.13.0-strict-symbolic.” validated source baseline, 2026.

[10] EveMissLab. “PSSA-BSAR v0.1 Milestone 4 Source.” controlled address-first semantic recovery harness, 2026.

---

# Appendix A — 形式化摘要

Workspace spatial state：

$$
\mathcal W_t=(Q_t,E_t,P_t,X_t,L_t).
$$

Placement：

$$
p_{i,t}=(F,T,B,z,\lambda,r).
$$

Spatial parser：

$$
\Phi_{\sigma}(P_t,G,K)\rightarrow\widehat E_t.
$$

Spatial grammar：

$$
\mathcal G_s=(\Sigma,N,\mathcal P,\Psi,\mathcal A,\nu).
$$

Parse：

$$
Parse_{\mathcal G_s}(S_r)\rightarrow(T,\widehat E,D).
$$

Authority promotion：

$$
Promote(\hat e,authority)\rightarrow e.
$$

Layout graph：

$$
G_L=(V,E_L).
$$

Execution graph：

$$
G_X=(V_X,E_X).
$$

Spatial compilation：

$$
Compile_r(T,E^{explicit})\rightarrow G_X.
$$

Execution：

$$
Exec(G_X,\Gamma)\rightarrow(result,trace,state').
$$

Canonical normalization：

$$
N_{\sigma}(P)\rightarrow P^{canon}.
$$

Spatial state address：

$$
a^{spaceState}=H(D_s\Vert C_{\sigma}(P^{canon})).
$$

Semantic zoom：

$$
\Pi(o,z,\Gamma)\rightarrow view_z.
$$

---

# Appendix B — Implementation-facing Checklist

在 TW-01 / TW-03 / MVP-01 開始實作 Paper 02 前，至少必須回答：

1. world coordinate 採何種 numeric representation？
2. canonical quantization/normalization 如何定義？
3. region-local transform 如何序列化？
4. view transform 如何保證不污染 canonical spatial state？
5. transient gesture state 存在哪一層？
6. gesture commit boundary 是 pointer-up、transaction 還是 explicit command？
7. candidate relation 的 schema 與 provenance 欄位為何？
8. spatial grammar 如何版本化與載入？
9. tolerance profile 如何與 grammar 綁定？
10. hysteresis 如何 deterministically 實作？
11. ambiguous parse 如何保留多候選？
12. region local formality 如何顯示給使用者？
13. visual group 與 semantic scope 如何在 UI 明確區分？
14. connector endpoint 與 connector route 如何分離？
15. spatial snapshot hash 包含哪些欄位？
16. nested canvas policy inheritance 如何解析？
17. executable spatial region 的 permission model 為何？
18. candidate edge promotion 需要哪種 authority？
19. AI-generated spatial relations 預設停在哪一層？
20. content revision 與 placement revision 如何獨立 merge？
21. spatial index 如何保證只是 acceleration structure？
22. semantic zoom renderer 如何保持 persistent identity？
23. import SVG/diagram 時，哪些 spatial relations 是 explicit、哪些只能 derived？
24. MVP 如何證明 freeform region 與 executable region 可在同一 canvas 共存？

Paper 02 不要求現在決定所有實作答案；它要求未來任何答案都不能破壞本文已凍結的 spatial authority model。


<!-- SOURCE: 03_原生可計算數學_超越LaTeX字串的語義物件執行與投影模型_v0.1.md -->

# 03｜原生可計算數學：超越 LaTeX 字串的語義物件、執行與投影模型

**English Title:** Native Computational Mathematics Beyond LaTeX: Semantic Objects, Execution, Binding, Assumptions, and Projection in EveGlyph

**作者：** Neo.K  
**機構：** EveMissLab / 一言諾科技有限公司  
**版本：** v0.1  
**日期：** 2026-08-24  
**文件類型：** 專題論文 / Formal Architecture Paper  
**系列定位：** EveGlyph Addressable Symbolic Computational Space Series — Paper 03  
**前置錨點：** Paper 00 — From Linear Documents to Addressable Symbolic Computational Spaces；Paper 01 — Addressable Symbolic Object Model；Paper 02 — Spatial Syntax and Infinite Canvas Computation

---

## Canonical Source Note

本文件以 UTF-8 Markdown 保存正式原稿。數學 source 僅使用 `$...$` 與 `$$...$$` 作為 canonical delimiter。

這個選擇只服務目前的人類可讀原稿與既有工具鏈；本文所定義的 future native mathematical object **不以 LaTeX source 作為 canonical mathematical ontology**。因此，本文件在 chat／Markdown 中出現的公式只是本文所討論數學物件的一種 projection。

本文亦不主張 LaTeX、MathML、OpenMath、OMDoc、CAS expression tree 或 theorem-prover term 應被單一新格式取代。相反地，本文提出一個上層的 **Native Computational Mathematics Object Model, NCM**，讓既有格式成為 importer、exporter、renderer、interchange profile 或 proof/computation backend。

因此：

$$
\text{mathematical object}
\neq
\text{LaTeX source}
\neq
\text{rendered glyphs}
\neq
\text{execution result}.
$$

---

## 摘要

數位數學工具長期存在一個結構性錯位：人類看到的是二維數學符號，計算機收到的卻常是描述這些符號如何排版的線性字串。LaTeX 對高品質排版極其成功，但當它被進一步充當公式的 canonical source、計算輸入、語義識別與版本比較基礎時，表示層、語義層與執行層容易被混在一起。例如，同一個偏導數可以被多種 LaTeX 寫法排成幾乎相同的畫面；同一串可見符號又可能在不同 domain、scope 或 binding 下具有不同意義。單靠字串或視覺相等，無法穩定回答「這個公式是什麼」、「哪些變數被綁定」、「在哪個 domain 上成立」、「使用了哪些假設」、「這個近似值的精度與 rounding mode 是什麼」、「這個結果如何被算出或證明」等問題。

MathML、OpenMath、OMDoc 與計算代數／定理證明系統早已分別證明：數學可以有 presentation 與 content 的區分，數學物件可以被機器可讀地表示，甚至可附帶 theory、proof 與 document-level knowledge。2026 年的 MathML 4 Working Draft 仍同時處理 mathematical notation 與 mathematical content，而 OpenMath 2.0 Revision 2 明確以「表示與交換數學物件的語義」為核心。本文不是忽略這些成熟工作，而是將其分層思想與 Paper 00–02 的 addressable object、revision DAG、infinite canvas、spatial grammar、provenance 與 native execution 統一到 EveGlyph 的一般數學物件模型中。

本文提出 **Native Computational Mathematics, NCM**。一個 NCM object 不只是 expression tree，而是一個可定址、可版本化的 mathematical object，其 intrinsic state 至少能分離：semantic expression graph、binding/scoping、type/domain、assumptions、constraints、units/dimensions、numeric exactness/precision、presentation hints、execution bindings 與 provenance anchors。二維數學排版可以透過 Paper 02 的 spatial grammar 解析為 candidate semantics；LaTeX、Presentation MathML 或手寫輸入亦可透過 importer 產生 candidate NCM；但任何 ambiguous interpretation 都允許以 unresolved state 留存，而不是被 parser 或生成式 AI 強迫選成唯一含義。

本文進一步建立數學相等關係族：surface equality、structural equality、alpha-equivalence、definitional/canonical equivalence、theorem-backed equivalence 與 approximate numerical equivalence，禁止把 renderer equality 或 decimal equality 偷換成 formal semantic equality。對計算，本文定義結果不是單一 value，而是：

$$
Eval(M,\Gamma,\Pi)
\rightarrow
(R,\Delta,\rho,\chi),
$$

其中 $R$ 為結果物件，$\Delta$ 為衍生狀態／新物件，$\rho$ 為 provenance trace，$\chi$ 為條件、警告、未定義或未解決狀態。這使「結果成立需要什麼前提」與「顯示了什麼數字」不再被混在一起。

本文最後凍結二十項 Native Math invariants 與十八個 conformance tests，並定義 MVP-01 的最小 native-math vertical slice。核心結論是：未來 EveGlyph 不需要讓使用者放棄傳統數學排版；它只需要讓排版退回 projection，使真正的 canonical state 成為一個可計算的數學對象。

**關鍵詞：** Native Computational Mathematics、LaTeX、MathML、OpenMath、OMDoc、Semantic Math、Binding、Assumptions、Exact Arithmetic、Mathematical Object、EveGlyph、Symbol IR、Computational Document

---

## Abstract

Digital mathematics still frequently conflates three distinct concerns: mathematical meaning, mathematical notation, and textual serialization. LaTeX is exceptionally successful as a typesetting language, but a typesetting-oriented source string is not necessarily an adequate canonical ontology for executable, versioned, semantically addressable mathematics. Equivalent formulas may have different LaTeX sources, identical visual forms may encode different semantics under different scopes or domains, and numerical outputs may conceal assumptions, undefined cases, approximations, precision, or provenance.

This paper proposes **Native Computational Mathematics (NCM)** for the EveGlyph Addressable Symbolic Computational Space. An NCM object is a persistent, versioned mathematical object whose intrinsic state separates semantic expression structure, binding and scope, types and domains, assumptions and constraints, units and dimensions, exact and approximate numeric states, presentation hints, execution bindings, and provenance anchors. LaTeX, MathML, OpenMath, and other mathematical encodings remain important interoperability and projection layers, but none is required to be the sole canonical ontology of an EveGlyph mathematical object.

The model supports multiple non-equivalent notions of equality, including surface equality, structural equality, alpha-equivalence, canonical or definitional equivalence, theorem-backed equivalence, and approximate numerical equivalence. Mathematical parsing is modeled as an interpretation process that may remain ambiguous or unresolved. Computation produces not merely a displayed value but a result object, derived state, provenance trace, and explicit conditions or exceptional states. The paper also connects native mathematics to spatial syntax: two-dimensional notation on an infinite canvas can be parsed into candidate mathematical structure under declared local grammars without making screen coordinates themselves the final mathematical meaning.

The resulting architecture allows the same mathematical object to be rendered as traditional notation, exported to LaTeX or MathML, exchanged through semantic formats such as OpenMath, executed by multiple backends, checked by proof systems, addressed in the workspace, and versioned without collapsing its identity into any single textual representation.

---

# 1. 問題：數學不是它的排版字串

## 1.1 線性 source 與二維 notation 的歷史折衷

傳統文字檔案天然適合序列：

$$
S=(c_1,c_2,\ldots,c_n).
$$

而數學 notation 經常是二維甚至具有複雜 scope：

$$
\frac{\partial f}{\partial x},
$$

$$
\sum_{i=1}^{n} a_i,
$$

$$
\int_{0}^{1} f(x)\,dx,
$$

矩陣、分段函數、上下標、根號、張量指標、交換圖與 proof diagram 更直接使用空間結構。

LaTeX 的歷史功績，是以線性語法高效描述這些排版。然而若系統將：

$$
\text{LaTeX string}
$$

同時當成：

- identity；
- semantics；
- computation input；
- equality basis；
- provenance；
- presentation；

就會產生層次混淆。

## 1.2 同義不同字串

同一個數學結構可能有不同 textual forms。例如空白、macro、parentheses、notation style、implicit multiplication 與自訂 command 都可能改變 source，而不改變 intended semantics。

因此：

$$
source_1\neq source_2
$$

不推出：

$$
meaning_1\neq meaning_2.
$$

## 1.3 同形不同義

反過來，畫面相同也可能不同義。

例如：

$$
f(x)
$$

可能是 function application；某些 domain 中相同 glyph arrangement 也可能代表 multiplication、indexing 或自訂 operator syntax。

又例如：

$$
i
$$

可以是普通變數，也可以在特定 context 中指 imaginary unit。

因此：

$$
projection_1=projection_2
$$

不推出：

$$
semantics_1=semantics_2.
$$

## 1.4 原生數學的目標

NCM 的目標不是讓人類手寫 AST，而是讓系統內部承認：

> 使用者真正操作的是 mathematical object；notation 是 object 的 projection / editing surface。

因此：

$$
\boxed{
\text{Mathematical Meaning}
\rightarrow
\text{Native Math Object}
\rightarrow
\text{many projections / executions}
}
$$

而不是：

$$
\boxed{
\text{LaTeX string}
\rightarrow
\text{parse again whenever meaning is needed}
}.
$$

---

# 2. 既有標準已經證明 presentation/content 分離是成熟方向

## 2.1 MathML

MathML Core 的目標是讓瀏覽器原生處理數學 notation；MathML 4 則明確同時支援 mathematical notation 與 mathematical content。這代表現有 Web 標準本身就不把「畫面長什麼樣」與「數學是什麼」視為完全相同的問題。

NCM 吸收這個方向，但不要求 EveGlyph canonical state 必須就是某段 XML。MathML 可以作為：

$$
Adapter_{MathML}:NCM\leftrightarrow MathML_{subset}.
$$

## 2.2 OpenMath

OpenMath 的核心就是 representation and communication of mathematical objects，並強調 encode meaning rather than only visual representation。

因此 OpenMath 是 NCM 最接近的既有語義互通參照之一。

但 NCM 還需額外處理 EveGlyph 特有需求：

- ASOM persistent identity；
- revision DAG；
- spatial editing；
- unresolved interpretation；
- local execution bindings；
- provenance；
- workspace relation graph；
- projection hints；
- AI proposal / authority boundary。

因此關係是：

$$
\text{OpenMath semantic object interoperability}
\subseteq
\text{NCM interoperability surface},
$$

而不是宣稱 OpenMath 本身不足或應被淘汰。

## 2.3 OMDoc

OMDoc 將 semantic mathematics 提升到 statements、theories、proofs 與 mathematical documents。這提醒 NCM：公式不能永遠被當成孤立 expression。

因此 NCM 必須允許數學物件與：

- definition；
- theorem；
- proof；
- assumption；
- theory；
- dataset；
- algorithm；
- experiment；

建立 first-class relations。

## 2.4 CAS 與 theorem prover

電腦代數系統與定理證明器長期使用 expression tree、term、typed term、symbol table、rewrite rule 與 proof object。這些實作再次說明：真正執行數學時，系統通常早已超越「純排版字串」。

NCM 的工作不是重造 CAS，而是建立一個 **workspace-level mathematical object contract**，讓多種 CAS、numeric engine、proof engine 與 renderer 可以共用同一個可定址數學物件。

---

# 3. NCM 的基本對象

令一個 ASOM persistent math object 為：

$$
O_i^{math}=(i,\texttt{math},H_i).
$$

其某一 revision 為：

$$
M_{i,v}
=
(i,v,G,\Beta,\Tau,\Gamma,\mathcal A,\mathcal C,\mathcal U,\mathcal N,\mathcal P,\mathcal X,\mathcal M).
$$

其中：

- $G$：semantic expression graph；
- $\Beta$：binding and scope structure；
- $\Tau$：type/domain information；
- $\Gamma$：symbol environment / context references；
- $\mathcal A$：assumptions；
- $\mathcal C$：constraints / side conditions；
- $\mathcal U$：units / dimensional structure；
- $\mathcal N$：numeric exactness / precision state；
- $\mathcal P$：presentation hints / notation preferences；
- $\mathcal X$：execution bindings；
- $\mathcal M$：metadata / provenance anchors。

這不是 TW-01 的最終 wire schema，而是 Paper 03 的 semantic decomposition。

最重要的設計是：

$$
G
$$

不必包含畫面 pixel coordinates；

$$
\mathcal P
$$

也不必決定 mathematical truth。

---

# 4. Semantic Expression Graph

## 4.1 為什麼不是只叫 AST

樹結構適合許多 expression，但數學環境常有：

- shared subexpressions；
- references；
- recursive definitions；
- named constants；
- external theorem references；
- graph-like dependency。

因此 NCM 使用一般化 attributed graph：

$$
G=(N,E,\lambda,\eta).
$$

其中：

- $N$：node set；
- $E$：typed edges；
- $\lambda$：node labels / operators；
- $\eta$：node attributes / semantic references。

特定 expression 可限制成 tree/DAG，但 model 本身不強迫所有數學都是 tree。

## 4.2 最小 node families

NCM 至少需要概念上支援：

1. `literal`；
2. `symbol`；
3. `application`；
4. `binder`；
5. `relation`；
6. `collection`；
7. `piecewise`；
8. `matrix/tensor`；
9. `reference`；
10. `hole/unresolved`；
11. `annotation`；
12. `external-semantic-object`。

例如：

$$
f(x)+1
$$

不必 canonicalize 成字串 `f(x)+1`，而可以是：

$$
Apply(+,[Apply(f,[x]),1]).
$$

真正 serialization 由 TW-01 決定。

---

# 5. Binding 與 Scope 是數學本體的一部分

## 5.1 變數名稱不等於變數 identity

考慮：

$$
\int_0^1 x^2\,dx.
$$

積分內的 $x$ 是 bound variable。

若只用 visible string `x` 當 identity，就容易與外部同名自由變數混淆。

NCM 因此要求 binding relation：

$$
Bind(b,x,scope).
$$

或等價的 binder structure。

## 5.2 Alpha-equivalence

例如：

$$
\int_0^1 x^2\,dx
$$

與：

$$
\int_0^1 y^2\,dy
$$

在適當條件下應該 alpha-equivalent。

因此：

$$
M_1\equiv_{\alpha}M_2
$$

可以成立，即使 visible symbol names 不同。

## 5.3 Capture avoidance

任何 substitution：

$$
Substitute(M,x\mapsto E)
$$

都必須遵守 capture-avoiding semantics。

因此 serializer/parser 不得把 binding information 丟失後再靠字串猜測。

## 5.4 Scope 與 Paper 02 region

Canvas 上的 region scope 可以提供 symbol environment，但 visual containment 不直接等於 binder。

即：

$$
Inside_{geo}(x,R)
\not\Rightarrow
BoundBy(x,b).
$$

只有 math grammar / explicit semantic structure 能建立 binding。

---

# 6. Type、Domain 與 Operator Meaning

## 6.1 同一 glyph 在不同 domain 可不同義

加號：

$$
+
$$

可能作用於：

- integers；
- reals；
- complex numbers；
- matrices；
- vectors；
- polynomials；
- abstract groups；
- custom algebraic objects。

因此 operator node 至少需要 semantic reference / dispatch context。

可表示為：

$$
op=(symbolRef,typeSignature,theoryRef).
$$

## 6.2 Domain information

一個 expression 的 type/domain judgement 可寫為：

$$
\Gamma\vdash M:T.
$$

NCM 不強迫單一 type theory，但要求 type/domain 資訊可被保存、查詢與版本化。

## 6.3 Unknown type 是合法狀態

在創作初期，系統可能只有：

$$
\Gamma\vdash M:?
$$

這不是錯誤；它是 unresolved type state。

AI 或 inference engine 可以提出候選，但：

$$
TypeCandidate
\neq
CommittedType.
$$

---

# 7. Assumptions 與 Constraints 必須是一級結構

## 7.1 很多數學等式只在條件下成立

例如：

$$
\sqrt{x^2}=|x|
$$

對 real $x$ 與 complex branch convention 的處理不同。

又例如：

$$
\frac{x^2-1}{x-1}=x+1
$$

需要：

$$
x\neq1.
$$

若系統只輸出右側而丟掉 side condition，就改變了命題。

## 7.2 Assumption set

定義：

$$
\mathcal A=\{a_1,a_2,\ldots,a_n\}.
$$

例如：

$$
x\in\mathbb R,
$$

$$
x>0.
$$

## 7.3 Constraint set

定義：

$$
\mathcal C=\{c_1,c_2,\ldots,c_m\}.
$$

constraint 可以是：

- domain restriction；
- nonzero condition；
- convergence condition；
- branch choice；
- dimensional compatibility；
- shape constraint；
- boundary condition。

## 7.4 計算結果不能偷丟條件

若 backend 得到：

$$
R
$$

只在 $\chi$ 成立時有效，則 NCM result 應保存：

$$
(R,\chi).
$$

而不是只保存 $R$。

---

# 8. Exact、Approximate、Precision 與 Rounding

## 8.1 字面 `0.1` 並不足以描述 numeric semantics

`0.1` 可以是：

- exact decimal rational $1/10$；
- binary floating-point approximation；
- measured value；
- interval midpoint；
- arbitrary precision decimal。

因此 numeric node 不應只保存 display string。

## 8.2 Numeric state

本文定義抽象 numeric descriptor：

$$
\mathcal N=(kind,value,precision,error,rounding,provenance).
$$

其中 `kind` 可以包含：

- integer；
- rational；
- algebraic exact；
- symbolic exact；
- float；
- decimal；
- interval；
- complex approximate；
- measured/uncertain。

## 8.3 Exactness 不得被 renderer 改寫

例如 exact：

$$
\frac13
$$

投影成：

$$
0.333333
$$

時，projection 不得讓 canonical numeric object 變成有限 decimal approximation。

因此：

$$
Projection_{decimal}(Exact(1/3))
\neq
Mutation(Approx(0.333333)).
$$

## 8.4 Approximate equality

近似比較必須帶 metric/tolerance：

$$
a\approx_{\epsilon}b.
$$

不得把：

$$
a\approx_{\epsilon}b
$$

偷換成：

$$
a\equiv_{formal}b.
$$

---

# 9. Units 與 Dimensions

## 9.1 單位不是文字後綴

例如：

$$
3\ \mathrm{m}
$$

若 `m` 只是一段文字，系統無法穩定進行 dimension checking。

NCM 應允許 unit semantic reference：

$$
Quantity(value,unitRef).
$$

## 9.2 Dimension judgement

可定義：

$$
Dim(M)=d.
$$

例如：

$$
Dim(v)=L/T.
$$

## 9.3 Dimension mismatch

對：

$$
3\ \mathrm{m}+5\ \mathrm{s},
$$

系統應返回 typed diagnostic，而不是僅按字串拼接。

## 9.4 單位系統也是 context

同一 mathematical object 可在不同 display profile 中使用不同 unit projection，但 canonical quantity semantics 可保持一致。

---

# 10. Undefined、Partial、Conditional 與 Unresolved 是合法數學狀態

傳統 UI 常傾向讓任何輸入都有一個值，但數學不是總函數世界。

## 10.1 Undefined

例如：

$$
\frac10
$$

在通常實數／複數 field semantics 中是 undefined。

應有：

$$
ResultStatus=Undefined(reason).
$$

## 10.2 Conditional

例如 symbolic integration 可能只有在 parameter 條件下給出特定形式。

應有：

$$
ResultStatus=Conditional(\chi).
$$

## 10.3 Unresolved

如果 importer 不知道 `f x` 是 multiplication 還是 application，可保留：

$$
UnresolvedInterpretation(\{I_1,I_2\}).
$$

## 10.4 Unevaluated

某 expression 合法，但 backend 不支援或不值得展開：

$$
Unevaluated(M,reason).
$$

這四者不得被混成一個 generic error。

---

# 11. Presentation Plan：排版仍然重要，但不是 ontology

## 11.1 Presentation hints

NCM 不應因為語義優先就丟掉人類 notation 偏好。

同一 semantic object 可以有：

$$
\mathcal P=(notationStyle,parenthesisPolicy,operatorForm,layoutHints,labels).
$$

例如 derivative 可顯示成：

$$
\frac{df}{dx},
$$

$$
f'(x),
$$

或 operator node。

## 11.2 Presentation hint 不改 mathematical identity

若只更改：

$$
f'(x)
\rightarrow
\frac{df}{dx}
$$

且 semantics 未變，persistent math identity 可以保持不變，semantic content 亦可等價；是否產生新的 revision 由 ASOM intrinsic boundary / presentation-version policy 決定。

Paper 03 建議：**presentation hint 可版本化，但不應被誤認為 semantic expression graph 本身。**

## 11.3 Accessibility projection

同一 NCM object 可產生：

- visual notation；
- speech / aural math；
- linear text description；
- Braille adapter；
- structural tree view。

所以 NCM 的價值也包含 accessibility：不再必須從排版 glyph 逆推出結構。

---

# 12. LaTeX 在 NCM 中的新位置

## 12.1 Import

LaTeX importer：

$$
I_{TeX}:S_{TeX}\rightharpoonup Candidate(NCM).
$$

注意是 partial map，因為任意 TeX macro programming 並不天然等於可完整恢復的數學 semantics。

## 12.2 Export

LaTeX exporter：

$$
E_{TeX}:NCM\rightarrow S_{TeX}.
$$

同一 NCM object 可以有多個合法 TeX outputs：

$$
E_{TeX}^{(1)}(M)\neq E_{TeX}^{(2)}(M),
$$

但兩者都 render/represent 同一 intended math object。

## 12.3 LaTeX fidelity profile

Importer/exporter 應宣告：

$$
Fidelity\in\{semantic,structural,presentation,lossy,unknown\}.
$$

並記錄 unresolved macro、unsupported package semantics 與 dropped annotations。

## 12.4 LaTeX 不再是 canonical hash 的必要輸入

NCM content hash 應基於 canonical semantic object，而不是基於任意 TeX source formatting。

因此兩個語義等價的 supported TeX imports 可以 canonicalize 到同一 structural/semantic content address，即使原 source 不同。

---

# 13. MathML、OpenMath 與 NCM 的互通

## 13.1 Presentation MathML

Presentation MathML 主要服務 notation/layout，適合作為 NCM projection/interchange view。

## 13.2 Content MathML

Content-oriented representation 更接近 NCM semantic graph，可作為 supported subset 的高 fidelity adapter。

## 13.3 OpenMath

OpenMath symbol/content dictionary 模型可對接 NCM operator semantic reference 與 theory reference。

可定義：

$$
Map_{OM}:NCM_{subset}\leftrightarrow OpenMath.
$$

## 13.4 不要求一對一覆蓋

NCM workspace-specific fields，例如：

- persistent ID；
- revision DAG；
- canvas placement；
- local AI provenance；
- execution cache；

不必硬塞進每個外部 math standard。

因此 adapter 的原則是：

$$
\text{math semantics interoperability}
\neq
\text{workspace state identity}.
$$

---

# 14. 二維數學與 Paper 02 Spatial Syntax

## 14.1 二維 notation 可以是 editing syntax

使用者在 math region 中畫／放置：

- numerator；
- fraction bar；
- denominator；

spatial grammar 可以解析候選：

$$
Fraction(A,B).
$$

但 canonical result 應成為 semantic node，例如：

$$
Divide(A,B)
$$

或 domain-specific rational construction。

坐標本身不是最終数学 meaning。

## 14.2 Superscript ambiguity

$$
x^2
$$

通常是 exponentiation，但某些 notation 中 superscript 可表示：

- tensor index；
- derivative marker；
- label；
- conjugation；
- group action notation。

因此 spatial parser：

$$
Parse_{math}(layout)
\rightarrow
\{I_1,\ldots,I_n\}
$$

可以保留 ambiguity，再由 domain/context resolve。

## 14.3 Matrix parsing

矩陣 visual grid 可解析為：

$$
Matrix([a_{ij}],m,n),
$$

而不是把每個 cell 的 pixel coordinate 當 canonical order。

## 14.4 Spatial editing 與 semantic object round-trip

NCM renderer：

$$
R_{canvas}(M,\mathcal P)
\rightarrow
Layout.
$$

使用者對 layout 的結構性編輯再透過 grammar 轉回 semantic mutation：

$$
Edit(Layout)
\rightarrow
CandidateMutation(M).
$$

只有 validate/commit 後才產生新 math revision。

---

# 15. Mathematical Equality 不是單一 `==`

NCM 延續 Paper 01 的 equality family。

## 15.1 Surface equality

$$
M_1\equiv_{surface,\Pi}M_2
$$

表示特定 renderer 下看起來相同。

它最弱，不推出 semantics 相同。

## 15.2 Structural equality

$$
M_1\equiv_{struct}M_2
$$

表示 canonical expression graph 結構一致。

## 15.3 Alpha-equivalence

$$
M_1\equiv_{\alpha}M_2
$$

允許 bound variable renaming。

## 15.4 Canonical / definitional equivalence

對有 normalization $N_{\Theta}$ 的 theory：

$$
M_1\equiv_{def,\Theta}M_2
\iff
N_{\Theta}(M_1)=N_{\Theta}(M_2).
$$

## 15.5 Theorem-backed equivalence

若 proof system 產生 certificate $\pi$：

$$
\pi:\Theta\vdash M_1=M_2,
$$

則：

$$
M_1\equiv_{proof,\Theta,\pi}M_2.
$$

## 15.6 Approximate numerical equivalence

$$
M_1\approx_{metric,\epsilon}M_2.
$$

它不得冒充 formal equality。

## 15.7 Equality provenance

若系統 UI 顯示「等價」，應能回答：

- structural？
- alpha？
- rewrite normalization？
- theorem prover？
- numeric tolerance？
- heuristic CAS simplification？

所以 equality verdict 本身也是可追蹤 computation result。

---

# 16. Native Evaluation Contract

## 16.1 Evaluation 不是 `string -> string`

本文定義：

$$
Eval(M,\Gamma,\Pi)
\rightarrow
(R,\Delta,\rho,\chi).
$$

其中：

- $M$：input math object revision；
- $\Gamma$：symbol/type/domain context；
- $\Pi$：execution policy / backend profile；
- $R$：result math/data object；
- $\Delta$：新建／更新的 derived objects or relations；
- $\rho$：execution provenance；
- $\chi$：conditions/status/diagnostics。

## 16.2 Backend profile

$\Pi$ 至少可描述：

- engine name/version；
- exact vs numeric mode；
- precision；
- timeout/resource limit；
- simplification policy；
- branch convention；
- assumptions；
- trusted/untrusted status。

## 16.3 Result identity

計算結果預設是 derived object：

$$
O_R\xleftarrow{derivedFrom}O_M.
$$

而不是直接覆寫 input object identity。

## 16.4 Re-evaluation

若 backend version 或 policy 改變：

$$
\Pi_1\neq\Pi_2,
$$

系統可以保留兩個 result objects / revisions，並比較：

$$
R_1,R_2.
$$

這對 reproducibility 非常重要。

---

# 17. Simplification 必須保留語義條件

## 17.1 Rewrite rule

一個 rewrite：

$$
r:(L\rightarrow R)\mid\chi
$$

其中 $\chi$ 是 side condition。

## 17.2 Unsafe simplification

如果執行：

$$
\frac{x}{x}\rightarrow1
$$

卻沒有記錄：

$$
x\neq0,
$$

就不是語義保真的 rewrite。

## 17.3 Rewrite trace

每個 canonical/important transformation 可保存：

$$
Trace=(ruleID,input,output,conditions,engineVersion).
$$

## 17.4 Cosmetic normalization 與 semantic simplification 分離

例如排序顯示 terms 與實際運用 commutativity theorem 不必被同一機制處理。

Presentation reordering：

$$
\Pi(M)
ightarrow\Pi'(M)
$$

不必改 semantic graph。

真正 rewrite：

$$
M\rightarrow M'
$$

則應產生 mathematical transformation provenance。

---

# 18. Proof 與 Computation 的關係

## 18.1 計算結果不是自動證明

CAS 輸出一個 expression：

$$
R
$$

不必然構成 formal proof。

因此 provenance 應標記：

$$
EvidenceClass\in\{computed,verified,proved,assumed,heuristic,external\}.
$$

## 18.2 Proof object / certificate

若 backend 能產生 proof certificate：

$$
\pi:\Theta\vdash P,
$$

可建立：

$$
ProofObject(\pi)
$$

並 relation：

$$
proves(\pi,P).
$$

## 18.3 Cross-check

同一 result 可由：

- CAS；
- numerical engine；
- theorem prover；
- independent backend；

分別產生 evidence。

NCM 可以把這些 evidence 掛在同一 mathematical claim 上，而不必把它們混成單一字串註解。

---

# 19. Caching 與 Memoization 不得污染數學 identity

## 19.1 Cache key

execution cache 可以基於：

$$
K=H(mathContent,context,assumptions,policy,engineVersion).
$$

## 19.2 Cache 不是 truth

cache hit 只表示相同 execution contract 已有結果，不表示結果已被正式證明。

## 19.3 Projection cache 更弱

KaTeX/SVG/raster render cache 只服務 projection：

$$
Cache_{render}
$$

不得成為 semantic content source。

---

# 20. Mathematical Addressing

Paper 01 的六層 address 在 math object 中具體化。

## 20.1 Persistent address

$$
a^{id}(M)=i.
$$

## 20.2 Content address

基於 canonical semantic state：

$$
a^{content}=H(D_m\Vert C_{\sigma}(SemanticState(M))).
$$

## 20.3 Semantic address

可指向：

- theory symbol；
- theorem；
- operator；
- concept；
- formal ontology node；
- partial PSSA-like address。

## 20.4 Spatial address

指 math object 在 canvas/region 的 placement，而不是公式本身的 mathematical identity。

## 20.5 Physical address

指 serialization / storage location。

## 20.6 Revision address

指特定 math revision。

## 20.7 Subexpression address

Paper 03 額外提出 path-like subobject address：

$$
a^{sub}=(a^{ver},path/schemaRef).
$$

用來穩定指向某 revision 內的 subexpression。

但若 expression rewrite 後 path 改變，系統需要 provenance mapping，而不能假裝 path 永久 persistent。

---

# 21. Canonicalization of Native Math

## 21.1 Canonicalization 不等於 simplification

這是非常重要的區分。

Canonical serialization：

$$
C_{\sigma}(M)
$$

只需要讓同一 abstract object 有 deterministic bytes。

Semantic simplification：

$$
S_{\Theta}(M)
$$

可能使用代數法則改寫 expression。

因此一般情況：

$$
C_{\sigma}(M)
\neq
C_{\sigma}(S_{\Theta}(M))
$$

是完全正常的。

## 21.2 Alpha-normalization

canonicalization 可以合法處理 bound variable representation，例如 de Bruijn-style index 或 deterministic binder IDs，以避免純名稱差異造成不必要 hash 變化。

但具體方案留給 TW-01。

## 21.3 Commutative canonicalization 的風險

對：

$$
a+b
$$

與：

$$
b+a,
$$

即使在某 theory 中等價，也不一定應被 byte-canonicalization 自動排序成完全相同 representation，因為：

- 原始 human intent / presentation order 可能有價值；
- operator 未必在所有 domain commutative；
- rewrite equality 與 structural identity 是不同層。

因此 Paper 03 禁止「為了 hash 去隨意做數學 theorem rewrite」。

---

# 22. Import Ambiguity 與 AI

## 22.1 來源可能是 LaTeX、手寫、OCR、圖像、自然語言或 Canvas

Importer：

$$
I_s(source,context)
\rightarrow
\{(M_1,q_1),\ldots,(M_n,q_n)\}.
$$

## 22.2 低信心不強制 commit

若：

$$
q_{max}<\theta,
$$

系統可以建立：

$$
UnresolvedMathObject.
$$

## 22.3 AI 是 interpretation proposer

AI 可以：

- 猜測 operator meaning；
- 補 type；
- 建議 assumptions；
- 解讀自訂 notation；
- 轉 LaTeX；
- 轉 semantic graph。

但：

$$
AIProposal
\neq
CanonicalMathCommit.
$$

重要結構必須經 schema/domain validator 或 user/authorized-agent commit。

## 22.4 不確定性要保留下來

如果某符號有三個可能解讀，保留三候選比強迫一個錯解更符合 NCM。

這與 Paper 02 ambiguous spatial parse、PSSA unresolved semantic address 是同一設計哲學。

---

# 23. Native Math 的 Object Lifecycle

## 23.1 Create

$$
CreateMath(candidate)
\rightarrow
(O_i,M_{i,v_0}).
$$

## 23.2 Semantic Edit

修改 operator/operand/binding/assumption：

$$
M_{i,v_1}\rightarrow M_{i,v_2}.
$$

persistent identity 可保持：

$$
i_{v_1}=i_{v_2}.
$$

## 23.3 Presentation Edit

只改 notation/presentation hints，可依 policy 產生 presentation revision，但不應自動宣稱 semantic graph 改變。

## 23.4 Clone

$$
Clone(M_i)\rightarrow M_j,
$$

其中：

$$
i\neq j
$$

但初始 semantic content 可相同。

## 23.5 Derive

例如 derivative：

$$
D_x(M_i)\rightarrow M_j.
$$

$j$ 是新 persistent object，並保存：

$$
derivedFrom(M_j,M_i).
$$

## 23.6 Replace-by-equivalent 不等於 identity merge

若 proof 證明 $M_a=M_b$，仍不表示兩個 persistent workspace objects 是同一 identity。

因此：

$$
M_a\equiv_{proof}M_b
\not\Rightarrow
M_a\equiv_{id}M_b.
$$

---

# 24. 可執行數學與安全邊界

## 24.1 純數學 expression 不一定有副作用

理想 symbolic evaluation 可是 pure：

$$
M\mapsto R.
$$

但實際 backend 可能：

- 呼叫外部程式；
- 讀資料；
- 執行自訂 code；
- 啟動 numerical solver；
- 使用 GPU；
- 載入 plugin。

所以 math execution 仍受 TW-03 runtime permission model 管理。

## 24.2 Data dependency 與 code execution 分離

一個 mathematical object 可以引用 dataset，但 dataset reference 不代表任意 code permission。

## 24.3 Reproducibility

execution provenance 至少要能回答：

- input revision；
- backend；
- backend version；
- policy；
- assumptions；
- precision；
- timestamp / environment fingerprint；
- result revision。

---

# 25. 二十項核心不變量

以下構成 Paper 03 的 design freeze。

## M1 — Semantic Object / Projection Separation

$$
M\neq\Pi(M).
$$

任何單一 LaTeX/MathML/SVG/PNG projection 不等於 mathematical object 本身。

## M2 — LaTeX Non-Canonicality

LaTeX 可以是正式 source artifact 的當前文件載體與 interchange adapter，但 future native math content identity 不以任意 LaTeX source bytes 為唯一 canonical basis。

## M3 — Binding Preservation

任何會改變 free/bound variable 關係的轉換都屬 semantic mutation；合法 substitution 必須 capture-avoiding。

## M4 — Alpha-Equivalence Distinction

bound variable renaming 可產生 alpha-equivalent object，但不得僅以 surface string equality 判定。

## M5 — Type/Domain Explicitness

type/domain 可未知，但不得在需要 domain-sensitive operator semantics 時被默默假設且不記錄。

## M6 — Assumption Preservation

任何 rewrite/evaluation 若依賴 assumptions，結果必須保留或引用該 assumption set。

## M7 — Side-Condition Preservation

conditional equivalence/transformation 不得丟失 side conditions。

## M8 — Exactness Preservation

exact numeric object 被近似 projection 顯示時，不得因此改變 canonical exactness。

## M9 — Precision/Rounding Provenance

任何 approximate numeric result 必須可追蹤 precision/rounding/error policy 或等價資訊。

## M10 — Unit/Dimension Semantics

unit/dimension 不只是 display suffix；可計算 quantity 必須能由 semantic layer辨識其 units/dimensions。

## M11 — Undefined Is a First-Class State

undefined、conditional、unresolved、unevaluated 不得全部 collapse 成 generic text error。

## M12 — Equality Is Typed

surface、structural、alpha、formal/proof、approximate equality 不得互相偷換。

## M13 — Canonicalization Is Not Theorem Simplification

canonical byte normalization 與 semantic rewrite/simplification 必須分離。

## M14 — Execution Produces Provenance

任何 committed evaluation result 必須可追溯 input revision、backend/policy 與 output/result relation。

## M15 — Result Does Not Overwrite Source Identity by Default

計算衍生結果預設取得新 identity 或新 result revision/relation，不默認把 source math identity 改成 result。

## M16 — Ambiguity Preservation

Importer/spatial parser/AI 無法唯一判定 semantics 時，unresolved candidate set 是合法 canonical state。

## M17 — Spatial Layout Is Editing Syntax, Not Final Mathematical Ontology

math region 的二維座標可參與 parse，但 canonical math semantics 不依賴 viewport coordinates。

## M18 — External Standards Remain Adapters

MathML/OpenMath/LaTeX/OMDoc 等保持 first-class interoperability roles，不被不必要地封閉或破壞。

## M19 — Proof/Computation Evidence Distinction

computed、verified、proved、heuristic evidence 必須可區分。

## M20 — Semantic Revision / Persistent Identity Separation

數學 expression 被編輯後可以是同 persistent math object 的新 revision；semantic equality 也不等於 persistent identity equality。

---

# 26. Conformance Tests

## T1 — Two TeX sources, one supported semantic object

對 supported subset 的兩個不同 LaTeX sources，若 importer resolve 到相同 native semantics，要求 semantic structural comparison 可相等，而原始 source artifact 仍可分別保存。

## T2 — Same rendering, different binding

建立兩個 visually identical expression，但 binder references 不同。要求：

$$
\equiv_{surface}
$$

可成立，但：

$$
\equiv_{struct}
$$

或 semantic equivalence 不得被自動宣告。

## T3 — Alpha-equivalence

$$
\int_0^1 x^2\,dx
$$

與：

$$
\int_0^1 y^2\,dy
$$

在同 domain/profile 下應被 alpha-equivalence checker 判為等價。

## T4 — Capture avoidance

substitution 不得把自由變數意外變成 bound variable。

## T5 — Domain-sensitive operator

同一 `+` glyph 在 scalar 與 matrix domain 中必須解析到可區分的 operator/type context，或保持 unresolved。

## T6 — Side condition

對：

$$
\frac{x^2-1}{x-1}\rightarrow x+1,
$$

結果必須保存：

$$
x\neq1.
$$

或 equivalent domain restriction。

## T7 — Exact-to-decimal projection

exact $1/3$ 被顯示成有限 decimal 時，content exactness 不變。

## T8 — Approximate result metadata

數值積分結果必須保存 precision/tolerance/backend policy。

## T9 — Unit mismatch

$$
3\mathrm m+5\mathrm s
$$

必須產生 dimension diagnostic，而非成功 numeric addition。

## T10 — Undefined state

$$
1/0
$$

在 standard field profile 下回傳 `Undefined` object/status，而不是字串 `Infinity`，除非選定的 extended domain/profile 明確定義不同語義。

## T11 — Ambiguous superscript

未指定 domain 的 superscript notation 若可有多種解讀，系統可保留多候選，不強制 commit exponentiation。

## T12 — LaTeX export round trip profile

NCM supported subset export 成 LaTeX，再 import 時必須達到宣告的 structural/semantic fidelity；若 loss，必須 report。

## T13 — OpenMath/Content MathML adapter

對受支援 semantic subset，adapter 應保留 operator identity、argument order、binding 與 literal semantics。

## T14 — Equality evidence label

CAS heuristic 說兩 expression 等價時，不得在 UI/API 中冒充 theorem-proved equality，除非有 proof/certificate backend。

## T15 — Spatial fraction compile

math region 中 numerator/bar/denominator 經 parse+commit 後產生 native Divide/Fraction semantic object；移動畫布整體位置不改該 semantics。

## T16 — Result provenance

執行 derivative：

$$
D_x(x^2)\rightarrow2x
$$

必須能追蹤 source revision、operator/backend、result revision 與 assumptions。

## T17 — Backend version divergence

兩 backend/version 產生不同 simplification forms時，兩結果均保留 provenance，不 silent overwrite。

## T18 — Canonicalization does not commute-sort blindly

對未宣告 commutative 的 operator，canonicalizer 不得為了 hash 任意重排 operands。

---

# 27. MVP-01 的最小 Native Math Slice

MVP 不需要先做完整 CAS。只需證明 native object contract。

## 27.1 Native expression object

至少支援：

- symbol；
- integer/rational literal；
- addition；
- multiplication；
- power；
- function application；
- derivative operator。

## 27.2 Binding

至少支援一個 binder，例如 lambda、sum 或 integral 中的一種，以證明 bound variable 不只是 visible name。

## 27.3 Assumptions

至少能附：

$$
x\in\mathbb R
$$

與：

$$
x\neq0.
$$

## 27.4 Exact arithmetic

至少證明：

$$
1/3
$$

可以保持 exact，不因顯示 decimal 而 mutation。

## 27.5 Native execution

至少能執行：

$$
f(x)=x^2
$$

到：

$$
D_x(f)=2x.
$$

內部計算不得要求先把 canonical object轉回 LaTeX 再 parse。

## 27.6 Multiple projections

同一 math object 至少可有：

- traditional visual projection；
- linear/debug structural projection；
- LaTeX export。

最好再加入 MathML/OpenMath 之一的 minimal adapter。

## 27.7 Spatial math region

Paper 02 的 math region 至少支援一個二維 construct，例如 fraction 或 superscript，並 parse 成 NCM object。

## 27.8 Provenance

result object 要能顯示：

- input ID/revision；
- operation；
- backend；
- output ID/revision。

若上述八項成立，MVP 即能證明：

$$
\boxed{
\text{math object}
\neq
\text{LaTeX source}
}
$$

不只是哲學口號，而是工程事實。

---

# 28. 對 Paper 04 — Generative Glyph 的接口

Paper 04 會處理自訂 visual glyph 如何成為 symbol object。

Paper 03 為其提供 mathematical semantic attachment point：

$$
GlyphObject
\xrightarrow{denotes}
MathOperator/Symbol.
$$

同一 operator 可有多個 glyph/projection：

$$
Glyph_1\mapsto op,
$$

$$
Glyph_2\mapsto op.
$$

反過來，同一 glyph geometry 在不同 local grammar/domain 可以指向不同 semantic candidates。

因此：

$$
\text{glyph identity}
\neq
\text{operator semantic identity}.
$$

這個分離對未來「使用者自己畫數學符號」尤其重要。

---

# 29. 對 Paper 05 — Multi-Layer Addressing 的接口

Paper 05 將深入展開：

- mathematical persistent address；
- semantic theory/symbol address；
- subexpression address；
- proof object address；
- execution result address；
- cross-version subexpression mapping；
- external OpenMath/MathML/URI mapping。

Paper 03 已凍結一個重要前提：

$$
\text{subexpression location}
$$

不能只依賴可變的 visible character offset。

未來應以 revision-aware structural address / node identity / provenance mapping 解決。

---

# 30. 對 TW-01 — Symbol IR 的工程接口

TW-01 必須把本文抽象模型轉為真正 schema，至少回答：

1. math node kind registry；
2. operator semantic reference 格式；
3. symbol identity 與 visible name 分離方式；
4. binder/bound-variable representation；
5. type/domain representation；
6. assumptions/constraints schema；
7. units/dimensions schema；
8. exact/approx numeric schema；
9. undefined/conditional/unresolved states；
10. presentation hints；
11. execution binding references；
12. content canonicalization；
13. alpha-normalization；
14. subexpression addressing；
15. MathML/OpenMath/LaTeX adapter fidelity metadata。

---

# 31. 對 TW-03 — Runtime 的工程接口

TW-03 必須回答：

1. math backend plugin API；
2. symbolic vs numeric execution profile；
3. precision/resource sandbox；
4. result caching；
5. rewrite trace；
6. proof/certificate backend；
7. backend trust labels；
8. concurrent math edits；
9. spatial math parser scheduling；
10. error/undefined/conditional UI；
11. computation provenance ledger；
12. deterministic validation boundary。

---

# 32. 非主張

本文不主張：

1. LaTeX 沒有價值；
2. 所有人都應停止手寫 LaTeX；
3. MathML/OpenMath/OMDoc 應被 EveGlyph 私有格式取代；
4. 所有數學都有唯一 canonical normal form；
5. 所有 semantic equivalence 都可判定；
6. 所有 CAS simplification 都是 formal proof；
7. 所有數學符號都有唯一跨文化、跨理論含義；
8. AI 可以可靠猜出所有手寫／自訂 notation；
9. 空間座標本身就是數學 ontology；
10. exact arithmetic 可以取代所有 numerical computing；
11. theorem prover 可以取代所有 numerical/symbolic engine；
12. 一個 expression tree 足以表示全部數學知識；
13. NCM v0.1 已凍結完整數學宇宙 ontology；
14. native math 必須綁定單一 programming language 或 CAS。

本文主張的是更有限但更基礎的一件事：

> **在 AI-native computational workspace 中，mathematical object 應該成為 first-class canonical object，而 LaTeX 與其他 notation/serialization 則成為可互通的 projection 與 adapter。**

---

# 33. Paper 03 Design Freeze

完成本文後，後續文件不得在未顯式修訂的情況下破壞以下決策：

1. native math object 與任意單一 presentation/serialization 分離；
2. future NCM canonical math semantics 不以 LaTeX source bytes 作為唯一 ontology；
3. expression graph、binding、type/domain、assumptions、constraints、units、numeric state、presentation、execution/provenance 分離；
4. bound variable identity 與 visible variable name 分離；
5. alpha-equivalence 是正式 equality 類型；
6. assumptions 與 side conditions 不得在 rewrite/evaluation 中被靜默丟失；
7. exact/approximate numeric states 分離；
8. approximate result 必須帶 precision/error/rounding 或等價 provenance；
9. units/dimensions 進入 semantic layer；
10. undefined/conditional/unresolved/unevaluated 是 distinct first-class states；
11. surface/structural/alpha/formal/proof/approximate equality 分離；
12. canonical serialization 與 theorem-based simplification 分離；
13. computation result 需有 provenance，且預設不覆寫 source identity；
14. proof evidence 與 computation evidence 分離；
15. ambiguous import/parse 可以保持 unresolved；
16. spatial notation 可作 editing syntax，但 canonical math semantics 不依賴 viewport coordinates；
17. MathML/OpenMath/LaTeX/OMDoc 保留互通角色；
18. subexpression addressing 必須 revision-aware，而不能只依賴 character offset；
19. AI-generated interpretation 預設是 candidate，不是 canonical truth；
20. Native Math MVP 必須證明 computation 可直接作用於 NCM object，而不是依賴「轉 LaTeX 再 parse」作為 canonical execution path。

---

# 34. 結論

LaTeX 解決的是一個非常成功、非常重要的問題：如何用文字工具精確描述高品質數學排版。它之所以被廣泛使用，不是因為歷史錯誤，而是因為它在自己的問題域極其有效。

但 AI-native computational workspace 問的是另一個問題。

它需要知道的不只是：

> 「這個公式要怎麼排？」

而是：

> 「這個數學物件是什麼？」

> 「哪些符號是 free，哪些被 binder 綁定？」

> 「它在哪個 domain/theory 中？」

> 「依賴哪些 assumptions？」

> 「這個 rewrite 有什麼 side conditions？」

> 「這個數字是 exact 還是 approximate？」

> 「這個結果由哪個 backend、哪個版本、哪個 policy 產生？」

> 「這個等價是畫面相同、結構相同、alpha-equivalent、CAS 判定、還是有 theorem proof？」

> 「它可以如何被投影成 LaTeX、MathML、OpenMath、Canvas、語音或其他形式？」

如果 canonical source 只有排版字串，這些問題每次都需要重新推理、重新 parse、重新猜測。

NCM 的方向是把這些關係直接提升成數學物件本身的一部分：

$$
\boxed{
\text{Native Math}
=
\text{Semantic Structure}
+
\text{Binding}
+
\text{Context}
+
\text{Conditions}
+
\text{Execution}
+
\text{Provenance}
}
$$

而 notation 變成：

$$
\boxed{
\text{Notation}
=
\text{Projection / Editing Surface}
}
$$

這不是「消滅 LaTeX」。恰恰相反，它讓 LaTeX 回到最擅長的位置，並且仍可長期保留。

未來 EveGlyph 的使用者甚至不必知道內部 NCM schema。他可以：

- 打字；
- 手寫；
- 貼 LaTeX；
- 拉一條 fraction bar；
- 畫自訂 glyph；
- 讓 AI 協助解讀；
- 從 MathML/OpenMath 匯入；

而系統真正 commit 的，是經過解析與驗證的 native mathematical object。

於是：

$$
\text{Human Notation}
\leftrightarrow
\text{Native Math Object}
\leftrightarrow
\text{Computation / Proof}
$$

才成為主循環。

Paper 00 把文件從字串提升成可定址計算空間；Paper 01 解決「物件是誰」；Paper 02 解決「空間何時成為 syntax」；Paper 03 則完成下一個關鍵轉換：

$$
\boxed{
\text{formula as text}
\rightarrow
\text{mathematics as object}
}
$$

有了這個基礎，Paper 04 才能真正處理更進一步的問題：**如果符號本身也不必受限於現成 Unicode 字元，那麼人類或 AI 新畫出的 glyph，如何被編譯、定址、賦予語義，並成為 NCM 或其他 computational domain 的一級符號？**

---

# References

[1] W3C Math Working Group. *MathML Core*. Candidate Recommendation Snapshot, 24 June 2025.

[2] W3C Math Working Group. *Mathematical Markup Language (MathML) Version 4.0*. Working Draft, 04 June 2026.

[3] The OpenMath Society. *The OpenMath Standard, Version 2.0 Revision 2*. 2019.

[4] Michael Kohlhase. *OMDoc — An Open Markup Format for Mathematical Documents [Version 1.2]*. Lecture Notes in Computer Science 4180. Springer, 2006.

[5] Bruno Buchberger et al. “Theorema: Towards computer-aided mathematical theory exploration.” 2006.

[6] Fairouz Kamareddine and J. B. Wells. “Computerizing Mathematical Text with MathLang.” 2008.

[7] EveMissLab. *00 — From Linear Documents to Addressable Symbolic Computational Spaces*. v0.1, 2026.

[8] EveMissLab. *01 — Addressable Symbolic Object Model: Identity, Content, Semantics, Relations, Versioning, and Equality in Computational Documents*. v0.1, 2026.

[9] EveMissLab. *02 — Spatial Syntax and Infinite Canvas Computation: From Geometric Arrangement to Verifiable Executable Structure*. v0.1, 2026.

[10] EveMissLab. *Generative Symbol Compiler Lab v1.13.0-strict-symbolic*. validated source baseline, 2026.

[11] EveMissLab. *PSSA-BSAR v0.1 Milestone 4 Source*. controlled address-first semantic recovery harness, 2026.

---

# Appendix A — 最小形式化摘要

Persistent math object：

$$
O_i^{math}=(i,\texttt{math},H_i).
$$

Math revision：

$$
M_{i,v}
=
(i,v,G,\Beta,\Tau,\Gamma,\mathcal A,\mathcal C,\mathcal U,\mathcal N,\mathcal P,\mathcal X,\mathcal M).
$$

Expression graph：

$$
G=(N,E,\lambda,\eta).
$$

Typing：

$$
\Gamma\vdash M:T.
$$

Evaluation：

$$
Eval(M,\Gamma,\Pi)
\rightarrow
(R,\Delta,\rho,\chi).
$$

Theorem-backed equality：

$$
\pi:\Theta\vdash M_1=M_2.
$$

Approximate equality：

$$
M_1\approx_{metric,\epsilon}M_2.
$$

Content address：

$$
a^{content}=H(D_m\Vert C_{\sigma}(SemanticState(M))).
$$

Subexpression address：

$$
a^{sub}=(a^{ver},path/schemaRef).
$$

Spatial interpretation：

$$
Parse_{math}(Layout)
\rightarrow
\{(M_i,q_i)\}_{i=1}^{n}.
$$

LaTeX import/export：

$$
I_{TeX}:S_{TeX}\rightharpoonup Candidate(NCM),
$$

$$
E_{TeX}:NCM\rightarrow S_{TeX}.
$$

---

# Appendix B — Implementation-facing Checklist

在 TW-01 / TW-03 / MVP-01 正式實作 Paper 03 前，至少必須回答：

1. math node IDs 是否在 revision 內穩定？
2. symbol visible name 與 semantic identity 如何分離？
3. binder 用 named variables、unique IDs、de Bruijn indices 或其他方案？
4. alpha-normalization 如何 deterministic？
5. expression graph 是否允許 shared subexpression？
6. operator/theory reference 如何映射 OpenMath content dictionary / local namespace？
7. unresolved operator 如何表示？
8. type/domain 系統是否 extensible？
9. assumptions 與 constraints 是否分不同 authority level？
10. unit/dimension schema 是否使用外部 registry？
11. exact rational、arbitrary precision、float、interval 如何表示？
12. rounding mode / precision / error bound 如何保存？
13. undefined、conditional、unevaluated、unresolved 的 wire representation？
14. presentation hints 是否進 semantic content hash？若部分進，邊界如何定義？
15. LaTeX source artifact 是否可作 provenance attachment 而非 math identity？
16. MathML/OpenMath adapter 支援哪些 subset？
17. importer fidelity report schema？
18. semantic equality service API 如何回報 evidence class？
19. rewrite trace 如何保存 side conditions？
20. proof certificate 如何掛接 claim？
21. execution backend plugin contract？
22. backend version/resource policy 如何進 cache key？
23. result object identity policy？
24. subexpression address 在 rewrite 後如何 map？
25. math region spatial grammar 的 candidate/commit UI？
26. AI interpretation 如何標 confidence 與 authority？
27. 哪些 transformation 必須由 deterministic validator 重驗？
28. canonicalization 如何避免偷做 theorem simplification？
29. native math debug view 如何顯示 graph/binding/type/assumption？
30. MVP 如何證明不需要把 NCM object 先轉成 LaTeX 才能計算？

Paper 03 不要求現在把整個數學 ontology 寫完；它要求後續任何實作都不能把「native math」退化回「換了一個名字的公式字串」。


<!-- SOURCE: 04_生成式字形與符號編譯_從像素來源到可定址幾何拓撲部件語法與語義符號_v0.1.md -->

# 04｜生成式字形與符號編譯：從像素來源到可定址幾何、拓撲、部件語法與語義符號

**English Title:** Generative Glyph and Symbol Compilation: From Raster Sources to Addressable Geometry, Topology, Part Grammars, and Semantic Symbols

**作者：** Neo.K  
**機構：** EveMissLab / 一言諾科技有限公司  
**版本：** v0.1  
**日期：** 2026-08-24  
**文件類型：** 專題論文 / Formal Architecture Paper  
**系列定位：** EveGlyph Addressable Symbolic Computational Space Series — Paper 04  
**前置錨點：** Paper 00 — From Linear Documents to Addressable Symbolic Computational Spaces；Paper 01 — Addressable Symbolic Object Model；Paper 02 — Spatial Syntax and Infinite Canvas Computation；Paper 03 — Native Computational Mathematics Beyond LaTeX

---

## Canonical Source Note

本文件以 UTF-8 Markdown 保存正式原稿。數學 source 僅使用 `$...$` 與 `$$...$$` 作為 canonical delimiter。

本文中的 glyph、symbol、shape、visual asset、raster source、symbolic asset 與 semantic symbol 必須嚴格區分。本文不主張任何一張影像經過壓縮後就自然成為「真正的符號」，也不主張目前 Generative Symbol Compiler 已完成一般視覺理解。相反地，本文把從像素到符號的過程拆成可驗證的多層 compilation ladder，使「可逆承載」、「幾何結構」、「拓撲結構」、「部件語法」、「語義身份」與「執行行為」不再被混成同一概念。

因此：

$$
\text{source image}
\neq
\text{symbolic carry}
\neq
\text{structural symbol}
\neq
\text{semantic glyph}.
$$

本文凍結的是未來 EveGlyph glyph/symbol object 的抽象語義、編譯層級、identity/provenance discipline 與驗證條件，不直接凍結最終 vector format、GPU renderer、curve representation、font technology 或模型架構。具體 wire schema 將由 TW-01 定義，runtime/rendering 則由 TW-03 與 MVP-01 定義。

---

## 摘要

如果未來的 EveGlyph 要讓使用者直接畫一個符號、組合圖形、建立新的運算 glyph，甚至讓圖像符號成為機器內部可定址、可重用、可計算的一級物件，那麼「符號」就不能被簡化成 Unicode code point，也不能被簡化成 PNG、SVG path 或一串像素。真正的問題是：一個 visual source 如何在不秘密依賴原始影像的情況下，被編譯成足以重建、比較、版本化、分析、賦義與執行的 symbolic object？

既有電腦視覺、圖形學、字元辨識、shape descriptor、skeletonization 與 shape grammar 研究已提供大量局部工具：輪廓可以被抽取，medial/skeleton structure 可以近似形狀骨架，shape grammar 可以描述可重用組合規則，vector graphics 可以將幾何從像素解析度中分離。然而，這些技術通常服務辨識、渲染、建模或特定視覺語言，並不直接等同於一個具有 persistent identity、content address、semantic address、revision DAG、spatial placement、provenance 與 execution binding 的文件原生符號物件。

本文提出 **Generative Glyph and Symbol Compilation, GGSC** 作為 ASCS 的 visual-symbol layer。GGSC 將編譯流程拆成六個層級：source artifact、normalized compile target、exact symbolic carry、structural lift、part grammar、semantic symbol object。每一層回答不同問題，且證據不能跨層偷換。若某 representation 能在 source 被刪除後 bit-exact 重建 normalized raster，它證明的是 representation sufficiency，而不是高階語義理解；若 skeleton graph 能穩定抽取，也不代表系統已知道某個部件是「手臂」、「積分號」或「導數運算子」。語義必須由 explicit assignment、validated recognition、domain grammar、external ontology 或人類／AI proposal 經 commit boundary 建立。

本文以 EveMissLab 現有 Generative Symbol Compiler Lab v1.13.0-strict-symbolic 為工程基線。該實作使用 `AssetSymbol v0.7` 作為 canonical representation，strict renderer 的函式介面只接受 symbolic asset；Gate 1 以 palette 加 RUN tokens 完成 source-blind exact carry，後續 Gate 2 至 Gate 5 逐步加入 normalizer、region/topology、ordered contour anchors、skeleton/medial hints、skeleton graph/segment compression 與 part grammar；後續 gates 再處理 enhanced rendering、runtime/autotile、native import package 與 preview-only project binding。本文在本輪重新執行其測試，結果為 $105/105$ automated tests passed，並通過三個 JavaScript syntax checks。這些結果支持的是「限定 finite-palette pixel-art / pixel-like domain 中，source-independent symbolic reconstruction 與結構提升已具有可重現工程基線」，而不是一般圖像語義壓縮已完成。

在此基礎上，本文提出 EveGlyph `glyph` object 的形式模型：intrinsic geometry、topology、part graph、semantic binding、rendering profile 與 behavior/execution binding 分離；source image 與 compiled symbol 採 derivation relation 而非 identity collapse；glyph 的存在不依賴 Unicode assignment；同一 glyph 可擁有多種 raster/vector/canvas projection；幾何相等、拓撲相等、結構相等、視覺相等與語義相等被定義為不同 equivalence relation。本文最後凍結二十項 GGSC invariants 與十八項 conformance tests，並給出 EveGlyph MVP 的最小 custom-symbol vertical slice。

**關鍵詞：** Generative Glyph、Symbol Compilation、AssetSymbol、Shape Grammar、Skeletonization、Topology、Part Grammar、Source-Blind Reconstruction、EveGlyph、Symbol IR、Custom Glyph、Semantic Symbol、Visual Object

---

## Abstract

Future symbolic workspaces require more than image embedding or font glyph lookup. If a user can draw a new symbol, compose graphical parts, assign semantics, bind executable behavior, and later address that symbol as a first-class computational object, then a glyph cannot be reduced to a Unicode code point, a raster image, or an SVG path alone.

This paper proposes **Generative Glyph and Symbol Compilation (GGSC)** as the visual-symbol layer of the EveGlyph Addressable Symbolic Computational Space. The compilation process is decomposed into distinct evidence levels: source artifact, normalized target, exact symbolic carry, structural lift, part grammar, and semantic symbol object. These levels are intentionally non-interchangeable. Source-independent exact reconstruction demonstrates representation sufficiency but not semantic understanding; topology and skeleton extraction demonstrate structural lifting but do not by themselves determine conceptual meaning; semantic identity must be introduced through explicit, validated, or provenance-bearing mechanisms.

The paper uses EveMissLab's Generative Symbol Compiler Lab v1.13.0-strict-symbolic as an engineering baseline. Its `AssetSymbol v0.7` representation supports source-blind exact rendering for a finite-palette pixel-art domain and progressively adds normalization, regions, adjacency, topology, contour anchors, skeleton and medial hints, skeleton graphs, segment compression, part grammar, enhanced rendering, runtime adapters, native import packages, and non-mutating project-binding previews. A fresh verification during this paper's preparation produced 105/105 passing automated tests and successful JavaScript syntax checks.

GGSC then lifts these engineering results into a general EveGlyph glyph-object model that separates intrinsic geometry, topology, part structure, semantic bindings, presentation profiles, spatial placement, provenance, and executable behavior. It further distinguishes visual equivalence, geometric equivalence, topological equivalence, structural equivalence, and semantic equivalence. The goal is not to replace Unicode, SVG, fonts, or image formats, but to make them projections and interoperability layers over addressable symbolic objects whose existence is not dependent on any single encoding standard.

---

# 1. 問題：字形、圖片與符號不是同一層

## 1.1 Raster image 回答的是「每個 sample 是什麼」

一張 raster image 可抽象為：

$$
I:\Omega\rightarrow\mathcal C,
$$

其中 $\Omega$ 是離散 sample domain，$\mathcal C$ 是顏色／alpha 空間。

它非常擅長保存視覺結果，但通常不直接回答：

- 哪些 pixels 屬於同一 region；
- 哪些 region 形成同一 part；
- 哪些部件有 adjacency／attachment；
- 哪個形狀是 operator；
- 哪一個局部 stroke 是可替換 primitive；
- 這個圖像與另一個 resolution 是否代表同一 glyph；
- 這個 glyph 在某個 domain 中代表什麼。

因此：

$$
\text{pixel fidelity}
\neq
\text{symbolic structure}.
$$

## 1.2 Vector path 回答的是幾何，不必然回答語義

若使用 vector representation：

$$
V=(P_1,P_2,\ldots,P_n),
$$

其中 $P_i$ 為 path/curve primitive，系統已經從 raster sampling 中抽離一層。

但 vector path 仍不必然知道：

$$
\text{this path}=\text{derivative operator}.
$$

所以：

$$
\text{geometry}
\neq
\text{semantic identity}.
$$

## 1.3 Unicode code point 回答的是編碼身份，不是任意 visual object ontology

Unicode 對一般文字交換極其重要，但 EveGlyph 的 domain-specific glyph 不應要求先獲得全球標準 code point 才能存在。

因此：

$$
\operatorname{ExistsAsGlyph}(g)
\not\Rightarrow
\operatorname{HasUnicodeCodePoint}(g).
$$

反過來，一個 Unicode character 可以有多種字型、字重與 glyph design，因此：

$$
\text{character identity}
\neq
\text{glyph geometry identity}.
$$

---

# 2. 從 Shape Representation 到 Symbol Object

既有 shape feature、skeletonization 與 visual-language research 提供重要基礎。

shape descriptor 研究已長期區分 boundary-based 與 region-based representations，並使用 contour、moments、skeleton、topological properties 等描述形狀。Skeleton/medial representations 則試圖把 area-like shape 壓縮成保留主要 branch/width 結構的線性骨架；thinning algorithms 亦廣泛用於 character recognition、fingerprint、diagram analysis 等場景。

另一方面，shape grammar 與 visual grammar 研究說明 visual object 可以透過 primitive、spatial relation 與 production rule 被組合與生成。這與 GGSC 的 part grammar 方向一致，但本文加入 ASOM 的 identity/version/provenance 以及 Paper 02 的 authority boundary。

也就是說，本文不把 shape grammar 當成 complete semantics，而將它放在：

$$
\text{geometry}
\rightarrow
\text{structure}
\rightarrow
\text{candidate semantics}
$$

的中介層。

---

# 3. 六層 Compilation Ladder

本文定義：

$$
L_0\rightarrow L_1\rightarrow L_2\rightarrow L_3\rightarrow L_4\rightarrow L_5.
$$

每一層必須有不同驗證標準。

## 3.1 $L_0$ — Source Artifact

原始來源：

$$
I_S.
$$

可能是：

- raster image；
- hand-drawn stroke stream；
- vector source；
- camera capture；
- imported font glyph；
- legacy sprite/tile。

source 是 evidence/provenance，不必是 final canonical glyph state。

## 3.2 $L_1$ — Normalized Compile Target

透過顯式 normalizer：

$$
N_{\nu}(I_S)\rightarrow I_N.
$$

例如 finite-palette quantization、alpha threshold、despeckle 或 grid normalization。

重要的是：

$$
I_N\neq I_S
$$

是合法的，前提是 transformation 被記錄。

## 3.3 $L_2$ — Exact Symbolic Carry

編譯：

$$
C_2(I_N)\rightarrow S_2.
$$

source-blind renderer：

$$
R_2(S_2)\rightarrow \hat I_N.
$$

在 exact domain 中要求：

$$
\hat I_N=I_N.
$$

這只證明：

> $S_2$ 足以承載 $I_N$。

不證明：

> $S_2$ 已理解 $I_N$ 的高階語義。

## 3.4 $L_3$ — Structural Lift

由 symbolic carry 抽出：

$$
S_3=(regions,adjacency,contours,topology,skeleton,graph).
$$

此層開始提供比 raster 更可操作的結構。

## 3.5 $L_4$ — Part Grammar

由 region/topology/skeleton graph 抽出 reusable parts：

$$
G_P=(P,E_P,R_P).
$$

其中 $P$ 為 part tokens，$E_P$ 為 attachment/composition relations，$R_P$ 為 part-role hypotheses。

## 3.6 $L_5$ — Semantic Symbol Object

最終 EveGlyph glyph object：

$$
G^*=(i,v,G,T,P,S,B,M).
$$

其中：

- $i$：persistent identity；
- $v$：revision；
- $G$：intrinsic geometry；
- $T$：topology；
- $P$：part structure；
- $S$：semantic bindings；
- $B$：behavior/execution bindings；
- $M$：metadata/provenance。

只有到這一層，系統才正式擁有可定址 semantic glyph。

---

# 4. GSC v1.13 作為工程基線

目前 Generative Symbol Compiler Lab v1.13.0-strict-symbolic 已建立一條刻意隔離的 strict symbolic path。

其核心驗證模式可寫成：

$$
I
\xrightarrow{C}
S
\xrightarrow{delete\ source}
S
\xrightarrow{R}
\hat I.
$$

strict renderer 的函式介面只接受 symbolic asset $S$，因此不能在 render 階段偷讀原始 RGBA buffer。

Gate 1 canonical representation 為：

$$
S=(canvas,palette,RUN,regions,adjacency).
$$

其中 RUN token 先確保 exact finite-palette carry。

後續 Gate 3 至 Gate 5 已逐步加入：

$$
regions
\rightarrow topology
\rightarrow contour\ anchors
\rightarrow medial/skeleton
\rightarrow skeleton\ graph
\rightarrow part\ grammar.
$$

目前 `AssetSymbol v0.7` 為 canonical representation。Gate 6 之後 enhanced renderer 仍只讀 `AssetSymbol`；runtime/native import package 是 consumer-layer artifact；Gate 11 project binding plan 為 preview-only non-mutating review artifact。

本輪 fresh verification：

$$
105/105
$$

automated tests passing，且：

- `src/core.js` syntax check passed；
- `strict-symbolic-app.js` syntax check passed；
- `app.js` syntax check passed。

這些結果應被精確表述為：

> GSC v1.13 已在目前限定 domain 中證明 source-blind exact symbolic reconstruction 與逐層 structural metadata lifting 的工程基線可重現。

而不是：

> 一般視覺語義已被完整編譯。

---

# 5. Representation Sufficiency 與 Semantic Sufficiency 分離

定義 visual fidelity metric：

$$
F_v(S,I).
$$

若 exact renderer 達到：

$$
F_v(S,I)=1,
$$

只能說 representation 對指定 visual target 足夠。

另定義 structural fidelity：

$$
F_s(S,\Sigma),
$$

以及 semantic fidelity：

$$
F_m(S,\mathcal M).
$$

一般而言：

$$
F_v=1
\not\Rightarrow
F_s=1,
$$

更不推出：

$$
F_m=1.
$$

這是 Paper 04 的第一個核心防誇大原則。

---

# 6. Source Artifact 與 Compiled Glyph 的 Identity

若 raster source $O_r$ 經 compiler 產生 glyph $O_g$：

$$
Compile(O_r)\rightarrow O_g.
$$

ASOM identity discipline 要求預設：

$$
id(O_r)\neq id(O_g).
$$

並建立 provenance：

$$
derivedFrom(O_g,O_r).
$$

或：

$$
generatedBy(O_g,C_{\nu},O_r).
$$

這比把 PNG 與 glyph 強迫視為同一 persistent identity 更精確。

source 可以刪除或移入 archival storage，而 glyph object 仍持續存在；只要 provenance retention policy 被滿足即可。

---

# 7. Glyph Object 模型

本文定義一個 glyph revision：

$$
\rho_g=
(i,v,k,G,T,P,S,R,B,A,M).
$$

其中：

- $i$：persistent identity；
- $v$：revision identity；
- $k$：glyph kind/profile；
- $G$：intrinsic geometry；
- $T$：topology；
- $P$：part graph/grammar；
- $S$：semantic bindings；
- $R$：rendering profiles；
- $B$：behavior/execution bindings；
- $A$：address bundle；
- $M$：metadata/provenance。

注意：

$$
G
\neq
S
\neq
B.
$$

同一 geometry 可以被賦予不同 semantics；同一 semantics 也可以有不同 glyph geometries。

---

# 8. Intrinsic Geometry

intrinsic geometry：

$$
G=(primitives,parameters,constraints,localFrame).
$$

primitive 可以依 profile 包含：

- pixel runs；
- points；
- polylines；
- curves；
- closed contours；
- filled regions；
- strokes；
- parametric shapes；
- procedural primitives。

Paper 04 不規定未來一定採哪一種 representation。

重要的是 intrinsic geometry 存在於 object-local frame：

$$
F_g^{local}.
$$

canvas placement 則由 Paper 02 的 extrinsic transform 處理。

因此：

$$
Move(g)
\not\Rightarrow
EditGeometry(g).
$$

---

# 9. Topology 是獨立結構

兩個 geometry 可以視覺近似，但 topology 不同。

定義：

$$
T=(components,holes,adjacency,connectivity,boundaryRelations).
$$

例如：

- component count；
- hole count；
- region adjacency；
- connectedness；
- contour nesting。

因此 topology 不應只作 ephemeral renderer metadata。

如果 topology 是 glyph recognition / grammar / execution 所需的 intrinsic structure，它就應進入 glyph revision 的 canonical state。

---

# 10. Skeleton / Medial Structure 的定位

skeleton 可以提供形狀的 branch、endpoint、junction 與 approximate width structure。

可抽象：

$$
K=(V_K,E_K,r_K).
$$

其中：

- $V_K$：skeleton nodes；
- $E_K$：branch/path；
- $r_K$：medial radius hints。

GSC v1.13 使用 deterministic Zhang-Suen thinning baseline 加上 Manhattan distance transform 建立 medial hints，並明確聲明這不是連續幾何意義下的 exact medial axis。

這個限制應被保留到 EveGlyph：

$$
SkeletonHint
\neq
ExactMedialAxis.
$$

不同 skeletonizer 可以成為不同 versioned derivation profile。

---

# 11. Part Graph 與 Part Grammar

當 glyph 只有 raw contours 時，許多高階操作仍需重新掃描 geometry。

因此定義 part graph：

$$
P_G=(V_P,E_P,\lambda_P).
$$

每個 part 可包含：

$$
p=(id,primitive,orientation,roleCandidate,attachments,geometryRef).
$$

part grammar：

$$
\mathcal G_P=(\Sigma_P,N_P,Rules_P,Version_P).
$$

其功能是：

- 重用結構；
- 支援局部替換；
- 支援 procedural rerender；
- 支援 family/variant generation；
- 支援 semantic candidate generation。

但：

$$
PartRoleCandidate
\neq
CommittedSemanticRole.
$$

例如「vertical stroke」是 structural role；「積分號主幹」則可能是 domain semantic role。

---

# 12. Semantic Binding

一個 glyph 可具有：

$$
S_g=(domain,conceptRef,positiveAnchors,negativeAnchors,constraints,confidence,authority).
$$

semantic binding 的來源至少分：

1. explicit human assignment；
2. imported standard mapping；
3. validated domain grammar；
4. AI/recognizer candidate；
5. inherited family mapping；
6. unresolved。

因此 AI recognition：

$$
Recognize(g)\rightarrow\hat S_g
$$

預設只能得到 candidate。

commit：

$$
Promote(\hat S_g,authority)\rightarrow S_g.
$$

這與 Paper 02 的 spatial authority model 同構。

---

# 13. Glyph 不需要先進 Unicode 才能存在

EveGlyph domain glyph 可以先取得：

$$
a^{id}(g),
$$

$$
a^{content}(g),
$$

$$
a^{sem}(g).
$$

它可以具有 textual fallback：

$$
name(g)=\text{``custom-derivative-01''}.
$$

也可以選擇性綁定 Unicode/PUA/external font glyph，但這只是 adapter：

$$
Map_{unicode}:g\rightharpoonup codepoint.
$$

不是存在條件。

這使研究型、企業內部、遊戲、數學、音樂或 AI-only 符號可以先在局部 domain 建立，不必把全世界的 character standard 當成每個新物件的登記處。

---

# 14. Character、Glyph、Symbol 三層分離

本文使用以下區分。

## 14.1 Character

抽象文字編碼 identity。

## 14.2 Glyph

某個可視形式／幾何物件。

## 14.3 Symbol

具有 domain semantics 的記號物件。

因此可以有：

$$
OneCharacter\rightarrow ManyGlyphs,
$$

以及：

$$
OneGlyph\rightarrow ManyPossibleSemantics.
$$

也可以有：

$$
OneSemanticSymbol\rightarrow ManyGlyphVariants.
$$

EveGlyph 的 Symbol IR 必須允許這三層 many-to-many mapping，而不是強迫一對一。

---

# 15. Glyph Family 與 Variant

定義 glyph family：

$$
F=(i_F,baseGrammar,parameters,constraints,variants).
$$

variant 可以由：

$$
g_{\theta}=Instantiate(F,\theta).
$$

產生。

$\theta$ 可以控制：

- stroke width；
- aspect ratio；
- palette；
- ornament；
- resolution profile；
- component presence；
- animation state。

但 family membership 與 semantic identity 必須有明確 policy。

例如兩個風格 variant 可以：

$$
g_1\equiv_{sem}g_2
$$

但：

$$
g_1\not\equiv_{geo}g_2.
$$

---

# 16. Rendering Profiles

canonical glyph object 不應綁死一種 renderer。

定義：

$$
R_{\pi}(g,ctx)\rightarrow view.
$$

render profile $\pi$ 可以是：

- exact pixel renderer；
- enhanced pixel renderer；
- vector projection；
- monochrome accessibility renderer；
- low-resolution icon renderer；
- semantic zoom renderer；
- print renderer；
- animation renderer。

如果 renderer 只是 projection，則：

$$
R_{\pi_1}(g)\neq R_{\pi_2}(g)
$$

不意味 glyph identity 改變。

---

# 17. Source-Blindness 是可測試的 Renderer Contract

對 strict renderer：

$$
R:S\rightarrow I.
$$

其 API contract 不允許 source argument。

驗證可以進一步做 destructive source test：

$$
C(I)\rightarrow S,
$$

刪除或破壞：

$$
I.data:=\varnothing,
$$

然後：

$$
R(S)\rightarrow\hat I.
$$

如果仍滿足：

$$
\hat I=I,
$$

則 source-blind reconstruction 得到強工程證據。

這比「程式理論上沒有使用 source」更可靠，因為它對資料依賴本身做負向測試。

---

# 18. Visual Equality Family

Paper 01 已指出 equality 必須帶型別。Glyph domain 至少需要以下關係。

## 18.1 Pixel equality

$$
g_1\equiv_{pixel,\pi}g_2
$$

表示指定 renderer/profile 下 raster 結果一致。

## 18.2 Geometric equality

$$
g_1\equiv_{geo,G}g_2
$$

表示在允許 transform group $G$ 下 geometry 等價。

## 18.3 Topological equality

$$
g_1\equiv_{topo}g_2.
$$

## 18.4 Part-structural equality

$$
g_1\equiv_{part}g_2.
$$

## 18.5 Semantic equality

$$
g_1\equiv_{sem,\Theta}g_2.
$$

重要的是：

$$
g_1\equiv_{pixel}g_2
\not\Rightarrow
g_1\equiv_{sem}g_2.
$$

反過來：

$$
g_1\equiv_{sem}g_2
\not\Rightarrow
g_1\equiv_{pixel}g_2.
$$

---

# 19. Drawing-to-Symbol 不應一次跨越所有層

使用者在 EveGlyph Canvas 畫一個新符號時，可採 pipeline：

$$
D
\xrightarrow{Capture}
I_S
\xrightarrow{Normalize}
I_N
\xrightarrow{Compile}
S_2
\xrightarrow{Lift}
S_3
\xrightarrow{PartParse}
P_G
\xrightarrow{SemanticProposal}
\hat S_g
\xrightarrow{Commit}
G^*.
$$

每一步都可以停下。

例如：

- 只要 exact carry，不要 semantic binding；
- 只要 vector/skeleton structure；
- 只建立 private symbol name；
- 之後再賦予 operator semantics。

這種漸進式 formalization 比「每畫一筆就要求 AI 猜它是什麼」更穩健。

---

# 20. 與 Native Mathematics 的接口

Paper 03 中的 native math operator 不應把 glyph 本身當唯一 operator identity。

令 operator semantic object 為：

$$
o_{op}.
$$

glyph 為：

$$
g_{op}.
$$

建立：

$$
represents(g_{op},o_{op}).
$$

於是同一 operator 可以有：

$$
\{g_1,g_2,g_3\}
$$

多個 notation glyph。

而同一視覺 glyph 在不同 domain 也可以透過 scope 被解析成不同 operator candidate。

因此 native math 最終執行的是：

$$
o_{op},
$$

而不是 image bytes。

---

# 21. 與 Spatial Syntax 的接口

Glyph intrinsic geometry：

$$
G^{int}
$$

與 Canvas placement：

$$
P^{ext}
$$

必須分離。

因此：

$$
MoveGlyph
$$

只改：

$$
P^{ext}.
$$

EditGlyphGeometry 才改：

$$
G^{int}.
$$

多 glyph 組合在 declared symbol-construction region 中，可以經 spatial grammar 產生 composite symbol candidate：

$$
\{g_1,g_2,\ldots,g_n\}+P
\xrightarrow{Parse}
\hat g_c.
$$

但仍需 commit 才成為 persistent composite glyph。

---

# 22. Composite Symbol 與 Recursive Symbol

一個 composite glyph 可由其他 glyph 引用構成：

$$
g_c=(Refs,Transforms,Constraints,Topology).
$$

而不是每次 flatten 成 raster。

這使：

- reusable primitives；
- shared components；
- recursive motifs；
- procedural families；
- semantic inheritance；

成為可能。

但 runtime 必須避免無界 recursion。

可定義：

$$
Expand(g,depthLimit,resourceBudget).
$$

超出 budget 時產生明確 diagnostic，而不是無限展開。

---

# 23. Compression 與 Abstraction 不應混為一談

如果 part grammar 讓表示 bytes 變少：

$$
|S_{high}|<|S_{exact}|,
$$

這可能是 compression benefit。

但真正的 abstraction 需要：

$$
Ops(S_{high})
$$

提供新操作能力，例如：

- part replacement；
- semantic query；
- variant generation；
- topology-aware render；
- operator binding。

因此：

$$
Compression
\neq
Abstraction.
$$

一個表示即使更大，也可能因更好的結構而具有更高 abstraction value。

---

# 24. Lossless、Structural、Semantic 三種 Fidelity

本文建議 importer/compiler 宣告：

$$
FidelityProfile=(F_v,F_s,F_m).
$$

其中：

- $F_v$：visual fidelity；
- $F_s$：structural fidelity；
- $F_m$：semantic fidelity。

例如 GSC Gate 1 可以在限定 domain 宣稱：

$$
F_v=exact.
$$

但不應因此宣稱：

$$
F_m=exact.
$$

若某手寫 recognizer 高 confidence 認出 integral symbol，它可能：

$$
F_m\approx high,
$$

但 visual reconstruction 並非 exact。

這三軸比單一「準確率」更符合符號編譯實際需求。

---

# 25. AI 在 Glyph Compilation 中的角色

AI 可以：

- 建議 segmentation；
- 建議 part roles；
- 建議 semantic mapping；
- 建議 family parameters；
- 建議 simplification；
- 建議 visual-to-operator mapping；
- 產生 alternate render plan。

但任何生成式輸出預設：

$$
AIOutput\in CandidateLayer.
$$

Deterministic layers，例如：

- hash；
- canonical serialization；
- exact renderer；
- topology validator；
- schema validator；
- project mutation boundary；

不應依賴 AI 猜測完成。

這與 UTF-8X「AI 可生成策略、decode 必須 deterministic」以及 Paper 00 的 proposal-validation-commit 原則一致。

---

# 26. Provenance 與 Compiler Reproducibility

每次 compilation 至少應記錄：

$$
CRecord=(sourceRef,compilerVersion,profile,parameters,outputRevision,tests,actor,time).
$$

若 normalizer 存在：

$$
NRecord=(sourceRef,normalizerVersion,parameters,normalizedHash).
$$

如此才能區分：

$$
Change(Source)
$$

與：

$$
Change(CompilerVersion).
$$

如果相同 source 在不同 compiler version 產生不同 symbol：

$$
C_{v_1}(I)\neq C_{v_2}(I),
$$

這不是資料錯誤，而是需要被 version/provenance 顯式保存的 derivation difference。

---

# 27. Security Boundary：Glyph 不是天然安全資料

當 glyph 只負責 rendering 時，風險較低；一旦 glyph 可以綁定 behavior：

$$
B(g)\neq\varnothing,
$$

就必須區分：

- visual import；
- semantic binding；
- executable binding。

import 一張圖片不應自動獲得執行權。

因此：

$$
ImportVisual
\not\Rightarrow
EnableBehavior.
$$

behavior promotion 必須使用獨立 permission/commit path。

這也是未來「圖像符號即程式」必須具備的基本安全界線。

---

# 28. 二十項核心不變量

以下構成 Paper 04 design freeze。

## G1 — Source/Symbol Separation

source artifact 與 compiled glyph 預設為不同 persistent identities，以 provenance 關聯。

## G2 — Representation/Semantics Separation

source-blind reconstruction success 不得被解讀為 semantic understanding success。

## G3 — Normalization Provenance

任何 normalization 都必須可追蹤 version、parameters 與 normalized target hash。

## G4 — Source-Blind Renderer Contract

宣稱 strict source-independent renderer 時，其 runtime API 不得存取 source artifact。

## G5 — Exactness Is Profile-Scoped

`exact` 必須相對於指定 compile target/domain/profile 定義，不得無條件泛化。

## G6 — Geometry/Topology Separation

intrinsic geometry 與 topology 必須可獨立表示與驗證。

## G7 — Skeleton Hint Honesty

近似 skeleton/medial representation 不得標記為 exact medial truth，除非有相應證明／算法契約。

## G8 — Part Candidate/Semantic Role Separation

structural part role 不得自動等於 semantic role。

## G9 — Glyph/Character Separation

EveGlyph glyph identity 不得依賴 Unicode code point 才成立。

## G10 — Glyph/Symbol Separation

visual glyph 與 semantic symbol identity 必須允許 many-to-many mapping。

## G11 — Intrinsic/Placement Separation

canvas move 不得改變 intrinsic glyph content。

## G12 — Renderer Non-Authority

不同 projection 不得自動生成新 persistent glyph identity。

## G13 — Equality Typing

pixel/geometric/topological/part/semantic equality 必須分離。

## G14 — Composite Reference Preservation

composite symbol 應允許保留 child references，而非強制永久 flatten。

## G15 — Semantic Promotion Boundary

recognizer/AI output 預設為 candidate，需 explicit/validated promotion 才成 authoritative semantic binding。

## G16 — Behavior Permission Boundary

visual import 不得自動啟用 executable behavior。

## G17 — Versioned Compiler Provenance

任何 canonical glyph revision 必須可回答其 compiler/normalizer/profile lineage。

## G18 — Structural Abstraction Is Not Measured Only by Compression Ratio

表示品質不得只以 byte reduction 判定。

## G19 — Deterministic Canonicalization

相同 abstract glyph state 與 canonicalization version 必須產生相同 canonical bytes。

## G20 — Unresolved Is Legal

無法可靠賦義的 visual glyph 可以保持 semantic-unresolved 狀態。

---

# 29. 十八項 Conformance Tests

## T1 — Source destruction reconstruction

compile 後破壞 source buffer，strict renderer 仍能依 profile 完成預期 reconstruction。

## T2 — Renderer interface audit

strict renderer 函式不接受 source image argument，也不透過 hidden global 讀 source。

## T3 — Normalized target identity

若 normalizer 改變 source，系統明確區分 source hash 與 normalized target hash。

## T4 — Move preserves intrinsic hash

canvas move 後：

$$
a^{content}_{before}=a^{content}_{after}.
$$

## T5 — Geometry edit changes intrinsic revision

修改 stroke/region geometry 後產生新 revision。

## T6 — Same pixels, different semantics

兩個 pixel-identical glyph 可保持不同 semantic binding，不得 auto-merge identity。

## T7 — Same semantics, different glyphs

兩個 style variant 可指向同一 semantic symbol，但保有不同 glyph identities。

## T8 — Unicode-free glyph

未綁定 Unicode code point 的 custom glyph 仍可完整儲存、render、address、version。

## T9 — Skeleton version provenance

更換 skeletonizer 後，新 derived structure 記錄 algorithm/version，而不 silently overwrite old provenance。

## T10 — Part grammar round-trip

part graph/grammar serialize-deserialize 後，在規格 equality 下保持相同。

## T11 — Composite reference retention

composite glyph export/import 後仍可辨識 child identities，不必只剩 flatten pixels。

## T12 — Semantic candidate non-authority

AI recognizer 產生 high-confidence label 時，未 commit 前不得進 authoritative semantic binding。

## T13 — Visual import non-executable

import 帶有陌生 metadata 的 visual file 不得自動啟用 behavior binding。

## T14 — Renderer variation preserves identity

同一 glyph 在 exact pixel renderer 與 enhanced renderer 下 view 不同，但 persistent identity 不變。

## T15 — Topology-sensitive difference

pixel/geometry similarity 高但 hole/connectivity 不同時，topology equality 必須可判不同。

## T16 — Family instantiation lineage

由 family $F$ 產生 variant $g_{\theta}$ 時保存 family/parameter provenance。

## T17 — Canonicalization reproducibility

兩個合規 implementation 對相同 abstract glyph revision 產生相同 canonical bytes/hash。

## T18 — Unresolved semantic state survives serialization

未賦義 glyph 經 save/load 後仍維持 unresolved，而不是被自動填入虛構語義。

---

# 30. MVP-01 的最小 Glyph Vertical Slice

第一版不需要做完整 SVG editor、font compiler 或通用 computer vision。

只需證明以下八件事。

## 30.1 Draw / Import

使用者可以畫或匯入一個有限 palette symbol。

## 30.2 Normalize

可選擇 deterministic normalizer。

## 30.3 Compile

產生 source-independent symbolic asset。

## 30.4 Structural Lift

至少抽出：

- region；
- adjacency；
- contour；
- skeleton graph 或 equivalent structural representation。

## 30.5 Persistent Glyph Object

建立：

$$
a^{id},a^{content},a^{ver}.
$$

## 30.6 Semantic Binding

使用者可將 glyph 綁到一個 native operator 或 custom concept。

## 30.7 Reuse

同一 glyph object 可被多次放到 canvas，不複製 intrinsic content identity。

## 30.8 Execute

至少一個 glyph 可以表示 Paper 03 的 operator，並透過 semantic binding 參與 native computation。

例如自訂 glyph $g_D$：

$$
represents(g_D,DerivativeOperator).
$$

在 canvas 上：

$$
g_D(f,x)
$$

經 parse/commit 後執行：

$$
D_x(f).
$$

只要這條 vertical slice 成立，就能工程證明：

$$
\boxed{
\text{custom visual glyph}
\rightarrow
\text{addressable semantic object}
\rightarrow
\text{computation}
}
$$

不需要 Unicode 新 code point，也不需要把 glyph 永久降回 LaTeX macro。

---

# 31. 與 Paper 05 的接口

Paper 05 將深入處理 glyph 的多層 address。

一個 glyph 至少可能同時具有：

$$
a^{id},
$$

$$
a^{content},
$$

$$
a^{sem},
$$

$$
a^{space},
$$

$$
a^{phys},
$$

$$
a^{ver}.
$$

此外，composite glyph 還可能需要：

$$
a^{part},
$$

用以指向特定 revision 中的 component/part。

因此 Paper 04 提供 visual-symbol object，Paper 05 再回答「如何跨內容、語義、空間、版本與局部部件穩定地指向它」。

---

# 32. 與 TW-01 的接口

TW-01 至少需要凍結：

1. `glyph` object kind；
2. geometry primitive schema；
3. topology schema；
4. part graph schema；
5. semantic binding schema；
6. renderer profile reference；
7. behavior binding reference；
8. compiler provenance record；
9. normalizer provenance record；
10. family/variant relation；
11. composite child reference；
12. semantic unresolved state；
13. Unicode/external-font optional mapping；
14. visual/structural fidelity declaration。

Paper 04 不提前決定 JSON key，但這些 semantic fields 不應在 implementation 中被重新混為單一 image blob。

---

# 33. 非主張

本文不主張：

1. 所有 raster image 都應轉成 glyph；
2. GSC v1.13 已完成一般影像理解；
3. source-blind exact reconstruction 等於 semantic compression；
4. skeletonization 能唯一決定 shape semantics；
5. part grammar 能自動理解所有物件部件；
6. Unicode 已過時或不再需要；
7. SVG/vector path 自身沒有價值；
8. 所有 custom glyph 都應具有可執行行為；
9. AI recognizer 的高 confidence 等於 authoritative truth；
10. glyph geometry 與 mathematical operator identity 應一對一；
11. exact pixel reconstruction 是所有 future renderer 的必要目標；
12. byte compression ratio 是 symbol abstraction 的唯一品質指標；
13. 所有 visual symbols 都需要同一 grammar；
14. source artifact 必須永遠保留在線上 hot storage；
15. 2D glyph 是未來 symbolic system 的維度上限。

本文只主張：

> 若 visual object 要升級為可定址計算符號，必須把來源、可逆承載、幾何、拓撲、部件、語義與行為拆成可驗證層，而不是讓「看起來像」直接取代 object identity 與 semantics。

---

# 34. Paper 04 Design Freeze

完成本文後，後續文件不得在未顯式修訂的情況下破壞以下決策：

1. source artifact、normalized target、symbolic carry、structural lift、part grammar、semantic symbol 分層；
2. exact reconstruction claim 必須限定 domain/profile；
3. source-blind rendering 必須是可測試的 dependency contract；
4. source 與 compiled glyph 預設不同 persistent identity，以 provenance 相連；
5. intrinsic geometry、topology、part structure、semantics、rendering、behavior 分離；
6. canvas placement 不屬於 intrinsic glyph geometry；
7. skeleton/medial hint 的 approximation status 必須保留；
8. part role candidate 與 semantic role 分離；
9. glyph 存在不依賴 Unicode assignment；
10. character、glyph、semantic symbol 分離並允許 many-to-many mapping；
11. visual/geometric/topological/part/semantic equality 分離；
12. renderer 是 projection，不是 canonical identity authority；
13. semantic recognizer/AI output 預設停在 candidate layer；
14. visual import 與 executable behavior permission 分離；
15. compiler/normalizer/version/profile lineage 必須可追蹤；
16. composite symbol 可保留 recursive/referenced child structure；
17. compression ratio 不等於 abstraction quality；
18. unresolved semantic glyph 是合法 canonical state；
19. custom glyph 可以被綁定 Paper 03 native operator；
20. MVP 必須證明至少一個 custom glyph 能從 visual construction 進入 addressable semantic computation。

---

# 35. 結論

如果未來仍把每一個新符號理解為：

> 先找到一個 Unicode character；如果沒有，就放一張圖片；需要運算時再額外寫一個 LaTeX macro 或程式函式，

那麼畫面、語義、程式與機器身份仍然是彼此分裂的。

GGSC 提出的轉換不是：

$$
\text{PNG}\rightarrow\text{更小的 PNG}.
$$

而是：

$$
\boxed{
\text{Visual Source}
\rightarrow
\text{Symbolic Carry}
\rightarrow
\text{Structure}
\rightarrow
\text{Part Grammar}
\rightarrow
\text{Addressable Semantic Glyph}
}
$$

其中每一步都有不同證據要求。

GSC v1.13 已經在限定 pixel-art domain 中提供一個重要工程起點：source 可以在 compile 後退出 strict renderer 的依賴鏈，而 symbolic representation 仍足以完成 exact reconstruction；其後 topology、skeleton graph 與 part grammar 則開始把表示從「像素承載」提升到「可操作結構」。真正下一步不是宣稱已經理解所有圖像，而是把這條結構鏈接上 Paper 01 的 identity/version model、Paper 02 的 spatial syntax、Paper 03 的 native operator semantics。

於是，一個使用者自己畫出的符號未來可以同時是：

- 可視 geometry；
- 可查 topology；
- 可拆 part graph；
- 可版本化 object；
- 可擁有 semantic address；
- 可被重複放置於無限畫布；
- 可輸出成 raster/vector/font-like projection；
- 可選擇性綁定可執行 operator。

真正重要的不是「這個符號是不是 Unicode」。

真正重要的是：

$$
\boxed{
\text{Can the system identify it, reconstruct it, reason about it, relate it, version it, and execute its meaning?}
}
$$

只要這些條件成立，code point 就回到它應該在的位置：一種非常重要的全球文字交換地址，而不是所有可能符號存在的唯一許可證。

Paper 04 至此完成 visual-symbol layer。下一篇 Paper 05 將把 Paper 01 至 Paper 04 中已經反覆出現的 identity、content、semantic、spatial、physical、version 與 sub-object reference 統合成完整的 **Multi-Layer Addressing Model for Computational Documents**。

---

# References

[1] EveMissLab. *Generative Symbol Compiler Lab v1.13.0-strict-symbolic — README*. 2026.

[2] EveMissLab. *Generative Symbol Compiler Lab v1.13.0-strict-symbolic — Technical Design v0.1, Gate 1 through Gate 11 Addenda*. 2026.

[3] EveMissLab. *Generative Symbol Compiler Lab v1.13.0-strict-symbolic — VALIDATION*. Packaging baseline: 105/105 tests passing; fresh Paper 04 rerun: 105/105 tests passing.

[4] EveMissLab. *00 — From Linear Documents to Addressable Symbolic Computational Spaces*. v0.1, 2026.

[5] EveMissLab. *01 — Addressable Symbolic Object Model*. v0.1, 2026.

[6] EveMissLab. *02 — Spatial Syntax and Infinite Canvas Computation*. v0.1, 2026.

[7] EveMissLab. *03 — Native Computational Mathematics Beyond LaTeX*. v0.1, 2026.

[8] Mingqiang Yang, Kidiyo Kpalma, and Joseph Ronsin. “A Survey of Shape Feature Extraction Techniques.” InTech/Open-access survey on shape representation methods.

[9] Khalid Saeed, Marek Tabedzki, Mariusz Rybnik, and Marcin Adamski. “K3M: A Universal Algorithm for Image Skeletonization and a Review of Thinning Techniques.” 2010.

[10] Alexander Bucksch. “A Practical Introduction to Skeletons for the Plant Sciences.” *Applications in Plant Sciences*, 2014.

[11] Soumen Bag and Gaurav Harit. “A Medial Axis Based Thinning Strategy for Character Images.” 2011.

[12] Eric J. Golin and Steven P. Reiss. “The Specification of Visual Language Syntax.” *Journal of Visual Languages & Computing*, 1990.

[13] Eric J. Golin. “Parsing Visual Languages with Picture Layout Grammars.” *Journal of Visual Languages & Computing*, 1991.

[14] Margaret Burnett et al. “Forms/3: A First-Order Visual Language to Explore the Boundaries of the Spreadsheet Paradigm.” *Journal of Functional Programming*, 2001.

[15] Neil Cohn. “A Visual Lexicon.” Research on structured visual vocabulary and graphical form-meaning systems.

[16] Neil Cohn, Jan Engelen, and Joost Schilperoord. “The Grammar of Emoji? Constraints on Communicative Pictorial Sequencing.” *Cognitive Research: Principles and Implications*, 2019.

---

# Appendix A — 形式化摘要

Compilation ladder：

$$
L_0\rightarrow L_1\rightarrow L_2\rightarrow L_3\rightarrow L_4\rightarrow L_5.
$$

Normalization：

$$
N_{\nu}(I_S)\rightarrow I_N.
$$

Exact symbolic carry：

$$
C_2(I_N)\rightarrow S_2,
$$

$$
R_2(S_2)\rightarrow \hat I_N.
$$

Exact-domain condition：

$$
\hat I_N=I_N.
$$

Structural lift：

$$
S_3=(regions,adjacency,contours,topology,skeleton,graph).
$$

Part graph：

$$
P_G=(V_P,E_P,\lambda_P).
$$

Semantic glyph revision：

$$
\rho_g=(i,v,k,G,T,P,S,R,B,A,M).
$$

Semantic promotion：

$$
Recognize(g)\rightarrow\hat S_g,
$$

$$
Promote(\hat S_g,authority)\rightarrow S_g.
$$

Rendering：

$$
R_{\pi}(g,ctx)\rightarrow view.
$$

Family instantiation：

$$
g_{\theta}=Instantiate(F,\theta).
$$

Visual fidelity profile：

$$
FidelityProfile=(F_v,F_s,F_m).
$$

Native operator binding：

$$
represents(g_{op},o_{op}).
$$

---

# Appendix B — Implementation-facing Checklist

在 TW-01 / TW-03 / MVP-01 開始實作 Paper 04 前，至少必須回答：

1. `glyph` object 的 persistent identity 如何產生？
2. source artifact 與 glyph object 的 derivation relation 如何儲存？
3. normalized target 是否作為獨立 addressable artifact？
4. exact renderer 的 source-blindness 如何自動測試？
5. geometry primitives 的最小共同集合是什麼？
6. pixel RUN representation 是否保留為一種 profile，而非 universal geometry？
7. topology schema 如何表示 components、holes、adjacency？
8. skeleton/medial representation 如何標記 approximate algorithm/version？
9. part graph 的 node/edge/role schema 為何？
10. part candidate 如何被 promote 成 semantic part？
11. glyph 與 semantic symbol 的 mapping 是 reference、relation 還是 embedded binding？
12. 同一 semantic symbol 的 variant family 如何表示？
13. Unicode mapping 是否採 optional adapter field？
14. external font glyph mapping 如何處理？
15. renderer profiles 如何版本化？
16. exact pixel renderer 與 enhanced renderer 如何同時對一 canonical glyph 存在？
17. geometry equality 的 transform group 如何按 domain 宣告？
18. topology equality 如何 canonicalize？
19. composite glyph 如何引用 child revisions？
20. recursive expansion 的 resource limit 如何定義？
21. family parameter 如何進 provenance？
22. semantic unresolved 狀態如何序列化？
23. AI recognition candidate 的 confidence/authority 如何標記？
24. visual import 為何預設不能啟動 executable behavior？
25. behavior binding 的 permission gate 在 TW-03 如何實作？
26. custom glyph 如何綁定 Paper 03 native math operator？
27. Canvas 上重複使用同一 glyph 時，placement instance 與 intrinsic glyph identity 如何分離？
28. export SVG/PNG/font-like artifact 時，哪些資訊會 loss？
29. importer 如何回報 visual/structural/semantic fidelity？
30. MVP 用哪一個 custom glyph 證明 visual-to-semantic-to-execution vertical slice？

Paper 04 不要求現在凍結所有具體格式；它要求任何 implementation 都不得把 image bytes、geometry、topology、semantics 與 executable behavior 重新壓回一個無法辨識 authority 的單一 blob。


<!-- SOURCE: 05_多層定址的可計算文件_身份內容語義空間物理版本解析與跨工作區參照_v0.1.md -->

# 05｜多層定址的可計算文件：身份、內容、語義、空間、物理、版本、解析與跨工作區參照

**English Title:** Multi-Layer Addressing for Computational Documents: Identity, Content, Semantics, Space, Physical Location, Version Resolution, and Cross-Workspace Reference

**作者：** Neo.K  
**機構：** EveMissLab / 一言諾科技有限公司  
**版本：** v0.1  
**日期：** 2026-08-24  
**文件類型：** 專題論文 / Formal Architecture Paper  
**系列定位：** EveGlyph Addressable Symbolic Computational Space Series — Paper 05  
**前置錨點：** Paper 00 — From Linear Documents to Addressable Symbolic Computational Spaces；Paper 01 — Addressable Symbolic Object Model；Paper 02 — Spatial Syntax and Infinite Canvas Computation；Paper 03 — Native Computational Mathematics Beyond LaTeX；Paper 04 — Generative Glyph and Symbol Compilation

---

## Canonical Source Note

本文件以 UTF-8 Markdown 保存正式原稿。數學 source 僅使用 `$...$` 與 `$$...$$` 作為 canonical delimiter。

本文凍結的是 **Multi-Layer Address Model, MLAM（多層地址模型）** 的抽象語義、不變量、resolution contract 與 authority boundary，不直接凍結最終 URI scheme、DID method、database key format、path syntax、network resolver、binary wire format 或 registry governance。這些工程選擇將由 `TW-01 — EveGlyph Symbol IR Specification`、`TW-02 — UTF-8 / UTF-8X Compatibility & Storage Architecture` 與 `TW-03 — EveGlyph Computational Canvas Runtime Architecture` 進一步凍結。

本文的核心主張不是「所有東西都需要六個 URI」，而是：

> **一個 computational object 同時可能具有多種不同意義的地址；這些地址回答不同問題，因此不能被單一 UUID、單一 hash、單一路徑或單一 URL 偷換。**

因此：

$$
\text{identity address}
\neq
\text{content address}
\neq
\text{semantic address}
\neq
\text{spatial address}
\neq
\text{physical address}
\neq
\text{version address}.
$$

---

## 摘要

Paper 01 已提出六層 address bundle：persistent identity、content、semantic、spatial、physical 與 version addressing；Paper 02 進一步要求 spatial address 具有 region-relative、frame-aware 與 versioned semantics；Paper 03 將數學 subexpression address 提升為 revision-aware reference；Paper 04 則要求 glyph、semantic symbol 與 Unicode character identity 彼此分離。本文作為 ASCS 核心論文系列最後一篇，正式把這些分散的地址概念統一成可解析、可驗證、可移動、可版本化與可跨 workspace 參照的多層定址模型。

數位系統長期存在一種便利但危險的簡化：將「找到資料的位置」當成「資料的身份」。檔案路徑、URL、資料庫主鍵、memory address、hash、DOI、URN、DID、symbol table path 與畫布座標都能在特定語境中指向某物，但它們並不回答相同問題。RFC 3986 將 URI 定義為識別抽象或實體 resource 的一般機制，並明確將 identification 與 interaction 分離；URN 進一步以 persistent、location-independent identifier 為目的；RFC 6920 與 ISO/IEC 18670:2025 SWHID 則顯示 content-derived identifiers 可以提供去中心化的完整性驗證；DOI System 將 persistent identifier 與 resolution service、metadata 明確分離；DID Core 則進一步將 identifier、controller、DID document 與 resolution process 分離。這些成熟標準共同指出：**identifier、locator、content verification 與 resolution 本來就是不同層次。**

本文提出 MLAM，將 EveGlyph object 的定址寫為：

$$
A(o,t)=
(
A^{id},
A^{content},
A^{sem},
A^{space},
A^{phys},
A^{ver}
),
$$

並額外定義 alias、subobject、external、workspace-relative 與 resolution context。persistent identity address 回答「這是否是同一個持續 object lineage」；content address 回答「這個 canonical intrinsic state 是否相同」；semantic address 回答「它在某 ontology/theory/constraint space 中指向什麼」；spatial address 回答「它在特定 workspace、region、frame 與 spatial snapshot 中位於何處」；physical address 回答「承載 bytes/object record 的實際 carrier 在哪裡」；version address 則回答「這個 object lineage 的哪個 immutable revision 被指涉」。

本文進一步提出 `Resolve` 與 `Dereference` 的區分、relative reference、address qualification、alias lifecycle、tombstone behavior、cross-workspace federation、semantic uncertainty、spatial relativity、subobject path stability、resolution cache、offline mode、capability/security boundary 與 address migration。核心原則是：解析器可以回傳 zero、one 或 many candidates；「無法解析」是合法狀態；語義地址與近似搜尋不能自動升格為 identity equality；physical relocation 不改 persistent identity；content verification 不保證 resolver availability；alias 不是 identity；跨 workspace import 不得僅依 display name 或 spatial similarity 自動合併 object lineage。

本文最後凍結二十四項 addressing invariants 與二十項 conformance tests。至此，Paper 00–05 完成了 ASCS 的六個核心理論支柱：global architecture、object identity、spatial syntax、native mathematics、generative glyph compilation 與 multi-layer addressing。下一階段即可從理論轉入三篇技術白皮書與 MVP。

**關鍵詞：** Multi-Layer Addressing、Persistent Identity、Content Addressing、Semantic Address、Spatial Address、Version Address、URI、URN、SWHID、DID、DOI、Resolution、Cross-Workspace Reference、EveGlyph、ASCS

---

## Abstract

Computational documents require more than a single identifier. A file path can locate bytes but cannot necessarily preserve identity across movement. A cryptographic hash can verify immutable content but changes when content changes. A semantic description can retrieve conceptually related objects but may be ambiguous or context-dependent. A canvas coordinate can locate an object in one workspace state but is not a persistent identity. A version identifier points to a particular revision, while a persistent object identifier refers to an evolving lineage.

This paper develops the **Multi-Layer Address Model (MLAM)** for the EveGlyph Addressable Symbolic Computational Space. It formalizes six non-interchangeable address classes: persistent identity, content, semantic, spatial, physical, and version addresses. The model is informed by established identifier and resolution systems including URI/URN architecture, hash-based naming, SWHID, DOI resolution, and decentralized identifiers, but does not attempt to replace those standards. Instead, it defines how multiple address semantics coexist inside a versioned computational workspace.

MLAM separates resolution from dereferencing, allows relative and qualified references, supports aliases without collapsing them into identity, treats semantic resolution as potentially ambiguous, distinguishes local and federated workspace references, and requires provenance for address migration and rebinding. It also defines revision-aware subobject addressing for mathematical expressions, glyph parts, canvas regions, and other structured objects. Physical relocation, spatial movement, rendering changes, and alias changes are explicitly prevented from silently mutating persistent object identity.

The paper concludes with formal invariants and conformance tests intended to guide the EveGlyph Symbol IR, UTF-8/UTF-8X storage layer, runtime resolver, and MVP implementation.

---

# 1. 問題：地址不是只有「在哪裡」

## 1.1 一個檔案路徑回答的是 locator 問題

假設：

```text
/workspace/math/derivative.eg
```

這條 path 可以回答：

> 在目前檔案系統 namespace 中，要去哪裡找這份 bytes？

但把檔案搬到：

```text
/workspace/archive/derivative.eg
```

並不意味它必然成為另一個 persistent mathematical object。

因此：

$$
A^{phys}_{t_1}\neq A^{phys}_{t_2}
$$

可以與：

$$
A^{id}_{t_1}=A^{id}_{t_2}
$$

同時成立。

## 1.2 一個 hash 回答的是 content verification 問題

對 immutable canonical bytes：

$$
h=H(C_{\sigma}(x)).
$$

它非常適合回答：

> 我現在拿到的這份 canonical content 是否就是原本指涉的那份？

但只要 object 被合法編輯：

$$
x_1\neq x_2,
$$

通常：

$$
H(C_{\sigma}(x_1))\neq H(C_{\sigma}(x_2)).
$$

如果 hash 就等於 persistent identity，所有 edit 都會把 object 變成「另一個東西」。Paper 01 已拒絕這個模型。

## 1.3 一個語義描述回答的是 retrieval / conceptual location 問題

例如 semantic address：

$$
A^{sem}=(\text{derivative},\text{operator},\text{real-analysis},\ldots).
$$

它可能找到多個候選：

$$
Resolve_{sem}(A^{sem},\Gamma)
\rightarrow
\{(o_1,q_1),(o_2,q_2),\ldots\}.
$$

因此 semantic address 天然可以是 partial、ambiguous 與 context-sensitive。

## 1.4 一個畫布座標回答的是 spatial placement 問題

$$
A^{space}=(workspace,region,frame,x,y,\ldots).
$$

移動 object 時 spatial address 變化，但 identity 可以保持。

## 1.5 所以單一「Address」欄位是不夠的

MLAM 的第一原則是：

$$
\boxed{
\text{Address must be typed by the question it answers.}
}
$$

---

# 2. 既有標準已經分離 identification、location、resolution 與 verification

## 2.1 URI：resource identification 不等於 interaction

RFC 3986 將 URI 定義為識別抽象或實體 resource 的 compact sequence，並明確討論 identification 與 interaction 的分離。

這對 ASCS 的直接啟示是：一個 object identifier 不必等於「可以用 HTTP GET 下載的 URL」。

## 2.2 URN：location-independent persistence

RFC 8141 將 URN 定義為 URI scheme 下、意圖具有 persistent、location-independent resource identification 的名稱。

這證明：

$$
\text{name}\neq\text{current location}
$$

本來就是成熟網路架構中的正常設計。

## 2.3 RFC 6920：hash-based naming

RFC 6920 將 hash output 納入 digital object names，用於識別並可提供與 reference 同程度的 authentication。

其設計對應 MLAM 的：

$$
A^{content}.
$$

## 2.4 SWHID：Merkle DAG 上的 intrinsic identifier

ISO/IEC 18670:2025 SWHID 對 software artifacts 使用可由 artifact 本身計算的 cryptographic identifiers，並以 Merkle DAG 處理 directories、revisions、releases 與 repository snapshots。

特別值得注意的是，ISO specification 明確指出 **resolution 不在 SWHID specification 範圍內**。

這正好支持 MLAM 的：

$$
\text{identification}\neq\text{resolution}.
$$

## 2.5 DOI：persistent identifier 與 resolution service

DOI System 把 DOI name 視為 globally unique persistent identifier，再經 Handle System resolution 得到目前 metadata、location 或其他服務資訊。

也就是：

$$
DOI\ Name
\xrightarrow{Resolve}
Record
\xrightarrow{Select}
Location/Metadata/Service.
$$

它不是把 URL 本身當 DOI identity。

## 2.6 DID：identifier、controller、document 與 resolution

W3C DID Core v1.0 已是 Recommendation；DID v1.1 截至 2026-03-05 為 Candidate Recommendation Snapshot。DID architecture 將 DID、DID subject、DID document、controller、verification methods、services 與 resolution 分離。

MLAM 不需要採用 DID 作為所有 EveGlyph object 的 identity scheme，但它吸收一項重要設計原則：

> identity reference 可以在不等於 storage location 的情況下，透過 resolver 取得目前可用 metadata、service endpoints 或 verification material。

---

# 3. MLAM 基本模型

對 object $o$、revision $v$、workspace state $t$，定義：

$$
A(o,v,t,\Gamma)=
(
A^{id},
A^{content},
A^{sem},
A^{space},
A^{phys},
A^{ver},
Q
).
$$

其中 $Q$ 是 address qualification metadata，例如 namespace、algorithm、schema version、authority、scope、resolver profile 與 provenance。

六種核心地址分別回答：

| Address class | 核心問題 |
|---|---|
| $A^{id}$ | 這是否是同一 persistent object lineage？ |
| $A^{content}$ | intrinsic canonical content 是否完全相同？ |
| $A^{sem}$ | 它在何種語義／關係／約束空間中被描述？ |
| $A^{space}$ | 它在某 workspace / region / frame / snapshot 中位於何處？ |
| $A^{phys}$ | bytes / record / chunk / endpoint 實際承載在哪裡？ |
| $A^{ver}$ | 指的是 persistent object 的哪個 immutable revision？ |

---

# 4. Persistent Identity Address

## 4.1 Identity address 指向 lineage，不指向 bytes

$$
A^{id}(O_i)=i.
$$

它必須跨 edit、move、rerender、storage migration 與 alias change 穩定。

## 4.2 Identity namespace

完整 identity address 不應只有一串裸 UUID，而至少具有：

$$
A^{id}=(scheme,namespace,identifier,qualifiers).
$$

例如未來可以是 private URI、URN-like name、DID-like method、UUID namespace 或其他可驗證形式。

Paper 05 不凍結 scheme，只凍結 semantic requirement。

## 4.3 Identity address 不得被重新綁定

若 $i$ 曾指向 object lineage $L_i$，則 tombstone 後：

$$
Rebind(i,L_j),\quad j\neq i
$$

必須被禁止。

否則歷史引用會被「地址劫持」。

---

# 5. Content Address

## 5.1 Canonical input

$$
A^{content}
=
(alg,canonVersion,digest).
$$

其中：

$$
digest=H(D_c\Vert C_{\sigma}(Intrinsic(o_v))).
$$

## 5.2 Self-verification

resolver 取得 bytes 後可以：

$$
Verify(A^{content},bytes)
\rightarrow
\{true,false,error\}.
$$

## 5.3 Content address 不保證 location availability

即使 content hash 正確：

$$
A^{content}=h,
$$

也不代表任何 resolver 當下都能找到 bytes。

所以：

$$
Identified(h)
\not\Rightarrow
Retrievable(h).
$$

## 5.4 Hash agility

地址必須保存 algorithm identity：

$$
A^{content}=(sha256,h)
$$

而不是只保存 $h$。

未來 algorithm migration 可建立：

$$
AliasHash(h_1,h_2,proof/provenance).
$$

但不能把不同 hash algorithm 的裸 digest 混在同一 namespace。

---

# 6. Semantic Address

## 6.1 Semantic address 是 structured description

Paper 01 已提出：

$$
A^{sem}
=
(\Omega,A^+,A^-,R,C,U,q,\nu).
$$

其中：

- $\Omega$：ontology/theory/frame；
- $A^+$：positive anchors；
- $A^-$：negative anchors；
- $R$：typed semantic relations；
- $C$：constraints；
- $U$：open variables；
- $q$：confidence/qualification；
- $\nu$：address schema/version。

## 6.2 Semantic resolution 原生允許多解

$$
Resolve_{sem}(A^{sem},\Gamma)
\rightarrow
\{(candidate_i,score_i,evidence_i)\}_{i=1}^{n}.
$$

合法結果包括：

$$
n=0,
$$

$$
n=1,
$$

或：

$$
n>1.
$$

## 6.3 Semantic match 不等於 identity equality

即使：

$$
score(o_1,o_2)>0.99,
$$

也不能推出：

$$
A^{id}(o_1)=A^{id}(o_2).
$$

這是 AI-native resolver 的重要邊界。

## 6.4 Semantic address 可以是暫時性的

某未命名概念可先只有 partial address，之後逐步 refined：

$$
A^{sem}_0
\rightarrow
A^{sem}_1
\rightarrow
A^{sem}_2.
$$

semantic-address revision 不必強迫 object persistent identity 改變。

---

# 7. Spatial Address

Paper 02 已要求空間具有 frame-relative semantics。

完整 spatial address 可以抽象為：

$$
A^{space}
=
(workspace,spatialSnapshot,region,frame,selector/transform).
$$

## 7.1 World-relative address

$$
A^{space}_{world}
=(W,t,F_W,T_i).
$$

## 7.2 Region-relative address

$$
A^{space}_{region}
=(W,t,R_j,F_j,T_{i\rightarrow j}).
$$

## 7.3 Relative spatial reference

對 object $A$ 指向 object $B$：

$$
RelSpace(A,B)
=(anchor=A,relation=RightOf,offset=\delta).
$$

這可以比 absolute coordinate 更適合某些 layout constraints。

## 7.4 Spatial address 必須 snapshot-aware

如果 object 移動：

$$
A^{space}_{t_1}\neq A^{space}_{t_2}.
$$

因此任何需要歷史重現的 spatial reference 都應攜帶 spatial snapshot / revision context。

---

# 8. Physical Address

## 8.1 Physical address 是 carrier locator

$$
A^{phys}
=(carrierType,authority,locator,qualifiers).
$$

可能包括：

- file path；
- database primary/storage key；
- object-store key；
- content chunk；
- local process resource；
- remote service endpoint；
- UTF-8X region/chunk；
- archive package entry。

## 8.2 Physical relocation

$$
Migrate(o,p_1\rightarrow p_2)
$$

若 content 與 object lineage 未改：

$$
A^{phys}_1\neq A^{phys}_2,
$$

但：

$$
A^{id}_1=A^{id}_2.
$$

## 8.3 Replication

同一 content 可以同時有：

$$
A^{phys}(o)=\{p_1,p_2,\ldots,p_n\}.
$$

因此 physical address 天然可是一對多。

---

# 9. Version Address

## 9.1 Revision-specific immutable reference

$$
A^{ver}(o_v)
=(objectID,revisionID).
$$

或 revision 本身使用 intrinsic digest。

## 9.2 Latest alias 不等於 immutable version

若：

```text
object://A/latest
```

代表目前 head，則它是 mutable resolver alias：

$$
Latest(A,t_1)=v_1,
$$

$$
Latest(A,t_2)=v_2.
$$

不能把 `/latest` 當 immutable citation。

## 9.3 Branch-aware resolution

$$
ResolveVersion(A,branch,policy)
\rightarrow
v.
$$

若存在多 head：

$$
\{v_a,v_b\},
$$

resolver 可以回 ambiguity/conflict，而不是隨機選一個。

---

# 10. Address、Name、Locator、Reference 與 Alias

本文正式區分五個概念。

## 10.1 Address

具有明確 type semantics 的可解析描述。

## 10.2 Name

人類或系統使用的 label，可以穩定也可以不穩定。

## 10.3 Locator

偏向 retrieval/interaction 的實際位置。

## 10.4 Reference

從一個 object/context 指向另一個 address target 的結構。

## 10.5 Alias

可被重新綁定的名稱：

$$
Alias_t(name)\rightarrow target.
$$

因此：

$$
AliasEquality
\not\Rightarrow
IdentityEquality.
$$

---

# 11. Resolve 與 Dereference 分離

這是 MLAM 的第二核心原則。

## 11.1 Resolve

$$
Resolve(A,\Gamma,Policy)
\rightarrow
ResolutionResult.
$$

Resolution result 可以包含：

- canonical target identity；
- candidate targets；
- current version；
- physical locations；
- metadata；
- verification material；
- ambiguity；
- tombstone；
- unavailable；
- permission denied。

## 11.2 Dereference

$$
Dereference(ResolutionResult,selector)
\rightarrow
Representation/Bytes/ObjectView.
$$

Resolve 可以成功但 dereference 失敗，例如已知 object identity，但實體 carrier offline。

因此：

$$
ResolveSuccess
\not\Rightarrow
DereferenceSuccess.
$$

---

# 12. Resolution Result 是 first-class typed state

本文建議：

$$
ResolutionResult
\in
\{
Resolved,
Multiple,
Unresolved,
Tombstoned,
Unavailable,
Unauthorized,
Invalid,
Stale
\}.
$$

特別地：

$$
Unresolved
$$

不是 exception-only state，而是合法可保存狀態。

AI 不得因 resolver 回 `Unresolved` 就自行虛構 identity。

---

# 13. Relative Reference

## 13.1 Workspace-relative

$$
Ref_{rel}
=(baseWorkspace,path/selector).
$$

例如：

```text
../operators/derivative
```

只是 human-friendly projection；canonical resolution 必須有 base context。

## 13.2 Object-relative

對 composite glyph：

$$
Ref(child_3\mid parent=g).
$$

## 13.3 Theory-relative

Paper 03 math symbol 可以在 theory $\Theta$ 內：

$$
Ref_{\Theta}(operatorName).
$$

若缺少 $\Theta$，相同 visible name 可能 ambiguous。

因此 relative references 必須永遠與 base resolution context 綁定。

---

# 14. Subobject Addressing

## 14.1 為什麼 character offset 不夠

若公式從：

$$
f(x)+g(x)
$$

改寫成：

$$
g(x)+f(x),
$$

character offset 與 screen bounding box 都不是穩定 semantic subobject identity。

## 14.2 Revision-aware subaddress

Paper 03 已提出：

$$
A^{sub}=(A^{ver},selector).
$$

selector 可以是：

- structural path；
- child identity；
- typed graph edge path；
- semantic selector；
- glyph-part reference；
- region member reference。

## 14.3 Persistent child identity

若 domain 需要 edit-stable subobject references，可以為 child 建立自己的 persistent identity：

$$
A^{id}_{child}.
$$

否則 structural path 只保證對某 revision 有效。

## 14.4 Rebase mapping

從 revision $v_1$ 到 $v_2$：

$$
MapSubAddress(A^{sub}_{v_1},v_2)
\rightarrow
\{A^{sub}_{v_2},Ambiguous,Deleted,Unmapped\}.
$$

不能默認 offset 不變。

---

# 15. Cross-Workspace Reference

## 15.1 Workspace identity

每個 workspace 可以有：

$$
A^{id}(W)=w.
$$

跨 workspace reference：

$$
Ref_{cross}=(w,targetAddress,policy).
$$

## 15.2 Link 與 Import 分離

Link：

$$
Link(W_A,o_B)
$$

保留 remote/external identity。

Import clone：

$$
ImportClone(o_B)\rightarrow o_A,
$$

通常建立：

$$
A^{id}(o_A)\neq A^{id}(o_B),
$$

並保存：

$$
importedFrom(o_A,o_B).
$$

## 15.3 Identity federation

只有在兩個 workspace 明確同意共享 global identity namespace 時，才可讓同一 persistent identity 在多 workspace 出現：

$$
FederatedIdentity(i,W_A,W_B).
$$

不能因 content hash 相同就自動 federation。

---

# 16. Address Qualification

裸地址不足以保證可正確解讀。

完整 qualification 可包含：

$$
Q=(schemeVersion,namespace,algorithm,schema,authority,scope,time,proof).
$$

例如 content digest 沒有 algorithm 就不完整；semantic address 沒有 ontology/version 就可能歧義；spatial address 沒有 workspace/snapshot/frame 就不能重現；version alias 沒有 branch/policy 就可能多解。

因此：

$$
\boxed{
\text{Address} + \text{Qualification} = \text{Resolvable Intent}
}
$$

---

# 17. Address Migration

## 17.1 Physical migration

最簡單：

$$
A^{phys}_1\rightarrow A^{phys}_2.
$$

persistent identity 不變。

## 17.2 Identifier-scheme migration

若未来 EveGlyph 更換 persistent ID scheme：

$$
i_{old}\rightarrow i_{new},
$$

必須保存 verified mapping：

$$
EquivalentIdentity(i_{old},i_{new},proof/provenance).
$$

這是高度權威操作，不能由一般 alias 取代。

## 17.3 Semantic-schema migration

$$
A^{sem}_{\nu_1}
ightarrow A^{sem}_{\nu_2}.
$$

應保存 mapping quality：

$$
Fidelity\in\{exact,lossless-structural,approximate,partial,unknown\}.
$$

---

# 18. Tombstone 與 Gone Semantics

若 persistent object 被退役：

$$
Tombstone(i,t).
$$

resolver 之後不應回：

$$
Unresolved
$$

來假裝「從未存在」。

更精確的是：

$$
Resolve(i)\rightarrow Tombstoned(metadata).
$$

這對引用完整性非常重要。

內容 bytes 可以依 policy 被刪除，但 identity history 仍然可以存在。

---

# 19. Cache 與 Staleness

## 19.1 Immutable addresses 可安全 cache

對 content/version address：

$$
Cache(A^{content})
$$

在 hash contract 下具有強穩定性。

## 19.2 Mutable aliases 必須有 freshness policy

例如：

$$
/latest,
$$

$$
/main,
$$

$$
/current.
$$

cache 需要：

$$
TTL/revalidation/versionToken.
$$

## 19.3 Stale resolution 是 first-class result

$$
ResolvedStale(target,lastVerifiedAt).
$$

比 silent 使用舊結果更安全。

---

# 20. Offline Resolution

EveGlyph 是 local-first，因此 resolver 必須允許：

$$
Resolve_{offline}(A,LocalIndex,Cache).
$$

可能得到：

- locally resolved；
- known-but-unavailable；
- stale；
- external network required。

不應把 network unavailable 與 identifier invalid 混在一起。

---

# 21. Security 與 Capability Boundary

知道 address 不代表擁有存取權。

因此：

$$
Know(A)
\not\Rightarrow
CanRead(A).
$$

也不代表：

$$
CanExecute(A).
$$

resolution policy 可以回：

$$
Unauthorized
$$

而不洩露敏感 physical locator。

特別是 executable glyph、operator、AI tool binding，必須分離：

$$
IdentityResolution,
$$

$$
ContentResolution,
$$

$$
ExecutionCapability.
$$

不能因成功 resolve object 就自動取得 runtime execution permission。

---

# 22. Alias Poisoning 與 Namespace Collision

## 22.1 Alias poisoning

若 attacker 可以把：

```text
Derivative
```

alias 改指向惡意 operator，就可能造成 semantic confusion。

因此高權威 alias 必須保存：

- authority/controller；
- change history；
- scope；
- signature / policy when applicable。

## 22.2 Namespace collision

兩個 domain 都可能有：

```text
plus
```

但 semantics 不同。

因此 canonical reference 應攜帶 namespace/theory：

$$
Ref(\Theta_1,plus)
\neq
Ref(\Theta_2,plus).
$$

---

# 23. AI-Native Resolution

AI 可以協助：

- 從 natural language 建構 semantic address；
- 對 unresolved alias 建議 candidate target；
- 做 cross-format identity reconciliation；
- 建議 subobject remapping；
- 建議 external reference match；
- 評估 semantic similarity。

但 AI 不得直接決定：

$$
PersistentIdentityEquality.
$$

預設流程：

$$
AIProposal
\rightarrow
CandidateResolution
\rightarrow
Evidence/Validator
\rightarrow
AuthorityDecision
\rightarrow
Commit.
$$

這延續 Paper 00–04 的 candidate/authority separation。

---

# 24. Resolver Architecture

抽象 resolver pipeline：

$$
Request
\rightarrow
Parse
\rightarrow
ClassifyAddressType
\rightarrow
ApplyContext
\rightarrow
ResolveNamespace
\rightarrow
Verify
\rightarrow
PolicyFilter
\rightarrow
ResolutionResult.
$$

## 24.1 Parse

確認 address syntax/version。

## 24.2 Classify

辨識：identity/content/semantic/spatial/physical/version/subobject/external。

## 24.3 Apply Context

補齊 relative base、workspace、theory、region、branch、time snapshot。

## 24.4 Resolve Namespace

呼叫 local index、object graph、semantic index、external resolver 或 storage provider。

## 24.5 Verify

若有 hash/signature/provenance，執行 deterministic verification。

## 24.6 Policy Filter

套用 ACL、capability、sandbox、privacy policy。

## 24.7 Return Typed Result

永遠回 typed resolution state，不用 silent fallback。

---

# 25. Address Graph

地址本身也可以形成 graph：

$$
G_A=(V_A,E_A).
$$

邊可以包含：

- aliasOf；
- resolvesTo；
- contentOf；
- revisionOf；
- locatedAt；
- semanticallyDescribes；
- spatiallyLocatedAt；
- migratedFrom；
- importedFrom；
- federatedWith。

這使系統能回答：

> 這個 object 現在在哪裡？

> 這份 bytes 對應哪個 revision？

> 這個舊 alias 現在指向誰？

> 這個 external reference 是否已被 import？

> 這個 semantic candidate 是否已被 promote？

地址不再只是字串，而是可被 provenance 管理的 reference structure。

---

# 26. 與 UTF-8 / UTF-8X 的接口

MLAM 對 UTF-8X 的角色非常明確。

UTF-8 / UTF-8X 可以承擔：

- address serialization；
- physical region/chunk locator；
- canonical object record carrier；
- content verification metadata；
- local indexing representation。

但：

$$
UTF8XPhysicalAddress
\neq
PersistentIdentity.
$$

換 carrier 時，identity 仍可保持。

TW-02 必須進一步凍結 physical address、chunk/content digest、manifest、migration 與 resolver adapter。

---

# 27. 與 Paper 03 Native Mathematics 的接口

數學 object：

$$
M@v.
$$

可以同時具有：

$$
A^{id}(M),
$$

$$
A^{ver}(M@v),
$$

$$
A^{content}(M@v),
$$

以及：

$$
A^{sub}(M@v,path).
$$

一個 theorem proof 可以引用某特定 revision：

$$
proves(P,M@v),
$$

而不是模糊地引用「目前最新的 M」。

這對可重現數學推理非常重要。

---

# 28. 與 Paper 04 Glyph 的接口

glyph $g$ 可以有：

- persistent glyph identity；
- structural content hash；
- semantic symbol address；
- canvas placement address；
- source/compiled physical addresses；
- glyph revision address。

同一 semantic operator：

$$
A^{sem}(DerivativeOperator)
$$

可以被多個 glyph identity 表示。

反之，同一 glyph geometry 在不同 namespace 也可能綁定不同 semantic address。

因此 character/glyph/symbol many-to-many mapping 最終由 MLAM 的 typed references 支撐。

---

# 29. 與 Paper 02 Infinite Canvas 的接口

spatial address 必須包含：

$$
(workspace,spatialRevision,region,frame,selector).
$$

Paper 02 的 semantic zoom 不改 object identity；nested canvas 則可以使用 relative spatial addresses。

若 region 被移動，其 child 的 world address可能整體改變，但 child 的 region-relative address可以保持：

$$
A^{space}_{world,t_1}\neq A^{space}_{world,t_2},
$$

而：

$$
A^{space}_{local,t_1}=A^{space}_{local,t_2}.
$$

這是 hierarchical canvas 必須具備的 reference stability。

---

# 30. 二十四項核心不變量

以下構成 Paper 05 的 design freeze。

## A1 — Typed Address Separation

六種核心 address semantics 不得靜默合併成單一「address」概念。

## A2 — Persistent Identity Independence

physical move、canvas move、renderer change、alias change 不得改 persistent identity。

## A3 — Content Address Determinism

相同 canonical intrinsic state、algorithm 與 canonicalization version 必須得到相同 content address。

## A4 — Hash Algorithm Qualification

content/version digest 不得以無 algorithm metadata 的裸 digest 作為完整 canonical address。

## A5 — Semantic Address Non-Uniqueness

semantic address 原生允許 zero/one/many resolution candidates。

## A6 — Semantic Match Non-Identity

semantic similarity 不得自動建立 persistent identity equality。

## A7 — Spatial Context Requirement

canonical spatial address 必須可解析其 workspace/snapshot/frame context。

## A8 — Physical Multiplicity

同一 immutable content 可合法存在多個 physical locations。

## A9 — Version Immutability

特定 version address 一旦 commit，不得被重新綁定到不同 revision state。

## A10 — Mutable Alias Disclosure

`latest`、`main`、human alias 等 mutable references 必須明確標示其可變性。

## A11 — Alias Non-Identity

alias equality 不等於 identity equality。

## A12 — Resolve/Dereference Separation

resolver 成功不保證 dereference 成功。

## A13 — Typed Failure States

unresolved、tombstoned、unavailable、unauthorized、invalid、stale 必須可區分。

## A14 — Relative Reference Requires Base

任何 relative address 都必須攜帶或可取得 resolution base/context。

## A15 — Subobject Revision Awareness

structural subobject address 若沒有 child persistent identity，必須至少綁定 parent revision。

## A16 — Cross-Workspace Import Provenance

import clone 預設產生新 identity，並保存 importedFrom lineage。

## A17 — Federation Requires Explicit Contract

跨 workspace 共享同 persistent identity 必須有 explicit federation/namespace contract。

## A18 — Address Migration Provenance

identifier、semantic-schema、physical-location migration 必須可追蹤。

## A19 — Tombstone Non-Reuse

被 tombstone 的 persistent identity 不可重新指向另一 lineage。

## A20 — Cache Freshness Discipline

mutable resolver output 必須具有 freshness/revalidation policy。

## A21 — Offline/Network Failure Separation

network unavailable 不得被回報成 identifier invalid。

## A22 — Resolution Non-Capability

知道／成功解析 address 不等於取得 read/write/execute capability。

## A23 — AI Candidate Boundary

AI-assisted address reconciliation 預設只產生 candidate，不直接 commit persistent identity equality。

## A24 — Resolver Version/Policy Provenance

任何會影響 nontrivial resolution 結果的 resolver profile、namespace mapping、policy 或 semantic model 必須可識別其版本/authority。

---

# 31. 二十項 Conformance Tests

## T1 — Physical Move

搬動檔案後：

$$
A^{phys}_1\neq A^{phys}_2,
$$

要求：

$$
A^{id}_1=A^{id}_2.
$$

## T2 — Canvas Move

移動畫布 object：

$$
A^{space}_1\neq A^{space}_2,
$$

但 identity/content 在純 move 下維持。

## T3 — Edit

編輯 intrinsic content：

$$
A^{id}_1=A^{id}_2,
$$

$$
A^{content}_1\neq A^{content}_2,
$$

$$
A^{ver}_1\neq A^{ver}_2.
$$

## T4 — Clone

clone 初始：

$$
A^{content}_A=A^{content}_B,
$$

但：

$$
A^{id}_A\neq A^{id}_B.
$$

## T5 — Replication

相同 content 有兩個 physical locations，resolver 仍判定 content equality。

## T6 — Semantic Ambiguity

partial semantic address 命中兩個高分候選，resolver 必須回 `Multiple` 而不是隨機 identity collapse。

## T7 — Semantic Zero Result

無候選時可回 `Unresolved` 且持久化，不得自動生成假 object。

## T8 — Version Citation

引用 immutable revision $v_1$ 後，即使 head 移到 $v_2$，舊 citation 仍解析到 $v_1$。

## T9 — Latest Alias

`latest` 隨 head 更新，但 resolver metadata 必須表明它是 mutable alias。

## T10 — Tombstone

被刪除 persistent object 再 resolve 時回 `Tombstoned`，不是被新 object 佔用。

## T11 — Resolve Without Dereference

identity resolver 成功，但 storage offline；結果應為已知 target + `Unavailable` dereference state，而不是 invalid address。

## T12 — Relative Base

同一 relative string 在不同 base workspace/theory 下可解析到不同 target，且 resolver 必須記錄 base。

## T13 — Subobject Revision

對 $v_1$ 的 structural path 不得未驗證直接套用到 $v_2$。

## T14 — Import Clone

跨 workspace import copy 產生新 persistent identity 並保存 source reference。

## T15 — Federated Identity

只有 explicit federation profile 下，同一 global identity 才能跨 workspace resolution。

## T16 — Hash Algorithm Agility

同一 bytes 使用兩個 hash algorithms 產生兩個 content addresses；兩者可透過 verified equivalence record 關聯但不得裸 digest 混用。

## T17 — Unauthorized Resolution

resolver 知道 target 存在但 policy 禁止揭露 physical locator，必須回 typed unauthorized/restricted result。

## T18 — Stale Cache

mutable alias cache 過期後不能 silent 使用舊 head；至少標為 stale 或 revalidate。

## T19 — AI Reconciliation

AI 提議兩個 external references 是同一 object，在 authority commit 前不得合併 persistent identities。

## T20 — Resolver Reproducibility

對 deterministic identity/content/version resolution，在相同 namespace snapshot、policy version 與合法 input 下，兩個合規 resolver 應得到相同 canonical target/result class。

---

# 32. MVP-01 最小 Addressing Slice

MVP 不需要一開始做全球分散式 resolver。只需證明六層地址真的能在同一 workspace 中互不偷換。

## 32.1 必做欄位

每個 object 至少：

- persistent ID；
- revision ID；
- content hash；
- workspace placement address；
- physical storage locator；
- optional semantic address。

## 32.2 必做 resolver

至少提供：

$$
ResolveID,
$$

$$
ResolveVersion,
$$

$$
VerifyContent,
$$

$$
ResolveSpatial,
$$

$$
ResolvePhysical,
$$

$$
ResolveSemanticCandidate.
$$

## 32.3 必做情境

同一 math object：

1. 建立 $v_1$；
2. 移動畫布位置；
3. 搬動 storage file；
4. 編輯成 $v_2$；
5. 保留對 $v_1$ 的 citation；
6. 建立 human alias；
7. 用 semantic search 找回；
8. clone 成另一 identity。

MVP 必須能同時證明：

$$
\boxed{
\text{same identity can change content/location/space/version}
}
$$

以及：

$$
\boxed{
\text{same content/semantics can belong to different identities}
}
$$

---

# 33. 對 TW-01 的接口

TW-01 必須正式凍結：

1. persistent identity syntax/namespace；
2. revision address schema；
3. content digest algorithm/profile；
4. canonicalization version representation；
5. semantic address schema；
6. spatial address schema；
7. physical locator schema；
8. alias record；
9. subobject selector；
10. external/cross-workspace reference；
11. typed resolution result；
12. tombstone representation；
13. address migration record；
14. resolver provenance fields。

---

# 34. 對 TW-02 的接口

TW-02 必須凍結：

- UTF-8 canonical textual representation；
- binary/UTF-8X carrier；
- physical chunks/regions；
- manifest/content hash；
- relocation/replication；
- local index；
- deterministic decode；
- storage-level resolution；
- corruption detection；
- offline retrieval。

MLAM 要求 TW-02 永遠不能把 storage locator 重新升格為 object identity。

---

# 35. 對 TW-03 的接口

TW-03 必須實作：

- resolver service layer；
- workspace-local identity index；
- revision DAG resolver；
- semantic candidate resolver；
- spatial resolver；
- external adapter resolver；
- cache/freshness；
- ACL/capability filter；
- offline mode；
- agent candidate resolution；
- diagnostic/debug view。

Runtime 必須能回答「為什麼這個 reference 被解析成這個 target」。

也就是提供：

$$
ExplainResolution(A)
\rightarrow
(trace,policy,evidence).
$$

---

# 36. 核心六篇論文的統一閉環

至 Paper 05，核心架構可以寫成：

$$
\mathcal W
=
(O,R,P,A,X,H).
$$

Paper 01 定義：

$$
O,H,R.
$$

Paper 02 深化：

$$
P
$$

與 spatial-to-execution boundary。

Paper 03 深化 native mathematical object：

$$
O_{math},X_{math}.
$$

Paper 04 深化 visual symbol/glyph object：

$$
O_{glyph}.
$$

Paper 05 最後凍結：

$$
A
$$

及 resolver semantics。

因此 ASCS 現在不再只是「無限畫布 + 新格式」的想法，而具備：

$$
\boxed{
\text{Object}
+
\text{Relation}
+
\text{Space}
+
\text{Address}
+
\text{Execution}
+
\text{History}
}
$$

六個互相分離但可組合的 canonical dimensions。

---

# 37. 非主張

本文不主張：

1. 所有 EveGlyph addresses 必須使用 URI；
2. 所有 persistent IDs 必須採 DID；
3. 所有 content IDs 必須採 SWHID；
4. 所有 public objects 必須註冊 DOI；
5. semantic address 必然可唯一解析；
6. global identity federation 必然適合所有 workspace；
7. address 本身自帶 access capability；
8. resolver 必須永遠連線；
9. content hash 能取代 persistent editable identity；
10. physical path 能取代 object identity；
11. semantic similarity 能證明 identity；
12. spatial proximity 能證明 relation；
13. alias 是永久不可變 identity；
14. AI 可以自行完成高權威 identity merge；
15. 一套 resolver namespace 可以統治所有 domain。

本文只主張：

> **每種地址必須說清楚它回答什麼問題、依賴什麼 context、具有什么 authority、如何被解析，以及它不能被用來證明什麼。**

---

# 38. Paper 05 Design Freeze

完成本文後，後續技術文件與 MVP 不得在未顯式修訂的情況下破壞以下決策：

1. persistent/content/semantic/spatial/physical/version 六層地址保持可分離；
2. persistent identity 不等於 locator 或 content hash；
3. content address 必須 algorithm + canonicalization qualified；
4. semantic address 可以 partial、ambiguous、zero-result；
5. semantic similarity 不建立 identity equality；
6. spatial address 必須 workspace/snapshot/frame aware；
7. physical address 可一對多、可遷移；
8. immutable version address 不可重新綁定；
9. `latest`/`main`/human aliases 必須標明 mutable；
10. alias 不等於 identity；
11. Resolve 與 Dereference 分離；
12. resolution failure/status 必須 typed；
13. relative references 必須有 base context；
14. subobject reference 必須 revision-aware；
15. cross-workspace import clone 預設建立新 identity + lineage；
16. identity federation 必須 explicit；
17. address migration 必須保存 provenance/fidelity；
18. tombstone identity 不可重用；
19. mutable resolver cache 必須有 freshness policy；
20. offline/unavailable 與 invalid address 分離；
21. address resolution 不等於 read/write/execute capability；
22. AI resolver 產生 candidate，不直接 merge persistent identities；
23. resolver policy/namespace/model version 必須可追蹤；
24. MVP 必須實際證明同 identity 可改 content/space/physical/version，而同 content/semantics 可屬不同 identities。

---

# 39. 結論

數位文件走向 AI-native、可執行、可空間化、多模態與長期版本化之後，「地址」不再只是工程細節。

如果把檔案路徑當 identity，那麼搬檔就是物件死亡。

如果把 content hash 當 persistent identity，那麼每次編輯都是新物件。

如果把 semantic similarity 當 identity，那麼 AI 的近似判斷會把不同 lineage 錯誤合併。

如果把 canvas coordinate 當 identity，那麼移動節點就會改變本體。

如果把 `latest` 當 immutable version，歷史 citation 會漂移。

如果把 resolve 當 permission，知道地址就變成取得執行權。

因此 MLAM 的核心不是增加更多複雜度，而是把原本已經存在、卻常被藏在不同系統中的複雜度顯式化：

$$
\boxed{
\text{Who/what is it?}
\neq
\text{What exact content is it?}
\neq
\text{What does it mean?}
\neq
\text{Where is it in the workspace?}
\neq
\text{Where are its bytes?}
\neq
\text{Which revision is referenced?}
}
$$

當這六個問題被分開，EveGlyph 才能真正支撐一個長期演化的 computational world。

同一個 symbol 可以被移動、重新渲染、換 storage、升級內容、建立新 revision，而仍保有 persistent lineage；另一個 clone 可以擁有完全相同 content 卻是不同 object；一個未命名概念可以只有 partial semantic address；一個舊 version citation 可以永遠指向當時的數學狀態；一個 custom glyph 可以在無 Unicode code point 的情況下被穩定識別、定位、版本化與綁定運算。

於是 Paper 00–05 形成完整閉環：

$$
\boxed{
\text{Linear Document}
\rightarrow
\text{Addressable Symbolic Computational Space}
}
$$

不是靠一個「更強的檔案格式」完成，而是靠六個彼此解耦、可驗證又能重新組合的層：

$$
\boxed{
O+R+P+A+X+H.
}
$$

核心理論層至此完成。

下一階段不再需要增加新的總論，而應直接進入：

$$
\text{TW-01 Symbol IR Specification}
$$

$$
\text{TW-02 UTF-8 / UTF-8X Storage Architecture}
$$

$$
\text{TW-03 Computational Canvas Runtime}
$$

最後由：

$$
\text{MVP-01}
$$

把這六篇論文的核心 invariants 轉成真正可以操作、驗證與失敗的工程系統。

---

# References

[1] T. Berners-Lee, R. Fielding, and L. Masinter. *RFC 3986: Uniform Resource Identifier (URI): Generic Syntax*. IETF, 2005.

[2] P. Saint-Andre and J. Klensin. *RFC 8141: Uniform Resource Names (URNs)*. IETF, 2017.

[3] S. Farrell, D. Kutscher, C. Dannewitz, B. Ohlman, A. Keränen, and P. Hallam-Baker. *RFC 6920: Naming Things with Hashes*. IETF, 2013.

[4] ISO/IEC. *ISO/IEC 18670:2025 — Information technology — SoftWare Hash IDentifier (SWHID) Specification V1.2*. 2025.

[5] Software Heritage / SWHID.org. *SoftWare Hash IDentifier Public Specification and Documentation*.

[6] DOI Foundation. *DOI Handbook*. Current handbook edition consulted in 2026.

[7] W3C. *Decentralized Identifiers (DIDs) v1.0*. W3C Recommendation, 19 July 2022.

[8] W3C. *Decentralized Identifiers (DIDs) v1.1*. Candidate Recommendation Snapshot, 05 March 2026.

[9] W3C. *PROV-O: The PROV Ontology*. W3C Recommendation, 2013.

[10] EveMissLab. *00 — From Linear Documents to Addressable Symbolic Computational Spaces*. v0.1, 2026.

[11] EveMissLab. *01 — Addressable Symbolic Object Model*. v0.1, 2026.

[12] EveMissLab. *02 — Spatial Syntax and Infinite Canvas Computation*. v0.1, 2026.

[13] EveMissLab. *03 — Native Computational Mathematics Beyond LaTeX*. v0.1, 2026.

[14] EveMissLab. *04 — Generative Glyph and Symbol Compilation*. v0.1, 2026.

[15] EveMissLab. *UTF-8X — 區域動態表示架構*. research engineering baseline, 2026.

[16] EveMissLab. *PSSA-BSAR v0.1 Milestone 4 Source*. address-first semantic representation experiment, 2026.

---

# Appendix A — 形式化摘要

$$
A(o,v,t,\Gamma)=
(
A^{id},
A^{content},
A^{sem},
A^{space},
A^{phys},
A^{ver},
Q
).
$$

$$
A^{id}(O_i)=i.
$$

$$
A^{content}
=
(alg,canonVersion,H(D_c\Vert C_{\sigma}(Intrinsic(o_v)))).
$$

$$
A^{sem}
=
(\Omega,A^+,A^-,R,C,U,q,\nu).
$$

$$
A^{space}
=
(workspace,spatialSnapshot,region,frame,selector/transform).
$$

$$
A^{phys}
=
(carrierType,authority,locator,qualifiers).
$$

$$
A^{ver}(o_v)
=
(objectID,revisionID).
$$

$$
Resolve(A,\Gamma,Policy)
\rightarrow
ResolutionResult.
$$

$$
Dereference(ResolutionResult,selector)
\rightarrow
Representation.
$$

$$
ResolutionResult
\in
\{
Resolved,
Multiple,
Unresolved,
Tombstoned,
Unavailable,
Unauthorized,
Invalid,
Stale
\}.
$$

$$
A^{sub}
=
(A^{ver},selector).
$$

$$
Ref_{cross}
=
(workspaceID,targetAddress,policy).
$$

$$
G_A=(V_A,E_A).
$$

---

# Appendix B — Implementation-facing Checklist

在 TW-01 / TW-02 / TW-03 / MVP-01 開始前，至少必須回答：

1. persistent identity 採何種 scheme / namespace？
2. identity namespace 是否 local、federated 或 global？
3. revision ID 是否 content-derived？
4. content digest 採哪些 algorithms，如何 algorithm agility？
5. canonicalization version 如何嵌入 address？
6. semantic address schema 如何表示 unresolved/open variables？
7. semantic resolver 如何區分 exact/approximate candidate？
8. spatial address 如何表示 workspace/snapshot/frame？
9. nested canvas relative spatial address 如何 canonicalize？
10. physical locator 是否允許 multiple replicas？
11. UTF-8X chunk/region 如何映射 $A^{phys}$？
12. alias record 如何表示 mutable/immutable？
13. `/latest`、branch、tag 的 resolver semantics 是什麼？
14. tombstone 要保留哪些最小 metadata？
15. subobject selector 使用 child identity、graph path 或 mixed strategy？
16. subobject rebase mapping 如何保存 provenance？
17. cross-workspace link/import/federation 三者如何在 UI 區分？
18. external URI/URN/DOI/DID/SWHID adapters 如何掛接？
19. offline resolver 的 local cache/index 優先序為何？
20. mutable resolution cache 如何 revalidate？
21. resolver trace 如何 expose 給 debug/AI？
22. unauthorized resolution 如何避免洩露 sensitive physical locators？
23. identity reconciliation 哪些操作需要 human/authority commit？
24. hash migration 如何建立 verifiable equivalence？
25. semantic-schema migration 如何標 fidelity？
26. resolver implementation 如何 version/policy pinning？
27. MVP 如何展示同 identity across move/edit/storage migration？
28. MVP 如何展示 same content with different identities？
29. MVP 如何展示 semantic multi-candidate result？
30. MVP 如何展示 old revision citation 不隨 latest 漂移？

Paper 05 不要求現在決定所有語法細節；它要求之後所有 addressing implementation 都必須保留本文已凍結的 typed-address separation 與 resolution authority boundary。


<!-- SOURCE: TW-01_EveGlyph_Symbol_IR_Specification_v0.1.md -->

# TW-01｜EveGlyph Symbol IR Specification v0.1

**English Title:** EveGlyph Symbol IR Specification v0.1: Canonical Object, Revision, Relation, Address, Spatial, Mathematical, Glyph, and Provenance Records

**作者：** Neo.K  
**機構：** EveMissLab / 一言諾科技有限公司  
**版本：** v0.1  
**日期：** 2026-08-24  
**文件類型：** 技術白皮書 / Normative Technical Specification  
**系列定位：** EveGlyph Addressable Symbolic Computational Space Series — TW-01  
**前置理論錨點：** Paper 00–05 ASCS v0.1 Core Theory Freeze

---

## Canonical Source Note

本文件以 UTF-8 Markdown 保存正式規格原稿，數學 source 僅使用 `$...$` 與 `$$...$$` 作為 canonical delimiter。

本白皮書第一次把 Paper 00–05 的形式化決策壓成可實作規格。與前六篇論文不同，本文件使用 **MUST / MUST NOT / SHOULD / SHOULD NOT / MAY** 表示規範強度。這些詞只在全大寫時具有規範性。

本文件定義 **EveGlyph Symbol IR，縮寫 EGIR**。v0.1 的 portable canonical carrier 是 UTF-8 JSON；JSON Schema Draft 2020-12 用於結構驗證；hash preimage 使用 `EGIR-CJ/0.1` deterministic canonicalization。未來 TW-02 可以新增 CBOR、UTF-8X region carrier 或其他 binary representation，但不得改變本文定義的 abstract IR semantics。

因此：

$$
\text{EGIR abstract model}
\neq
\text{JSON surface}
\neq
\text{storage carrier}.
$$

---

# 1. 規格目標

TW-01 的目標不是設計完整 EveGlyph UI，也不是把所有未來 object kind 一次凍死；它要提供一個最小但足夠穩定的 **canonical object contract**，使 Paper 00–05 的不變量可以被程式驗證。

v0.1 必須支援：

1. persistent object identity；
2. immutable revision records；
3. content addressing；
4. revision DAG；
5. first-class relations；
6. workspace placement 與 spatial state；
7. multi-layer address references；
8. event/provenance records；
9. native math profile；
10. glyph profile；
11. candidate/authority separation；
12. deterministic canonicalization；
13. import/export adapter metadata；
14. schema evolution 與 extension preservation。

EGIR v0.1 明確不處理完整網路 federation、distributed consensus、CRDT、GPU renderer、CAS backend、font engine 或 UTF-8X storage layout；這些留給 TW-02/TW-03。

---

# 2. Conformance Classes

實作者可宣告三種 conformance class。

## 2.1 Reader

Reader MUST：

- 解析 UTF-8 JSON EGIR bundle；
- 驗證 `ir_version`；
- 拒絕 duplicate JSON object keys；
- 驗證 core schema；
- 保留未知 extension fields/records；
- 不把未知 executable binding 自動執行；
- 能辨識 typed addresses 與 typed failure/candidate states。

## 2.2 Writer

Writer 除 Reader 要求外 MUST：

- 生成合法 persistent IDs；
- 生成 deterministic content/revision addresses；
- 生成 provenance event；
- 將 placement 與 intrinsic state 分離；
- 不把 candidate relations 寫成 explicit relations；
- 保留 parent revision DAG；
- 使用 canonical UTF-8 source output。

## 2.3 Runtime

Runtime 除 Writer 要求外 MUST：

- 驗證 execution binding；
- 在執行前做 policy/permission check；
- 產生 execution provenance；
- 不以 visual projection equality 判定 semantic identity；
- 不以 AI suggestion 直接完成 high-authority identity merge。

---

# 3. EGIR Bundle

v0.1 的交換單位稱為 **bundle**：

```json
{
  "ir_version": "egir/0.1",
  "bundle_kind": "workspace-snapshot",
  "workspace": {},
  "object_records": [],
  "revision_records": [],
  "event_records": [],
  "candidate_records": [],
  "extensions": {}
}
```

`bundle_kind` v0.1 定義：

- `workspace-snapshot`：完整 workspace state；
- `fragment`：部分 object/revision graph；
- `object-pack`：一組可匯入 objects 與 lineage。

bundle 是 carrier unit，不是 object identity。

$$
\text{Bundle identity}
\neq
\text{Object identity}.
$$

---

# 4. Persistent Identity

## 4.1 新 object 的預設格式

EGIR v0.1 新建 persistent identities SHOULD 使用 RFC 9562 UUIDv7，並以 lowercase UUID URN 表示：

```text
urn:uuid:0190a001-1111-7abc-8def-111111111111
```

新 writer SHOULD 使用 UUIDv7，因其時間排序特性有利於 local-first event/object store；reader MUST NOT 依時間順序推論 causality。

## 4.2 Legacy identity

Reader MAY 接受從舊系統導入的其他 identity schemes，但轉入 canonical EGIR 時 MUST 以明確 adapter record 保存來源，不得把 display name 當 persistent identity。

## 4.3 Identity invariants

對 persistent object $O_i$：

$$
A^{id}(O_i)=i.
$$

`i` MUST NOT 因 edit、move、rerender、storage migration、alias rename 改變。

Tombstoned identity MUST NOT 被重用。

---

# 5. Object Record

Object record 描述 persistent lineage，而不是某一版內容：

```json
{
  "record_type": "object",
  "persistent_id": "urn:uuid:...",
  "kind": "math",
  "status": "active",
  "created_event": "urn:uuid:...",
  "heads": {
    "main": "rev:sha256:..."
  },
  "aliases": [],
  "metadata": {}
}
```

## 5.1 `kind`

v0.1 保留以下 built-in kinds：

- `text`；
- `math`；
- `code`；
- `glyph`；
- `data`；
- `operator`；
- `region`；
- `relation`；
- `media-ref`；
- `external-ref`；
- `composite`。

Reader MUST preserve unknown kinds。Runtime MUST NOT execute unknown kinds without explicit extension support。

## 5.2 `heads`

`heads` 是 branch-name 到 immutable revision address 的 mapping。

同一 object MAY 同時存在：

```json
{
  "main": "rev:sha256:...",
  "agent-a": "rev:sha256:...",
  "agent-b": "rev:sha256:..."
}
```

因此 branch divergence 是合法 canonical state。

---

# 6. Revision Record

Revision record 描述 immutable object state：

```json
{
  "record_type": "revision",
  "persistent_id": "urn:uuid:...",
  "revision_id": "rev:sha256:...",
  "kind": "math",
  "parents": [],
  "content_address": "content:sha256:...",
  "intrinsic": {},
  "event_id": "urn:uuid:...",
  "created_at": "2026-08-24T10:30:00.000Z",
  "metadata": {}
}
```

## 6.1 Immutable contract

一旦 commit，revision record 的 hash-covered fields MUST NOT 被修改。

需要改動時 MUST 產生新 revision：

$$
v_1\rightarrow v_2.
$$

Merge revision MAY 有多個 parent：

$$
Parents(v_m)=\{v_a,v_b\}.
$$

## 6.2 Intrinsic boundary

`intrinsic` 只保存 object 本體 state。Canvas placement、viewport、selection、cache、UI-expanded state MUST NOT 進入一般 object intrinsic content。

不同 kind 的 intrinsic boundary 由 profile 規格定義。

---

# 7. Content Address 與 Revision Address

EGIR v0.1 使用 SHA-256 作為 mandatory digest algorithm。未來 TW-02 MAY 增加 algorithm agility，但 v0.1 writer MUST 同時支援 SHA-256。

## 7.1 Content preimage

對 kind $k$ 與 intrinsic $I$：

$$
P_c=
\{
canon=\text{egir-cj/0.1},
kind=k,
intrinsic=I
\}.
$$

$$
A^{content}=\text{content:sha256:}H(C(P_c)).
$$

Canvas placement、physical locator、human alias 不進 $P_c$。

## 7.2 Revision preimage

v0.1 revision address preimage：

$$
P_v=
\{
canon,
persistent\_id,
kind,
parents,
content\_address,
event\_id,
created\_at
\}.
$$

其中 `parents` MUST 在 hash preimage 中以 revision ID lexical order 排序。

$$
A^{ver}=\text{rev:sha256:}H(C(P_v)).
$$

因此同 intrinsic content 在不同 persistent object 中可以有相同 content address，但不同 revision address。

---

# 8. EGIR-CJ/0.1 Canonicalization

## 8.1 原則

EGIR-CJ/0.1 的目的不是定義新的數學簡化器，而是生成 deterministic hash bytes。

$$
\text{Canonicalization}
\neq
\text{semantic normalization}
\neq
\text{theorem simplification}.
$$

## 8.2 JSON lowering

所有 hash-covered state MUST 先 lowering 到 safe JSON domain。

v0.1 禁止在 hash preimage 中使用：

- NaN；
- Infinity；
- binary floating-point runtime values；
- 不可攜的 language-specific object；
- raw pointer/memory address。

## 8.3 數值規則

大整數、exact rational、arbitrary decimal、measurement、coordinate decimal SHOULD 使用 typed string representation，例如：

```json
{ "type": "integer", "value": "123456789012345678901234567890" }
```

```json
{ "type": "rational", "numerator": "1", "denominator": "3" }
```

Canvas transform v0.1 使用 decimal strings：

```json
{
  "x": "120.0",
  "y": "80.0",
  "scale_x": "1.0",
  "scale_y": "1.0",
  "rotation_deg": "0.0"
}
```

這避免不同語言把同一概念輸出成不同 IEEE-754 shortest-string representation。

## 8.4 Key order

JSON object keys 在 canonical output 中 MUST 按 Unicode code point lexical order 排序。

## 8.5 Arrays

Array order 預設具有語義，MUST 保留。

只有規格明確宣告為 set 的欄位才排序。例如：

- revision `parents`：lexical sort；
- workspace `object_heads`：以 `(persistent_id, revision)` 排序；
- workspace `relation_heads`：同上；
- canonical placement list：以 `(object_id, region_id, placement_id)` 排序。

## 8.6 Unicode

EGIR-CJ/0.1 MUST 保存 Unicode scalar sequence，不在 canonicalization 階段自動執行 NFC/NFKC normalization。

搜尋／比較層 MAY 建立 normalized secondary index，但不得回寫 source string。

## 8.7 Whitespace

Canonical JSON output MUST 不包含 token 之間的非必要 whitespace，並以 UTF-8 bytes hash。

---

# 9. 為什麼不是「直接 JCS 就好」

RFC 8785 JSON Canonicalization Scheme 是 EGIR-CJ/0.1 的重要基礎：deterministic key ordering、JSON primitive serialization 與 hash-friendly bytes 都直接採納其精神。

但 JCS 將 input 約束在 I-JSON，且 JSON number 需可由 IEEE-754 double precision 表示。Native Computational Mathematics 必須支援 arbitrary integer、rational 與 exact decimal，因此 EGIR 必須先把這些值 lowering 成 typed strings/objects，再在 safe JSON layer 做 deterministic serialization。

所以：

$$
\text{NCM exact number}
\xrightarrow{lower}
\text{safe EGIR JSON value}
\xrightarrow{canonicalize}
\text{hash bytes}.
$$

---

# 10. Event / Provenance Record

任何 persistent state mutation MUST 有 event：

```json
{
  "record_type": "event",
  "event_id": "urn:uuid:...",
  "actor": {
    "type": "human",
    "id": "Neo.K",
    "model": null
  },
  "op": "create-object",
  "inputs": [],
  "outputs": [],
  "base_workspace_revision": null,
  "tool": {
    "name": "eveglyph-runtime",
    "version": "0.1"
  },
  "policy": {},
  "created_at": "2026-08-24T10:30:00.000Z",
  "metadata": {}
}
```

Actor type：

- `human`；
- `ai`；
- `system`；
- `importer`。

AI event SHOULD 記錄 model/runtime identifier，但 MUST NOT 把 API key、token 或 secrets 寫入 canonical provenance。

---

# 11. Relations as First-Class Objects

EGIR v0.1 將 authoritative relation 實作成普通 persistent object，`kind="relation"`。

Relation intrinsic：

```json
{
  "profile": "relation/0.1",
  "source": { "type": "identity", "value": "urn:uuid:..." },
  "predicate": "eg:dependsOn",
  "target": { "type": "identity", "value": "urn:uuid:..." },
  "qualifiers": {},
  "authority": {
    "class": "explicit",
    "source": "user",
    "rule": null,
    "confidence": "1.0"
  }
}
```

`authority.class` 只能是：

- `explicit`；
- `derived`。

AI、spatial parser、recognizer 尚未 commit 的輸出 MUST 先放在 `candidate_records`，不能直接出現在 workspace `relation_heads`。

---

# 12. Candidate Records

Candidate 是可保存但沒有 authoritative semantics 的結構：

```json
{
  "candidate_id": "urn:uuid:...",
  "candidate_type": "relation",
  "payload": {},
  "authority": "candidate",
  "created_at": "...",
  "source": {}
}
```

v0.1 candidate types：

- `relation`；
- `semantic`；
- `parse`；
- `identity-match`。

Promotion 必須產生 event：

$$
Candidate
\xrightarrow{Promote}
CommittedRevision.
$$

---

# 13. Multi-Layer AddressRef

EGIR v0.1 address reference 是 tagged union。

## 13.1 Identity

```json
{ "type": "identity", "value": "urn:uuid:..." }
```

## 13.2 Version

```json
{
  "type": "version",
  "object": "urn:uuid:...",
  "revision": "rev:sha256:..."
}
```

## 13.3 Content

```json
{
  "type": "content",
  "algorithm": "sha-256",
  "canonicalization": "egir-cj/0.1",
  "digest": "..."
}
```

## 13.4 Semantic

```json
{
  "type": "semantic",
  "schema": "eg-sem/0.1",
  "ontology": "eg:math",
  "anchors": ["derivative"],
  "negative_anchors": [],
  "relations": [],
  "constraints": [],
  "open_variables": [],
  "confidence": "0.93",
  "authority": "candidate"
}
```

## 13.5 Spatial

```json
{
  "type": "spatial",
  "workspace": "urn:uuid:...",
  "snapshot": "wrev:sha256:...",
  "region": null,
  "frame": "world",
  "selector": {}
}
```

## 13.6 Physical

```json
{
  "type": "physical",
  "carrier": "file",
  "locator": "workspace.egir.json",
  "authority": "local",
  "qualifiers": {}
}
```

Physical references MUST NOT be interpreted as persistent identity。

---

# 14. Workspace Revision

Workspace revision 是 object heads、relation heads 與 placements 的 immutable snapshot：

```json
{
  "workspace_id": "urn:uuid:...",
  "workspace_revision": "wrev:sha256:...",
  "parents": [],
  "title": "Example",
  "object_heads": [],
  "relation_heads": [],
  "placements": [],
  "event_id": "urn:uuid:...",
  "created_at": "...",
  "metadata": {}
}
```

Workspace revision preimage 包含：

$$
P_W=
\{
canon,
workspace\_id,
parents,
object\_heads,
relation\_heads,
placements,
event\_id,
created\_at
\}.
$$

$$
A^{workspaceVer}=
\text{wrev:sha256:}H(C(P_W)).
$$

UI viewport、selection、cursor、hover、temporary drag state MUST NOT 進 workspace revision preimage。

---

# 15. Placement Record

Placement 是 extrinsic workspace state：

```json
{
  "placement_id": "place:node-001",
  "object_id": "urn:uuid:...",
  "region_id": null,
  "frame": "world",
  "transform": {
    "x": "120.0",
    "y": "80.0",
    "scale_x": "1.0",
    "scale_y": "1.0",
    "rotation_deg": "0.0"
  },
  "z": 0,
  "layer": "main"
}
```

純 move 只建立新 workspace revision，不建立新 object revision：

$$
Move(o)
\Rightarrow
v_o'=v_o,
\quad
v_W'\neq v_W.
$$

---

# 16. Region / Local Formality

`region` 是 built-in object kind。其 intrinsic SHOULD 包含：

- boundary geometry；
- local frame；
- grammar profile；
- execution policy；
- namespace policy；
- snap/tolerance profile。

幾何進入 region 只能產生 candidate membership；semantic scope 必須 explicit commit。

$$
Inside_{geo}(o,r)
\not\Rightarrow
ScopedBy(o,r).
$$

---

# 17. Native Math Profile `ncm/0.1`

`math` revision intrinsic MUST 使用 profile：

```json
{
  "profile": "ncm/0.1",
  "expression": {
    "root": "n3",
    "nodes": []
  },
  "bindings": [],
  "type_info": {},
  "assumptions": [],
  "constraints": [],
  "units": {},
  "numeric_policy": {},
  "presentation": {},
  "execution": {}
}
```

## 17.1 Expression nodes

v0.1 core node types SHOULD 至少支援：

- `symbol`；
- `integer`；
- `rational`；
- `decimal`；
- `apply`；
- `binder`；
- `relation`；
- `matrix`；
- `piecewise`；
- `hole`。

## 17.2 Bound variables

Bound variables SHOULD 有 local node identity / binding record，而不是只靠 visible name。

## 17.3 Exactness

Exact numeric value MUST NOT 被 renderer 的 decimal approximation 回寫成 intrinsic mutation。

## 17.4 Execution

Runtime MUST 能直接在 NCM intrinsic 上執行，不得把 NCM 先輸出 LaTeX 再作 canonical parse-back。

---

# 18. Glyph Profile `glyph/0.1`

`glyph` revision intrinsic：

```json
{
  "profile": "glyph/0.1",
  "geometry": {},
  "topology": {},
  "parts": {},
  "semantics": [],
  "render_profiles": [],
  "behavior": {}
}
```

## 18.1 Geometry / placement separation

`geometry` 是 intrinsic local geometry；Canvas transform 放在 placement record。

## 18.2 Unicode

Unicode code point MAY 存成 adapter metadata，但 MUST NOT 成為 glyph persistent identity 的唯一來源。

## 18.3 Behavior

Imported glyph behavior MUST 預設 disabled / untrusted。Runtime 必須有 explicit permission transition 才能執行。

---

# 19. Alias Records

Alias：

```json
{
  "scope": "workspace",
  "name": "Derivative",
  "mutable": true,
  "authority": "user"
}
```

`mutable=true` 的 alias MUST NOT 被用作 immutable citation。

`latest`、`main`、display names 都屬 mutable resolution surface；真正 reproducible reference 應使用 version address。

---

# 20. Tombstone

Object deletion 不等於 identity 消失。

Object record：

```json
{
  "status": "tombstoned"
}
```

Tombstoned object MAY 移除 content bytes，但 reader/resolver SHOULD 保留：

- persistent ID；
- tombstone event；
- last known revision；
- minimal provenance。

Identity MUST NOT 被分配給新 lineage。

---

# 21. Extension Model

EGIR 必須可演化。

## 21.1 Unknown fields

Core records 使用封閉 schema，因此 core 欄位不能任意增加。Extension data MUST 放進：

```json
"extensions": {
  "org.example.feature/1": {}
}
```

或 object/revision `metadata` 中的 namespace-qualified field。

## 21.2 Unknown kinds

Reader MUST preserve unknown kind revision `intrinsic`，Writer SHOULD round-trip unchanged。

Runtime MUST NOT execute unknown kind。

## 21.3 Version negotiation

`ir_version` v0.1 僅接受 `egir/0.1`。

未來 `egir/0.2` 若破壞 core semantics，MUST 使用顯式 migration，而不是 silent reinterpretation。

---

# 22. Serialization Profiles

## 22.1 UTF-8 JSON — REQUIRED

所有 v0.1 implementations MUST 支援。

要求：

- valid UTF-8；
- no BOM SHOULD be emitted；
- duplicate object keys MUST be rejected；
- parsed strings MUST preserve scalar sequence；
- canonical hashing 使用 EGIR-CJ/0.1，不使用 pretty-printed bytes。

## 22.2 CBOR — RESERVED / OPTIONAL

RFC 8949 CBOR 是後續 compact/binary carrier 的候選。TW-01 不凍結 CBOR tag mapping。

若實作者提前提供 CBOR exporter，MUST 以 JSON canonical abstract state 作 cross-check，且不得因 CBOR map order、float encoding 或 tag choice 改變 EGIR semantic identity。

## 22.3 UTF-8X — DEFERRED TO TW-02

UTF-8X 可承擔 physical/region representation，但其 encode/decode 必須滿足：

$$
Decode(Encode(EGIR))=EGIR
$$

在本文件定義 equality 下成立。

---

# 23. JSON Schema 2020-12

本封裝包含：

```text
TW-01_Support/schemas/eveglyph-ir.schema.json
```

v0.1 使用 JSON Schema Draft 2020-12 作 structural validation。

Schema validation 不是全部 conformance：hash、cross-record reference、DAG parent existence、content/revision recomputation、authority boundary 仍需要 semantic validator。

因此：

$$
SchemaValid(x)
\not\Rightarrow
EGIRConformant(x).
$$

---

# 24. Cross-Record Semantic Validation

Writer/validator MUST 額外檢查：

1. 每個 object head revision 存在；
2. revision `persistent_id` 與 object lineage 相符；
3. revision parents 存在或明確 external；
4. content address recompute 相符；
5. revision address recompute 相符；
6. workspace revision recompute 相符；
7. relation source/target references 型別合法；
8. explicit relation 不引用 candidate-only target 作 authoritative identity，除非 target reference type 本身允許 unresolved semantics；
9. placement target object 存在；
10. tombstoned ID 不被新 lineage 重用。

---

# 25. Import / Export Adapter Contract

Adapter 必須回：

$$
AdapterResult=(objects,candidates,diagnostics,fidelity,provenance).
$$

`fidelity` 至少可為：

- `lossless`；
- `structural`；
- `semantic-subset`；
- `visual-only`；
- `unknown`。

LaTeX importer 不得宣稱所有 macro 都已取得 NCM semantics；SVG importer 不得把所有 group/geometry 都當 semantic relation；PDF/image importer 更不得假裝 recovered structure 是原 canonical source。

---

# 26. AI Authority Boundary

AI 可以建立：

- candidate semantic address；
- candidate relation；
- candidate identity match；
- candidate parse；
- suggested rewrite。

AI output SHOULD 進 `candidate_records`。

High-authority commit 必須經：

$$
Proposal
\rightarrow
Validation
\rightarrow
Policy
\rightarrow
CommitEvent.
$$

任何生成式模型 output 都不能取代 content/revision hash recomputation。

---

# 27. Security Requirements

## 27.1 Parsing

Reader MUST：

- reject duplicate keys；
- impose maximum nesting / record count / byte size appropriate to deployment；
- reject malformed UTF-8；
- reject invalid ID/hash syntax；
- avoid code execution during parse。

## 27.2 Physical locators

Physical addresses MAY 包含敏感本機路徑。Exporter SHOULD 提供 redaction profile，public bundle SHOULD NOT 預設洩露 private absolute paths。

## 27.3 Executable bindings

`behavior`、`execution`、operator/tool binding MUST NOT 在 import 時自動取得執行權。

## 27.4 Provenance secrets

API keys、tokens、passwords、private credentials MUST NOT 寫入 event metadata。

---

# 28. Deterministic Validation Order

推薦 validator pipeline：

$$
Bytes
\rightarrow
UTF8Decode
\rightarrow
JSONParse
\rightarrow
SchemaValidate
\rightarrow
ReferenceValidate
\rightarrow
Canonicalize
\rightarrow
HashVerify
\rightarrow
AuthorityValidate
\rightarrow
RuntimePolicy.
$$

任何前置 stage 失敗，後續 MUST NOT 以 AI 猜測方式「修好後當作原資料」。Repair 可以是新的 explicit transformation event，但不能竄改 input provenance。

---

# 29. Conformance Vectors

本封裝包含：

```text
TW-01_Support/conformance/tw01_vectors.json
```

並提供 reference validator：

```text
TW-01_Support/tools/validate_tw01.py
```

必測向量包括：

1. canonical key ordering；
2. UTF-8 canonical bytes hash；
3. math content address；
4. relation content address；
5. revision IDs；
6. workspace revision；
7. edit preserves identity；
8. move preserves intrinsic object revision；
9. clone separates identity；
10. candidate non-authority。

---

# 30. Minimal Example

本封裝的：

```text
TW-01_Support/examples/minimal_workspace.egir.json
```

建立一個 `math` object：

$$
x^2
$$

一個 explicit semantic relation，以及一個 Canvas placement。

這個 example 實際證明：

- math intrinsic content 有獨立 content address；
- revision 有獨立 revision address；
- relation 是 persistent/versioned object；
- placement 不進 math content hash；
- workspace snapshot 自己具有 workspace revision；
- provenance event 與 revision 互相可追蹤。

---

# 31. v0.1 Reference Package Layout

```text
EveGlyph_Addressable_Symbolic_Computational_Space_Series_v0.1/
├─ 00_...md
├─ 01_...md
├─ 02_...md
├─ 03_...md
├─ 04_...md
├─ 05_...md
├─ TW-01_EveGlyph_Symbol_IR_Specification_v0.1.md
├─ TW-01_Support/
│  ├─ schemas/
│  │  └─ eveglyph-ir.schema.json
│  ├─ examples/
│  │  └─ minimal_workspace.egir.json
│  ├─ conformance/
│  │  └─ tw01_vectors.json
│  └─ tools/
│     └─ validate_tw01.py
├─ SERIES_INDEX_v0.1.md
├─ VALIDATION.md
└─ SHA256SUMS.txt
```

---

# 32. TW-01 Design Freeze

完成本文件後，TW-02、TW-03 與 MVP-01 不得在未顯式升版的情況下破壞以下決策：

1. EGIR abstract model 與 carrier 分離；
2. UTF-8 JSON 是 v0.1 mandatory portable carrier；
3. JSON Schema 2020-12 是 v0.1 structural schema dialect；
4. new persistent object IDs SHOULD 使用 UUIDv7 URN；
5. persistent object 與 immutable revision 分離；
6. content address 與 revision address 分離；
7. SHA-256 是 v0.1 mandatory digest；
8. hash 使用 EGIR-CJ/0.1 canonicalization；
9. arbitrary/exact numerics 不直接依賴 binary float JSON serialization；
10. canonicalization 不做 theorem simplification；
11. Unicode scalar sequence 在 canonicalization 中不做 automatic normalization；
12. relation 是 first-class persistent/versioned object；
13. candidate records 不具有 explicit authority；
14. placement 是 workspace extrinsic state；
15. pure move 不建立 object intrinsic revision；
16. workspace snapshot 有自己的 immutable revision；
17. identity/content/semantic/spatial/physical/version refs 是 tagged typed union；
18. mutable alias 不得冒充 immutable citation；
19. Native Math 使用 `ncm/0.1` profile 且可直接執行；
20. Glyph 使用 `glyph/0.1` profile，geometry 與 placement 分離；
21. import adapter 必須回 fidelity 與 provenance；
22. executable binding 匯入後預設不取得權限；
23. schema validation 與 full semantic conformance 分離；
24. unknown extension kinds 必須可保存，但不得自動執行；
25. state mutation 必須有 event/provenance；
26. content/revision/workspace hash 必須可由不同合規 implementation 重算一致；
27. secrets 不進 canonical provenance；
28. repair 是新 transformation event，不可 silent 改寫 input；
29. TW-02 可替換 physical carrier，但不能改 EGIR identity semantics；
30. TW-03 可替換 runtime/index/renderer，但不能改 authority / revision / addressing semantics。

---

# 33. MVP-01 直接實作要求

MVP-01 不需要一次實作整個 schema registry，只需完成一個垂直切片：

1. create `math` object；
2. write object/revision/event records；
3. compute content/revision address；
4. place object on canvas；
5. move without changing math revision；
6. create relation object；
7. create one custom glyph object；
8. bind glyph semantic candidate → explicit operator relation；
9. execute math operator；
10. create result object + provenance；
11. export bundle；
12. validate with schema + hash recomputation；
13. import bundle and reproduce identities/revisions；
14. export LaTeX only as adapter projection。

成功條件：

$$
Decode(Encode(W))\equiv_{EGIR}W.
$$

並且：

$$
Move(o)
\Rightarrow
A^{content}(o)\text{ unchanged}.
$$

以及：

$$
Execute(M)
\not\Rightarrow
\text{canonical LaTeX reparse}.
$$

---

# 34. 與 TW-02 的明確接口

TW-02 接手：

- EGIR bundle 的 file/chunk/object-store layout；
- UTF-8 text carrier；
- CBOR/UTF-8X optional carrier；
- block manifests；
- physical address；
- deduplication；
- random access；
- corruption recovery；
- replication；
- migration；
- storage benchmark。

TW-02 不得重新定義 persistent identity、revision identity 或 content canonical preimage。

---

# 35. 與 TW-03 的明確接口

TW-03 接手：

- in-memory object graph；
- Canvas scene graph；
- spatial index；
- resolver service；
- agent bridge；
- candidate promotion；
- execution scheduler；
- sandbox / permission；
- semantic zoom；
- adapter pipeline；
- collaboration/branch/merge；
- diagnostics / ExplainResolution / ExplainExecution。

TW-03 不得把 runtime cache 或 screen coordinates 重新升格為 canonical identity。

---

# 36. 結論

Paper 00–05 解決了「未來 EveGlyph 應該是什麼」；TW-01 第一次回答：

> **那它到底要怎麼存成一份可以由兩個不同程式重算、驗證、交換與再次執行的資料？**

答案不是把所有東西塞進一個巨大 JSON blob，而是把 object lineage、immutable revision、intrinsic content、relations、workspace placement、typed addresses、events、math profile 與 glyph profile 分層，再由 deterministic canonicalization 將需要驗證的 state 轉成 stable bytes。

因此 EGIR v0.1 的核心可以縮成：

$$
\boxed{
\text{Object Identity}
+
\text{Immutable Revision}
+
\text{Intrinsic Content}
+
\text{Typed Relations}
+
\text{Workspace State}
+
\text{Provenance}
}
$$

配上：

$$
\boxed{
\text{Deterministic Canonicalization}
+
\text{Typed Addressing}
+
\text{Schema Validation}
}
$$

這時 Markdown、LaTeX、SVG、PDF、PNG、UTF-8X、CBOR 甚至未來新的 representation 都可以重新回到各自適合的位置：它們是 carrier、adapter 或 projection，而不是唯一 ontology。

TW-01 至此把六篇理論真正壓成第一份機器可驗證的工程契約。

下一步 TW-02 不再重新設計 object model，而只回答：

$$
\boxed{
\text{How should EGIR be stored, transported, indexed, deduplicated, and recovered?}
}
$$

---

# References

[1] EveMissLab. *Paper 00 — From Linear Documents to Addressable Symbolic Computational Spaces*. v0.1, 2026.

[2] EveMissLab. *Paper 01 — Addressable Symbolic Object Model*. v0.1, 2026.

[3] EveMissLab. *Paper 02 — Spatial Syntax and Infinite Canvas Computation*. v0.1, 2026.

[4] EveMissLab. *Paper 03 — Native Computational Mathematics Beyond LaTeX*. v0.1, 2026.

[5] EveMissLab. *Paper 04 — Generative Glyph and Symbol Compilation*. v0.1, 2026.

[6] EveMissLab. *Paper 05 — Multi-Layer Addressing for Computational Documents*. v0.1, 2026.

[7] A. Rundgren, B. Jordan, and S. Erdtman. *RFC 8785 — JSON Canonicalization Scheme (JCS)*. 2020.

[8] C. Bormann and P. Hoffman. *RFC 8949 — Concise Binary Object Representation (CBOR)*. Internet Standard, 2020.

[9] K. Davis, B. Peabody, and P. Leach. *RFC 9562 — Universally Unique IDentifiers (UUIDs)*. 2024.

[10] JSON Schema Project. *JSON Schema Draft 2020-12 Core and Validation*. Published 2022.

[11] T. Bray. *RFC 8259 — The JavaScript Object Notation (JSON) Data Interchange Format*. 2017.

[12] EveMissLab. *UTF-8X — 區域動態表示架構*. research engineering baseline, 2026.

---

# Appendix A — Core Hash Formulas

$$
P_c=
\{
canon,
kind,
intrinsic
\}.
$$

$$
A^{content}=
\text{content:sha256:}H(C(P_c)).
$$

$$
P_v=
\{
canon,
persistent\_id,
kind,
parents,
content\_address,
event\_id,
created\_at
\}.
$$

$$
A^{ver}=
\text{rev:sha256:}H(C(P_v)).
$$

$$
P_W=
\{
canon,
workspace\_id,
parents,
object\_heads,
relation\_heads,
placements,
event\_id,
created\_at
\}.
$$

$$
A^{workspaceVer}=
\text{wrev:sha256:}H(C(P_W)).
$$

---

# Appendix B — Reference Files

本白皮書的 normative-support artifacts 為：

- `TW-01_Support/schemas/eveglyph-ir.schema.json`
- `TW-01_Support/examples/minimal_workspace.egir.json`
- `TW-01_Support/conformance/tw01_vectors.json`
- `TW-01_Support/tools/validate_tw01.py`

`validate_tw01.py` 是 v0.1 的 reference validator，不代表唯一允許的 implementation。任何獨立 implementation 只要能通過相同 schema、canonicalization 與 conformance vectors，即可作為 TW-01 compatible implementation。

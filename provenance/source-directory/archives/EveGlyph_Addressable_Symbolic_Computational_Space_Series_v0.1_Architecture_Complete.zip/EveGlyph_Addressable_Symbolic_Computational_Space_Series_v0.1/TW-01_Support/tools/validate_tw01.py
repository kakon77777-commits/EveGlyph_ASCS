#!/usr/bin/env python3
from pathlib import Path
import json, hashlib, sys
from jsonschema import Draft202012Validator, FormatChecker

ROOT=Path(__file__).resolve().parents[1]
SCHEMA=ROOT/'schemas'/'eveglyph-ir.schema.json'
EXAMPLE=ROOT/'examples'/'minimal_workspace.egir.json'
VECTORS=ROOT/'conformance'/'tw01_vectors.json'

SAFE=9007199254740991

def canonicalize(obj):
    if obj is None: return 'null'
    if obj is True: return 'true'
    if obj is False: return 'false'
    if isinstance(obj,str): return json.dumps(obj,ensure_ascii=False,separators=(',',':'))
    if isinstance(obj,int):
        if abs(obj)>SAFE: raise ValueError('unsafe structural integer')
        return str(obj)
    if isinstance(obj,float): raise ValueError('floats forbidden in EGIR-CJ/0.1 hash preimages')
    if isinstance(obj,list): return '['+','.join(canonicalize(x) for x in obj)+']'
    if isinstance(obj,dict): return '{'+','.join(canonicalize(k)+':'+canonicalize(obj[k]) for k in sorted(obj))+'}'
    raise TypeError(type(obj))

def h(s): return hashlib.sha256(s.encode('utf-8')).hexdigest()

def content_addr(kind,intrinsic):
    return 'content:sha256:'+h(canonicalize({'canon':'egir-cj/0.1','kind':kind,'intrinsic':intrinsic}))

def revision_id(r):
    pre={'canon':'egir-cj/0.1','persistent_id':r['persistent_id'],'kind':r['kind'],'parents':sorted(r['parents']),'content_address':r['content_address'],'event_id':r['event_id'],'created_at':r['created_at']}
    return 'rev:sha256:'+h(canonicalize(pre))

def workspace_rev(w):
    pre={'canon':'egir-cj/0.1','workspace_id':w['workspace_id'],'parents':sorted(w['parents']),'object_heads':sorted(w['object_heads'],key=lambda x:(x['persistent_id'],x['revision'])),'relation_heads':sorted(w['relation_heads'],key=lambda x:(x['persistent_id'],x['revision'])),'placements':sorted(w['placements'],key=lambda x:(x['object_id'],x.get('region_id') or '',x['placement_id'])),'event_id':w['event_id'],'created_at':w['created_at']}
    return 'wrev:sha256:'+h(canonicalize(pre))

def main():
    schema=json.loads(SCHEMA.read_text(encoding='utf-8'))
    data=json.loads(EXAMPLE.read_text(encoding='utf-8'))
    vectors=json.loads(VECTORS.read_text(encoding='utf-8'))
    errors=sorted(Draft202012Validator(schema,format_checker=FormatChecker()).iter_errors(data),key=lambda e:list(e.path))
    if errors:
        for e in errors: print('SCHEMA FAIL',list(e.path),e.message)
        return 1
    objects={o['persistent_id']:o for o in data['object_records']}
    revisions={r['revision_id']:r for r in data['revision_records']}
    if len(objects)!=len(data['object_records']) or len(revisions)!=len(data['revision_records']):
        print('REFERENCE FAIL duplicate object/revision id'); return 2
    for o in data['object_records']:
        for branch,rid in o['heads'].items():
            if rid not in revisions:
                print('REFERENCE FAIL missing head',o['persistent_id'],branch,rid); return 2
            if revisions[rid]['persistent_id']!=o['persistent_id']:
                print('REFERENCE FAIL head lineage mismatch',o['persistent_id'],rid); return 2
    for r in data['revision_records']:
        if r['persistent_id'] not in objects:
            print('REFERENCE FAIL missing object',r['persistent_id']); return 2
        for parent in r['parents']:
            if parent not in revisions:
                print('REFERENCE FAIL missing parent',parent); return 2
        ca=content_addr(r['kind'],r['intrinsic'])
        if ca!=r['content_address']:
            print('CONTENT FAIL',r['persistent_id'],ca,r['content_address']); return 3
        rid=revision_id(r)
        if rid!=r['revision_id']:
            print('REVISION FAIL',r['persistent_id'],rid,r['revision_id']); return 4
    for ph in data['workspace']['object_heads']+data['workspace']['relation_heads']:
        if ph['persistent_id'] not in objects or ph['revision'] not in revisions:
            print('WORKSPACE REF FAIL',ph); return 5
    for place in data['workspace']['placements']:
        if place['object_id'] not in objects:
            print('PLACEMENT REF FAIL',place['object_id']); return 5
    wr=workspace_rev(data['workspace'])
    if wr!=data['workspace']['workspace_revision']:
        print('WORKSPACE FAIL',wr,data['workspace']['workspace_revision']); return 6
    c=vectors['canonicalization']
    if canonicalize(c['input'])!=c['canonical_utf8'] or h(c['canonical_utf8'])!=c['sha256']:
        print('VECTOR FAIL'); return 7
    sv=vectors['executable_semantic_vectors']
    if sv['edit']['persistent_id']!=data['revision_records'][0]['persistent_id'] or sv['edit']['original_content_address']==sv['edit']['edited_content_address']:
        print('EDIT VECTOR FAIL'); return 8
    if sv['move']['object_revision_before']!=sv['move']['object_revision_after'] or sv['move']['workspace_revision_before']==sv['move']['workspace_revision_after']:
        print('MOVE VECTOR FAIL'); return 9
    if sv['clone']['original_persistent_id']==sv['clone']['clone_persistent_id'] or sv['clone']['original_content_address']!=sv['clone']['clone_content_address']:
        print('CLONE VECTOR FAIL'); return 10
    print('PASS: schema')
    print('PASS: cross-record references')
    print('PASS: content addresses')
    print('PASS: revision ids')
    print('PASS: workspace revision')
    print('PASS: canonicalization vector')
    print('PASS: edit/move/clone semantic vectors')
    return 0

if __name__=='__main__': raise SystemExit(main())

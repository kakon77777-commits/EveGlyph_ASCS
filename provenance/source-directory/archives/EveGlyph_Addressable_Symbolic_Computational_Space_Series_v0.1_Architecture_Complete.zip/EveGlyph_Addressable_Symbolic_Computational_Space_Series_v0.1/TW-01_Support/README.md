# TW-01 Support Artifacts

This directory contains the machine-readable support package for `TW-01_EveGlyph_Symbol_IR_Specification_v0.1.md`.

## Files

- `schemas/eveglyph-ir.schema.json` — JSON Schema Draft 2020-12 structural schema.
- `examples/minimal_workspace.egir.json` — minimal validated EGIR workspace snapshot.
- `conformance/tw01_vectors.json` — canonicalization/hash and semantic conformance vectors.
- `tools/validate_tw01.py` — independent reference validator for the included example/vectors.

## Validate

```bash
python TW-01_Support/tools/validate_tw01.py
```

Expected result:

```text
PASS: schema
PASS: cross-record references
PASS: content addresses
PASS: revision ids
PASS: workspace revision
PASS: canonicalization vector
PASS: edit/move/clone semantic vectors
```

The script is a reference implementation, not the only conformant implementation. Independent implementations should reproduce the same canonical hashes and semantic invariants.

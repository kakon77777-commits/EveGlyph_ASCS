# EveGlyph Addressable Symbolic Computational Space Series v0.1

## Completed Papers

- `00_從線性文件到可定址符號計算空間_統合論文_v0.1.md`
  - Role: canonical architecture anchor for the full series.
- `01_可定址符號物件模型_身份內容語義關係版本與相等性_v0.1.md`
  - Role: formal object identity / revision / relation / equality anchor.
- `02_空間語法與無限畫布計算_從幾何配置到可驗證執行結構_v0.1.md`
  - Role: spatial authority / infinite-canvas grammar / executable spatial compilation anchor.
- `03_原生可計算數學_超越LaTeX字串的語義物件執行與投影模型_v0.1.md`
  - Role: native mathematical object / binding / assumptions / exactness / execution / projection anchor.
- `04_生成式字形與符號編譯_從像素來源到可定址幾何拓撲部件語法與語義符號_v0.1.md`
  - Role: visual-symbol compilation / glyph identity / geometry-topology-part grammar / semantic binding anchor.
- `05_多層定址的可計算文件_身份內容語義空間物理版本解析與跨工作區參照_v0.1.md`
  - Role: typed multi-layer addressing / resolution / alias / migration / cross-workspace reference anchor.

## Core Paper Set Status

- Paper 00–05: COMPLETE for v0.1 theory freeze.
- TW-01: COMPLETE for v0.1 Symbol IR specification freeze.
- TW-02: COMPLETE for v0.1 compatibility / storage architecture freeze.
- TW-03: COMPLETE for v0.1 computational-canvas runtime architecture freeze.
- Paper 00–05 + TW-01–TW-03 now form the complete v0.1 architecture/specification anchor before MVP-01.

## Completed Technical Whitepapers

- `TW-01_EveGlyph_Symbol_IR_Specification_v0.1.md`
  - Role: normative machine-facing Symbol IR contract; freezes portable JSON carrier, canonicalization, object/revision/event/address/placement records, Native Math/Glyph profiles, machine-readable schema and conformance vectors.
- `TW-02_UTF-8_UTF-8X_Compatibility_and_Storage_Architecture_v0.1.md`
  - Role: normative physical-storage contract; freezes UTF-8 compatibility anchoring, EGStore manifests/chunks, decoded-vs-encoded hashes, codec/chunking profiles, random-access and storage metrics, durability/recovery boundaries, and the experimental placement of legacy UTF-8X below EGIR semantics.
- `TW-03_EveGlyph_Computational_Canvas_Runtime_Architecture_v0.1.md`
  - Role: normative live-runtime contract; freezes canonical/session/cache/effect separation, version-pinned transactions, spatial candidate promotion, native execution, capability enforcement, agent/protocol adapters, recovery, diagnostics, and the deterministic runtime conformance harness.

## Planned Technical Whitepapers

- None for ASCS v0.1 before MVP-01.

## Planned Implementation

- MVP-01 — EveGlyph Computational Canvas v0.1

## Series Freeze Rules

Paper 00 remains the global architecture anchor. Papers 01–05 add progressively lower-level semantic freezes. Later documents may refine implementation details but must not silently violate these invariants.

### Paper 00 invariants

1. canonical object is distinct from projection;
2. UTF-8 compatibility is preserved;
3. native math is not canonically stored as LaTeX source;
4. spatial position and semantic relation are distinct layers;
5. identity/content/semantic/spatial/physical/version addressing are separable;
6. deterministic decode and validation are not delegated to generative AI;
7. legacy formats remain first-class adapters rather than being discarded.

### Paper 01 invariants

1. persistent object is distinct from revision;
2. persistent identity is distinct from content hash;
3. intrinsic state is distinct from workspace placement;
4. content/revision addressing uses versioned deterministic canonicalization;
5. semantic address is not required to be unique or scalar;
6. authoritative relations are addressable/versioned/provenanced first-class structures;
7. explicit relations remain distinct from derived relation candidates;
8. revision histories may form DAGs with branch and merge;
9. clone may preserve content while creating a new identity;
10. fork/derive preserve lineage explicitly;
11. projection equality does not imply semantic or identity equality;
12. tombstoned persistent identities are never reused.

### Paper 02 invariants

1. infinite canvas is logically unbounded but finitely materialized;
2. intrinsic geometry and extrinsic placement remain distinct;
3. world/region/local/view coordinate frames remain separable;
4. pan/zoom is a view transformation, not a canonical object move;
5. transient placement, derived candidates, and explicit relations have distinct authority;
6. spatial parsing is versioned and reproducible;
7. ambiguity/unresolved spatial parses may remain explicit states;
8. regions may define local grammars and local levels of formality;
9. visual containment/grouping and semantic scope are non-equivalent by default;
10. layout graph and execution graph remain distinct;
11. spatial execution passes through parse/validate/commit/compile boundaries;
12. threshold-derived relations require a deterministic stability policy;
13. canonical spatial representation does not depend directly on viewport floating-point state;
14. spatial indexes are accelerators, not ontology;
15. AI-inferred spatial relations remain candidates unless explicitly authorized;
16. semantic zoom changes projection, not persistent identity;
17. nested canvases use composable local frames/policies;
18. uncommitted or unvalidated spatial candidates cannot directly execute.

### Paper 03 invariants

1. native mathematical objects remain distinct from any single notation, renderer, or serialization;
2. LaTeX is preserved as a first-class adapter/projection rather than used as the unique native-math ontology;
3. semantic expression structure, binding, type/domain, assumptions, constraints, units, numeric state, presentation, execution, and provenance remain separable;
4. bound-variable identity remains distinct from visible variable names;
5. alpha-equivalence is a distinct equality class;
6. assumptions and side conditions cannot be silently discarded by rewrite/evaluation;
7. exact and approximate numerical states remain distinct;
8. approximate results retain precision/error/rounding provenance or equivalent metadata;
9. units and dimensions are semantic structures rather than display suffixes only;
10. undefined, conditional, unresolved, and unevaluated states remain distinguishable;
11. surface, structural, alpha, formal/proof, and approximate equality are non-interchangeable;
12. canonical serialization is distinct from theorem-driven simplification;
13. computation results retain provenance and do not overwrite source identity by default;
14. proof evidence and computation evidence remain distinguishable;
15. ambiguous import/spatial/AI interpretations may remain unresolved;
16. spatial mathematical layout is an editing syntax, not the final mathematical ontology;
17. MathML, OpenMath, LaTeX, and OMDoc remain interoperability layers;
18. subexpression addressing is revision-aware rather than character-offset-only;
19. AI mathematical interpretation is candidate structure unless authorized/validated;
20. native-math execution must be able to operate directly on NCM objects without a canonical LaTeX reparse step.

### Paper 04 invariants

1. source artifact, normalized target, symbolic carry, structural lift, part grammar, and semantic symbol remain distinct compilation levels;
2. exact reconstruction claims are scoped to a declared domain/profile;
3. source-blind rendering is a testable dependency contract;
4. source artifacts and compiled glyphs are distinct persistent identities by default and are connected by provenance;
5. intrinsic geometry, topology, part structure, semantics, rendering, and behavior remain separable;
6. canvas placement is extrinsic to glyph geometry;
7. skeleton/medial approximations retain algorithm/version/provenance and cannot silently become exact topology claims;
8. structural part-role candidates remain distinct from committed semantic roles;
9. glyph existence does not depend on Unicode assignment;
10. character, glyph, and semantic-symbol identity remain distinct and may map many-to-many;
11. pixel, geometric, topological, part-structural, and semantic equality are non-interchangeable;
12. renderers are projections rather than canonical identity authorities;
13. AI/recognizer semantic outputs remain candidates unless explicitly authorized/validated;
14. visual import does not automatically grant executable behavior;
15. compiler/normalizer/profile lineage remains versioned and recoverable;
16. composite symbols may retain referenced child structure instead of mandatory flattening;
17. compression ratio is not treated as a complete measure of abstraction quality;
18. unresolved semantic glyphs are valid canonical states;
19. custom glyphs may bind to Paper 03 native operators without becoming identical to those operators;
20. the MVP must demonstrate at least one visual-to-addressable-to-semantic-to-execution glyph path.


### Paper 05 invariants

1. persistent/content/semantic/spatial/physical/version addresses remain separable typed concepts;
2. persistent identity remains independent of physical or spatial locators and content hashes;
3. content addresses include algorithm and canonicalization qualification;
4. semantic resolution may validly return zero, one, or many candidates;
5. semantic similarity does not establish persistent identity equality;
6. canonical spatial addresses remain workspace/snapshot/frame aware;
7. physical addresses may migrate and may have multiple replicas;
8. immutable version addresses cannot be rebound to different revision states;
9. mutable aliases such as `latest`, `main`, or human labels disclose mutability;
10. aliases remain distinct from persistent identity;
11. resolution and dereferencing remain distinct operations;
12. unresolved/tombstoned/unavailable/unauthorized/invalid/stale results remain distinguishable;
13. relative references require an explicit or recoverable base context;
14. subobject addresses are revision-aware unless a child has its own persistent identity;
15. cross-workspace import clones create new identity plus provenance by default;
16. cross-workspace identity federation requires an explicit namespace/federation contract;
17. address migrations preserve provenance and fidelity metadata;
18. tombstoned identities are never reused;
19. mutable resolution caches require freshness/revalidation policy;
20. offline/network failure is not treated as identifier invalidity;
21. successful resolution does not grant read/write/execute capability;
22. AI-assisted reconciliation remains candidate-level until authoritative commit;
23. resolver namespace/policy/model versions remain traceable;
24. the MVP must demonstrate both identity continuity across content/location/version changes and distinct identities sharing the same content or semantics.

### TW-01 invariants

1. EGIR abstract model remains distinct from JSON/CBOR/UTF-8X carriers;
2. UTF-8 JSON is the mandatory portable v0.1 carrier;
3. JSON Schema Draft 2020-12 is the v0.1 structural schema dialect;
4. new persistent IDs SHOULD use lowercase RFC 9562 UUIDv7 URNs;
5. persistent object and immutable revision remain separate;
6. content address and revision address remain separate;
7. SHA-256 is mandatory in v0.1;
8. hash preimages use EGIR-CJ/0.1 deterministic canonicalization;
9. arbitrary/exact numerics are lowered to typed safe JSON values instead of relying on binary float serialization;
10. canonicalization is not theorem simplification;
11. canonicalization preserves Unicode scalar sequences without automatic NFC/NFKC rewriting;
12. relations are first-class persistent/versioned objects;
13. candidate records have no explicit authority before promotion;
14. placement is workspace extrinsic state; pure move does not create object revision;
15. workspace snapshots have immutable workspace revision IDs;
16. identity/content/semantic/spatial/physical/version references are typed tagged unions;
17. mutable aliases are not immutable citations;
18. Native Math uses the `ncm/0.1` profile and supports direct execution;
19. Glyph uses the `glyph/0.1` profile and keeps geometry separate from placement;
20. import/export adapters report fidelity and provenance;
21. executable bindings do not gain permission on import;
22. structural JSON Schema validation is distinct from full semantic conformance;
23. unknown extension kinds are preserved but not auto-executed;
24. every persistent state mutation is provenance-event backed;
25. content/revision/workspace digests must be independently reproducible;
26. secrets are forbidden from canonical provenance;
27. repair is a new explicit transformation event, never a silent input rewrite;
28. TW-02 may replace physical carrier without redefining EGIR identity semantics;
29. TW-03 may replace runtime/index/renderer without redefining EGIR authority/revision/address semantics.

### TW-02 invariants

1. UTF-8 remains the standards-compatible anchor; EGStore does not define a private UTF-8 encoding form;
2. EGIR semantics remain distinct from physical store carriers;
3. EGStore manifest identity remains distinct from TW-01 workspace revision identity;
4. decoded chunk hashes remain distinct from encoded blob hashes;
5. chunk IDs are content-addressed over decoded raw bytes;
6. compression or recompression does not change TW-01 persistent/content/revision identities;
7. rechunking does not change TW-01 object/revision identities;
8. the `identity` codec remains the mandatory v0.1 fallback;
9. Brotli/Zstd/Shared Brotli reuse existing formats rather than being redefined by EveGlyph;
10. legacy UTF-8X is an optional/experimental physical-representation profile rather than the EGIR ontology;
11. AI may select an encoding plan but is not part of deterministic decode;
12. all decode dependencies are manifested, content-addressed, or explicitly versioned;
13. any random-access superiority claim reports read amplification;
14. adaptive-storage claims do not report compression ratio alone;
15. benchmark profiles report at least compression ratio, read amplification, and metadata overhead, with production work additionally expected to report write amplification, deduplication, CPU, and memory;
16. chunking profiles are storage policy rather than ontology;
17. fixed/structural/CDC profiles are versioned and deterministic;
18. storage indexes are accelerators rather than canonical truth;
19. fast checksums, cryptographic encoded-blob hashes, decoded-content hashes, and EGIR semantic validation remain distinct layers;
20. missing/corrupt chunks are never reconstructed by generative guessing;
21. replicas are verified independently;
22. physical garbage collection does not reuse or rewrite persistent object identity;
23. payload unavailability remains distinct from revision nonexistence;
24. durability classes and platform semantics are explicit rather than assuming a single POSIX filesystem model;
25. encryption-key or ciphertext rotation does not change EGIR canonical identity;
26. archive filename/path encoding is not an object-identity authority;
27. CBOR, UTF-8X, and future carriers round-trip to the same EGIR abstract state;
28. MVP-01 must demonstrate the same EGIR workspace migrating across at least two physical storage representations with object/revision identities unchanged.

### TW-03 invariants

1. Canonical State, Session Overlay, Derived Cache, and External Effects remain distinct runtime state classes;
2. UI singleton/DOM/viewport state cannot become canonical authority merely because it is live in memory;
3. derived spatial/semantic/render/execution caches remain rebuildable accelerators;
4. every canonical mutation flows through a runtime command/transaction boundary;
5. canonical writes pin a base workspace revision or equivalent precondition;
6. stale canonical writes cannot silently overwrite current state;
7. the default stale-write policy may be `Conflict`, with branch/rebase/merge as explicit alternatives;
8. branch and merge preserve Paper 01 DAG semantics;
9. resolution remains distinct from capability/permission;
10. resolver results and failures remain typed;
11. transient gestures do not create a workspace revision per pointer update;
12. spatial parsing produces candidate structure before authority promotion;
13. candidate state remains distinct from authoritative relation heads;
14. layout graph and execution graph remain distinct;
15. a pure placement move does not change the execution graph;
16. the execution compiler consumes only committed/validated dependencies;
17. Native Math executes NCM objects directly rather than requiring a canonical LaTeX parse-back path;
18. computed results create a distinct result identity plus provenance by default;
19. computed and proved evidence remain distinct;
20. glyph rendering/image bytes do not grant execution authority;
21. imported executable behavior is disabled until explicitly authorized;
22. operator/backend selection is recorded in execution provenance;
23. deterministic, seeded, observed-nondeterministic, and external-effecting execution classes remain distinct;
24. successful address resolution does not grant `runtime.execute`;
25. AI agent output is proposal/candidate by default;
26. direct agent mode cannot bypass validator, capability, or base-revision checks;
27. the current filesystem/git-diff agent path is a compatibility adapter rather than the final canonical-state authority;
28. MCP/CLI/HTTP/UI are transport adapters rather than ontology or transaction authority;
29. the runtime core is not coupled to an external protocol session lifecycle;
30. crash recovery may discard/rebuild derived caches but cannot rewrite canonical hashes;
31. secrets remain outside portable canonical provenance;
32. MVP-01 must pass TW-01, TW-02, and TW-03 validation layers and reproduce the reference transaction semantics.


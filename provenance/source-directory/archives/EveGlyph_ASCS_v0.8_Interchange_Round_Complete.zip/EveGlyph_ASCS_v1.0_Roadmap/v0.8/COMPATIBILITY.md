# v0.8 Compatibility

## Result

`v0.7 -> v0.8` requires **no mandatory canonical migration**.

## Preserved

- `egir/0.1` and `egir-cj/0.1`
- `egstore/0.1`
- `egcr/0.1`
- `ncm/0.1` and `ncm/1.0-candidate.1`
- `glyph/0.1` and `glyph/1.0-candidate.1` family
- v0.3 history/merge semantics
- v0.4 spatial semantics
- v0.7 Agentic Workspace authority semantics

## Additive change

v0.8 adds interchange profiles. Existing objects do not need to be rewritten. New adapter/reference records are created only when import/export/resolve operations occur.

## Identity rule

Legacy adapters allocate new local identities by default. Only verified canonical carrier decoders may preserve existing local identities.

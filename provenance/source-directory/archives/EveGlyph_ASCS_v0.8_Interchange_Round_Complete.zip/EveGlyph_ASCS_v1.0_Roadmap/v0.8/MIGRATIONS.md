# v0.8 Migrations

There is no mandatory migration from v0.7.

Optional enrichment operations:

1. Attach adapter provenance to newly imported legacy artifacts.
2. Create typed external-reference records for existing plain URL/DOI/DID/SWHID strings.
3. Re-export older static projections with a v0.8 fidelity report.
4. Wrap existing legacy UTF-8X/CBOR transport support in an explicit carrier adapter profile.

Optional enrichment MUST create new records/revisions/events as appropriate. It MUST NOT reinterpret prior hashes in place.

# VERSION

- ASCS release: `v0.8`
- Freeze: Interchange & Legacy Adapter
- Date: `2026-08-25`
- New profiles: `adapter-profile/1.0-candidate.1`, `adapter-result/1.0-candidate.1`, `fidelity-report/1.0-candidate.1`, `external-reference/1.0-candidate.1`, `roundtrip-report/1.0-candidate.1`
- Previous canonical freezes remain unchanged.

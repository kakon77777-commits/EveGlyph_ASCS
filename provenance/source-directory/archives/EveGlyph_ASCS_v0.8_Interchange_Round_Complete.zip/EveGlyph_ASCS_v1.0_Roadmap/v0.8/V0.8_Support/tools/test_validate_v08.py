import copy
import json
import sys
import unittest
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
ROOT = TOOLS.parent
sys.path.insert(0, str(TOOLS))

import validate_v08  # noqa: E402


class InterchangeValidatorTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.examples = ROOT / "examples"
        cls.schemas = ROOT / "schemas"

    def load(self, name):
        return json.loads((self.examples / name).read_text(encoding="utf-8"))

    def test_valid_markdown_import_passes(self):
        obj = self.load("markdown_import_result.json")
        self.assertEqual(validate_v08.validate_adapter_result(obj, self.schemas), [])

    def test_legacy_import_cannot_claim_canonical_authority(self):
        obj = self.load("markdown_import_result.json")
        obj["authority_mode"] = "preserve-canonical"
        errors = validate_v08.validate_adapter_result(obj, self.schemas)
        self.assertTrue(any("legacy" in e.lower() and "authority" in e.lower() for e in errors), errors)

    def test_byte_exact_requires_exact_lexical_fidelity(self):
        obj = self.load("egir_json_carrier_result.json")
        obj["fidelity"]["dimensions"]["lexical"] = "equivalent"
        errors = validate_v08.validate_adapter_result(obj, self.schemas)
        self.assertTrue(any("byte-exact" in e.lower() for e in errors), errors)

    def test_external_resolution_does_not_grant_local_identity(self):
        obj = self.load("external_reference_doi.json")
        obj["binding"]["mode"] = "federated-binding"
        obj["binding"]["authority"] = "candidate"
        errors = validate_v08.validate_external_reference(obj, self.schemas)
        self.assertTrue(any("federated" in e.lower() and "explicit" in e.lower() for e in errors), errors)

    def test_source_hash_mismatch_is_rejected(self):
        obj = self.load("latex_import_result.json")
        obj["source"]["sha256"] = "0" * 64
        errors = validate_v08.validate_adapter_result(obj, self.schemas)
        self.assertTrue(any("source sha256" in e.lower() for e in errors), errors)


if __name__ == "__main__":
    unittest.main(verbosity=2)

from __future__ import annotations
import argparse, hashlib, json, re, sys, warnings
warnings.filterwarnings("ignore", category=DeprecationWarning)
from pathlib import Path
from jsonschema import Draft202012Validator, RefResolver

ROOT = Path(__file__).resolve().parent.parent
SCHEMAS = ROOT / 'schemas'
EXAMPLES = ROOT / 'examples'
CONFORMANCE = ROOT / 'conformance' / 'interchange_conformance_vectors.json'


def load(path: Path):
    return json.loads(path.read_text(encoding='utf-8'))


def schema_errors(obj, schema_path: Path):
    schema = load(schema_path)
    store = {load(p).get('$id'): load(p) for p in SCHEMAS.glob('*.json')}
    resolver = RefResolver.from_schema(schema, store=store)
    validator = Draft202012Validator(schema, resolver=resolver)
    return [f"schema {'.'.join(map(str,e.path)) or '<root>'}: {e.message}" for e in validator.iter_errors(obj)]


def fidelity_semantic_errors(fid):
    errors=[]
    rt=fid['round_trip_class']; d=fid['dimensions']
    if rt=='byte-exact' and d['lexical']!='exact':
        errors.append('byte-exact round trip requires lexical fidelity exact')
    if rt=='canonical-state' and (d['structural']!='exact' or d['semantic']!='exact'):
        errors.append('canonical-state round trip requires structural and semantic fidelity exact')
    if rt=='semantic-equivalent' and d['semantic'] not in ('exact','equivalent'):
        errors.append('semantic-equivalent round trip requires semantic fidelity exact or equivalent')
    if rt=='presentation-equivalent' and d['visual'] not in ('exact','equivalent'):
        errors.append('presentation-equivalent round trip requires visual fidelity exact or equivalent')
    return errors


def validate_adapter_result(obj, schemas_dir=SCHEMAS):
    schemas_dir=Path(schemas_dir)
    errors=schema_errors(obj, schemas_dir/'adapter-result.schema.json')
    if errors: return errors
    role=obj['adapter_role']; auth=obj['authority_mode']; direction=obj['direction']
    legacy_roles={'legacy-document','semantic-math','visual-asset','static-projection'}
    if role in legacy_roles and direction=='import' and auth!='candidate-only':
        errors.append('legacy import authority must remain candidate-only')
    if role=='carrier' and auth!='preserve-canonical':
        errors.append('carrier decode/encode may preserve canonical state and must declare preserve-canonical')
    if role!='carrier':
        for act in obj['identity_actions']:
            if act['action']=='preserve-existing-local':
                errors.append('legacy adapter cannot preserve existing local identity by default')
    if obj['source']['inline_text'] is not None:
        actual=hashlib.sha256(obj['source']['inline_text'].encode('utf-8')).hexdigest()
        if actual != obj['source']['sha256']:
            errors.append(f"source sha256 mismatch: expected {obj['source']['sha256']} actual {actual}")
    if not obj['provenance']['source_hash_verified']:
        errors.append('source hash must be verified before successful adapter result')
    errors.extend(fidelity_semantic_errors(obj['fidelity']))
    return errors


def validate_external_reference(obj, schemas_dir=SCHEMAS):
    schemas_dir=Path(schemas_dir)
    errors=schema_errors(obj, schemas_dir/'external-reference.schema.json')
    if errors: return errors
    b=obj['binding']
    if b['mode']=='federated-binding':
        if b['authority']!='explicit':
            errors.append('federated binding requires explicit authority')
        if b.get('capability')!='identity.bind.external':
            errors.append('federated binding requires identity.bind.external capability')
        if not b.get('binding_event'):
            errors.append('federated binding requires binding_event provenance')
    # Resolution alone never changes binding authority.
    if obj['resolution']['status']=='resolved' and b['mode']=='reference-only' and b['authority']!='candidate':
        errors.append('resolved external reference does not itself grant local identity authority')
    if obj['scheme']=='doi' and not re.match(r'^10\.\d{4,9}/\S+$', obj['value'], re.I):
        errors.append('invalid DOI-shaped value')
    if obj['scheme']=='did' and not obj['value'].startswith('did:'):
        errors.append('invalid DID-shaped value')
    if obj['scheme']=='swhid' and not re.match(r'^swh:1:(cnt|dir|rev|rel|snp):[0-9a-f]{40}(;.*)?$', obj['value']):
        errors.append('invalid SWHID v1-shaped value')
    return errors


def validate_profile(obj, schemas_dir=SCHEMAS):
    errors=schema_errors(obj, Path(schemas_dir)/'adapter-profile.schema.json')
    if errors: return errors
    if obj['role'] in {'legacy-document','semantic-math','visual-asset'} and obj['authority_mode']!='candidate-only':
        errors.append('legacy/content adapter profile must be candidate-only')
    if obj['role']=='static-projection' and obj['authority_mode']!='projection-only':
        errors.append('static projection adapter must be projection-only')
    if obj['role']=='carrier' and obj['authority_mode']!='preserve-canonical':
        errors.append('carrier adapter must declare preserve-canonical')
    return errors


def validate_roundtrip(obj, schemas_dir=SCHEMAS):
    return schema_errors(obj, Path(schemas_dir)/'roundtrip-report.schema.json')


def run_all():
    results={'schemas':{},'examples':{},'vectors':{},'errors':[]}
    for p in sorted(SCHEMAS.glob('*.json')):
        try:
            schema=load(p); Draft202012Validator.check_schema(schema); results['schemas'][p.name]='PASS'
        except Exception as e:
            results['schemas'][p.name]=f'FAIL: {e}'; results['errors'].append(f'{p.name}: {e}')
    for p in sorted(EXAMPLES.glob('*.json')):
        obj=load(p)
        if obj.get('profile')=='adapter-profile/1.0-candidate.1': errs=validate_profile(obj)
        elif obj.get('profile')=='adapter-result/1.0-candidate.1': errs=validate_adapter_result(obj)
        elif obj.get('profile')=='external-reference/1.0-candidate.1': errs=validate_external_reference(obj)
        elif obj.get('profile')=='roundtrip-report/1.0-candidate.1': errs=validate_roundtrip(obj)
        else: errs=[f'unknown example profile {obj.get("profile")}']
        results['examples'][p.name]='PASS' if not errs else 'FAIL: '+'; '.join(errs)
        results['errors'].extend(f'{p.name}: {e}' for e in errs)
    vec=load(CONFORMANCE)
    ve=schema_errors(vec, SCHEMAS/'interchange-vectors.schema.json')
    ids=[x['id'] for x in vec.get('vectors',[])]
    if len(ids)!=len(set(ids)): ve.append('conformance vector IDs must be unique')
    results['vectors']={'count':len(ids),'unique':len(ids)==len(set(ids)),'status':'PASS' if not ve else 'FAIL'}
    results['errors'].extend(ve)
    return results


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--json', action='store_true'); args=ap.parse_args()
    res=run_all()
    if args.json: print(json.dumps(res,ensure_ascii=False,indent=2))
    else:
        print(f"schemas: {sum(v=='PASS' for v in res['schemas'].values())}/{len(res['schemas'])}")
        print(f"examples: {sum(v=='PASS' for v in res['examples'].values())}/{len(res['examples'])}")
        print(f"vectors: {res['vectors']['count']}, unique={res['vectors']['unique']}")
        if res['errors']:
            print('ERRORS:'); [print(' -',e) for e in res['errors']]
        else: print('PASS')
    return 1 if res['errors'] else 0

if __name__=='__main__': raise SystemExit(main())

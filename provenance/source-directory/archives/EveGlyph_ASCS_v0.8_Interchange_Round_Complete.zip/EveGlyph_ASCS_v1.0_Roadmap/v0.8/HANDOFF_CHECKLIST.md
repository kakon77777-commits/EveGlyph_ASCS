# v0.8 Handoff Checklist

- [x] Legacy import authority is candidate-only.
- [x] Static export is projection-only.
- [x] Carrier preservation privilege is separated from legacy import.
- [x] Fidelity dimensions are explicit.
- [x] Round-trip classes are explicit.
- [x] Markdown baseline is version-pinned.
- [x] LaTeX unknown-macro policy is fail-safe/opaque.
- [x] MathML presentation/content distinction is preserved.
- [x] OpenMath unknown CD stays unresolved.
- [x] SVG/raster imports do not gain semantic/behavior authority.
- [x] PDF remains static-projection boundary.
- [x] Arbitrary JSON cannot masquerade as EGIR.
- [x] CBOR/UTF-8X remain physical carriers.
- [x] URI/DOI/DID/SWHID are external references, not local identity.
- [x] Federated binding requires explicit authority + capability.
- [x] Source hash and adapter version enter provenance.
- [x] AI-assisted mapping remains under v0.7 candidate/promotion rules.
- [x] v0.7 -> v0.8 has no mandatory canonical migration.

# v0.8 Validation Report

**Release:** EveGlyph ASCS v0.8 — Interchange & Legacy Adapter Freeze  
**Date:** 2026-08-25

## Machine-readable contract

Fresh final validation on the release tree:

```text
validator regression tests: 5 / 5 PASS
Draft 2020-12 schemas: 6 / 6 PASS
machine-readable examples: 23 / 23 PASS
conformance vectors: 36 / 36 PASS
vector IDs unique: PASS
```

The regression suite verifies that the validator rejects:

- legacy imports that attempt to claim canonical authority;
- `byte-exact` reports whose lexical fidelity is not exact;
- external references that attempt candidate-only federated identity binding;
- adapter results whose declared source SHA-256 does not match the inline source.

It also verifies that the canonical Markdown import example passes.

## Semantic validator checks

`validate_v08.py` additionally checks:

- legacy/document/math/visual import authority ceilings;
- carrier-only canonical identity preservation;
- source SHA-256 recomputation;
- fidelity / round-trip class consistency;
- federated binding explicit authority;
- `identity.bind.external` capability requirement;
- federated binding provenance event requirement;
- DOI / DID / SWHID basic syntax shape;
- conformance vector ID uniqueness.

## Source gate

Fresh source scan after removing Python bytecode caches:

```text
canonical source files checked: 42
JSON files parsed: 30
Python source files parsed by AST: 2
Markdown files checked: 10
UTF-8 strict decode: PASS
LF-only: PASS
control-character scan: PASS
canonical math delimiter policy: PASS
math delimiter balance: PASS
```

Canonical Markdown source uses only dollar-sign inline/display delimiters for math.

## Compatibility gate

No existing canonical profile or hash preimage is redefined by v0.8.

```text
v0.7 -> v0.8 mandatory canonical migration: NONE
legacy import default authority: candidate-only
static projection authority: projection-only
verified carrier authority: preserve-canonical
external resolution -> local identity binding: NOT IMPLICIT
```

## Release hygiene

Python-generated `__pycache__` bytecode is excluded from the release source tree and package.

The release folder includes `SHA256SUMS.txt`; package validation additionally checks ZIP integrity and extracted SHA-256 verification.

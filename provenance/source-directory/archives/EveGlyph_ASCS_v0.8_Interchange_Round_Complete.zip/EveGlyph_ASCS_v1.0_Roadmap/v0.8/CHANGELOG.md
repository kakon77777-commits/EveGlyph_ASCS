# v0.8 Changelog

## Added

- Versioned interchange adapter profile
- Adapter result + multi-dimensional fidelity report
- Seven round-trip classes
- External URI/DOI/DID/SWHID reference profile
- Explicit federated binding authority requirements
- Format Adapter Matrix
- External Reference Matrix
- 6 JSON Schemas
- 23 machine-readable examples
- 36 conformance vectors
- Reference validator and regression tests

## Changed

No prior canonical ontology or hash preimage changed.

## Deprecated

Implicit assumptions that a legacy file format, URL, DOI, DID, SVG ID, font ID, or PDF object number is equivalent to an EveGlyph persistent identity.

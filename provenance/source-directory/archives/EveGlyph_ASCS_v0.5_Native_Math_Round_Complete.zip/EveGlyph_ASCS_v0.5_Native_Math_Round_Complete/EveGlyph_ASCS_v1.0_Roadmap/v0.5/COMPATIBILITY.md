# v0.5 Compatibility

## Compatibility class

`v0.4 -> v0.5 = Backward + ForwardPreserve for workspaces that do not require the new Native Math candidate profile`

Existing `ncm/0.1` objects remain valid and retain their original semantics.

## No silent reinterpretation

- Existing persistent IDs are unchanged.
- Existing revision/content/workspace hashes are unchanged.
- Existing `ncm/0.1` bytes are interpreted only according to `ncm/0.1`.
- `ncm/1.0-candidate.1` is a new namespaced profile.
- Existing EGIR/EGStore/EGCR/history/spatial profiles are unchanged.
- No change to `egir-cj/0.1` or existing hash preimages.

## Mixed-profile workspace

A workspace MAY contain both:

```text
ncm/0.1
ncm/1.0-candidate.1
```

A runtime MUST negotiate/profile-dispatch rather than reinterpret the older profile.

## Optional enrichment migration

A compatible `ncm/0.1` object MAY be explicitly migrated to `ncm/1.0-candidate.1`. Migration MUST create a new revision on the same persistent object lineage, preserve migration provenance, and recompute content/revision addresses.

# v0.5 Migrations

## Mandatory migration

None.

$$
\boxed{v0.4\rightarrow v0.5\text{ requires no mandatory canonical migration}}
$$

## Optional Native Math enrichment

Legacy `ncm/0.1` math objects MAY be upgraded through an explicit transformation:

$$
ncm/0.1\xrightarrow{Migrate}ncm/1.0-candidate.1.
$$

The migration MUST:

1. preserve persistent object identity;
2. create a new immutable revision;
3. preserve or explicitly classify adapter/migration fidelity;
4. materialize free/bound declaration semantics when determinable;
5. preserve assumptions/constraints if known;
6. mark unknown type/domain/evidence fields as unknown rather than inventing facts;
7. record a migration event and source revision;
8. recompute content and revision addresses.

Because intrinsic representation changes, identical content hashes before/after migration are NOT expected.

## Future candidate change

Any breaking change to binding semantics, node meaning, numeric canonical forms, evidence-class meaning, equality-class meaning, or adapter-fidelity meaning MUST publish a new candidate profile identifier such as `ncm/1.0-candidate.2` and provide explicit migration.

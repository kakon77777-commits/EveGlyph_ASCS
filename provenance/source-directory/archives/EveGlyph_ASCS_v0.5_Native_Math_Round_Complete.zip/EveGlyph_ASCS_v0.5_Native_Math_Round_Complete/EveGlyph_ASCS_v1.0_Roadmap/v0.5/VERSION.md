# Version

```text
ASCS = ascs/0.5
NativeMathObject = ncm/1.0-candidate.1
MathTransform = org.evemisslab.math-transform/0.1
MathEquality = org.evemisslab.math-equality/0.1
MathAdapterFidelity = org.evemisslab.math-adapter-fidelity/0.1
MathConformanceVectors = org.evemisslab.math-conformance-vectors/0.1
```

Existing identifiers remain unchanged, including:

```text
egir/0.1
egstore/0.1
egcr/0.1
ncm/0.1
glyph/0.1
egir-cj/0.1
org.evemisslab.history/0.1
org.evemisslab.spatial-region/0.1
org.evemisslab.spatial-grammar/0.1
org.evemisslab.spatial-policy/0.1
org.evemisslab.semantic-zoom/0.1
```

`ncm/1.0-candidate.1` is a new profile identifier. It does not redefine `ncm/0.1`.

# v0.5 Validation Report

**Release:** EveGlyph ASCS v0.5 Native Math Object v1 Candidate  
**Date:** 2026-08-25

## Source validation

- UTF-8 strict decode: PASS
- LF-only newlines: PASS
- Forbidden control-character scan: PASS
- Canonical math delimiters restricted to `$...$` / `$$...$$`: PASS
- Math delimiter balance outside fenced code: PASS
- Release-source scan excludes generated Python bytecode/cache artifacts: PASS

## Machine-readable validation

- `native-math-object-v1-candidate.schema.json`: Draft 2020-12 validator PASS
- `native_math_integral_example.json`: 0 schema errors
- Reference semantic graph validator: PASS
  - unique node IDs: PASS
  - lexical canonical node order: PASS
  - graph references: PASS
  - graph reachability: PASS
  - expression-cycle check: PASS
  - binder scope / bound-ref check: PASS
  - rational canonicality check: PASS
  - evidence / condition reference checks: PASS
- `math-transform-evidence.schema.json`: Draft 2020-12 validator PASS
- `math_transform_example.json`: 0 schema errors
- `math_equality_example.json`: 0 schema errors
- `math_adapter_fidelity_example.json`: 0 schema errors
- `math-conformance-vectors.schema.json`: Draft 2020-12 validator PASS
- `native_math_conformance_vectors.json`: 0 schema errors
- Conformance vector count: 30
- Unique vector IDs: 30/30
- `validate_v05.py --json`: PASS

## Main specification size

- UTF-8 bytes: 32,848
- Lines: 1,762
- Characters: 27,944

## Compatibility gate

PASS:

- `egir/0.1` unchanged
- `egstore/0.1` unchanged
- `egcr/0.1` unchanged
- `ncm/0.1` unchanged and remains loadable under its original semantics
- `glyph/0.1` unchanged
- `egir-cj/0.1` unchanged
- v0.3 history profiles unchanged
- v0.4 spatial profiles unchanged
- Existing content/revision/workspace hash preimages unchanged
- `ncm/1.0-candidate.1` introduced as a new profile identifier
- Mixed `ncm/0.1` + `ncm/1.0-candidate.1` workspaces explicitly permitted
- No mandatory canonical migration from v0.4 to v0.5

## External standards cross-check

Current public standards/status were checked on 2026-08-25:

- W3C MathML 4 latest published Working Draft: 2026-06-04.
- W3C MathML Core: Candidate Standard dated 2025-06-24.
- OpenMath official normative standard: Version 2.0 Revision 2.
- OMDoc stable format: OMDoc 1.2; used only as statement/theory/proof interoperability reference.
- SMT-LIB current referenced standard: Version 2.7, release 2025-02-05.

These standards are adapter/back-end references. None is promoted to EveGlyph persistent identity/history/runtime ontology.

## Design checks

PASS:

- Small structural kernel is separated from domain operator registry.
- Free declaration identity and bound-variable binding slots are separated from display names.
- Alpha-equivalence is explicitly defined.
- Exact and approximate numerics are semantically distinct.
- Rational canonicality and exact-decimal representation are frozen.
- Assumptions and constraints are distinct.
- Undefined / conditional / unresolved / unevaluated are distinct result states.
- Units/dimensions are semantic records.
- Evidence classes separate computed / verified / proved / heuristic.
- `proved` requires proof/certificate/verifier evidence.
- Equality verdicts require an equality class.
- Canonicalization remains separate from mathematical simplification.
- Rewrite provenance includes rule, conditions, backend/evidence, and node mapping.
- Subexpression addresses are revision-aware.
- Adapter fidelity is multidimensional.
- Candidate parser/AI/CAS interpretations do not gain authority automatically.
- Legacy `ncm/0.1` is not silently reinterpreted.

## Release conclusion

v0.5 is suitable as the first freeze of the second v1.0 roadmap stage:

$$
\text{v0.5}=\text{Native Math Object v1 Candidate}.
$$

Next: v0.6 Glyph / Symbol Object v1 Candidate.

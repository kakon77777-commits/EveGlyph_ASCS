from __future__ import annotations

import argparse
import json
import math
import re
import sys
from pathlib import Path

try:
    import jsonschema
except ImportError:  # pragma: no cover
    jsonschema = None

ROOT = Path(__file__).resolve().parents[2]
SCHEMAS = ROOT / "V0.5_Support" / "schemas"
EXAMPLES = ROOT / "V0.5_Support" / "examples"
CONFORMANCE = ROOT / "V0.5_Support" / "conformance"

INT_RE = re.compile(r"^-?(0|[1-9][0-9]*)$")


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def schema_validate(instance, schema_path: Path) -> list[str]:
    if jsonschema is None:
        return ["jsonschema package is not installed"]
    schema = load_json(schema_path)
    validator = jsonschema.Draft202012Validator(schema)
    return [f"{list(err.path)}: {err.message}" for err in sorted(validator.iter_errors(instance), key=lambda e: list(e.path))]


def node_refs(node: dict) -> list[str]:
    k = node["kind"]
    if k == "apply":
        return list(node["args"])
    if k == "binder":
        refs = [node["body"]]
        limits = node.get("limits") or {}
        if "lower" in limits:
            refs.append(limits["lower"])
        if "upper" in limits:
            refs.append(limits["upper"])
        for b in node["bindings"]:
            domain = b.get("domain")
            if isinstance(domain, dict) and set(domain) == {"node"}:
                refs.append(domain["node"])
        return refs
    if k == "sequence":
        return list(node["items"])
    if k == "matrix":
        return [x for row in node["cells"] for x in row]
    if k == "piecewise":
        refs = []
        for case in node["cases"]:
            refs.extend([case["condition"], case["value"]])
        if node["otherwise"] is not None:
            refs.append(node["otherwise"])
        return refs
    if k == "quantity":
        return [node["value"]]
    return []


def validate_math_semantics(obj: dict) -> list[str]:
    errors: list[str] = []
    expr = obj["expression"]
    nodes = expr["nodes"]
    ids = [n["id"] for n in nodes]
    if len(ids) != len(set(ids)):
        errors.append("expression node IDs must be unique")
    if ids != sorted(ids):
        errors.append("expression.nodes must be sorted lexically by id")
    by_id = {n["id"]: n for n in nodes}
    if expr["root"] not in by_id:
        errors.append("expression root does not exist")

    for n in nodes:
        for ref in node_refs(n):
            if ref not in by_id:
                errors.append(f"node {n['id']} references missing node {ref}")
        if n["kind"] == "rational":
            p, q = int(n["numerator"]), int(n["denominator"])
            if q <= 0:
                errors.append(f"rational {n['id']} denominator must be positive")
            elif p == 0 and q != 1:
                errors.append(f"rational {n['id']} zero must have denominator 1")
            elif math.gcd(abs(p), q) != 1:
                errors.append(f"rational {n['id']} is not reduced")

    decls = obj["environment"]["declarations"]
    decl_ids = [d["declaration_id"] for d in decls]
    if len(decl_ids) != len(set(decl_ids)):
        errors.append("declaration IDs must be unique")
    if decl_ids != sorted(decl_ids):
        errors.append("environment.declarations must be sorted lexically")
    decl_set = set(decl_ids)
    for n in nodes:
        if n["kind"] == "free-ref" and n["declaration_id"] not in decl_set:
            errors.append(f"free-ref {n['id']} has unknown declaration {n['declaration_id']}")

    # Scope-aware traversal from root. Limits and binding-domain node refs are outside the new binding scope;
    # body is inside it. Reaching a bound-ref without its binding is invalid.
    reachable: set[str] = set()
    visiting: set[tuple[str, tuple[str, ...]]] = set()
    done: set[tuple[str, tuple[str, ...]]] = set()

    def walk(node_id: str, active: tuple[str, ...]):
        key = (node_id, active)
        if key in done:
            return
        if key in visiting:
            errors.append(f"expression cycle detected at {node_id}")
            return
        if node_id not in by_id:
            return
        visiting.add(key)
        reachable.add(node_id)
        n = by_id[node_id]
        k = n["kind"]
        if k == "bound-ref":
            if n["binding_id"] not in active:
                errors.append(f"bound-ref {node_id} is outside binding scope {n['binding_id']}")
        elif k == "binder":
            limits = n.get("limits") or {}
            if "lower" in limits:
                walk(limits["lower"], active)
            if "upper" in limits:
                walk(limits["upper"], active)
            for b in n["bindings"]:
                domain = b.get("domain")
                if isinstance(domain, dict) and set(domain) == {"node"}:
                    walk(domain["node"], active)
            new_bindings = tuple(b["binding_id"] for b in n["bindings"])
            if len(new_bindings) != len(set(new_bindings)):
                errors.append(f"binder {node_id} has duplicate binding IDs")
            walk(n["body"], active + new_bindings)
        else:
            for ref in node_refs(n):
                walk(ref, active)
        visiting.remove(key)
        done.add(key)

    if expr["root"] in by_id:
        walk(expr["root"], tuple())
    unreachable = sorted(set(ids) - reachable)
    if unreachable:
        errors.append(f"unreachable canonical nodes: {unreachable}")

    assumption_ids = [a["assumption_id"] for a in obj["assumptions"]]
    constraint_ids = [c["constraint_id"] for c in obj["constraints"]]
    evidence_ids = [e["evidence_id"] for e in obj["evidence"]]
    for label, vals in [("assumption", assumption_ids), ("constraint", constraint_ids), ("evidence", evidence_ids)]:
        if len(vals) != len(set(vals)):
            errors.append(f"{label} IDs must be unique")
        if vals != sorted(vals):
            errors.append(f"{label} records must be sorted lexically")

    ev_set = set(evidence_ids)
    for a in obj["assumptions"]:
        if a["expression_root"] not in by_id:
            errors.append(f"assumption {a['assumption_id']} root missing")
    for c in obj["constraints"]:
        if c["expression_root"] not in by_id:
            errors.append(f"constraint {c['constraint_id']} root missing")
        if c["status"] == "discharged" and c["evidence_ref"] not in ev_set:
            errors.append(f"discharged constraint {c['constraint_id']} requires evidence_ref")
    for e in obj["evidence"]:
        if e["class"] == "proved" and e["certificate_ref"] is None:
            errors.append(f"proved evidence {e['evidence_id']} requires certificate_ref")
        for cond in e["conditions"]:
            if cond not in by_id:
                errors.append(f"evidence {e['evidence_id']} condition node missing: {cond}")
    for t in obj["type_assertions"]:
        if t["node"] not in by_id:
            errors.append(f"type assertion references missing node {t['node']}")
        if t["status"] == "verified" and t["evidence_ref"] not in ev_set:
            errors.append(f"verified type assertion on {t['node']} requires evidence_ref")
    for u in obj["unit_assertions"]:
        if u["node"] not in by_id:
            errors.append(f"unit assertion references missing node {u['node']}")
        if u["status"] == "verified" and u["evidence_ref"] not in ev_set:
            errors.append(f"verified unit assertion on {u['node']} requires evidence_ref")
    rs = obj["result_state"]
    if rs["value_root"] is not None and rs["value_root"] not in by_id:
        errors.append("result_state.value_root references missing node")
    for c in rs["condition_roots"]:
        if c not in by_id:
            errors.append(f"result_state condition node missing: {c}")

    return errors


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    example_path = EXAMPLES / "native_math_integral_example.json"
    vector_path = CONFORMANCE / "native_math_conformance_vectors.json"
    obj = load_json(example_path)
    vectors = load_json(vector_path)

    checks = {}
    checks["object_schema_errors"] = schema_validate(obj, SCHEMAS / "native-math-object-v1-candidate.schema.json")
    checks["object_semantic_errors"] = validate_math_semantics(obj)
    checks["vector_schema_errors"] = schema_validate(vectors, SCHEMAS / "math-conformance-vectors.schema.json")
    transform_schema = SCHEMAS / "math-transform-evidence.schema.json"
    checks["transform_example_errors"] = {}
    for name in ["math_transform_example.json", "math_equality_example.json", "math_adapter_fidelity_example.json"]:
        errs = schema_validate(load_json(EXAMPLES / name), transform_schema)
        checks["transform_example_errors"][name] = errs
    ids = [v["id"] for v in vectors["vectors"]]
    checks["vector_count"] = len(ids)
    checks["unique_vector_ids"] = len(set(ids))

    ok = (
        not checks["object_schema_errors"]
        and not checks["object_semantic_errors"]
        and not checks["vector_schema_errors"]
        and all(not v for v in checks["transform_example_errors"].values())
        and checks["vector_count"] == 30
        and checks["unique_vector_ids"] == 30
    )
    checks["ok"] = ok

    if args.json:
        print(json.dumps(checks, ensure_ascii=False, indent=2))
    else:
        for k, v in checks.items():
            print(f"{k}: {v}")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())

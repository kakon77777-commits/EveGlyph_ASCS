# v0.5 Changelog

- Added `ncm/1.0-candidate.1` as the Native Math Object v1 candidate profile.
- Froze a small structural math kernel instead of operator-specific core-node proliferation.
- Froze semantic symbol references for operators, constants, units, types, and theory integration.
- Added free declaration / bound binding separation and alpha-equivalence rules.
- Added acyclic expression graph, reference, reachability, and structural canonical-order requirements.
- Added exact integer, reduced rational, exact decimal, and explicit approximate-number forms.
- Added assumptions, constraints, condition discharge, units, and dimension records.
- Added first-class defined / conditional / undefined / unresolved / unevaluated result states.
- Froze assumed / computed / verified / proved / heuristic / external evidence classes.
- Froze surface / structural / alpha / definitional / theorem / approximate equality classes.
- Added math rewrite provenance and revision-aware subexpression mapping.
- Added math-specific multidimensional adapter fidelity for LaTeX, MathML, OpenMath, OMDoc, SMT-LIB, and future adapters.
- Added three Draft 2020-12 schemas, four machine-readable examples, 30 conformance vectors, and a reference semantic validator.
- Kept `ncm/0.1` valid without reinterpretation; migration to the candidate profile is explicit and optional.
- No change to `egir-cj/0.1`; no mandatory canonical migration from v0.4 to v0.5.

# v0.6 Migrations

No mandatory canonical migration is required.

Optional enrichment:

```text
glyph/0.1@old -> glyph/1.0-candidate.1@new
```

The migration MUST preserve persistent identity, create a new revision, recompute content/revision hashes, and record source profile plus migration tool version. Semantic and executable bindings MUST be migrated as candidate/explicit relations rather than copied into glyph intrinsic authority.

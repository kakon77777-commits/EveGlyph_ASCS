# v0.6 Handoff Checklist

- [x] Glyph candidate profile named and versioned.
- [x] Character/glyph/symbol/behavior boundary frozen.
- [x] Geometry canonical scalar grammar frozen.
- [x] Path/component/exact-carry kernel defined.
- [x] Topology and skeleton authority separated.
- [x] Structural part graph and ports defined.
- [x] Family/variant profile defined.
- [x] Renderer projection authority defined.
- [x] Unicode/OpenType adapters treated as adapters.
- [x] Semantic/behavior binding authority separated.
- [x] GSC AssetSymbol v0.7 bridge defined.
- [x] GSC v1.13-generated AssetSymbol v0.7 fixture pinned by SHA-256 and exact palette/RUN comparison.
- [x] 30 conformance vectors provided.
- [x] Reference validator provided.
- [x] v0.5 compatibility statement provided.

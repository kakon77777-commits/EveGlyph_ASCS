from __future__ import annotations

import argparse
import json
import re
import hashlib
from pathlib import Path

try:
    import jsonschema
except ImportError:  # pragma: no cover
    jsonschema = None

ROOT = Path(__file__).resolve().parents[2]
SCHEMAS = ROOT / 'V0.6_Support' / 'schemas'
EXAMPLES = ROOT / 'V0.6_Support' / 'examples'
CONFORMANCE = ROOT / 'V0.6_Support' / 'conformance'

SCALAR_RE = re.compile(r'^(0|-?[1-9][0-9]*|-?(0|[1-9][0-9]*)\.[0-9]*[1-9])$')


def load_json(path: Path):
    return json.loads(path.read_text(encoding='utf-8'))


def schema_validate(instance, schema_path: Path) -> list[str]:
    if jsonschema is None:
        return ['jsonschema package is not installed']
    schema = load_json(schema_path)
    validator = jsonschema.Draft202012Validator(schema)
    return [f'{list(err.path)}: {err.message}' for err in sorted(validator.iter_errors(instance), key=lambda e: list(e.path))]


def valid_scalar(s: str) -> bool:
    return isinstance(s, str) and bool(SCALAR_RE.fullmatch(s)) and s != '-0'


def validate_path(path: dict) -> list[str]:
    errors = []
    cmds = path['commands']
    if not cmds or cmds[0]['op'] != 'M':
        errors.append(f"path {path['path_id']} must start with M")
        return errors
    closed = False
    for i, cmd in enumerate(cmds):
        op = cmd['op']
        required = {
            'M': ('x','y'), 'L': ('x','y'), 'Q': ('x1','y1','x','y'),
            'C': ('x1','y1','x2','y2','x','y'), 'Z': ()
        }[op]
        for key in required:
            if key not in cmd or not valid_scalar(cmd[key]):
                errors.append(f"path {path['path_id']} command {i} invalid scalar {key}")
        if op == 'Z':
            if i != len(cmds) - 1:
                errors.append(f"path {path['path_id']} Z must be final command")
            closed = True
        elif closed:
            errors.append(f"path {path['path_id']} has command after Z")
    return errors


def validate_component_graph(obj: dict, current_ref: tuple[str, str] | None = None) -> list[str]:
    errors = []
    ids = [c['component_id'] for c in obj['geometry']['components']]
    if len(ids) != len(set(ids)):
        errors.append('component IDs must be unique')
    if ids != sorted(ids):
        errors.append('geometry.components must be sorted lexically by component_id')
    if current_ref is not None:
        for c in obj['geometry']['components']:
            r = c['glyph_ref']
            if (r['persistent_id'], r['revision_id']) == current_ref:
                errors.append(f"component cycle detected through {c['component_id']}")
    return errors


def validate_glyph_semantics(obj: dict) -> list[str]:
    errors: list[str] = []
    # canonical scalar grammar
    for v in obj['design_space']['view_box']:
        if not valid_scalar(v):
            errors.append(f'invalid canonical scalar in view_box: {v}')

    paths = obj['geometry']['paths']
    pids = [p['path_id'] for p in paths]
    if len(pids) != len(set(pids)):
        errors.append('path IDs must be unique')
    if pids != sorted(pids):
        errors.append('geometry.paths must be sorted lexically by path_id')
    for p in paths:
        errors.extend(validate_path(p))

    errors.extend(validate_component_graph(obj))
    geometry_refs = set(pids) | {c['component_id'] for c in obj['geometry']['components']}

    carries = obj['geometry']['exact_carries']
    cids = [c['carry_id'] for c in carries]
    if len(cids) != len(set(cids)):
        errors.append('carry IDs must be unique')
    if cids != sorted(cids):
        errors.append('exact_carries must be sorted lexically by carry_id')
    for carry in carries:
        w, h = carry['canvas']['width'], carry['canvas']['height']
        expected_y = 0
        expected_x = 0
        for run in carry['runs']:
            if run['palette_index'] >= len(carry['palette']):
                errors.append(f"carry {carry['carry_id']} references invalid palette index")
                continue
            if run['y'] != expected_y or run['x'] != expected_x or run['x'] + run['length'] > w:
                errors.append(f"carry {carry['carry_id']} RUN stream is not exact sequential coverage")
                break
            expected_x += run['length']
            if expected_x == w:
                expected_x = 0
                expected_y += 1
        if expected_y != h or expected_x != 0:
            errors.append(f"carry {carry['carry_id']} RUN stream does not cover full canvas")

    topo_components = obj['topology']['components']
    tcids = [c['component_id'] for c in topo_components]
    if len(tcids) != len(set(tcids)):
        errors.append('topology component IDs must be unique')
    if tcids != sorted(tcids):
        errors.append('topology.components must be sorted lexically')
    tcset = set(tcids)
    hole_ids = [h['hole_id'] for h in obj['topology']['holes']]
    if len(hole_ids) != len(set(hole_ids)):
        errors.append('hole IDs must be unique')
    if hole_ids != sorted(hole_ids):
        errors.append('topology.holes must be sorted lexically')
    hset = set(hole_ids)
    for c in topo_components:
        for gr in c['geometry_refs']:
            if gr not in geometry_refs:
                errors.append(f"topology component {c['component_id']} has dangling geometry ref {gr}")
        for hid in c.get('hole_ids', []):
            if hid not in hset:
                errors.append(f"topology component {c['component_id']} has missing hole {hid}")
    for hrec in obj['topology']['holes']:
        if hrec['owner_component'] not in tcset:
            errors.append(f"hole {hrec['hole_id']} owner missing")
        if hrec.get('boundary_ref') is not None and hrec['boundary_ref'] not in geometry_refs:
            errors.append(f"hole {hrec['hole_id']} boundary ref missing")
    for edge in obj['topology']['adjacency']:
        if edge['source'] not in tcset or edge['target'] not in tcset:
            errors.append('topology adjacency has missing endpoint')

    parts = obj['parts']['nodes']
    part_ids = [p['part_id'] for p in parts]
    if len(part_ids) != len(set(part_ids)):
        errors.append('part IDs must be unique')
    if part_ids != sorted(part_ids):
        errors.append('part nodes must be sorted lexically')
    pset = set(part_ids)
    for p in parts:
        for gr in p['geometry_refs']:
            if gr not in geometry_refs:
                errors.append(f"part {p['part_id']} has dangling geometry ref {gr}")
    for edge in obj['parts']['edges']:
        if edge['source'] not in pset or edge['target'] not in pset:
            errors.append('part edge has missing endpoint')
    port_ids = [p['port_id'] for p in obj['parts']['ports']]
    if len(port_ids) != len(set(port_ids)):
        errors.append('port IDs must be unique')
    for port in obj['parts']['ports']:
        for s in port['anchor']:
            if not valid_scalar(s):
                errors.append(f"port {port['port_id']} invalid anchor scalar")

    fb = obj['family_binding']
    if fb is not None:
        for _, val in fb['parameters'].items():
            if isinstance(val, str) and re.match(r'^-?[0-9]', val) and not valid_scalar(val):
                errors.append(f'invalid family numeric parameter {val}')
    return errors


def validate_family_semantics(fam: dict) -> list[str]:
    errors = []
    ids = [a['axis_id'] for a in fam['axes']]
    if len(ids) != len(set(ids)):
        errors.append('axis IDs must be unique')
    if ids != sorted(ids):
        errors.append('axes must be sorted lexically by axis_id')
    for a in fam['axes']:
        if a['kind'] == 'continuous':
            if not all(k in a for k in ('min','max')):
                errors.append(f"continuous axis {a['axis_id']} requires min/max")
            else:
                lo, hi, d = map(float, (a['min'], a['max'], a['default']))
                if lo > d or d > hi:
                    errors.append(f"continuous axis {a['axis_id']} default outside range")
        elif a['kind'] in ('discrete','categorical'):
            vals = a.get('values') or []
            if a['default'] not in vals:
                errors.append(f"axis {a['axis_id']} default must be listed in values")
    return errors


def validate_binding_semantics(binding: dict) -> list[str]:
    errors = []
    if binding['kind'] == 'behavior' and 'runtime.execute' not in binding['required_capabilities']:
        errors.append('behavior binding requires runtime.execute capability declaration')
    if binding['authority'] == 'candidate' and binding['provenance']['evidence_class'] == 'declared' and binding['provenance']['actor_class'] == 'system':
        errors.append('system-declared candidate is ill-formed authority combination')
    if binding['kind'] == 'semantic-symbol':
        t = binding['target']
        for key in ('registry','symbol','version'):
            if key not in t:
                errors.append(f'semantic-symbol binding target missing {key}')
    if binding['kind'] == 'unicode-sequence':
        seq = binding['target'].get('codepoints')
        if not isinstance(seq, list) or not seq:
            errors.append('unicode-sequence binding requires non-empty codepoints')
    if binding['kind'] == 'opentype-glyph':
        t = binding['target']
        if 'font_digest' not in t or 'glyph_id' not in t:
            errors.append('opentype-glyph binding requires font_digest and glyph_id')
    return errors


def validate_gsc_bridge(bridge: dict) -> list[str]:
    errors = []
    s = bridge['source_profile']
    if s.get('version') != '0.7' or s.get('mode') != 'strict-source-blind':
        errors.append('bridge must target GSC AssetSymbol v0.7 strict-source-blind profile')
    ev = bridge['evidence']
    if ev.get('source_blind') is not True:
        errors.append('GSC bridge example must preserve source-blind evidence')
    if ev.get('semantic_claim') is not False:
        errors.append('GSC exact carry bridge must not claim semantic authority')
    src = bridge.get('source_artifact') or {}
    src_path = EXAMPLES / src.get('path', '')
    if not src_path.is_file():
        errors.append('GSC bridge source artifact is missing')
    else:
        actual = hashlib.sha256(src_path.read_bytes()).hexdigest()
        if src.get('sha256') != actual:
            errors.append('GSC bridge source artifact sha256 mismatch')
        try:
            asset = load_json(src_path)
            if asset.get('schema') != 'evemisslab.symbolic-image' or asset.get('version') != '0.7':
                errors.append('GSC source artifact is not AssetSymbol v0.7')
            forbidden = {'sourceData','sourceImage','sourcePixels','pixelBuffer','dataUrl','sourceDataUrl'}
            def walk(v):
                if isinstance(v, dict):
                    for k, child in v.items():
                        if k in forbidden:
                            errors.append(f'GSC source artifact contains forbidden source field {k}')
                        walk(child)
                elif isinstance(v, list):
                    for child in v: walk(child)
            walk(asset)
            carry = bridge['mapped']['exact_carry']
            mapped_runs = [
                {
                    'op': t['op'], 'y': t['y'], 'x': t['x'],
                    'length': t['length'], 'palette_index': t['paletteIndex']
                } for t in asset.get('tokens', [])
            ]
            if bridge.get('bridge_fidelity') == 'carry-lossless':
                if carry.get('palette') != asset.get('palette') or carry.get('runs') != mapped_runs:
                    errors.append('GSC carry-lossless bridge does not exactly preserve palette/tokens')
        except Exception as exc:
            errors.append(f'GSC source artifact parse failed: {exc}')
    carry = bridge['mapped']['exact_carry']
    if carry['kind'] != 'palette-runs-v1':
        errors.append('GSC bridge must map exact carry to palette-runs-v1')
    return errors


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--json', action='store_true')
    args = parser.parse_args()

    glyph = load_json(EXAMPLES / 'custom_derivative_glyph_example.json')
    family = load_json(EXAMPLES / 'glyph_family_example.json')
    bindings = load_json(EXAMPLES / 'glyph_binding_example.json')
    bridge = load_json(EXAMPLES / 'gsc_asset_symbol_v07_bridge_example.json')
    vectors = load_json(CONFORMANCE / 'glyph_conformance_vectors.json')

    checks = {
        'glyph_schema_errors': schema_validate(glyph, SCHEMAS / 'glyph-object-v1-candidate.schema.json'),
        'glyph_semantic_errors': validate_glyph_semantics(glyph),
        'family_schema_errors': schema_validate(family, SCHEMAS / 'glyph-family-v1-candidate.schema.json'),
        'family_semantic_errors': validate_family_semantics(family),
        'binding_schema_errors': [],
        'binding_semantic_errors': [],
        'bridge_schema_errors': schema_validate(bridge, SCHEMAS / 'gsc-assetsymbol-bridge.schema.json'),
        'bridge_semantic_errors': validate_gsc_bridge(bridge),
        'renderer_schema_errors': schema_validate(load_json(EXAMPLES / 'renderer_profile_example.json'), SCHEMAS / 'glyph-renderer-profile.schema.json'),
        'vector_schema_errors': schema_validate(vectors, SCHEMAS / 'glyph-conformance-vectors.schema.json'),
    }
    for b in bindings:
        checks['binding_schema_errors'].extend(schema_validate(b, SCHEMAS / 'glyph-binding-evidence.schema.json'))
        checks['binding_semantic_errors'].extend(validate_binding_semantics(b))
    ids = [v['id'] for v in vectors['vectors']]
    checks['vector_count'] = len(ids)
    checks['unique_vector_ids'] = len(set(ids))
    checks['ok'] = (
        not checks['glyph_schema_errors'] and not checks['glyph_semantic_errors']
        and not checks['family_schema_errors'] and not checks['family_semantic_errors']
        and not checks['binding_schema_errors'] and not checks['binding_semantic_errors']
        and not checks['bridge_schema_errors'] and not checks['bridge_semantic_errors']
        and not checks['renderer_schema_errors'] and not checks['vector_schema_errors']
        and checks['vector_count'] == 30 and checks['unique_vector_ids'] == 30
    )
    print(json.dumps(checks, ensure_ascii=False, indent=2) if args.json else '\n'.join(f'{k}: {v}' for k,v in checks.items()))
    return 0 if checks['ok'] else 1


if __name__ == '__main__':
    raise SystemExit(main())

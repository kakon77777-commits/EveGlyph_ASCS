import copy
import importlib.util
import pathlib
import unittest

HERE = pathlib.Path(__file__).resolve().parent
MODULE_PATH = HERE / 'validate_v06.py'

spec = importlib.util.spec_from_file_location('validate_v06', MODULE_PATH)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

class ValidateV06Tests(unittest.TestCase):
    def test_valid_custom_glyph_has_no_semantic_errors(self):
        obj = mod.load_json(mod.EXAMPLES / 'custom_derivative_glyph_example.json')
        self.assertEqual(mod.validate_glyph_semantics(obj), [])

    def test_component_cycle_and_behavior_without_capability_are_rejected(self):
        obj = mod.load_json(mod.EXAMPLES / 'custom_derivative_glyph_example.json')
        obj = copy.deepcopy(obj)
        obj['geometry']['components'] = [
            {
                'component_id': 'self',
                'glyph_ref': {'persistent_id': 'self', 'revision_id': 'self'},
                'transform': ['1','0','0','1','0','0']
            }
        ]
        cycle_errors = mod.validate_component_graph(obj, current_ref=('self','self'))
        self.assertTrue(any('cycle' in e.lower() for e in cycle_errors))

        binding = mod.load_json(mod.EXAMPLES / 'glyph_binding_example.json')[-1]
        binding = copy.deepcopy(binding)
        binding['required_capabilities'] = []
        bind_errors = mod.validate_binding_semantics(binding)
        self.assertTrue(any('runtime.execute' in e for e in bind_errors))

    def test_gsc_bridge_rejects_tampered_source_artifact_hash(self):
        bridge = mod.load_json(mod.EXAMPLES / 'gsc_asset_symbol_v07_bridge_example.json')
        bridge = copy.deepcopy(bridge)
        bridge['source_artifact']['sha256'] = '0' * 64
        errors = mod.validate_gsc_bridge(bridge)
        self.assertTrue(any('sha256' in e.lower() for e in errors))

    def test_gsc_bridge_rejects_tampered_exact_carry_mapping(self):
        bridge = mod.load_json(mod.EXAMPLES / 'gsc_asset_symbol_v07_bridge_example.json')
        bridge = copy.deepcopy(bridge)
        bridge['mapped']['exact_carry']['runs'][0]['length'] += 1
        errors = mod.validate_gsc_bridge(bridge)
        self.assertTrue(any('carry-lossless' in e.lower() for e in errors))

if __name__ == '__main__':
    unittest.main()

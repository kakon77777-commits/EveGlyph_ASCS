# v0.6 Compatibility

## Compatibility class

`v0.5 -> v0.6 = Backward + ForwardPreserve` for workspaces not requiring the new glyph candidate profiles.

## No silent reinterpretation

- `glyph/0.1` retains its original semantics.
- `ncm/1.0-candidate.1` is unchanged.
- `egir-cj/0.1` and existing hash preimages are unchanged.
- Existing persistent IDs, revision IDs and content hashes are unchanged.
- New glyph candidate profiles are namespaced additions.

## Mixed-profile workspace

A workspace MAY contain `glyph/0.1` and `glyph/1.0-candidate.1` simultaneously. Runtime MUST profile-dispatch.

## Optional enrichment migration

Migration from `glyph/0.1` MUST create a new revision on the same persistent lineage and preserve migration provenance.

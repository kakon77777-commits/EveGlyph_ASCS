# v0.6 Version

`ascs/0.6`

New candidate profiles: `glyph/1.0-candidate.1`, `glyph-family/1.0-candidate.1`, `glyph-binding/1.0-candidate.1`, `gsc-assetsymbol-bridge/1.0-candidate.1`.

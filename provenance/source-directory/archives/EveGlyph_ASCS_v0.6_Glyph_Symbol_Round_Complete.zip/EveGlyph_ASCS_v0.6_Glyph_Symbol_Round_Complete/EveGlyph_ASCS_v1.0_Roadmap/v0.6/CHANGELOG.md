# v0.6 Changelog

- Added Glyph / Symbol Object v1 candidate profile.
- Added geometry, topology, part, port, family/variant and renderer boundaries.
- Added explicit semantic/behavior binding authority contract.
- Added Unicode/OpenType adapter boundary.
- Added GSC AssetSymbol v0.7 compatibility bridge.
- Added schemas, examples, 30 conformance vectors and reference validator.

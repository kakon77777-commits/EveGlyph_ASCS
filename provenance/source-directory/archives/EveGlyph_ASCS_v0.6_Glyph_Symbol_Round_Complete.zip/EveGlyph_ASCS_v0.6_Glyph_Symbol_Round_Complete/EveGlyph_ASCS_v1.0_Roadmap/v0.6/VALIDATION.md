# v0.6 Validation

**Release:** EveGlyph ASCS v0.6 — Glyph / Symbol Object v1 Candidate  
**Date:** 2026-08-25

## 1. Candidate profile validation

Reference command:

```bash
python V0.6_Support/tools/validate_v06.py --json
```

Fresh result:

```text
glyph_schema_errors: 0
glyph_semantic_errors: 0
family_schema_errors: 0
family_semantic_errors: 0
binding_schema_errors: 0
binding_semantic_errors: 0
bridge_schema_errors: 0
bridge_semantic_errors: 0
renderer_schema_errors: 0
vector_schema_errors: 0
vector_count: 30
unique_vector_ids: 30
ok: true
```

The validator checks more than JSON structure. It also checks canonical decimal grammar, path command sequencing, dangling geometry/topology/part references, exact RUN coverage, family-axis constraints, behavior capability declarations, source-artifact SHA-256, and the GSC source-blind semantic-claim boundary.

## 2. Validator TDD regression tests

```bash
python V0.6_Support/tools/test_validate_v06.py
```

Fresh result:

```text
Ran 4 tests
OK
```

The negative tests verify that a self-referential component cycle and an executable behavior binding without `runtime.execute` are rejected, that a tampered GSC bridge artifact hash is detected, and that a modified palette/RUN mapping cannot still claim `carry-lossless`.

## 3. JSON Schema 2020-12 meta-validation

Six v0.6 schemas were validated with `Draft202012Validator.check_schema()`:

- glyph object candidate;
- glyph family candidate;
- glyph binding evidence;
- glyph conformance vectors;
- glyph renderer profile;
- GSC AssetSymbol bridge.

Result: **6/6 PASS**.

All v0.6 JSON examples/conformance files parsed successfully: **13/13 PASS**.

## 4. GSC upstream compatibility evidence

The supplied GSC v1.13.0-strict-symbolic source package was freshly re-run with:

```bash
node --test tests/core.test.js tests/strict-symbolic.test.js
node --check src/core.js
node --check strict-symbolic-app.js
node --check app.js
```

Fresh result:

```text
105 tests
105 pass
0 fail
JavaScript syntax checks: PASS
```

A small `AssetSymbol v0.7` sample in this release was generated directly by the GSC v1.13 `compileStrictSymbolicAsset()` implementation, not handwritten. Its source artifact SHA-256 is pinned by the v0.6 bridge example.

This evidence establishes the engineering compatibility baseline only. It does **not** establish general visual semantic understanding.

## 5. Canonical source validation

The release specification plus Roadmap v0.5 were freshly checked for:

- UTF-8 strict decode;
- LF-only line endings;
- forbidden control characters;
- only `$...$` and `$$...$$` canonical math delimiters outside fenced code;
- balanced math delimiters;
- Python source syntax.

Fresh result: **PASS**.

Specification size:

```text
24,826 UTF-8 bytes
1,116 lines
```

## 6. Compatibility gate

No existing canonical profile was silently reinterpreted:

```text
egir/0.1               unchanged
egstore/0.1             unchanged
egcr/0.1                unchanged
ncm/0.1                 unchanged
ncm/1.0-candidate.1     unchanged
glyph/0.1               unchanged
egir-cj/0.1             unchanged
history/*                unchanged
spatial-region/*         unchanged
```

Therefore:

$$
\boxed{
v0.5\rightarrow v0.6
\text{ requires no mandatory canonical migration}
}
$$

The new glyph/family/renderer/binding/GSC bridge profiles are additive and version-qualified.

## 7. Release integrity

`SHA256SUMS.txt` is generated after the release tree is finalized. The outer ZIP is then integrity-tested with Python `zipfile.testzip()` and separately SHA-256 hashed.

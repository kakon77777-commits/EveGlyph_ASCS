# Version

```text
ASCS = ascs/0.4
SpatialRegion = org.evemisslab.spatial-region/0.1
SpatialGrammar = org.evemisslab.spatial-grammar/0.1
SpatialPolicy = org.evemisslab.spatial-policy/0.1
SemanticZoom = org.evemisslab.semantic-zoom/0.1
```

Existing EGIR/EGStore/EGCR/NCM/Glyph/History identifiers remain unchanged.

# v0.4 Changelog

- Added nested region / canonical parent hierarchy contract.
- Froze local-to-parent affine transform convention and composition order.
- Added KeepWorld / KeepLocal reparent semantics.
- Added deterministic region policy inheritance classes.
- Added local grammar resolution and cross-region parsing boundary.
- Froze semantic zoom as projection-only by default.
- Added cross-region execution port/export boundary.
- Added spatial address stability and v0.3 merge/conflict integration.
- Added 18 machine-readable conformance vectors and Draft 2020-12 schemas.
- No change to `egir-cj/0.1`; no mandatory v0.3 canonical migration.

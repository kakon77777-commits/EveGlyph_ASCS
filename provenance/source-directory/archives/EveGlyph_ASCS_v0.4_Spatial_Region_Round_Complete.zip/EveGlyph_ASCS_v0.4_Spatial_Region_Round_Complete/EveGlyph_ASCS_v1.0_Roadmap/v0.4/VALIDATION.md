# v0.4 Validation Report

**Release:** EveGlyph ASCS v0.4 Spatial Region, Nested Canvas & Local Grammar Freeze  
**Date:** 2026-08-24

## Source validation

- UTF-8 strict decode: PASS
- LF-only newlines: PASS
- Forbidden control-character scan: PASS
- Canonical math delimiters restricted to `$...$` / `$$...$$`: PASS
- Math delimiter balance outside fenced code: PASS

## Machine-readable validation

- `spatial-region-profile.schema.json`: Draft 2020-12 parse/validator PASS
- `spatial_region_example.json`: 0 schema errors
- `spatial-conformance-vectors.schema.json`: Draft 2020-12 validator PASS
- `spatial_conformance_vectors.json`: 0 schema errors
- Conformance vector count: 18
- Unique vector IDs: 18/18

## Main specification size

- UTF-8 bytes: 31,190
- Lines: 1,427
- Characters: 25,890

## Compatibility gate

PASS:

- `egir/0.1` unchanged
- `egstore/0.1` unchanged
- `egcr/0.1` unchanged
- `ncm/0.1` unchanged
- `glyph/0.1` unchanged
- `org.evemisslab.history/0.1` unchanged
- `egir-cj/0.1` unchanged
- Existing content/revision/workspace hash preimage unchanged
- Existing flat Canvas remains valid as root-world spatial model
- No mandatory canonical migration from v0.3 to v0.4

## External standards cross-check

Current W3C references were checked on 2026-08-24:

- SVG 2 current editor's draft, Chapter 8, explicitly models nested viewports, user coordinate systems, transforms, and cumulative coordinate-space composition. EveGlyph uses this as an interoperability reference, not as its canonical ontology.
- CSS Transforms Module Level 1 latest published W3C Candidate Recommendation remains dated 2019-02-14; EveGlyph does not copy its DOM/CSS authority model, only recognizes it as a rendering adapter reference.

## Design checks

PASS:

- Region parentage is single-parent + acyclic.
- Cross-region semantic graph relations remain first-class relations, not multiple spatial parents.
- Transform convention is explicitly column-vector / local-to-parent.
- KeepWorld and KeepLocal reparent are distinct.
- Non-invertible KeepWorld is a typed failure.
- Geometry containment does not automatically establish membership/scope.
- Policy inheritance uses deterministic named modes.
- Ancestor deny cannot be widened by child capability policy.
- Local grammar and semantic zoom authority boundaries are explicit.
- Derived spatial relation does not cross region by default.
- Cross-region execution requires explicit boundary/port contract.
- v0.3 merge/conflict semantics are extended without rewriting v0.3 history semantics.

## Release conclusion

v0.4 is suitable as the third and final freeze of the first v1.0 roadmap stage:

$$
\text{v0.2--v0.4}=\text{Contract + Editing + Space}.
$$

Next: v0.5 Native Math Object v1 Candidate.

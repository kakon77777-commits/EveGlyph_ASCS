# v0.4 Compatibility

## Compatibility class

`v0.3 -> v0.4 = Backward + ForwardPreserve for existing root-world workspaces`

Existing flat Canvas data remains valid under the implicit defaults: root world parent, no local region grammar override, workspace policy inheritance, identity semantic zoom projection.

## No silent reinterpretation

- Existing object IDs unchanged.
- Existing revision/content hashes unchanged.
- Existing placements retain their prior world-frame meaning.
- Existing explicit relations retain authority.
- New spatial profiles are namespaced extensions.
- No change to `egir-cj/0.1`.

## Optional enrichment

A writer MAY materialize explicit region profile records for a legacy flat workspace, but this is optional enrichment and must be recorded as a transformation, not required data migration.

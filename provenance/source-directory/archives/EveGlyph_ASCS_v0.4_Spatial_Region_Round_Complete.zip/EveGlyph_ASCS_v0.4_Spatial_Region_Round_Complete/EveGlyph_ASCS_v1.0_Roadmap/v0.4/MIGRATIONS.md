# v0.4 Migrations

## Mandatory migration

None.

$$
\boxed{v0.3\rightarrow v0.4\text{ requires no mandatory canonical migration}}
$$

## Optional enrichment migration

Legacy flat Canvas may be enriched by introducing an explicit root region and copying existing world placements into root-local placements. Such enrichment MUST preserve persistent IDs, object revisions, explicit relations, and world geometry.

## Future breaking spatial change

Any future change to matrix convention, parentage cardinality, transform composition order, policy inheritance meaning, or semantic-zoom authority MUST use a new version identifier and explicit migration.

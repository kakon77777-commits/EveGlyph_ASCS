# VALIDATION

## Canonical source files

- Paper 00: `00_從線性文件到可定址符號計算空間_統合論文_v0.1.md`
- Paper 01: `01_可定址符號物件模型_身份內容語義關係版本與相等性_v0.1.md`
- Paper 02: `02_空間語法與無限畫布計算_從幾何配置到可驗證執行結構_v0.1.md`
- Paper 03: `03_原生可計算數學_超越LaTeX字串的語義物件執行與投影模型_v0.1.md`
- Paper 04: `04_生成式字形與符號編譯_從像素來源到可定址幾何拓撲部件語法與語義符號_v0.1.md`
- Paper 05: `05_多層定址的可計算文件_身份內容語義空間物理版本解析與跨工作區參照_v0.1.md`

## Source encoding

All six formal papers:

- UTF-8 decode: PASS
- UTF-8 re-encode identity: PASS
- LF source output: PASS
- disallowed control-character scan: PASS

## Canonical math delimiter policy

All six formal paper sources:

- use `$...$` and `$$...$$` as the canonical Markdown math delimiters;
- contain no `\\(`, `\\)`, `\\[`, or `\\]` math delimiters;
- pass delimiter-balance validation outside fenced code blocks and inline code spans.

## Paper 00 referenced implementation verification

- GSC v1.13 strict symbolic: 105/105 Node tests PASS; JS syntax checks PASS.
- PSSA-BSAR v0.1 Milestone 4 source: 73/73 pytest tests PASS.

These test results validate the supplied code baselines and protocol plumbing. They do not independently validate all scientific hypotheses in Paper 00.

## Paper 01 literature / standards verification

Checked against public sources during drafting:

- RFC 6920 — hash-based names for digital objects;
- W3C PROV-O Recommendation — interoperable provenance representation;
- Software Hash IDentifier (SWHID) — intrinsic identifiers / Merkle object structure;
- Open Provenance Model and FAIR literature used only as supporting prior work.

## Paper 01 formal consistency checks

- persistent identity and content identity are explicitly non-equated;
- object revision history and workspace history are explicitly separated;
- intrinsic geometry and extrinsic placement are explicitly separated;
- explicit and derived relations are authority-distinct;
- revision model permits DAG branch/merge;
- 12 design-freeze invariants and 12 conformance vectors are included;
- no concrete JSON/wire schema is prematurely frozen; that boundary is deferred to TW-01.

## Paper 02 literature verification

Checked against public literature during drafting:

- Marshall & Shipman — implicit structure in spatial hypertext;
- VIKI — spatial hypertext supporting emergent structure;
- Shipman, Marshall & Moran — recognition/use of human-organized spatial layouts;
- Golin & Reiss — picture layout grammar for two-dimensional visual-language syntax;
- Golin — parsing visual languages with picture layout grammars.

The paper uses these works as prior evidence that spatial arrangement can carry implicit or formally parseable structure; it does not treat prior spatial-layout recognition as automatic semantic authority.

## Paper 02 formal consistency checks

- “infinite canvas” is operationally defined as logically unbounded and finitely materialized;
- world/region/local/view coordinate frames are explicitly separated;
- intrinsic geometry and extrinsic placement remain distinct;
- transient spatial state, derived candidates, and explicit committed relations are authority-distinct;
- ambiguous spatial parses are allowed to remain unresolved;
- local region grammars allow freeform and formal areas to coexist;
- layout graph and execution graph are explicitly non-equated;
- executable spatial compilation requires parse → validate → commit → compile boundaries;
- threshold relations include a stability requirement such as hysteresis/transaction boundaries;
- spatial indexes are defined only as acceleration structures;
- 18 design-freeze decisions and 15 conformance tests are included;
- concrete renderer/index/database choices remain deferred to TW-03.

## Paper 03 standards / literature verification

Checked against current public sources on 2026-08-24:

- W3C MathML Core — Candidate Recommendation Snapshot, 24 June 2025;
- W3C MathML 4.0 — Working Draft, 04 June 2026;
- OpenMath Standard — Version 2.0 Revision 2 remains the normative OpenMath standard;
- OMDoc — semantic mathematical documents / theories / proofs as prior art;
- historical CAS / semantic-math literature used only as background support.

These sources support the paper's claim that mathematical presentation and mathematical content are already distinct concerns in established standards. Paper 03 does not claim to invent semantic mathematics; its contribution is the integration with ASOM identity/versioning, spatial syntax, native execution, provenance, ambiguity, and workspace-level addressing.

## Paper 03 formal consistency checks

- mathematical object and notation/serialization are explicitly non-equated;
- LaTeX is retained as an adapter/projection and not declared obsolete;
- expression graph, binding, type/domain, assumptions, constraints, units, numeric exactness, presentation, execution, and provenance are explicitly separated;
- free/bound variable identity and alpha-equivalence are formalized;
- exact versus approximate numerical semantics are separated;
- assumptions and side conditions are required to survive transformations;
- undefined, conditional, unresolved, and unevaluated states remain distinct;
- canonicalization and theorem/simplification rewrites are explicitly non-equated;
- multiple equality classes are defined and non-interchangeable;
- spatial math notation is treated as an editing/parse surface rather than final ontology;
- evaluation returns result + derived state + provenance + conditions/status;
- computation evidence and proof evidence remain distinguishable;
- 20 design-freeze invariants and 18 conformance tests are included;
- the MVP requires direct computation on NCM objects without a canonical LaTeX reparse path.

## Paper 04 engineering / literature verification

Fresh GSC v1.13 verification during Paper 04 drafting:

- `node --test tests/core.test.js tests/strict-symbolic.test.js`: 105/105 tests PASS;
- `node --check src/core.js`: PASS;
- `node --check strict-symbolic-app.js`: PASS;
- `node --check app.js`: PASS.

The GSC baseline explicitly keeps `AssetSymbol v0.7` as the canonical strict-symbolic representation; the exact strict renderer is source-blind, the enhanced renderer remains source-blind, native import packages are consumer-layer artifacts, and Gate 11 project-binding plans remain non-mutating previews.

Supporting public literature checked during drafting includes shape-feature surveys, skeletonization/thinning literature, visual-language grammars, and visual-symbol/lexicon research. These sources are used only to support the existence of established geometry/topology/grammar techniques; Paper 04 does not claim that skeletonization, shape grammar, or visual recognition alone establishes semantic identity.

## Paper 04 formal consistency checks

- source artifact, normalized target, symbolic carry, structural lift, part grammar, and semantic symbol are explicitly separated;
- exact visual reconstruction and semantic understanding are explicitly non-equated;
- source and compiled glyph use separate persistent identities with derivation provenance by default;
- intrinsic geometry, topology, part graph, semantic binding, renderer profile, and behavior binding remain separable;
- character, glyph, and semantic symbol identities are distinguished;
- Unicode assignment is optional rather than a prerequisite for glyph existence;
- AI/recognizer semantic labels remain candidates until promotion/commit;
- visual import and executable behavior permission are separated;
- pixel, geometric, topological, part-structural, and semantic equality remain distinct;
- composite glyphs may preserve referenced child structure instead of being permanently raster-flattened;
- compiler/normalizer/profile provenance is versioned;
- 20 design-freeze invariants and 18 conformance tests are included;
- the MVP requires at least one custom glyph to participate in native semantic computation through an explicit binding.


## Paper 05 standards / literature verification

Checked against current public standards and official documentation during drafting on 2026-08-24:

- RFC 3986 — URI generic syntax and separation of identification from interaction;
- RFC 8141 — URNs as persistent, location-independent resource identifiers;
- RFC 6920 — hash-derived names for digital objects;
- ISO/IEC 18670:2025 — SWHID V1.2, intrinsic content-derived identifiers built over Merkle DAGs, with resolution explicitly outside the standard scope;
- DOI Foundation DOI Handbook — persistent identifier, metadata, and Handle-based resolution separation;
- W3C DID Core v1.0 Recommendation and DID v1.1 Candidate Recommendation Snapshot (05 March 2026) — identifier, subject/controller, document, service, and resolution separation.

These standards are used as architectural precedents. Paper 05 does not claim that ASCS must adopt URI, URN, SWHID, DOI, or DID as its universal native identifier scheme.

## Paper 05 formal consistency checks

- persistent/content/semantic/spatial/physical/version addresses are explicitly typed and non-interchangeable;
- resolver semantics are explicitly separated from dereference/retrieval;
- semantic resolution permits zero/one/many results and does not imply persistent identity;
- immutable revision addresses are separated from mutable aliases such as `latest`;
- aliases, locators, references, and persistent identities are distinguished;
- spatial addresses are workspace/snapshot/frame aware;
- physical addresses may migrate or replicate without identity mutation;
- subobject addresses are revision-aware unless child persistent identities are used;
- cross-workspace link/import/federation are distinct operations;
- tombstone, unavailable, unauthorized, invalid, stale, and unresolved states remain distinguishable;
- resolution success does not grant read/write/execute capability;
- AI identity reconciliation is candidate-level until authoritative commit;
- 24 design-freeze invariants and 20 conformance tests are included;
- MVP requirements explicitly demonstrate both identity continuity across edits/moves/storage migration and distinct identities sharing content/semantics.

## Core theory-set status

Paper 00–05 are complete for the ASCS v0.1 theory freeze. The next phase is technical specification/whitepaper work (TW-01, TW-02, TW-03), followed by MVP-01.

## TW-01 standards verification

Checked against current official/public specifications during drafting on 2026-08-24:

- RFC 8785 — JSON Canonicalization Scheme (JCS), used as the deterministic JSON canonicalization precedent;
- RFC 8949 — CBOR Internet Standard, reserved as a future compact/binary carrier rather than the v0.1 identity ontology;
- RFC 9562 — current UUID specification, used for the recommendation that newly created persistent identities use UUIDv7 URNs;
- JSON Schema Draft 2020-12 — current JSON Schema specification/dialect, used for structural validation.

TW-01 deliberately does not apply JCS directly to arbitrary-precision mathematical numbers. Exact/big numerics are lowered to typed string/object representations first, because JCS operates over the I-JSON / IEEE-754-compatible number domain.

## TW-01 machine-readable artifact verification

Included support artifacts:

- `TW-01_Support/schemas/eveglyph-ir.schema.json`;
- `TW-01_Support/examples/minimal_workspace.egir.json`;
- `TW-01_Support/conformance/tw01_vectors.json`;
- `TW-01_Support/tools/validate_tw01.py`.

Fresh reference validation result:

- JSON Schema Draft 2020-12 meta-schema check: PASS;
- minimal workspace schema validation: PASS;
- cross-record object/head/parent/placement references: PASS;
- content-address recomputation: PASS;
- revision-ID recomputation: PASS;
- workspace-revision recomputation: PASS;
- EGIR-CJ/0.1 canonicalization vector: PASS;
- executable edit/move/clone semantic vectors: PASS.

## TW-01 formal consistency checks

- persistent ID, content address, revision address, workspace revision and physical/spatial locators remain distinct;
- relation records are versioned persistent objects;
- candidate records are separated from committed relation heads;
- placement state is outside object intrinsic content;
- Native Math and Glyph profiles are included as built-in specialization contracts;
- exact/big numeric values do not depend on implementation-specific floating-point JSON serialization;
- canonicalization preserves Unicode scalar sequences and does not perform theorem simplification;
- import/export fidelity and execution-permission boundaries are explicit;
- the whitepaper includes 30 design-freeze decisions and a concrete MVP vertical-slice requirement.

## Technical-whitepaper phase status

- TW-01: COMPLETE.
- TW-02: next.
- TW-03: pending after TW-02.
- MVP-01: pending after TW-03.

